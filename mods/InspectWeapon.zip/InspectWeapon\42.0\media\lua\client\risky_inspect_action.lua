-- @author Risky
-- Custom timed actions

require "TimedActions/ISBaseTimedAction"

riskyInspectAction = ISBaseTimedAction:derive("riskyInspectAction");

function riskyInspectAction:isValid()
    return true
end

function riskyInspectAction:update()
end

function riskyInspectAction:start()
end

function riskyInspectAction:stop()
    ISBaseTimedAction.stop(self);
end

function riskyInspectAction:perform()
    -- Init main window
    if riskyInspectWindow[self.character:getPlayerNum()] == nil or not riskyInspectWindow[self.character:getPlayerNum()]:getIsVisible() then
        riskyInspectWindow[self.character:getPlayerNum()] = riskyUI:new(self.character:getModData().inspectWindowPos[1], self.character:getModData().inspectWindowPos[2], 0, 0, self.character)
        riskyInspectWindow[self.character:getPlayerNum()]:setTitle(getText('IGUI_RISKY_INSPECT_WEAPON'))
        riskyInspectWindow[self.character:getPlayerNum()]:addToUIManager()
        riskyInspectWindow[self.character:getPlayerNum()].resizable = false
        riskyInspectWindow[self.character:getPlayerNum()].collapsable = false

        riskyInspectWindow[self.character:getPlayerNum()]:renderInventory()
    end

    -- needed to remove from queue / start next.
    ISBaseTimedAction.perform(self);
end

function riskyInspectAction:new(character, time)
    local o = {}
    setmetatable(o, self)
    self.__index = self
    o.character = character;
    o.stopOnWalk = true;
    o.stopOnRun = true;
    o.maxTime = time;
    return o;
end
