require "TimedActions/SRRTimed"

if not SimpleRussianRoulette then
    SimpleRussianRoulette = {}
end

local function createToolTip(title, description) --tooltip
    local toolTip = ISToolTip:new()
    toolTip:initialise()
    toolTip:setName(title)
    toolTip.description = description
    return toolTip
end

local function createAndSetDisabledToolTipForOption(title, description, option) --tooltip
    local tooltip = createToolTip(title, description)
    option.toolTip = tooltip
    option.notAvailable = true
end

local function isRevolver(item) --check weapon reload type for revolver
if not item then return false end
    local ok, reloadType = pcall(function()
        return item:getWeaponReloadType()
    end)

    if not ok or reloadType == nil then
        return false
    end

    local reloadTypeStr = tostring(reloadType)
    return reloadTypeStr == "revolver"
end

local function performSRRAnim(playerObj, item)
    ISTimedActionQueue.add(SRRTimedAction:new(playerObj, item, "SimpleRussianRoulette"))
end

-- animation triggering
local function performRussianRoulette(player, weapon)
    performSRRAnim(player, weapon)
end

-- context menus
local function addSRRtoInv(player, context, items) --inventory menu
    local playerObj = getSpecificPlayer(player)
    local invItems = ISInventoryPane.getActualItems(items)
    local addedItems = {}
    for _, item in ipairs(invItems) do
        if instanceof(item, "HandWeapon") and item:isAimedFirearm() and isRevolver(item) then
            local itemType = item:getFullType() .. "_" .. item:getName()

            if not addedItems[itemType] then
                addedItems[itemType] = true

                local option = context:addOption("Play Russian Roulette", playerObj, performRussianRoulette, item)

                if not playerObj:isPrimaryHandItem(item) and not item:isRequiresEquippedBothHands() then
                    createAndSetDisabledToolTipForOption("Equip Revolver","You need a revolver equipped in your primary hand.",option)
                elseif item:getCurrentAmmoCount() <= 0 then
                    createAndSetDisabledToolTipForOption("Need Ammo","You need at least one round to play.",option)
                elseif item:getCurrentAmmoCount() == item:getMaxAmmo() then
                    createAndSetDisabledToolTipForOption("Fully Loaded","Remove at least one bullet. You cannot win.",option)
                end
            end
        end
    end
end

local function addSRRtoWorld(player, context, worldobjects, test) -- world menu
    local playerObj = getSpecificPlayer(player)
    local weapon = playerObj:getPrimaryHandItem()

    if instanceof(weapon, "HandWeapon") and isRevolver(weapon) then
        local option = context:addOption("Play Russian Roulette", playerObj, performRussianRoulette, weapon)

        if weapon:getCurrentAmmoCount() <= 0 then
            createAndSetDisabledToolTipForOption(
                "Need Ammo","You need at least one round to play.",option)
        elseif weapon:getCurrentAmmoCount() == weapon:getMaxAmmo() then
            createAndSetDisabledToolTipForOption(
                "Fully Loaded","Remove at least one bullet. You cannot win.",option)
        end
    end
end

Events.OnFillInventoryObjectContextMenu.Add(addSRRtoInv)
Events.OnFillWorldObjectContextMenu.Add(addSRRtoWorld)