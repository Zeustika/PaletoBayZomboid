local function onSRRCommand(module, command, player, args)
    if module ~= "SimpleRussianRoulette" then
        return
    end

    if command == "requestFXSync" then
        sendServerCommand(module, "receiveFXSync", {playerOnlineId = player:getOnlineID()})
    end

    if command == "youWin" then
        local stats = player:getStats()
        local weapon = player:getPrimaryHandItem()

        if SandboxVars.SimpleRussianRoulette.ReceiveXP == true then
            player:getXp():AddXP(Perks.Aiming, 30 * weapon:getCurrentAmmoCount(), false, true, true);
            player:getXp():AddXP(Perks.Reloading, 30 * weapon:getCurrentAmmoCount(), false, true, true);
        end 
        
        stats:set(CharacterStat.UNHAPPINESS, 0)

        if player:hasTrait(CharacterTrait.DESENSITIZED) or player:hasTrait(CharacterTrait.BRAVE) or player:hasTrait(CharacterTrait.ADRENALINE_JUNKIE) then
            stats:set(CharacterStat.PANIC, stats:get(CharacterStat.PANIC) + 15)
            stats:set(CharacterStat.STRESS, stats:get(CharacterStat.STRESS) + .15)
            if player:hasTrait(CharacterTrait.ADRENALINE_JUNKIE) then
                stats:set(CharacterStat.PANIC, stats:get(CharacterStat.PANIC) + 85)
            end
        else
            stats:set(CharacterStat.PANIC, stats:get(CharacterStat.PANIC) + 50)
            stats:set(CharacterStat.STRESS, stats:get(CharacterStat.STRESS) + .50)
        end

        sendServerCommand(module, "receiveWin", {playerOnlineId = player:getOnlineID()})
    end

    if command == "youLose" then
        local weapon = player:getPrimaryHandItem()
        weapon:setCurrentAmmoCount(weapon:getCurrentAmmoCount() - 1)
        weapon:setSpentRoundCount(weapon:getSpentRoundCount() + 1)
        
        sendServerCommand(module, "receiveLoss", {playerOnlineId = player:getOnlineID()})
    end

    if command == "youDie" then
        local body = player:getBodyDamage()
        local stats = player:getStats()
        local head = body:getBodyPart(BodyPartType.Head)

        head:setHaveBullet(true, 0)
        head:SetHealth(0)

        if SandboxVars.SimpleRussianRoulette.ForceZombie == true then
            body:setInfected(true)
            body:setInfectionMortalityDuration(-1)
            stats:set(CharacterStat.ZOMBIE_INFECTION, 100)
            stats:set(CharacterStat.ZOMBIE_FEVER, 100)
        else
            body:setInfected(false)
            body:setInfectionMortalityDuration(0)
            stats:set(CharacterStat.ZOMBIE_INFECTION, 0)
            stats:set(CharacterStat.ZOMBIE_FEVER, 0)
        end
        
        player:Kill(player)

        sendServerCommand(module, "receiveDeath", {playerOnlineId = player:getOnlineID()})
    end
end

Events.OnClientCommand.Add(onSRRCommand)