require "TimedActions/ISBaseTimedAction"

SRRTimedAction = ISBaseTimedAction:derive("SRRTimedAction")

-- full RR functionality
local function syncCharacterFX(character) --blood fx    
    character:splatBloodFloorBig()
end

local function triggerMuzzleFlash(player)
    local square = player:getSquare()
    local x = square:getX()
    local y = square:getY()
    local z = square:getZ()

    local flash = IsoLightSource.new(x, y, z, 1.0, 0.9, 0.7, 4, 5)
    getCell():addLamppost(flash)
end

local function youDie(player) -- DIEEEEE
    local body = player:getBodyDamage()
    local stats = player:getStats()
    local head = body:getBodyPart(BodyPartType.Head)

    head:setHaveBullet(true, 0)
    head:SetHealth(0)

    if SandboxVars.SimpleRussianRoulette.ForceZombie == true then
        body:setInfected(true)
        body:setInfectionMortalityDuration(-1)
        body:setInfectionTime(-1)
        stats:set(CharacterStat.ZOMBIE_INFECTION, 100)
        stats:set(CharacterStat.ZOMBIE_FEVER, 100)
    else
        body:setInfected(false)
        body:setInfectionMortalityDuration(0)
        body:setInfectionTime(0)
        stats:set(CharacterStat.ZOMBIE_INFECTION, 0)
        stats:set(CharacterStat.ZOMBIE_FEVER, 0)
    end
        
    player:Kill(player)
end

local function performKill(player) -- make sure you DIEEE
    if isClient() then
        sendClientCommand("SimpleRussianRoulette", "youDie", {})
    else
        youDie(player)
    end
end

local function playJam(player) -- you won!!!
    player:getEmitter():playSound("M625Jam")
    HaloTextHelper.addText(player, "Click.")
	addSound(player, player:getX(), player:getY(), player:getZ(), 2, 2)
end

local function playBang(player, weapon) --- :( you lost!!!
    triggerMuzzleFlash(player)
    player:playSound(weapon:getSwingSound());

    local radius = weapon:getSoundRadius() * getSandboxOptions():getOptionByName("FirearmNoiseMultiplier"):getValue()
    if not player:isOutside() then
        radius = radius * 0.5
    end

    player:addWorldSoundUnlessInvisible(radius, weapon:getSoundVolume(), true)

    if isClient() then
        sendClientCommand("SimpleRussianRoulette", "requestFXSync", {})
    else
        syncCharacterFX(player)
    end
end

local function youWin(player) 
    local stats = player:getStats()
    local weapon = player:getPrimaryHandItem()

    if SandboxVars.SimpleRussianRoulette.ReceiveXP == true then
        player:getXp():AddXP(Perks.Aiming, 30 * weapon:getCurrentAmmoCount())
        player:getXp():AddXP(Perks.Reloading, 30 * weapon:getCurrentAmmoCount())
    end

    stats:set(CharacterStat.UNHAPPINESS, 0)

    if player:hasTrait(CharacterTrait.DESENSITIZED) or player:hasTrait(CharacterTrait.BRAVE) or player:hasTrait(CharacterTrait.ADRENALINE_JUNKIE) then
        stats:set(CharacterStat.PANIC, stats:get(CharacterStat.PANIC) + 15)
        stats:set(CharacterStat.STRESS, stats:get(CharacterStat.STRESS) + .15)
        if player:hasTrait(CharacterTrait.ADRENALINE_JUNKIE) then
            stats:set(CharacterStat.PANIC, stats:get(CharacterStat.PANIC) + 85)
        end
    else
        stats:set(CharacterStat.PANIC, stats:get(CharacterStat.PANIC) + 50)
        stats:set(CharacterStat.STRESS, stats:get(CharacterStat.STRESS) + .50)
    end
end

local function youLose(player) --alter ammo count   
    if player:getUsername() ~= getPlayer():getUsername() then return end

    local weapon = player:getPrimaryHandItem()
    weapon:setCurrentAmmoCount(weapon:getCurrentAmmoCount() - 1)
    weapon:setSpentRoundCount(weapon:getSpentRoundCount() + 1)

    performKill(player)
end

local function doRussianRoulette(player, weapon) --play the game
    local loaded = weapon:getCurrentAmmoCount()
    local capacity = weapon:getMaxAmmo()

    local chance = loaded / capacity
    local roll = ZombRand(100) / 100

    if roll < chance then --death stuff
        playBang(player, weapon)
        if isClient() then
            sendClientCommand("SimpleRussianRoulette", "youLose", {})
        else
            youLose(player)
        end
    else
        playJam(player)
        if isClient() then
            sendClientCommand("SimpleRussianRoulette", "youWin", {})
        else
            youWin(player)
        end
    end
end
-- end of RR functionality

function SRRTimedAction:isValid()
    return true
end

function SRRTimedAction:start()
    if not self.anim then
        print("[Simple Russian Roulette] No animation set, forcing complete")
        self:forceComplete()
        return
    end

    if not self.weapon then
        print("[Simple Russian Roulette] No weapon set, forcing complete")
        self:forceComplete()
        return
    end

    self:setActionAnim(self.anim)
end

function SRRTimedAction:stop()
    ISBaseTimedAction.stop(self)
end

function SRRTimedAction:update()
    local gameSpeed = UIManager:getSpeedControls():getCurrentGameSpeed()
    if gameSpeed ~= 1 then
        UIManager:getSpeedControls():SetCurrentGameSpeed(1)
    end
end

function SRRTimedAction:animEvent(event, parameter)
    if event == "SRRDone" then
        self:forceComplete()
    end
end

function SRRTimedAction:perform()
    ISBaseTimedAction.perform(self)
    doRussianRoulette(self.character, self.weapon)
end

function SRRTimedAction:new(character, weapon, anim, maxTime)
    local obj = ISBaseTimedAction:new(character)
    setmetatable(obj, self)
    self.__index = self


    obj.stopOnAim = true
    obj.stopOnWalk = false
    obj.stopOnRun = true
    obj.useProgressBar = false
    if maxTime == nil then
        obj.maxTime = -1
        obj.useProgressBar = false
        obj.animSpeed = 1
    else
        obj.maxTime = maxTime
        obj.animSpeed = 1
    end

    obj.anim = anim
    obj.weapon = weapon

    return obj
end


-- server to client
local function onSRRServerCommand(module, command, args)
    if module ~= "SimpleRussianRoulette" then
        return
   end

   if command == "receiveWin" then
        local character = getPlayerByOnlineID(args.playerOnlineId)
        youWin(character)
   end

   if command == "receiveFXSync" then
       local character = getPlayerByOnlineID(args.playerOnlineId)
       syncCharacterFX(character)
   end

   if command == "receiveLoss" then
        local character = getPlayerByOnlineID(args.playerOnlineId)
        youLose(character)
   end

   if command == "receiveDeath" then
        local character = getPlayerByOnlineID(args.playerOnlineId)
        youDie(character)
   end
end

Events.OnServerCommand.Add(onSRRServerCommand)