local SpentCasingPhysicsAmmoCraft = require("SpentCasingAmmoCraft/CompatibilityMods")

local function addItem(distName, itemFullType, weight)
    local dist = ProceduralDistributions.list[distName]
    if not dist or not dist.items then
        return
    end
    table.insert(dist.items, itemFullType)
    table.insert(dist.items, weight)
end

local function mergeHBACDistributions()
    local hasVFE   = SpentCasingPhysicsAmmoCraft and SpentCasingPhysicsAmmoCraft.VFE
    local hasVFES  = SpentCasingPhysicsAmmoCraft and SpentCasingPhysicsAmmoCraft.VFES
    local hasVFE93 = SpentCasingPhysicsAmmoCraft and SpentCasingPhysicsAmmoCraft.VFE93

    -- Gun stores
    addItem("GunStoreMagsAmmo", "HBAC.PrimerBox", 6)
    addItem("GunStoreMagsAmmo", "Base.GunPowder", 6)
    addItem("GunStoreMagsAmmo", "HBAC.9mmProjectileBox", 6)
    addItem("GunStoreMagsAmmo", "HBAC.45ProjectileBox", 5)
    addItem("GunStoreMagsAmmo", "HBAC.38ProjectileBox", 4)
    addItem("GunStoreMagsAmmo", "HBAC.44ProjectileBox", 3)
    addItem("GunStoreMagsAmmo", "HBAC.ShotgunPelletsBox", 4)
    addItem("GunStoreMagsAmmo", "HBAC.556ProjectileBox", 3)
    addItem("GunStoreMagsAmmo", "HBAC.223ProjectileBox", 3)
    addItem("GunStoreMagsAmmo", "HBAC.308ProjectileBox", 2)

    addItem("GunStoreCounter", "HBAC.ReloadingTool", 2)
    addItem("GunStoreCounter", "HBAC.PrimerBox", 4)
    addItem("GunStoreCounter", "Base.GunPowder", 4)

    addItem("GunStoreShelf", "HBAC.PrimerBox", 2)
    addItem("GunStoreShelf", "Base.GunPowder", 2)
    addItem("GunStoreShelf", "HBAC.9mmProjectileBox", 2)
    addItem("GunStoreShelf", "HBAC.45ProjectileBox", 1.5)
    addItem("GunStoreShelf", "HBAC.ShotgunPelletsBox", 1.5)

    -- Gun store main ammo shelf (the big bulk-ammo distribution every gun store rolls on)
    addItem("GunStoreAmmunition", "HBAC.PrimerBox", 3)
    addItem("GunStoreAmmunition", "Base.GunPowder", 3)
    addItem("GunStoreAmmunition", "HBAC.ReloadingTool", 1)
    addItem("GunStoreAmmunition", "HBAC.9mmProjectileBox", 3)
    addItem("GunStoreAmmunition", "HBAC.45ProjectileBox", 2.5)
    addItem("GunStoreAmmunition", "HBAC.38ProjectileBox", 2)
    addItem("GunStoreAmmunition", "HBAC.44ProjectileBox", 1.5)
    addItem("GunStoreAmmunition", "HBAC.ShotgunPelletsBox", 2)
    addItem("GunStoreAmmunition", "HBAC.556ProjectileBox", 1.5)
    addItem("GunStoreAmmunition", "HBAC.223ProjectileBox", 1.5)
    addItem("GunStoreAmmunition", "HBAC.308ProjectileBox", 1)

    -- Police ammo storage
    addItem("PoliceStorageAmmunition", "HBAC.9mmProjectileBox", 6)
    addItem("PoliceStorageAmmunition", "HBAC.45ProjectileBox", 5)
    addItem("PoliceStorageAmmunition", "HBAC.38ProjectileBox", 2)
    addItem("PoliceStorageAmmunition", "HBAC.44ProjectileBox", 1)
    addItem("PoliceStorageAmmunition", "HBAC.ShotgunPelletsBox", 4)
    addItem("PoliceStorageAmmunition", "HBAC.PrimerBox", 1)
    addItem("PoliceStorageAmmunition", "Base.GunPowder", 1)

    -- SWAT tactical ammo storage
    addItem("SWATStorageAmmunition", "HBAC.PrimerBox", 1.5)
    addItem("SWATStorageAmmunition", "Base.GunPowder", 1.5)
    addItem("SWATStorageAmmunition", "HBAC.ReloadingTool", 0.3)
    addItem("SWATStorageAmmunition", "HBAC.9mmProjectileBox", 2)
    addItem("SWATStorageAmmunition", "HBAC.45ProjectileBox", 1.5)
    addItem("SWATStorageAmmunition", "HBAC.556ProjectileBox", 2)
    addItem("SWATStorageAmmunition", "HBAC.308ProjectileBox", 1)
    addItem("SWATStorageAmmunition", "HBAC.ShotgunPelletsBox", 1.5)

    -- Army / surplus
    addItem("ArmyStorageAmmunition", "HBAC.PrimerBox", 4)
    addItem("ArmyStorageAmmunition", "Base.GunPowder", 4)
    addItem("ArmyStorageAmmunition", "HBAC.ReloadingTool", 0.5)
    addItem("ArmyStorageAmmunition", "HBAC.556ProjectileBox", 6)
    addItem("ArmyStorageAmmunition", "HBAC.223ProjectileBox", 4)
    addItem("ArmyStorageAmmunition", "HBAC.308ProjectileBox", 3)

    addItem("ArmySurplusAmmoBoxes", "HBAC.PrimerBox", 2)
    addItem("ArmySurplusAmmoBoxes", "Base.GunPowder", 2)
    addItem("ArmySurplusAmmoBoxes", "HBAC.ReloadingTool", 0.25)
    addItem("ArmySurplusAmmoBoxes", "HBAC.556ProjectileBox", 4)
    addItem("ArmySurplusAmmoBoxes", "HBAC.223ProjectileBox", 2)
    addItem("ArmySurplusAmmoBoxes", "HBAC.308ProjectileBox", 2)

    -- Garages / pawn
    addItem("GarageFirearms", "HBAC.9mmProjectileBox", 1.5)
    addItem("GarageFirearms", "HBAC.45ProjectileBox", 1.2)
    addItem("GarageFirearms", "HBAC.38ProjectileBox", 1)
    addItem("GarageFirearms", "HBAC.ShotgunPelletsBox", 1.2)
    addItem("GarageFirearms", "HBAC.PrimerBox", 0.5)
    addItem("GarageFirearms", "Base.GunPowder", 0.5)
    addItem("GarageFirearms", "HBAC.ReloadingTool", 0.1)

    addItem("GarageTools", "HBAC.ReloadingTool", 0.25)
    addItem("GarageTools", "HBAC.PrimerBox", 0.4)
    addItem("GarageTools", "Base.GunPowder", 0.4)

    addItem("PawnShopTools", "HBAC.ReloadingTool", 0.75)
    addItem("PawnShopTools", "HBAC.PrimerBox", 1.5)
    addItem("PawnShopTools", "Base.GunPowder", 1.5)

    addItem("PawnShopGunsSpecial", "HBAC.9mmProjectileBox", 1.5)
    addItem("PawnShopGunsSpecial", "HBAC.45ProjectileBox", 1.2)
    addItem("PawnShopGunsSpecial", "HBAC.308ProjectileBox", 1)
    addItem("PawnShopGunsSpecial", "HBAC.PrimerBox", 0.8)
    addItem("PawnShopGunsSpecial", "Base.GunPowder", 0.8)

    addItem("MechanicTools", "HBAC.ReloadingTool", 0.15)
    addItem("StoreShelfMechanics", "HBAC.ReloadingTool", 0.1)

    -- VFE: 7.62 and .22
    if hasVFE then
        addItem("GunStoreMagsAmmo", "HBAC.22ProjectileBox", 4)
        addItem("GunStoreMagsAmmo", "HBAC.762ProjectileBox", 2)
        addItem("GunStoreAmmunition", "HBAC.22ProjectileBox", 2)
        addItem("GunStoreAmmunition", "HBAC.762ProjectileBox", 1)

        addItem("PoliceStorageAmmunition", "HBAC.22ProjectileBox", 1.5)

        addItem("ArmyStorageAmmunition", "HBAC.762ProjectileBox", 4)
        addItem("ArmySurplusAmmoBoxes", "HBAC.762ProjectileBox", 3)
    end

    -- VFES: 5.45 / 7.62x54 / 9x39
    if hasVFES then
        addItem("GunStoreMagsAmmo", "HBAC.545ProjectileBox", 1.5)
        addItem("GunStoreMagsAmmo", "HBAC.76254ProjectileBox", 1)
        addItem("GunStoreMagsAmmo", "HBAC.939ProjectileBox", 1)
        addItem("GunStoreAmmunition", "HBAC.545ProjectileBox", 1)
        addItem("GunStoreAmmunition", "HBAC.76254ProjectileBox", 0.75)
        addItem("GunStoreAmmunition", "HBAC.939ProjectileBox", 0.75)

        addItem("ArmyStorageAmmunition", "HBAC.545ProjectileBox", 3)
        addItem("ArmyStorageAmmunition", "HBAC.76254ProjectileBox", 2)
        addItem("ArmyStorageAmmunition", "HBAC.939ProjectileBox", 2)

        addItem("ArmySurplusAmmoBoxes", "HBAC.545ProjectileBox", 2)
        addItem("ArmySurplusAmmoBoxes", "HBAC.76254ProjectileBox", 1.5)
        addItem("ArmySurplusAmmoBoxes", "HBAC.939ProjectileBox", 1.5)
    end

    -- VFE93: 5.7 / 4.6
    if hasVFE93 then
        addItem("GunStoreMagsAmmo", "HBAC.57ProjectileBox", 1)
        addItem("GunStoreMagsAmmo", "HBAC.46ProjectileBox", 1)
        addItem("GunStoreAmmunition", "HBAC.57ProjectileBox", 0.75)
        addItem("GunStoreAmmunition", "HBAC.46ProjectileBox", 0.75)

        addItem("ArmyStorageAmmunition", "HBAC.57ProjectileBox", 1.5)
        addItem("ArmyStorageAmmunition", "HBAC.46ProjectileBox", 1.5)

        addItem("ArmySurplusAmmoBoxes", "HBAC.57ProjectileBox", 1)
        addItem("ArmySurplusAmmoBoxes", "HBAC.46ProjectileBox", 1)
    end
end

Events.OnPreDistributionMerge.Add(mergeHBACDistributions)
