local SpentCasingPhysics          = require("SpentCasingPhysics/Init")
local SpentCasingPhysicsAmmoCraft = {}

SpentCasingPhysicsAmmoCraft.VFE   = getActivatedMods():contains('HBACVFE')
SpentCasingPhysicsAmmoCraft.VFES  = getActivatedMods():contains('HBACVFES')
SpentCasingPhysicsAmmoCraft.VFE93 = getActivatedMods():contains('HBACVFE93')

return SpentCasingPhysicsAmmoCraft
