ItemBodyLocation.register("alicesweaponsling:slingfront")
ItemBodyLocation.register("alicesweaponsling:slingback")