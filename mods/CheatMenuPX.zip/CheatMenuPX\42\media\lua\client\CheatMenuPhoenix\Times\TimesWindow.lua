---@class TimesWindow : ISCollapsableWindow
---@field IDs string|nil
---@field YearInput ISTextEntryBox
---@field MonthInput ISTextEntryBox
---@field DayInput ISTextEntryBox
---@field HourInput ISTextEntryBox
---@field MinuteInput ISTextEntryBox
---@field InpButton ISButton
---@field titleBarFont UIFont
TimesWindow = ISCollapsableWindow:derive("TimesWindow")

---@class TimeBox : ISPanel
---@field target TimesWindow
---@field func fun()|nil
---@field hscroll any
TimeBox = ISPanel:derive("TimeBox")

TimesWindow.IDs = nil

function CheckNumeric(value)
    if value == "" then return true end

    local numStr = tostring(tonumber(value))
    if value ~= numStr then return false end

    return numStr ~= "."
end

function TimesWindow:initialise()
    ISCollapsableWindow.initialise(self);
    self:makeChildren()
end

function TimesWindow:SetTime()
    local time = getGameTime()
    local player = getPlayer()

    -- Helper function to get input values
    local function getVal(input, default, offset)
        local text = input:getText()
        if text == "" then return default + (offset or 0) end
        local num = tonumber(text)
        if not num or not CheckNumeric(text) then return nil end
        return math.floor(num)
    end

    local Y = getVal(self.YearInput, time:getYear())
    local M = getVal(self.MonthInput, time:getMonth(), 1)
    local D = getVal(self.DayInput, time:getDay(), 1)
    local H = getVal(self.HourInput, time:getHour())

    local textMM = self.MinuteInput:getText()
    local numMM = tonumber(textMM)
    local MM
    if textMM == "" then
        MM = time:getTimeOfDay() - time:getHour()
    elseif numMM and CheckNumeric(textMM) then
        MM = numMM / 60
    else
        MM = nil
    end

    -- Global validation
    if not (Y and M and D and H and MM) then
        player:Say(getText("UI_CMRB_Message_TimeCannotChange"))
        return
    end

    ---@cast Y number
    ---@cast M number
    ---@cast D number
    ---@cast H number
    ---@cast MM number

    -- Simplified leap year logic
    ---@type number[]
    local lastDays = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
    if (Y % 4 == 0 and (Y % 100 ~= 0 or Y % 400 == 0)) then
        lastDays[2] = 29
    end

    -- PZ limits (Game starts on July 9, 1993)
    if Y < 1993 or (Y == 1993 and (M < 7 or (M == 7 and D < 9))) then
        player:Say(getText(Y <= 0 and "UI_CMRB_Message_TimeCannotChange" or "UI_CMRB_Message_TimeCannotUndo"))
        return
    end

    -- Value range validation
    if M < 1 or M > 12 or D < 1 or D > 31 or H < 0 or H > 24 or MM < 0 or MM > 1 then
        player:Say(getText("UI_CMRB_Message_TimeCannotChange"))
        return
    end

    -- Auto-correct day if invalid for the month
    if D > lastDays[M] then
        player:Say(getText("UI_CMRB_Message_DateInvalid"))
        D = lastDays[M] --[[@as number]]
    end

    ---@cast D number

    -- Apply time
    ---@diagnostic disable: param-type-mismatch
    time:setYear(Y)
    time:setMonth(M - 1)
    time:setDay(D - 1)
    time:setTimeOfDay(H + MM)
    ---@diagnostic enable: param-type-mismatch

    -- Clean minute formatting
    local printMin = string.format("%02d", math.floor(MM * 60))
    player:Say(getText("UI_CMRB_Message_TimeChange_1") .. Y .. "/" .. M .. "/" .. D .. " , " .. H .. getText("UI_CMRB_Message_TimeChange_2") .. printMin .. " .")
end

function TimesWindow:makeChildren()

    self.YearInput = ISTextEntryBox:new("", 0, self:titleBarHeight()+20, self:getWidth() / 5, self:getHeight() / 5);
    self.YearInput:initialise();
    self.YearInput:instantiate();
    self.YearInput:setMultipleLine(false)
    self.YearInput.javaObject:setMaxLines(1);
    self:addChild(self.YearInput); -- to center, set border pixel and multiply by border pixel / 2

    self.MonthInput = ISTextEntryBox:new("", self:getWidth() / 5, self:titleBarHeight()+20, self:getWidth() / 5, self:getHeight() / 5);
    self.MonthInput:initialise();
    self.MonthInput:instantiate();
    self.MonthInput:setMultipleLine(false)
    self.MonthInput.javaObject:setMaxLines(1);
    self:addChild(self.MonthInput); -- to center, set border pixel and multiply by border pixel / 2

    self.DayInput = ISTextEntryBox:new("", (self:getWidth() / 5) * 2, self:titleBarHeight()+20, self:getWidth() / 5, self:getHeight() / 5);
    self.DayInput:initialise();
    self.DayInput:instantiate();
    self.DayInput:setMultipleLine(false)
    self.DayInput.javaObject:setMaxLines(1);
    self:addChild(self.DayInput); -- to center, set border pixel and multiply by border pixel / 2

    self.HourInput = ISTextEntryBox:new("", (self:getWidth() / 5) * 3, self:titleBarHeight()+20, self:getWidth() / 5, self:getHeight() / 5);
    self.HourInput:initialise();
    self.HourInput:instantiate();
    self.HourInput:setMultipleLine(false)
    self.HourInput.javaObject:setMaxLines(1);
    self:addChild(self.HourInput); -- to center, set border pixel and multiply by border pixel / 2

    self.MinuteInput = ISTextEntryBox:new("", (self:getWidth() / 5) * 4, self:titleBarHeight()+20, self:getWidth() / 5, self:getHeight() / 5);
    self.MinuteInput:initialise();
    self.MinuteInput:instantiate();
    self.MinuteInput:setMultipleLine(false)
    self.MinuteInput.javaObject:setMaxLines(1);
    self:addChild(self.MinuteInput); -- to center, set border pixel and multiply by border pixel / 2

    self.InpButton = ISButton:new(0, self.YearInput:getHeight() + self:titleBarHeight()+20, self:getWidth(), self:getHeight() / 2, getText("UI_CMRB_Window_Set"), self, self.SetTime); 
    self.InpButton:initialise();
    self.InpButton:instantiate();
    self.InpButton.borderColor = {r=0.4, g=0.4, b=0.4, a=1.0};
    self:addChild(self.InpButton);

    --self:setHeight(self:getHeight() - (self:titleBarHeight() / 2)) 
end

function TimesWindow:prerender()
    local height = self:getHeight();
    local th = self:titleBarHeight()
    if self.isCollapsed then
        height = th;
    end
    if self.drawFrame then
        self:drawRect(0, 0, self:getWidth(), th, self.backgroundColor.a, self.backgroundColor.r, self.backgroundColor.g, self.backgroundColor.b);
        self:drawTextureScaled(self.titlebarbkg, 2, 1, self:getWidth() - 4, th - 2, 1, 1, 1, 1);
        self:drawRectBorder(0, 0, self:getWidth(), th, self.borderColor.a, self.borderColor.r, self.borderColor.g, self.borderColor.b);
    end
    if self.background and not self.isCollapsed then
        local rh = self:resizeWidgetHeight()
        if not self.resizable or not self.resizeWidget:getIsVisible() then rh = 0 end
        self:drawRect(0, th, self:getWidth(), self.height - th - rh, self.backgroundColor.a, self.backgroundColor.r, self.backgroundColor.g, self.backgroundColor.b);
    end

    if self.clearStentil then
        self:setStencilRect(0,0,self.width, height);
    end

    if self.title ~= nil and self.drawFrame then
        self:drawTextCentre(self.title, self:getWidth() / 2, 1, 1, 1, 1, 1, self.titleBarFont);
    end
        self:drawTextCentre(getText("UI_CMRB_TimeWindow_Years"), (self.YearInput.x + self.MonthInput.x) / 2, self:titleBarHeight()+2, 1, 1, 1, 1, UIFont.Small)
        self:drawTextCentre(getText("UI_CMRB_TimeWindow_Months"), (self.MonthInput.x + self.DayInput.x) / 2, self:titleBarHeight()+2, 1, 1, 1, 1, UIFont.Small)
        self:drawTextCentre(getText("UI_CMRB_TimeWindow_Days"), (self.DayInput.x + self.HourInput.x) / 2, self:titleBarHeight()+2, 1, 1, 1, 1, UIFont.Small)
        self:drawTextCentre(getText("UI_CMRB_TimeWindow_Hours"), (self.HourInput.x + self.MinuteInput.x) / 2, self:titleBarHeight()+2, 1, 1, 1, 1, UIFont.Small)
        self:drawTextCentre(getText("UI_CMRB_TimeWindow_Minutes"), (self.MinuteInput.x + self:getWidth()) / 2, self:titleBarHeight()+2, 1, 1, 1, 1, UIFont.Small)
end

function TimesWindow:destroy() -- pre-defined
    self:setVisible(false)
    self:removeFromUIManager()
    TimesWindow.IDs = nil
end

function TimesWindow:close() -- Works here
    self:setVisible(false)
    self:removeFromUIManager()
    TimesWindow.IDs = nil
end

---@param x number
---@param y number
---@param width number
---@param height number
---@return TimesWindow
function TimesWindow:new(x, y, width, height)
    local o = {}
    o = ISCollapsableWindow:new(x, y, width, height)
    setmetatable(o, self)
    self.__index = self
    ---@type TimesWindow
    o = o ---@diagnostic disable-line: assign-type-mismatch
    o.title = getText("UI_CMRB_Utility_TimeWarpWindow")
    o.resizable = false
    o.pin = true;
    o.isCollapsed = false;
    o.x = x
    o.y = y
    o.width = width
    o.height = height
    TimesWindow.IDs = "TimeMachine"
    --o:noBackground();
    --o.clearStentil = false
    --o.borderColor = {r=0.4, g=0.4, b=0.4, a=0.4};
    return o;
end

function TimesWindow.makeWindow()
    local window = TimesWindow:new(100,100,370,100)
    -- Change the window's width, height << later job.
    window:initialise()
    window:addToUIManager()
end

function TimeBox:initialise()
    ISPanel.initialise(self);
    self:createChildren()
end

function TimeBox:createChildren()
    self:addScrollBars(true)
    self:setScrollWidth(1000)
    self.hscroll:setWidth(self.width - 1)
    --self.hscroll:setHeight(self.height)
    self.hscroll:setAlwaysOnTop(true)
    ---@diagnostic disable-next-line: inject-field
    self.hscroll.target, self.hscroll.func = self.target, self.func

    function self.hscroll:onMouseMove(dx, dy)
        ---@type ISScrollBar
        self = self
        if self.scrolling then
            local sw = self.parent:getScrollWidth()
            if sw > self.parent:getScrollAreaWidth() then
                local del = self:getWidth() / sw
                local boxheight = del * (self:getWidth()- (20 * 2))
                local dif = self:getWidth() - (20 * 2) - boxheight
                self.pos = self.pos + (dx / dif)
                if self.pos < 0 then
                    self.pos = 0
                end
                if self.pos > 1 then
                    self.pos = 1
                end
                self.parent:setXScroll(-(self.pos * (sw - self.parent:getScrollAreaWidth())))
            end
            ---@diagnostic disable-next-line: undefined-field
            if self.func then
                ---@diagnostic disable-next-line: undefined-field
                pcall(self.func)
            end
        end
    end
end

---@param x number
---@param y number
---@param width number
---@param height number
---@param target TimesWindow
---@param func fun()|nil
---@return TimeBox
function TimeBox:new(x, y, width, height, target, func)
    local o = {};
    o = ISPanel:new(x, y, width, height);
    setmetatable(o, self);
    self.__index = self;
    ---@type TimeBox
    o = o ---@diagnostic disable-line: assign-type-mismatch
    o.x = x
    o.y = y
    o.width = width
    o.height = height
    o.target = target
    o.func = func
    --o:noBackground();
    --o.clearStentil = false
    --o.borderColor = {r=0.4, g=0.4, b=0.4, a=0.4};
    return o;
end
