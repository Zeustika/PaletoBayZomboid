---@class VehicleControlWindow : ISCollapsableWindow
---@field IDs table
---@field func fun()|nil
---@field args unknown
---@field Selbtn ISButton
---@field DeSelbtn ISButton
---@field ColorChgbtn ISButton
---@field SkinChgbtn ISButton
---@field Keygenbtn ISButton
---@field Hotwirebtn ISButton
---@field Rustbtn ISButton
---@field AllRepairbtn ISButton
---@field VehicleGodbtn ISButton
---@field IndividualPartbtn ISButton
---@field DestroyVehiclebtn ISButton
---@field Condition25btn ISButton
---@field Condition50btn ISButton
---@field Condition75btn ISButton
---@field Condition100btn ISButton
VehicleControlWindow = ISCollapsableWindow:derive("VehicleControlWindow")
VehicleControlWindow.IDs = {}

function VehicleControlWindow:initialise()
    ISCollapsableWindow.initialise(self);
    if isClient() then
        if not ISVehicleMechanics.cheat then
            ISVehicleMechanics.cheat = true
        end
    end
end

function VehicleControlWindow:destroy()
    if isClient() and ISVehicleMechanics.cheat then
        ISVehicleMechanics.cheat = false
    end

    self:setVisible(false)
    self:removeFromUIManager()
    VehicleControlWindow.IDs = {}
end

---@param title string
---@param ID any
---@param onPress fun()|nil
---@param args unknown|nil
---@return VehicleControlWindow
function VehicleControlWindow:new(title, ID, onPress, args)
    local o = ISCollapsableWindow:new(getCore():getScreenWidth() / 3, getCore():getScreenHeight() / 3, 240, 320)
    --ISCollapsableWindow.initialise(o);
    setmetatable(o, self)
    self.__index = self
    ---@type VehicleControlWindow
    o = o ---@diagnostic disable-line: assign-type-mismatch
    o.title = title;
    o.resizable = false;
    --ISCollapsableWindow.initialise(self);

    o.func = onPress
    o.args = args

    local buttonN_width = 120
    local buttonN_height = 40

    o.Selbtn = ISButton:new(0, o:titleBarHeight(), buttonN_width, buttonN_height, getText("UI_CMRB_VehicleControl_SelectVehicle"), o, function ()o:MakeSelection() end)
    o.Selbtn:initialise()
    o.Selbtn:instantiate();
    o:addChild(o.Selbtn)

    o.DeSelbtn = ISButton:new(buttonN_width, o:titleBarHeight(), buttonN_width, buttonN_height, getText("UI_CMRB_VehicleControl_DeselectVehicle"), o, function () o:Deselection() end)
    o.DeSelbtn:initialise()
    o.DeSelbtn:instantiate();
    o:addChild(o.DeSelbtn)

    o.ColorChgbtn = ISButton:new(0, o:titleBarHeight() + buttonN_height, buttonN_width, buttonN_height, getText("UI_CMRB_VehicleControl_ColorEditor"), o, function () o:ColorChg() end)
    o.ColorChgbtn:initialise()
    o.ColorChgbtn:instantiate();
    o:addChild(o.ColorChgbtn)

    o.SkinChgbtn = ISButton:new(buttonN_width, o:titleBarHeight() + buttonN_height, buttonN_width, buttonN_height, getText("UI_CMRB_VehicleControl_SkinEditor"), o, function () o:SkinChg() end)
    o.SkinChgbtn:initialise()
    o.SkinChgbtn:instantiate();
    o:addChild(o.SkinChgbtn)

    o.Keygenbtn = ISButton:new(0, o:titleBarHeight() + buttonN_height * 2, buttonN_width, buttonN_height, getText("UI_CMRB_VehicleControl_KeyCreation"), o, function () o:Keygen() end) 
    o.Keygenbtn:initialise()
    o.Keygenbtn:instantiate()
    o:addChild(o.Keygenbtn)

    o.Hotwirebtn = ISButton:new(buttonN_width, o:titleBarHeight() + buttonN_height * 2, buttonN_width, buttonN_height, getText("UI_CMRB_VehicleControl_Hotwire"), o, function () o:SetHotwire() end) 
    o.Hotwirebtn:initialise()
    o.Hotwirebtn:instantiate();
    o:addChild(o.Hotwirebtn)

    o.Rustbtn = ISButton:new(0, o:titleBarHeight() + buttonN_height * 3, buttonN_width, buttonN_height, getText("UI_CMRB_VehicleControl_RustEditor"), o, function () o:SetRust() end)
    o.Rustbtn:initialise()
    o.Rustbtn:instantiate();
    o:addChild(o.Rustbtn)

    o.AllRepairbtn = ISButton:new(buttonN_width, o:titleBarHeight() + buttonN_height * 3, buttonN_width, buttonN_height, getText("UI_CMRB_VehicleControl_RepairAll"), o, function () o:AllRepair() end)
    o.AllRepairbtn:initialise()
    o.AllRepairbtn:instantiate();
    o:addChild(o.AllRepairbtn)

    o.VehicleGodbtn = ISButton:new(0, o:titleBarHeight() + buttonN_height * 4, buttonN_width, buttonN_height, getText("UI_CMRB_VehicleControl_Godmode"), o, function () o:VehicleGod() end)
    o.VehicleGodbtn:initialise()
    o.VehicleGodbtn:instantiate();
    o:addChild(o.VehicleGodbtn)

    o.IndividualPartbtn = ISButton:new(buttonN_width, o:titleBarHeight() + buttonN_height * 4, buttonN_width, buttonN_height, getText("UI_CMRB_Utility_VehicleParts"), o, function () o:IndividualPart() end)
    o.IndividualPartbtn:initialise()
    o.IndividualPartbtn:instantiate();
    o:addChild(o.IndividualPartbtn)

    o.DestroyVehiclebtn = ISButton:new(0, o:titleBarHeight() + buttonN_height * 5, buttonN_width, buttonN_height, getText("UI_CMRB_VehicleControl_DestroyVehicle"), o, function () o:DestroyVehicle() end)
    o.DestroyVehiclebtn:initialise()
    o.DestroyVehiclebtn:instantiate();
    o:addChild(o.DestroyVehiclebtn)

    local buttonS_width = 60
    o.Condition25btn = ISButton:new(0, o:titleBarHeight() + buttonN_height * 6, buttonS_width, buttonN_height, "25%", o, function () CheatCoreCM.VehicleSpawnCondition = 0.25 end)
    o.Condition25btn:initialise()
    o.Condition25btn:instantiate()
    o:addChild(o.Condition25btn)

    o.Condition50btn = ISButton:new(buttonS_width, o:titleBarHeight() + buttonN_height * 6, buttonS_width, buttonN_height, "50%", o, function () CheatCoreCM.VehicleSpawnCondition = 0.50 end)
    o.Condition50btn:initialise()
    o.Condition50btn:instantiate()
    o:addChild(o.Condition50btn)

    o.Condition75btn = ISButton:new(buttonS_width * 2, o:titleBarHeight() + buttonN_height * 6, buttonS_width, buttonN_height, "75%", o, function () CheatCoreCM.VehicleSpawnCondition = 0.75 end)
    o.Condition75btn:initialise()
    o.Condition75btn:instantiate()
    o:addChild(o.Condition75btn)

    o.Condition100btn = ISButton:new(buttonS_width * 3, o:titleBarHeight() + buttonN_height * 6, buttonS_width, buttonN_height, "100%", o, function () CheatCoreCM.VehicleSpawnCondition = 1.0 end)
    o.Condition100btn:initialise()
    o.Condition100btn:instantiate()
    o:addChild(o.Condition100btn)

    --o.backgroundColor = {r=0.1, g=0.1, b=0.1, a=0.6};
    --o.borderColor = {r=0.4, g=0.4, b=0.4, a=1};

    --o:setHeight(o:getHeight() - (o:titleBarHeight() / 2)) -- remove the space that's usually added for the resize widget
    VehicleControlWindow.IDs[ID] = o
    return o
end

function VehicleControlWindow:prerender()
    ISCollapsableWindow.prerender(self)
    local selectedColor = {r=1, g=0.5, b=0, a=1}
    local defaultColor = {r=0.4, g=0.4, b=0.4, a=1}

    self.Condition25btn.borderColor = (CheatCoreCM.VehicleSpawnCondition == 0.25) and selectedColor or defaultColor
    self.Condition50btn.borderColor = (CheatCoreCM.VehicleSpawnCondition == 0.50) and selectedColor or defaultColor
    self.Condition75btn.borderColor = (CheatCoreCM.VehicleSpawnCondition == 0.75) and selectedColor or defaultColor
    self.Condition100btn.borderColor = (CheatCoreCM.VehicleSpawnCondition == 1.0) and selectedColor or defaultColor

    if self.SkinChgbtn then
        local vehicle = CheatCoreCM.SelectedVehicle
        if vehicle and (vehicle:getSkinIndex() == -1 or vehicle:getSkinCount() <= 1) then
            self.SkinChgbtn:setEnable(false)
        else
            self.SkinChgbtn:setEnable(true)
        end
    end
end

function VehicleControlWindow:MakeSelection()
    if CheatCoreCM.SelectedVehicle ~= nil then
        CheatCoreCM.HandleToggle(nil, "CheatCoreCM.IsSelect", function() getPlayer():Say((CheatCoreCM.IsSelect and getText("UI_CMRB_Message_VehicleReselection") .. getText("UI_CMRB_Message_IsEnabled") .. getText("UI_CMRB_Message_VehicleSelection_2") or getText("UI_CMRB_Message_VehicleReselection") .. getText("UI_CMRB_Message_IsDisabled"))) end)
    else
        CheatCoreCM.HandleToggle(nil, "CheatCoreCM.IsSelect", function() getPlayer():Say((CheatCoreCM.IsSelect and getText("UI_CMRB_Message_VehicleSelection") .. getText("UI_CMRB_Message_IsEnabled") .. getText("UI_CMRB_Message_VehicleSelection_2") or getText("UI_CMRB_Message_VehicleSelection") .. getText("UI_CMRB_Message_IsDisabled"))) end)
    end
end

function VehicleControlWindow:Deselection()
    local player = getPlayer()

    if CheatCoreCM.SelectedVehicle then
        if CheatCoreCM.IsSelect then
            player:Say(getText("UI_CMRB_Message_VehicleSelection") .. getText("UI_CMRB_Message_IsDisabled"))
        end
        CheatCoreCM.SelectedVehicle = nil
        CheatCoreCM.IsReady = false
        player:Say(getText("UI_CMRB_Message_VehicleDeselected"))
        return
    end

    if CheatCoreCM.IsSelect then
        player:Say(getText("UI_CMRB_Message_VehicleSelection") .. getText("UI_CMRB_Message_IsDisabled"))
        CheatCoreCM.IsSelect = false
    else
        player:Say(getText("UI_CMRB_Message_VehicleDeselectedAlready"))
    end
end

function VehicleControlWindow:ColorChg()
    --print (ISUIColorWindow.IDs)
    if CheatCoreCM.SelectedVehicle ~= nil and ISUIColorWindow.IDs == nil then
        ISUIColorWindow.makeWindow()
    elseif CheatCoreCM.SelectedVehicle == nil then
        getPlayer():Say(getText("UI_CMRB_Message_VehicleDeselectedAlready"))
    else
        getPlayer():Say(getText("UI_CMRB_Message_AlreadyExistWindow"))
    end
end

function VehicleControlWindow:SkinChg()
    local vehicle = CheatCoreCM.SelectedVehicle
    if vehicle then
        local skinIndex = vehicle:getSkinIndex()
        skinIndex = skinIndex + 1
        if skinIndex >= vehicle:getSkinCount() then
            skinIndex = 0
        end
        vehicle:setSkinIndex(skinIndex)
        vehicle:updateSkin()
        local args = { vehicle = vehicle:getId(), index = skinIndex }
        sendClientCommand(getPlayer(), 'vehicle', 'setSkinIndex', args)
        getPlayer():Say(getText("UI_CMRB_Message_VehicleSkinChanged"))
    else
        getPlayer():Say(getText("UI_CMRB_Message_VehicleDeselectedAlready"))
    end
end

function VehicleControlWindow:Keygen()
    local vehicle = CheatCoreCM.SelectedVehicle
    if vehicle then
        if isClient() then
            sendClientCommand(getPlayer(), "vehicle", "getKey", { vehicle = vehicle:getId() })
        else
            if vehicle:getCurrentKey() ~= nil then 
                getPlayer():getInventory():AddItem(vehicle:getCurrentKey()) 
            else 
                getPlayer():getInventory():AddItem(vehicle:createVehicleKey()) 
            end
            getPlayer():Say(getText("UI_CMRB_Message_VehicleKeyAdded"))
        end
    else
        getPlayer():Say(getText("UI_CMRB_Message_VehicleDeselectedAlready"))
    end
end

function VehicleControlWindow:SetHotwire()
    local vehicle = CheatCoreCM.SelectedVehicle --[[@as BaseVehicle]]
    if not vehicle then
        getPlayer():Say(getText("UI_CMRB_Message_VehicleDeselectedAlready"))
        return
    end

    local player = getPlayer()
    local isCurrentlyHotwired = vehicle:isHotwired()
    local newHotwiredState = not isCurrentlyHotwired
    local messageKey = isCurrentlyHotwired and "UI_CMRB_Message_Hotwired" or "UI_CMRB_Message_NotHotwired"

    if isClient() then
        sendClientCommand(player, "vehicle", "cheatHotwire", {
            vehicle = vehicle:getId(),
            hotwired = newHotwiredState,
            broken = vehicle:isHotwiredBroken()
        })
    else
        vehicle:setHotwired(newHotwiredState)
    end

    player:Say(getText(messageKey))
end

function VehicleControlWindow:SetRust()
    --print (ISUIRustWindow.IDs)
    if CheatCoreCM.SelectedVehicle ~= nil and ISUIRustWindow.IDs == nil then
        ISUIRustWindow.makeWindow()

    elseif CheatCoreCM.SelectedVehicle == nil then
        getPlayer():Say(getText("UI_CMRB_Message_VehicleDeselectedAlready"))
    else
        getPlayer():Say(getText("UI_CMRB_Message_AlreadyExistWindow"))
    end
end

function VehicleControlWindow:AllRepair()
    local vehicle = CheatCoreCM.SelectedVehicle --[[@as BaseVehicle]]
    if not vehicle then
        getPlayer():Say(getText("UI_CMRB_Message_VehicleDeselectedAlready"))
        return
    end

    if isClient() then
        sendClientCommand(getPlayer(), "vehicle", "repair", { vehicle = vehicle:getId() })
    else
        vehicle:repair()
    end
    getPlayer():Say(getText("UI_CMRB_Message_RepairedVehicle"))
end

function VehicleControlWindow:VehicleGod()
    if not CheatCoreCM.SelectedVehicle then
        getPlayer():Say(getText("UI_CMRB_Message_VehicleDeselectedAlready"))
        return
    end

    if isClient() then
        getPlayer():Say(getText("UI_CMRB_Message_NotSuppportMP"))
    else
        CheatCoreCM.HandleToggle(getText("UI_CMRB_VehicleControl_Godmode"), "CheatCoreCM.MadMax")
    end
end

function VehicleControlWindow:IndividualPart()
    getPlayer():Say(getText("UI_CMRB_Message_NotSupported"))
end

function VehicleControlWindow:DestroyVehicle()
    local vehicle = CheatCoreCM.SelectedVehicle --[[@as BaseVehicle]]
    if not vehicle then
        getPlayer():Say(getText("UI_CMRB_Message_VehicleDeselectedAlready"))
        return
    end

    if isClient() then
        sendClientCommand(getPlayer(), "vehicle", "remove", { vehicle = vehicle:getId() })
    else
        vehicle:permanentlyRemove()
    end

    getPlayer():Say(getText("UI_CMRB_Message_DestroyedVehicle"))
    CheatCoreCM.SelectedVehicle = nil
    CheatCoreCM.IsReady = false
end

function VehicleControlWindow:checkExists(title, ID, onPress, args) -- to prevent duplicates when using it in conjunction with contextmenus. if inputUI returns nil then that means it's the first time the context menu has been opened.
    if VehicleControlWindow.IDs[ID] == nil then
        local newUI = VehicleControlWindow:new(title, ID, onPress, args)
        newUI:initialise()
        newUI:addToUIManager()
        newUI:setVisible(false)
    end
    return VehicleControlWindow.IDs[ID]
end
