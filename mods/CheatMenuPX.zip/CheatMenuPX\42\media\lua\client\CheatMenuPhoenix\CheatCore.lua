-- Cheat Menu: Phoenix
-- Version: 2.x
-- Developer: BlaBla
-- Developer: RelationLife (https://steamcommunity.com/id/relationlife)
-- Original Developer: dude person (https://steamcommunity.com/id/123ii854734653463)

---@class CheatCoreCM
---@field PZVersion number
---@field MasterKey boolean
---@field EventDisableKey number
---@field DoNotFill boolean
---@field DeleteWithoutWall boolean
---@field DeleteWithoutDoorWindow boolean
---@field DeleteWithCorpse boolean
---@field DeleteOnlyCorpse boolean
---@field DeleteWithZombie boolean
---@field DoLuaChecksum boolean?
---@field DeathMessage number
---@field IsFreezeTime boolean?
---@field IsActionCheat boolean?
---@field TimeOfDay number?
---@field SelectedVehicle BaseVehicle|nil
---@field AnimalBrushEnabled boolean?
---@field AnimalsToSpawn number|nil
---@field AnimalTypeToSpawn string|nil
---@field AnimalBreedToSpawn string|nil
---@field VehicleSpawnCondition number|nil

CheatCoreCM = CheatCoreCM or {}
require "CheatMenuPhoenix/Terraform/CheatMenuTerraformTiles"

CheatCoreCM.PZVersion = tonumber(string.match(getCore():getVersionNumber(), "%d+"))
CheatCoreCM.MasterKey = false
CheatCoreCM.EventDisableKey = 0

CheatCoreCM.DoNotFill = false
CheatCoreCM.DeleteWithoutWall = false
CheatCoreCM.DeleteWithoutDoorWindow = false
CheatCoreCM.DeleteWithCorpse = false
CheatCoreCM.DeleteOnlyCorpse = false
CheatCoreCM.DeleteWithZombie = false
CheatCoreCM.DoLuaChecksum = nil
CheatCoreCM.DeathMessage = 0
CheatCoreCM.IsAmmo = false
CheatCoreCM.IsNightVision = false
CheatCoreCM.VehicleSpawnCondition = 1.0

CheatCoreCM.AnimalBrushEnabled = false
CheatCoreCM.AnimalsToSpawn = 1
CheatCoreCM.AnimalTypeToSpawn = "rabbit"
CheatCoreCM.AnimalBreedToSpawn = "default"

CheatCoreCM.GhostRadius = 30
CheatCoreCM.TrackedZombies = {}

local Ori_MinDamage, Ori_MaxDamage, Ori_DoorDamage, CMWeaponOldName, Ori_RecoilDelay

function CheatCoreCM.checkFile(modID, fileName)
    local readFile = getModFileReader(modID, fileName, true)
    if not readFile then
        local writeFile = getModFileWriter(modID, fileName, true, false)
        if writeFile then
            writeFile:write("{}")
            writeFile:close()
        end
        return
    end
    local scanLine = readFile:readLine()
    if not scanLine then
        local writeFile = getModFileWriter(modID, fileName, true, false)
        if writeFile then
            writeFile:write("{}")
            writeFile:close()
        end
    end
end

function CheatCoreCM.readFile(modID, fileName)
    local fileTable = {}
    local readFile = getModFileReader(modID, fileName, true)
    if not readFile then
        return fileTable
    end
    local scanLine = readFile:readLine()
    while scanLine do
        fileTable[#fileTable+1] = scanLine
        scanLine = readFile:readLine()
        if not scanLine then break end
    end
    readFile:close()
    return fileTable
end

Events.OnGameStart.Add(function()
    CheatCoreCM.IsFreezeTime   = false
    CheatCoreCM.IsActionCheat  = false
    CheatCoreCM.IsAmmo = false
    CheatCoreCM.IsInfiniteCarryWeight = false
    local md = getPlayer():getModData()
    md.IsFreezeTime  = false
    md.IsActionCheat = false
    md.IsInfiniteAmmo = false
    md.IsInfiniteCarryWeight = false
    getPlayer():setWearingNightVisionGoggles(false)
end)

function CheatCoreCM.writeFile(tableToWrite, modID, fileName)
    local writeFile = getModFileWriter(modID, fileName, true, false)
    if not writeFile then
        return
    end
    for i = 1,#tableToWrite do
        writeFile:write(tableToWrite[i].."\r\n");
    end
    writeFile:close();
end

function CheatCoreCM.doRound(number)
    return number % 1 >= 0.5 and math.ceil(number) or math.floor(number)
end

function CheatCoreCM.enumJavaArray(array)
    local tbl = {}
    for i = array:size() - 1, 0, -1 do
        local obj = array:get(i)
        table.insert(tbl, obj)
    end
    return tbl
end

function CheatCoreCM.HandleToggle(DisplayName, VariableToToggle, ...)
    if VariableToToggle ~= nil then
        VariableToToggle = string.gsub(VariableToToggle, "CheatCoreCM.", "")
        _G.CheatCoreCM[VariableToToggle] = not _G.CheatCoreCM[VariableToToggle]

        local gvar = _G.CheatCoreCM[VariableToToggle]
        if VariableToToggle == "IsGod" or VariableToToggle == "IsGhost" or VariableToToggle == "IsNoClip" or VariableToToggle == "IsInfiniteCarryWeight" or VariableToToggle == "IsFly" then
            _G.getPlayer():getModData()[VariableToToggle] = gvar
        end

        if VariableToToggle == "IsInfiniteCarryWeight" and gvar == false then
            CheatCoreCM.CleanupCarryWeightCheat()
        end

        if DisplayName ~= nil then
            getPlayer():Say(DisplayName.. (gvar == true and getText("UI_CMRB_Message_IsEnabled") or getText("UI_CMRB_Message_IsDisabled")))
        end
    end
    local args = {...}
    if #args > 0 then
        for i = 1,#args do
            if type(args[i]) == "string" then
                local func = loadstring(args[i])
                if func then
                    func()
                end
            else
                pcall(args[i])
            end
        end
    end
end

function CheatCoreCM.HandleCheck(variableToCheck, cheatName, optionalSecondVariable, optionalCheatName)
    local sayString = {}
    local checkFunc = loadstring("return "..variableToCheck)
    if checkFunc and checkFunc() ~= true then
        local setFunc = loadstring(variableToCheck.." = true")
        if setFunc then
            setFunc()
        end
        table.insert(sayString, cheatName)
    end
    if optionalSecondVariable ~= nil then 
        local checkFunc2 = loadstring("return "..optionalSecondVariable)
        if checkFunc2 and checkFunc2() ~= true then
            local setFunc2 = loadstring(optionalSecondVariable.." = true")
            if setFunc2 then
                setFunc2()
            end
            table.insert(sayString, optionalCheatName)
        end
    end
    if #sayString > 1 then
        getPlayer():Say(cheatName..getText("UI_CMRB_Message_And")..optionalCheatName..getText("UI_CMRB_Message_IsEnabled"))
    elseif #sayString == 1 then
        getPlayer():Say(cheatName..getText("UI_CMRB_Message_IsEnabled"))
    end
end

function CheatCoreCM.getMouseCoords()
    local x = getMouseXScaled();
    local y = getMouseYScaled();
    local z = getPlayer():getZ();
    local wx, wy = ISCoordConversion.ToWorld(x, y, z);
    wx = math.floor(wx);
    wy = math.floor(wy);
    return x, y, z, wx, wy
end

function CheatCoreCM.OnClick()
    local _, _, wz, wx, wy = CheatCoreCM.getMouseCoords()

    if CheatCoreCM.IsSelect == true then
        --local vehicle = getNearVehicle()
        local cell = getWorld():getCell();
        local sq = cell:getGridSquare(wx, wy, wz)
        local vehicle = sq:getVehicleContainer()
        if vehicle ~= nil then
            CheatCoreCM.SelectedVehicle = vehicle
            CheatCoreCM.Parts = {}
            for i = vehicle:getPartCount()-1,0,-1 do
                local part = vehicle:getPartByIndex(i)
                local cat = part:getCategory() or "Other"
                local item = part:getId()
                if type(CheatCoreCM.Parts[cat]) ~= "table" then
                    CheatCoreCM.Parts[cat] = {}
                end
                CheatCoreCM.Parts[cat][item] = part
                if i == (vehicle:getPartCount() - 1) then
                    CheatCoreCM.IsReady = true 
                end
            end
            CheatCoreCM.IsSelect = false
            getPlayer():Say(getText("IGUI_VehicleName" .. vehicle:getScript():getName()) .. getText("UI_CMRB_Message_VehicleSelected"))
        end
    end
end

function CheatCoreCM.getSqObjs()
    local _, _, wz, wx, wy = CheatCoreCM.getMouseCoords()
    --[[
    local mx = getMouseXScaled();
    local my = getMouseYScaled();
    local wz = getPlayer():getZ();
    local wx, wy = ISCoordConversion.ToWorld(mx, my, wz);
    wx = math.floor(wx);
    wy = math.floor(wy);
    --]]
    local cell = getWorld():getCell();
    local sq = cell:getGridSquare(wx, wy, wz);
    if sq == nil then return false; end
    local sqObjs = sq:getObjects();
    local sqSize = sqObjs:size();
    local tbl = {}
    local obj
    for i = sqSize-1, 0, -1 do -- enumerate square objects and pack them into a table
        obj = sqObjs:get(i);
        table.insert(tbl, obj)
    end
    return sq, sqObjs, tbl, cell, obj
end

CheatCoreCM.CM_TempCoord = nil;
function CheatCoreCM.OnKeyKeepPressed(_keyPressed)
    if CheatCoreCM.FireBrushEnabled == true then
        local GridToBurn = CheatCoreCM.getSqObjs()
        if GridToBurn then
            if _keyPressed == 49 then
                IsoFireManager.StartFire(getCell(), GridToBurn, true, 100, 500)
            elseif _keyPressed == 33 then
                GridToBurn:stopFire()
                if isClient() then
                    GridToBurn:transmitStopFire()
                end
            end
        end
    end

    if CheatCoreCM.IsDelete == true and _keyPressed == 45 then
        local sq, _, objTbl = CheatCoreCM.getSqObjs()

        if not sq or not objTbl then return end

        if (CheatCoreCM.DeleteWithCorpse or CheatCoreCM.DeleteOnlyCorpse) then
            local deadbodies = sq:getDeadBodys()
            if deadbodies and deadbodies:size() > 0 then
                for i = deadbodies:size() - 1, 0, -1 do
                    sq:removeCorpse(deadbodies:get(i), false)
                end
            end
        end

        if not CheatCoreCM.DeleteOnlyCorpse then
            if CheatCoreCM.DeleteWithZombie then
                local zombieobject = sq:getZombie()
                if zombieobject then
                    zombieobject:removeFromWorld()
                    zombieobject:removeFromSquare()
                end
            end

            local function shouldDeleteObject(wallCheck, windowCheck)
                if (CheatCoreCM.DeleteWithoutWall and wallCheck ~= "wall") and (windowCheck == 0 and CheatCoreCM.DeleteWithoutDoorWindow) then
                    return true
                elseif (CheatCoreCM.DeleteWithoutWall and wallCheck ~= "wall") and not CheatCoreCM.DeleteWithoutDoorWindow then
                    return true
                elseif (windowCheck == 0 and CheatCoreCM.DeleteWithoutDoorWindow) and not CheatCoreCM.DeleteWithoutWall then
                    return true
                elseif not CheatCoreCM.DeleteWithoutWall and not CheatCoreCM.DeleteWithoutDoorWindow then
                    return true
                end
                return false
            end

            local function deleteServerObject(object)
                sq:RemoveTileObject(object)
                sq:getSpecialObjects():remove(object)
                sq:getObjects():remove(object)
            end

            for i = 1, #objTbl do
                local obj = objTbl[i]
                if obj then
                    local sprite = obj:getSprite()
                    if sprite and sprite:getProperties():has(IsoFlagType.solidfloor) ~= true then
                        local WallCheck = tostring(obj:getType()) or nil
                        local WindowCheck = instanceof(obj, "IsoDoor") or instanceof(obj, "IsoWindow") or instanceof(obj, "IsoThumpable") and 1 or 0

                        local stairObjects = buildUtil.getStairObjects(obj, false)
                        if #stairObjects > 0 then
                            for j=1,#stairObjects do
                                if isClient() then
                                    sledgeDestroy(stairObjects[j])
                                else
                                    stairObjects[j]:getSquare():RemoveTileObject(stairObjects[j])
                                end
                            end
                        elseif shouldDeleteObject(WallCheck, WindowCheck) then
                            if isClient() then
                                sledgeDestroy(obj)
                            else
                                deleteServerObject(obj)
                            end
                        end
                    end
                end
            end
        end
    end

    if CheatCoreCM.IsTerraforming == true and _keyPressed == 45 then
        local sq, _, objTbl = CheatCoreCM.getSqObjs()

        --[[
        if sq == nil then
            sq = cell:createNewGridSquare(wx, wy, wz)
            cell:ConnectNewSquare(sq, false)
        end
        --]]
        if not sq or not objTbl then
            --print("[CHEAT MENU] Attempted to terraform non-existent square")
            return
        end

        local rand;
        if #CheatCoreCM.TerraformRanges > 1 then
            rand = ZombRand(CheatCoreCM.TerraformRanges[1],CheatCoreCM.TerraformRanges[2] + 1)
            if CheatCoreCM.BannedRanges ~= nil then
                for i = 1,#CheatCoreCM.BannedRanges do
                    if rand == CheatCoreCM.BannedRanges[i] then
                        rand = rand + ZombRand(1,2 + 1) <= CheatCoreCM.TerraformRanges[2] or rand - ZombRand(1,2 + 1)
                    end
                end
            end
        else
            rand = CheatCoreCM.TerraformRanges[1]
        end

        local generatedTile = CheatCoreCM.Terraform..tostring(rand)
        local obj;
        local sprite;

        for i = 1, #objTbl do
            obj = objTbl[i]
            if obj then
                sprite = obj:getSprite()

                if sprite and sprite:getProperties():has(IsoFlagType.solidfloor) then
                    break
                end
            end
        end

        if sq ~= CheatCoreCM.CM_TempCoord then
            if not (CheatCoreCM.DoNotFill and not sq:getFloor()) then
                sq:addFloor(generatedTile)
                CheatCoreCM.CM_TempCoord = sq
            end
        end
    end
end

function CheatCoreCM.OnKeyPressed (_keyPressed, _)
    if CheatCoreCM.ZombieBrushEnabled and _keyPressed == 44 then
        local _, _, wz, wx, wy = CheatCoreCM.getMouseCoords()
        wx, wy, wz = math.floor(wx), math.floor(wy), math.floor(wz)

        local versionNumber = tonumber(string.match(getCore():getVersionNumber(), "%d+"))

        if not CheatCoreCM.ZombiesToSpawn then
            getPlayer():Say(getText("UI_CMRB_Message_NoZombieAmount"))
        elseif versionNumber >= 41 then
            if isClient() then
                SendCommandToServer(string.format("/createhorde2 -x %d -y %d -z %d -count %d", wx, wy, wz, CheatCoreCM.ZombiesToSpawn))
            else
                for i = 1, CheatCoreCM.ZombiesToSpawn do
                    ---@diagnostic disable-next-line: param-type-mismatch
                    addZombiesInOutfit(wx, wy, wz, 1, nil, 50)
                end
            end
        elseif versionNumber >= 32 then
            spawnHorde(wx,wy,wx,wy,wz,CheatCoreCM.ZombiesToSpawn)
        else
            for _ = 1, CheatCoreCM.ZombiesToSpawn do
                ---@diagnostic disable-next-line: undefined-global
                getVirtualZombieManager():createRealZombieNow(wx,wy,wz);
            end
        end
    end

    if CheatCoreCM.AnimalBrushEnabled and _keyPressed == 21 then
        local _, _, wz, wx, wy = CheatCoreCM.getMouseCoords()
        wx, wy, wz = math.floor(wx), math.floor(wy), math.floor(wz)
        local sq = getCell():getGridSquare(wx, wy, wz)

        if sq then
            ---@diagnostic disable-next-line: undefined-field
            local def = AnimalDefinitions.getDef(CheatCoreCM.AnimalTypeToSpawn)
            if def then
                if isClient() then
                    local breed = (CheatCoreCM.AnimalBreedToSpawn == "default") and def:getRandomBreed() or def:getBreedByName(CheatCoreCM.AnimalBreedToSpawn)
                    if not breed then breed = def:getRandomBreed() end
                    local breedName = breed:getName()
                    for i = 1, CheatCoreCM.AnimalsToSpawn do
                        ---@diagnostic disable: param-type-mismatch, redundant-parameter
                        sendClientCommandV(getPlayer(), "animal", "add",
                                "type", CheatCoreCM.AnimalTypeToSpawn,
                                "breed", breedName,
                                "x", wx,
                                "y", wy,
                                "z", wz,
                                "skeleton", false)
                        ---@diagnostic enable: param-type-mismatch, redundant-parameter
                    end
                else
                    local breed = (CheatCoreCM.AnimalBreedToSpawn == "default") and def:getRandomBreed() or def:getBreedByName(CheatCoreCM.AnimalBreedToSpawn)
                    if not breed then breed = def:getRandomBreed() end
                    for i = 1, CheatCoreCM.AnimalsToSpawn do
                        local animal = addAnimal(getCell(), wx, wy, wz, CheatCoreCM.AnimalTypeToSpawn, breed, false)
                        if animal then
                            animal:addToWorld()
                        end
                    end
                end
            end
        end
    end

    if CheatCoreCM.IsBarricade and _keyPressed == 44 then
        local _, sqObjs = CheatCoreCM.getSqObjs()
        if sqObjs then
            local player = getPlayer()
            for i = sqObjs:size()-1, 0, -1 do
                local obj = sqObjs:get(i)
                if obj and instanceof(obj, "BarricadeAble") then
                    local isMetal = CheatCoreCM.BarricadeType == "metal"
                    ---@type any
                    local tempObj = obj
                    local barricade = IsoBarricade.AddBarricadeToObject(tempObj, isMetal)
                    local item = player:getInventory():AddItem(isMetal and "Base.SheetMetal" or "Base.Plank")
                    if item then
                        ---@cast item InventoryItem
                        local numPlanks = barricade:getNumPlanks()

                        if CheatCoreCM.BarricadeLevel > numPlanks and not barricade:isMetal() then
                            local count = isMetal and 1 or (CheatCoreCM.BarricadeLevel - numPlanks)
                            for _ = 1, count do
                                if isClient() then
                                    local args = {x=obj:getX(), y=obj:getY(), z=obj:getZ(), index=obj:getObjectIndex(), isMetal=isMetal, itemID=item:getID(), condition=item:getCondition()}
                                    sendClientCommand(player, 'object', 'barricade', args)
                                else
                                    if isMetal then barricade:addMetal(player, item) else barricade:addPlank(player, item) end
                                end
                            end
                        elseif barricade:isMetal() then
                            barricade:removeMetal(player)
                        else
                            for _ = 1, numPlanks - CheatCoreCM.BarricadeLevel do
                                barricade:removePlank(player)
                            end
                        end
                        player:getInventory():Remove(item)
                        player:Say(getText("UI_CMRB_Message_BarricadeCreated"))
                    end
                end
            end
        end
    end

    if CheatCoreCM.IsFly == true or getPlayer():getModData().IsFly == true then
        if CheatCoreCM.FlightHeight == nil then CheatCoreCM.FlightHeight = getPlayer():getZ() end

        if _keyPressed == 200 and getPlayer():getZ() < 5 then
            CheatCoreCM.FlightHeight = CheatCoreCM.FlightHeight + 1
        elseif _keyPressed == 208 and getPlayer():getZ() > 0 then
            CheatCoreCM.FlightHeight = CheatCoreCM.FlightHeight - 1
        end
    end
end

function CheatCoreCM.RemoveAllZombiesServer()
    SendCommandToServer(string.format("/removezombies -remove true"))
    getPlayer():Say(getText("UI_CMRB_Message_ZombieRemoveServer"))
end

function CheatCoreCM.RemoveAllZombiesClient()
local count = 0
    local zombies = getCell():getObjectListForLua()
    for i=zombies:size(),1,-1 do
        local zombie = zombies:get(i-1)
        if instanceof(zombie, "IsoZombie") then
            count = count + 1
            zombie:removeFromWorld()
            zombie:removeFromSquare()
        end
    end
    getPlayer():Say(getText("UI_CMRB_Message_ZombieRemove1")..count..getText("UI_CMRB_Message_ZombieRemove2"))
end

function CheatCoreCM.RemoveAllAnimalsClient()
    local count = 0
    local animals = getCell():getObjectListForLua()
    for i=animals:size(),1,-1 do
        local animal = animals:get(i-1)
        if instanceof(animal, "IsoAnimal") then
            count = count + 1
            animal:removeFromWorld()
            animal:removeFromSquare()
        end
    end
    getPlayer():Say(getText("UI_CMRB_Message_ZombieRemove1")..count.. " animaux" ..getText("UI_CMRB_Message_ZombieRemove2"))
end

function CheatCoreCM.RemoveAllAnimalsServer()
    -- No built-in server command for removing all animals yet
    -- For now we use the client side removal on the local chunk
    CheatCoreCM.RemoveAllAnimalsClient()
end

function CheatCoreCM.highlightSquare()
    if CheatCoreCM.IsBarricade == true or CheatCoreCM.FireBrushEnabled == true or CheatCoreCM.IsDelete == true or CheatCoreCM.IsSelect == true or CheatCoreCM.FireBrushEnabled == true or CheatCoreCM.IsDelete == true or CheatCoreCM.IsTerraforming == true or CheatCoreCM.ZombieBrushEnabled == true or CheatCoreCM.AnimalBrushEnabled == true then 
        local mx = getMouseXScaled();
        local my = getMouseYScaled();
        local player = getPlayer();
        local wz = player:getZ();
        local wx, wy = ISCoordConversion.ToWorld(mx, my, wz);
        wx = math.floor(wx);
        wy = math.floor(wy);
        local cell = getWorld():getCell();
        local sq = cell:getGridSquare(wx, wy, wz);
        if sq ~= nil then
            local sqObjs = sq:getObjects();
            local sqSize = sqObjs:size();
            for i = sqSize - 1, 0, -1 do
                local obj = sqObjs:get(i)
                obj:setHighlighted(true)
            end
        end
    end
end

function CheatCoreCM.updateCoords()
    ---@diagnostic disable-next-line: undefined-field
    if GPSWindow:isVisible() then
        GPSWindow.compassLines[1] = getText("UI_CMRB_GPS_TargetLocation").."<LINE>"..CheatCoreCM.DisplayName.." <LINE> ".."X: "..CheatCoreCM.MarkedX.." Y: "..CheatCoreCM.MarkedY.." <LINE><LINE> "
        GPSWindow.compassLines[2] = getText("UI_CMRB_GPS_CurrentCoord").."<LINE> ".."X: "..CheatCoreCM.doRound(getPlayer():getX()).." Y: "..CheatCoreCM.doRound(getPlayer():getY()).." <LINE><LINE> "
        GPSWindow.compassLines[3] = getText("UI_CMRB_GPS_TargetDistance").." <LINE> ".."X: "..CheatCoreCM.checkCoords(tonumber(CheatCoreCM.MarkedX), getPlayer():getX()).." Y: "..CheatCoreCM.checkCoords(tonumber(CheatCoreCM.MarkedY), getPlayer():getY())..""
        CheatCoreCM.updateCompass()
    end
end

function CheatCoreCM.updateCompass()
    local newText = "";
    for i,v in ipairs(GPSWindow.compassLines) do
        if i == #GPSWindow.compassLines then
            v = string.gsub(v, " <LINE> $", "")
        end
        newText = newText .. v;
    end
    GPSWindow.HomeWindow.text = newText
    GPSWindow.HomeWindow:paginate()
end

function CheatCoreCM.checkCoords(number1, number2)
    local doRound = CheatCoreCM.doRound(number2)
    if doRound >= number1 then
        return doRound - number1
    else
        return number1 - doRound
    end
end

local CMCurrentEquipment = nil
local CMWeaponName = nil
local CMWeaponTrigger = 0

function CheatCoreCM.CheckEquipment()
    local player = getPlayer()
    local weapon = player:getPrimaryHandItem()
    local itemList = getAllItems()
    local itemListSize = itemList:size()
    if weapon ~= nil then
    CMWeaponName = weapon:getFullType()
        for i = itemListSize-1,0,-1 do
            local itemList_items = itemList:get(i)
            --local invItem = instanceItem(itemList_items)
            local itemname = itemList_items:getFullName()
            if CMWeaponName ~= CMWeaponOldName then
                if string.match (tostring(itemname), tostring(CMWeaponName)) then
                    Ori_DoorDamage = itemList_items:getDoorDamage()
                    Ori_MaxDamage = itemList_items:getMaxDamage()
                    Ori_MinDamage = itemList_items:getMinDamage()
                    --Ori_RecoilDelay = itemList_items:getRecoilDelay()
                    CMCurrentEquipment = weapon:getID()
                    CMWeaponOldName = CMWeaponName
                    --print (Ori_MinDamage)
                    --print (Ori_MaxDamage)
                end
            end
        end
    end
    return Ori_DoorDamage, Ori_MaxDamage, Ori_MinDamage, Ori_MinDamage, Ori_RecoilDelay, CMCurrentEquipment, CMWeaponName
end

function CheatCoreCM.DoVehicleGodMode()
    if CheatCoreCM.MasterKey then
        CheatCoreCM.MadMax = false
        return
    end

    if CheatCoreCM.MadMax then
        local player = getPlayer()
        ---@diagnostic disable-next-line: undefined-field
        local vehicle = player:getVehicle() or CheatCoreCM.SelectedVehicle
        if vehicle then
            ---@diagnostic disable-next-line: undefined-field
            vehicle:repair()
        end
    end
end

function CheatCoreCM.CheckCheatEnabled()
    if not getPlayer():isGodMod() then
        CheatCoreCM.IsGod = false
    end

    -- if not ISHealthPanel.cheat or not getPlayer():isHealthCheat() then
    if not ISHealthPanel.cheat then
        CheatCoreCM.IsHelathCheat = false
    end

    -- if not ISBuildMenu.cheat and not ISMoveableDefinitions.cheat or not getPlayer():	isBuildCheat() and getPlayer():isMovablesCheat() then
    if not ISBuildMenu.cheat and not ISMoveableDefinitions.cheat then
        CheatCoreCM.IsCreativeMode = false
    end

    if not getPlayer():isNoClip() then
        CheatCoreCM.IsNoClip = false
    end

    -- if not ISVehicleMechanics.cheat or not getPlayer():isMechanicsCheat() then
    if not ISVehicleMechanics.cheat then
        CheatCoreCM.IsMechanicsCheat = false
    end
end

function CheatCoreCM.FlyMode()
    if CheatCoreCM.MasterKey then return end

    local player = getPlayer()
    local modData = player:getModData()
    local isFlyEnabled = (CheatCoreCM.IsFly or modData.IsFly) and CheatCoreCM.FlightHeight ~= nil

    if isFlyEnabled then
        player:setZ(CheatCoreCM.FlightHeight)
        player:setbFalling(false)
        player:setFallTime(0)
        player:setLastFallSpeed(0)
        modData.IsFly = true
    else
        player:setbFalling(true)
        modData.IsFly = false
        CheatCoreCM.FlightHeight = player:getZ()
        modData.FlightHeight = CheatCoreCM.FlightHeight
    end

    -- Grid square connection logic
    local wz = math.floor(player:getZ())
    if wz > 0 then
        local wx, wy = math.floor(player:getX()), math.floor(player:getY())
        local cell = getWorld():getCell()

        local squares = {
            {x = wx, y = wy},
            {x = wx + 1, y = wy + 1}
        }

        for _, pos in ipairs(squares) do
            local sq = cell:getGridSquare(pos.x, pos.y, wz)
            if not sq then
                ---@diagnostic disable-next-line: param-type-mismatch
                sq = IsoGridSquare.new(cell, nil, pos.x, pos.y, wz)
                cell:ConnectNewSquare(sq, false)
            end
        end
    end
end

function CheatCoreCM.FreezeTime()
    if CheatCoreCM.MasterKey then
        CheatCoreCM.IsFreezeTime = false
        return
    end

    local player = getPlayer()
    if not CheatCoreCM.IsFreezeTime then
        CheatCoreCM.TimeOfDay = nil
        player:getModData().IsFreezeTime = false
        return
    end

    local time = getGameTime()
    if not CheatCoreCM.TimeOfDay then
        CheatCoreCM.TimeOfDay = time:getTimeOfDay() -- stores the current time of day
    end

    ---@cast CheatCoreCM.TimeOfDay number
    time:setTimeOfDay(CheatCoreCM.TimeOfDay)
    player:getModData().IsFreezeTime = true
end

function CheatCoreCM.UpdateGhostZombies()
    if not CheatCoreCM.IsGhost then return end

    local player = getPlayer()
    if not player then return end

    local world = getWorld()
    if not world then return end

    local cell = world:getCell()
    if not cell then return end

    local zombieList = cell:getZombieList()
    if not zombieList or zombieList:size() == 0 then return end

    local playerX = player:getX()
    local playerY = player:getY()
    local radiusSquared = CheatCoreCM.GhostRadius * CheatCoreCM.GhostRadius

    local processedZombies = {}

    for i = 0, zombieList:size() - 1 do
        local zombie = zombieList:get(i)
        if zombie then
            local distSquared = (zombie:getX() - playerX) ^ 2 + (zombie:getY() - playerY) ^ 2
            processedZombies[zombie] = true

            if distSquared <= radiusSquared then
                if not zombie:isUseless() then
                    zombie:setUseless(true)
                    CheatCoreCM.TrackedZombies[zombie] = true
                end
            else
                if zombie:isUseless() and CheatCoreCM.TrackedZombies[zombie] then
                    zombie:setUseless(false)
                    CheatCoreCM.TrackedZombies[zombie] = nil
                end
            end
        end
    end

    for zombie, _ in pairs(CheatCoreCM.TrackedZombies) do
        if not processedZombies[zombie] and zombie:isUseless() then
            zombie:setUseless(false)
            CheatCoreCM.TrackedZombies[zombie] = nil
        end
    end
end

function CheatCoreCM.DoGhostMode()
    if CheatCoreCM.MasterKey then
        CheatCoreCM.IsGhost = false
    end

    local player = getPlayer()
    player:getModData().IsGhost = CheatCoreCM.IsGhost

    if not CheatCoreCM.IsGhost then
        local zombieList = getWorld():getCell():getZombieList()
        for i = 0, zombieList:size() - 1 do
            local zombie = zombieList:get(i)
            if zombie and zombie:isUseless() and CheatCoreCM.TrackedZombies[zombie] then
                zombie:setUseless(false)
            end
        end
        CheatCoreCM.TrackedZombies = {}
    end
end

function CheatCoreCM.DoGodMode()
    if CheatCoreCM.MasterKey then
        CheatCoreCM.IsGod = false
    end

    local player = getPlayer()
    player:setGodMod(CheatCoreCM.IsGod, false)
    player:getModData().IsGod = CheatCoreCM.IsGod
end

function CheatCoreCM.DoCreativeMode()
    if CheatCoreCM.MasterKey then
        CheatCoreCM.IsCreativeMode = false
    end

    local player = getPlayer()
    local isEnabled = CheatCoreCM.IsCreativeMode

    ISBuildMenu.cheat = isEnabled
    ISMoveableDefinitions.cheat = isEnabled
    player:setBuildCheat(isEnabled)
    player:setMovablesCheat(isEnabled)
    player:getModData().IsCreativeMode = isEnabled
end

function CheatCoreCM.DoHealthCheat()
    if CheatCoreCM.MasterKey then
        CheatCoreCM.IsHelathCheat = false
    end

    local player = getPlayer()
    local isEnabled = CheatCoreCM.IsHelathCheat

    ISHealthPanel.cheat = isEnabled
    player:setHealthCheat(isEnabled)
    player:getModData().IsHelathCheat = isEnabled
end

function CheatCoreCM.DoMechanicsCheat()
    if CheatCoreCM.MasterKey then
        CheatCoreCM.IsMechanicsCheat = false
    end

    local player = getPlayer()
    local isEnabled = CheatCoreCM.IsMechanicsCheat

    ISVehicleMechanics.cheat = isEnabled
    player:setMechanicsCheat(isEnabled)
    player:getModData().IsMechanicsCheat = isEnabled
end

function CheatCoreCM.dragDownDisable()
    if CheatCoreCM.PZVersion >= 41 then
        local sb = SandboxOptions:getInstance()
        if getPlayer():getModData().IsGod == true then
            ---@diagnostic disable-next-line: undefined-field
            local DragdownCheck = sb:getOptionByName("ZombieLore.ZombiesDragDown"):getValue()
            if DragdownCheck == true then
                getPlayer():getModData().CMmodifiedSB = true
                sb:set("ZombieLore.ZombiesDragDown", false);
                -- print("[CHEAT MENU] ZombiesDragDown set to False to prevent God Mode instadeath")
            end
        elseif getPlayer():getModData().CMmodifiedSB == true then
            getPlayer():getModData().CMmodifiedSB = false
            sb:set("ZombieLore.ZombiesDragDown", true)
            -- print("[CHEAT MENU] God Mode disabled, ZombiesDragDown value restored to True")
        end
    end
end

function CheatCoreCM.DoNoClipMode()
    ISDebugMenu.forceEnable = true
    if CheatCoreCM.MasterKey == false then
        if CheatCoreCM.IsNoClip == true then
            CheatCoreCM.IsNoClip = true
            getPlayer():setNoClip(true, false)
            getPlayer():getModData().IsNoClip = true
        else
            CheatCoreCM.IsNoClip = false
            getPlayer():setNoClip(false, false)
            getPlayer():getModData().IsNoClip = false
        end
    else
        CheatCoreCM.IsNoClip = false
        getPlayer():setNoClip(false, false)
        getPlayer():getModData().IsNoClip = false
    end
end

function CheatCoreCM.DoCarryWeightCheat(player)
    player = player or getPlayer()
    if not player then return end
    local data = player:getModData()

    if CheatCoreCM.IsInfiniteCarryWeight or data.IsInfiniteCarryWeight then
        if not data.OldMaxWeightBase then
            data.OldMaxWeightBase = player:getMaxWeightBase()
        end
        if not data.OldInventoryCapacity then
            data.OldInventoryCapacity = player:getInventory():getCapacity()
        end
        player:setMaxWeightBase(750)
        -- Limit capacity to 100 to avoid log spam in B42.15
        player:getInventory():setCapacity(100)
        data.IsInfiniteCarryWeight = true
    else
        CheatCoreCM.CleanupCarryWeightCheat(player)
    end
end

function CheatCoreCM.CleanupCarryWeightCheat(player)
    player = player or getPlayer()
    if not player then return end
    local data = player:getModData()

    if data.OldMaxWeightBase then
        player:setMaxWeightBase(data.OldMaxWeightBase)
        data.OldMaxWeightBase = nil
    end

    if data.OldInventoryCapacity then
        player:getInventory():setCapacity(data.OldInventoryCapacity)
        data.OldInventoryCapacity = nil
    else
        -- Restoring capacity to a reasonable value (50 is vanilla default) if it was high
        local currentCap = player:getInventory():getCapacity()
        if currentCap > 50 then
            player:getInventory():setCapacity(50)
        end
    end
    data.IsInfiniteCarryWeight = false
end

function CheatCoreCM.ToggleInstantActions()
    if CheatCoreCM.MasterKey == true then
        CheatCoreCM.IsActionCheat = false
    end
end

function CheatCoreCM.DoSuicide_With_Zombified()
    local player = getPlayer()
    local bodyDamage = player:getBodyDamage()
    bodyDamage:SetBitten(BodyPartType.Head, true)
    bodyDamage:setInfectionTime(0.1)
    player:setHealth(0)
end

function CheatCoreCM.DoSuicide_Without_Zombified()
    getPlayer():setHealth(0)
end

function CheatCoreCM.DoRepair()
    local ToolToRepairP = getPlayer():getPrimaryHandItem()
    if ToolToRepairP ~= nil then
        ToolToRepairP:setCondition( ToolToRepairP:getConditionMax(), false ) 
        getPlayer():Say(getText("UI_CMRB_Message_RepairedPEquippedItem"))
    else
        getPlayer():Say(getText("UI_CMRB_Message_NoPItems"))
    end
    local ToolToRepairS = getPlayer():getSecondaryHandItem()  
    if ToolToRepairS ~= nil and ToolToRepairP ~= ToolToRepairS then
        ToolToRepairS:setCondition( ToolToRepairS:getConditionMax(), false ) 
        getPlayer():Say(getText("UI_CMRB_Message_RepairedSEquippedItem"))
    else
        getPlayer():Say(getText("UI_CMRB_Message_NoSItems"))
    end
end

function CheatCoreCM.DoALLRepair()
    local player = getPlayer()
    local InventoryItemList = player:getInventory():getItems()

    if InventoryItemList ~= nil then
    local InventorySize = InventoryItemList:size()
        for i = 0, InventorySize -1 do
            local Inventory_Items = InventoryItemList:get(i)
            Inventory_Items:setCondition(Inventory_Items:getConditionMax(), false)

            if Inventory_Items:IsWeapon() and Inventory_Items:getStringItemType() == "RangedWeapon" then
                Inventory_Items:setCurrentAmmoCount(Inventory_Items:getMaxAmmo())
                ---@diagnostic disable-next-line: undefined-field
                Inventory_Items:setContainsClip(true)
                ---@diagnostic disable-next-line: undefined-field
                Inventory_Items:setRoundChambered(true)
                ---@diagnostic disable-next-line: undefined-field
                Inventory_Items:setJammed(false)
            end

            if Inventory_Items:IsClothing() then
                local ClothingParts = BloodClothingType.getCoveredParts(Inventory_Items:getBloodClothingType())
                for j = 0, ClothingParts:size() - 1 do
                    local Parts_Points = ClothingParts:get(j)
                    if Parts_Points then
                    --print (Parts_Points)
                        Inventory_Items:setBlood(Parts_Points, 0)
                        Inventory_Items:setDirt(Parts_Points, 0)
                    end
                end
                for k = 0, BloodBodyPartType.MAX:index() - 1 do
                    Inventory_Items:getVisual():removeHole(k)
                end
                if Inventory_Items:IsClothing() then
                    Inventory_Items:setCondition(Inventory_Items:getConditionMax(), false)
                    Inventory_Items:setBloodLevel(0)
                    if instanceof(Inventory_Items, "Clothing") then
                        ---@diagnostic disable-next-line: undefined-field
                        if Inventory_Items.setDirtyness then Inventory_Items:setDirtyness(0) end
                        Inventory_Items:finishupdate()
                        ---@diagnostic disable-next-line: undefined-field
                        if Inventory_Items.flushWetness then Inventory_Items:flushWetness() end
                    end
               end
            end
        end
        getPlayer():Say(getText("UI_CMRB_Message_RepairedAllItem"))
    else
        getPlayer():Say(getText("UI_CMRB_Message_NoInventoryItems"))
    end
end

function CheatCoreCM.DoWearClothesRepair()
    local player = getPlayer()
    local Wearing_Items = getPlayer():getWornItems()
    local Wearing_Items_Size = Wearing_Items:size()

    if Wearing_Items ~= nil then
    for i = 0, Wearing_Items_Size - 1 do
        local Current_Item_Parent = Wearing_Items:get(i)
        local Current_Item = Current_Item_Parent:getItem()
        local ClothingParts = BloodClothingType.getCoveredParts(Current_Item:getBloodClothingType())
            for j = 0, ClothingParts:size() - 1 do
                local Parts_Points = ClothingParts:get(j)
                 if Parts_Points then
                    Current_Item:setBlood(Parts_Points, 0)
                    Current_Item:setDirt(Parts_Points, 0)
                    end
                end
        for k = 0, BloodBodyPartType.MAX:index() - 1 do
        Current_Item:getVisual():removeHole(k)
        end
        if Current_Item:IsClothing() then
            Current_Item:setCondition(Current_Item:getConditionMax(), false)
            Current_Item:setBloodLevel(0)
            if instanceof(Current_Item, "Clothing") then
                ---@diagnostic disable-next-line: undefined-field
                if Current_Item.setDirtyness then Current_Item:setDirtyness(0) end
                ---@diagnostic disable-next-line: undefined-field
                if Current_Item.setWetness then Current_Item:setWetness(0) end
            end
       end
    end
        getPlayer():Say(getText("UI_CMRB_Message_RepairedWearingClothes"))
    else
        getPlayer():Say(getText("UI_CMRB_Message_NoWearingClothes"))
    end
    triggerEvent("OnClothingUpdated", player)
    player:resetModel()
end

function CheatCoreCM.DoStatsUpdate(player)
    player = player or getPlayer()
    if not player or not instanceof(player, "IsoPlayer") then return end

    local data = player:getModData()
    if not data then return end

    if CheatCoreCM.IsInfiniteCarryWeight or data.IsInfiniteCarryWeight then
        CheatCoreCM.DoCarryWeightCheat(player)
    end

    if CheatCoreCM.MasterKey == false then
        local stats = player:getStats()
        local body = player:getBodyDamage()

        if CheatCoreCM.IsHunger == true and stats then
            stats:set(CharacterStat.HUNGER, 0)
        end

        if CheatCoreCM.IsThirst == true and stats then
            stats:set(CharacterStat.THIRST, 0)
        end

        if CheatCoreCM.IsPanic == true and stats then
            stats:set(CharacterStat.PANIC, 0)
        end

        if CheatCoreCM.IsSanity == true and stats then
            stats:set(CharacterStat.SANITY, 1)
        end

        if CheatCoreCM.IsStress == true and stats then
            stats:set(CharacterStat.STRESS, 0)
        end

        if CheatCoreCM.IsFatigue == true and stats then
            stats:set(CharacterStat.FATIGUE, 0)
        end

        if CheatCoreCM.IsAnger == true and stats then
            stats:set(CharacterStat.ANGER, 0)
        end

        if CheatCoreCM.IsPain == true and stats then
            stats:set(CharacterStat.PAIN, 0)
        end

        if CheatCoreCM.IsSickness == true and stats then
            stats:set(CharacterStat.SICKNESS, 0)
        end

        if CheatCoreCM.IsDrunkenness == true and stats then
            stats:set(CharacterStat.INTOXICATION, 0)
        end

        if CheatCoreCM.IsEndurance == true and stats then
            stats:set(CharacterStat.ENDURANCE, 1)
        end

        if CheatCoreCM.IsFitness == true and stats then
            stats:set(CharacterStat.FITNESS, 1)
        end

        if CheatCoreCM.IsTemperature == true and stats then
            stats:set(CharacterStat.TEMPERATURE, 37)
        end

        if CheatCoreCM.IsUnhappy == true and stats then
            stats:set(CharacterStat.MORALE, 100)
        end

        if CheatCoreCM.IsBoredom == true and stats then
            stats:set(CharacterStat.BOREDOM, 0)
        end

        if CheatCoreCM.IsWet == true and stats then
            stats:set(CharacterStat.WETNESS, 0)
        end

        if CheatCoreCM.IsHunger and CheatCoreCM.IsThirst and CheatCoreCM.IsPanic and CheatCoreCM.IsSanity and CheatCoreCM.IsStress and CheatCoreCM.IsFatigue and CheatCoreCM.IsAnger and CheatCoreCM.IsPain and CheatCoreCM.IsSickness and CheatCoreCM.IsDrunkenness and CheatCoreCM.IsEndurance and CheatCoreCM.IsFitness and CheatCoreCM.IsTemperature and CheatCoreCM.IsWet and CheatCoreCM.IsUnhappy and CheatCoreCM.IsBoredom then
            CheatCoreCM.IsInfiniteStats = true
        else
            CheatCoreCM.IsInfiniteStats = false
            data.IsAllStats = false
        end

        CheatCoreCM.FlyMode()

    else
        CheatCoreCM.AllStatsDisabled()
    end
end

function CheatCoreCM.AllStatsEnabled()
    CheatCoreCM.IsHunger = true
    CheatCoreCM.IsThirst = true
    CheatCoreCM.IsPanic = true
    CheatCoreCM.IsPanic = true
    CheatCoreCM.IsSanity = true
    CheatCoreCM.IsStress = true
    CheatCoreCM.IsFatigue = true
    CheatCoreCM.IsAnger = true
    CheatCoreCM.IsPain = true
    CheatCoreCM.IsSickness = true
    CheatCoreCM.IsDrunkenness = true
    CheatCoreCM.IsEndurance = true
    CheatCoreCM.IsFitness = true
    CheatCoreCM.IsTemperature = true
    CheatCoreCM.IsWet = true
    CheatCoreCM.IsUnhappy = true
    CheatCoreCM.IsBoredom = true
end

function CheatCoreCM.AllStatsDisabled()
    CheatCoreCM.IsHunger = false
    CheatCoreCM.IsThirst = false
    CheatCoreCM.IsPanic = false
    CheatCoreCM.IsPanic = false
    CheatCoreCM.IsSanity = false
    CheatCoreCM.IsStress = false
    CheatCoreCM.IsFatigue = false
    CheatCoreCM.IsAnger = false
    CheatCoreCM.IsPain = false
    CheatCoreCM.IsSickness = false
    CheatCoreCM.IsDrunkenness = false
    CheatCoreCM.IsEndurance = false
    CheatCoreCM.IsFitness = false
    CheatCoreCM.IsTemperature = false
    CheatCoreCM.IsWet = false
    CheatCoreCM.IsUnhappy = false
    CheatCoreCM.IsBoredom = false
end

function CheatCoreCM.AllStatsToggle()
    if CheatCoreCM.MasterKey then return end

    if CheatCoreCM.IsInfiniteStats then
        CheatCoreCM.AllStatsEnabled()
    else
        CheatCoreCM.AllStatsDisabled()
    end
end

--[[
function CheatCoreCM.ToggleInstantCrafting()
    
    if not ISCraftingUI._render then
        ISCraftingUI._render = ISCraftingUI.render
    end
    
    if CheatCoreCM.IsCraftingCheat == true then
    --getPlayer():getModData().IsCraftingCheat = true
        ISCraftingUI._craft = ISCraftingUI.craft
        function ISCraftingUI:craft()		
            local selectedItem = self.panel.activeView.view.recipes.items[self.panel.activeView.view.recipes.selected].item
            local itemType = selectedItem.recipe:getResult():getFullType()
            
            local inventory = getPlayer():getInventory()
            inventory:AddItem( itemType )
        end
        
        RecipeManager._IsRecipeValid = RecipeManager.IsRecipeValid
        function RecipeManager.IsRecipeValid() return true end
        
        function ISCraftingUI:render()
            ISCraftingUI._render( self )
            
            self.craftOneButton.onclick = ISCraftingUI.craftAll
        end
        
    else
    --getPlayer():getModData().IsCraftingCheat = false
        ISCraftingUI.craft = ISCraftingUI._craft
        RecipeManager.IsRecipeValid = RecipeManager._IsRecipeValid
        
        function ISCraftingUI:render()
            ISCraftingUI._render( self )
            self.craftOneButton.onclick = ISCraftingUI.craft
        end
    end
end
--]]

function CheatCoreCM.DoMaxAllSkills()
    getPlayer():Say(getText("UI_CMRB_Message_ChangedLevel"))

    local pf = PerkFactory.PerkList
    local pfSize = PerkFactory.PerkList:size()	
    for i = pfSize-1, 0, -1 do -- loop through PerkList and set level to 10
        local obj = pf:get(i)
        local skill = obj:getType()

        getPlayer():level0(skill) 
        getPlayer():getXp():setXPToLevel(skill, 0) -- make sure that xp and level is set to 0 first before levelling
        for _ = 1,10 do -- then set it
            getPlayer():LevelPerk(skill, false)
        end
    end
end

function CheatCoreCM.DoResetAllSkills()
    getPlayer():Say(getText("UI_CMRB_Message_ResetLevel"))

    local pf = PerkFactory.PerkList
    local pfSize = PerkFactory.PerkList:size()
    for i = pfSize-1, 0, -1 do -- loop through PerkList and set level to 10
        local obj = pf:get(i)
        local skill = obj:getType()

        getPlayer():level0(skill) 
        getPlayer():getXp():setXPToLevel(skill, 0) 
    end
end

function CheatCoreCM.DoHeal()
    local Player = getPlayer()
    local PlayerVisual = Player:getHumanVisual()
    local PlayerBodyDmg = Player:getBodyDamage()

    PlayerBodyDmg:RestoreToFullHealth();
    PlayerVisual:removeDirt()
    PlayerVisual:removeBlood()
        local PlayerBodyParts = PlayerBodyDmg:getBodyParts()
        for i = 0, PlayerBodyParts:size() - 1 do
            local bodyPart = PlayerBodyParts:get(i)
            --local bloodBodyPartType = BloodBodyPartType.FromIndex(bodyPart:getIndex())
            bodyPart:setStiffness(0)
        end
        --[[
    for k,v in pairs(FitnessExercises.exercisesType) do
        local CR = getPlayer():getFitness():getCurrentExeStiffnessTimer(k)
    end
    --]]
    --getPlayer():getFitness():resetValues()

    Player:resetModel()
    Player:resetModelNextFrame()
    getPlayer():Say(getText("UI_CMRB_Message_HealedCharacter"))
end

function CheatCoreCM.DoLearnRecipes()
    local allItems = getAllItems()
    local player = getPlayer()
    for i=0, allItems:size()-1 do
        local item = allItems:get(i)
        if item:getLearnedRecipes() and not item:getLearnedRecipes():isEmpty() then
            local recipes = item:getLearnedRecipes()
            for j=0, recipes:size()-1 do
                local recipeName = recipes:get(j)
                player:learnRecipe(recipeName)
            end
        end
    end
    player:Say(getText("UI_CMRB_Message_RecipesLearned"))
end

function CheatCoreCM.DoForgetRecipes()
    local allItems = getAllItems()
    local player = getPlayer()
    for i=0, allItems:size()-1 do
        local item = allItems:get(i)
        local skillTrained = item:getSkillTrained()

        if not skillTrained then
            ---@diagnostic disable-next-line: undefined-field
            if item:getLearnedRecipes() and not item:getLearnedRecipes():isEmpty() then
                ---@diagnostic disable-next-line: undefined-field
                player:getAlreadyReadBook():remove(item:getFullType())
            end
        end
    end
    player:getKnownRecipes():clear()
    player:Say(getText("UI_CMRB_Message_RecipesForgotten"))
end

function CheatCoreCM.DoSkillLevelUp(SkillToSet, ToLevel)
    --[[	
    for i = 1,getPlayer():getPerkLevel(SkillToSet) do -- clear the skill before setting it
        getPlayer():LoseLevel(SkillToSet)
    end
    --]]
    getPlayer():level0(SkillToSet)
    getPlayer():getXp():setXPToLevel(SkillToSet, 0)

    if ToLevel ~= 0 then
        for _ = 1,ToLevel do -- then set it
            getPlayer():LevelPerk(SkillToSet, false)
        end
        getPlayer():getXp():setXPToLevel(SkillToSet, ToLevel)
    end

    --getPlayer():getXp():setXPToLevel(SkillToSet, ToLevel);
    --getPlayer():setNumberOfPerksToPick(getPlayer():getNumberOfPerksToPick() + ToLevel);
end

function CheatCoreCM.DoNoReload()
    if CheatCoreCM.IsMelee == true then -- checks to make sure that IsMelee is enabled, and if it is then it disables it.
        CheatCoreCM.DoWeaponDamage()
    end

    local weapon = getPlayer():getPrimaryHandItem()
    if weapon ~= nil then
        if CheatCoreCM.NoReload == true then
            ---@diagnostic disable-next-line: undefined-field
            getPlayer():getModData().OriginalRecoilDelay = weapon:getRecoilDelay()
            ---@diagnostic disable-next-line: undefined-field
            weapon:setRecoilDelay( 0 )
            --getPlayer():getModData().IsNoReload = true
        else
            if getPlayer():getModData().OriginalRecoilDelay then
                ---@diagnostic disable-next-line: undefined-field
                weapon:setRecoilDelay( getPlayer():getModData().OriginalRecoilDelay )
            --getPlayer():getModData().IsNoReload = false
            end
        end
    else
        getPlayer():Say(getText("UI_CMRB_Message_NoWeaponEquipped"))
        CheatCoreCM.IsMelee = false
    end
end

-- Trigger Set --
local CMAmmoLoopSeq = 0
local CMAmmoFirstLaunch = 1
local CMAmmoMessageTrigger = 0

function CheatCoreCM.DoInfiniteAmmoMode()
    if CheatCoreCM.MasterKey then
        CMAmmoMessageTrigger = 0
        CheatCoreCM.IsAmmo = false
        return
    end

    if not CheatCoreCM.IsAmmo then
        CMAmmoLoopSeq = 0
        CMAmmoFirstLaunch = 1
        CMAmmoMessageTrigger = 0
        return
    end

    local player = getPlayer()
    local gun = player:getPrimaryHandItem()

    local function refillGun(isFirst)
        ---@diagnostic disable: undefined-field
        if gun:isRanged() == nil then
            player:Say(getText("UI_CMRB_Message_NotRangedWeapon"))
        elseif gun:isRanged() then
            gun:setCurrentAmmoCount(gun:getMaxAmmo())
            gun:setRoundChambered(true)
            if isFirst then gun:setContainsClip(true) end
            if gun:isJammed() then gun:setJammed(false) end
        end
        ---@diagnostic enable: undefined-field
        CMAmmoMessageTrigger = 0
    end

    local function handleNoWeapon()
        if CMAmmoMessageTrigger == 0 then
            player:Say(getText("UI_CMRB_Message_NoWeaponEquipped_IAM"))
            CheatCoreCM.IsAmmo = false
            CMAmmoMessageTrigger = 1
        end
    end

    CMAmmoLoopSeq = CMAmmoLoopSeq + 1

    if CMAmmoFirstLaunch == 1 then
        if gun then refillGun(true) else handleNoWeapon() end
        CMAmmoFirstLaunch = 0
    elseif CMAmmoLoopSeq >= 25 then
        CMAmmoLoopSeq = 0
        if gun then refillGun(false) else handleNoWeapon() end
    end
end

function CheatCoreCM.DoPreventDeathMode()
    if CheatCoreCM.MasterKey == true then
        CheatCoreCM.DoPreventDeath = false
        getPlayer():getModData().IsPreventDeath = false
        return
    end

    if CheatCoreCM.DoPreventDeath == true then
        local player = getPlayer()
        local bd = player:getBodyDamage()
        local currentHealth = bd:getOverallBodyHealth()

        getPlayer():getModData().IsPreventDeath = true

        if currentHealth <= 20 then
            bd:AddGeneralHealth(math.max(80 - currentHealth, 1))
        end
    else
        CheatCoreCM.DoPreventDeath = false
        getPlayer():getModData().IsPreventDeath = false
    end
end

function CheatCoreCM.DoInfiniteDurabilityMode()
    if CheatCoreCM.MasterKey then
        CheatCoreCM.IsRepair = false
        return
    end

    if not CheatCoreCM.IsRepair then return end

    local item = getPlayer():getPrimaryHandItem()
    if item and item:getCondition() ~= item:getConditionMax() then
        item:setCondition(item:getConditionMax(), false)
    end
end

function CheatCoreCM.DoWeaponDamage()
    local player = getPlayer()
    local weapon = player:getPrimaryHandItem()
    local InventoryItemList = player:getInventory():getItems()
    local InventorySize = InventoryItemList:size()
    local itemList = getAllItems()
    local itemListSize = itemList:size()

    if CheatCoreCM.IsMelee == true then
        if weapon ~= nil then
            --CMCurrentEquipment = weapon:getID()
            --TargetMinDamage = weapon:getMinDamage()
            --TargetMaxDamage = weapon:getMaxDamage()
            --TargetDoorDamage = weapon:getDoorDamage()
            CMWeaponName = weapon:getFullType()

            ---@diagnostic disable-next-line: undefined-field
            weapon:setMinDamage(1000)
            ---@diagnostic disable-next-line: undefined-field
            weapon:setMaxDamage(1000)
            ---@diagnostic disable-next-line: undefined-field
            weapon:setDoorDamage(1000)

        else
            getPlayer():Say(getText("UI_CMRB_Message_NotWeapon"))

        end
    else
        if weapon ~= nil then
        CMWeaponTrigger = 0
            --print (weapon:getFullType())
            for i = itemListSize-1,0,-1 do
            local itemList_items = itemList:get(i)
            local itemname = itemList_items:getFullName()

               if string.match (tostring(itemname), tostring(CMWeaponName)) then
                    ---@diagnostic disable-next-line: undefined-field
                    weapon:setMinDamage(Ori_MinDamage)
                    ---@diagnostic disable-next-line: undefined-field
                    weapon:setMaxDamage(Ori_MaxDamage)
                    ---@diagnostic disable-next-line: undefined-field
                    weapon:setDoorDamage(Ori_DoorDamage)
                    --print (Ori_MinDamage)
                    --print (Ori_MaxDamage)
                    CMWeaponTrigger = 1
                end
           end
           if CMWeaponTrigger == 0 then
                getPlayer():Say(getText("UI_CMRB_Message_NotWeapon"))
           end
        else
            getPlayer():Say(getText("UI_CMRB_Message_AttemptTracing"))
            CMWeaponTrigger = 0
            for i = 0, InventorySize -1 do
                local Inventory_Items = InventoryItemList:get(i)
                local Inv_ItemID = Inventory_Items:getID()
                    if Inv_ItemID == CMCurrentEquipment then
                        ---@diagnostic disable-next-line: undefined-field
                        Inventory_Items:setDoorDamage(Ori_DoorDamage)
                        ---@diagnostic disable-next-line: undefined-field
                        Inventory_Items:setMaxDamage(Ori_MaxDamage)
                        ---@diagnostic disable-next-line: undefined-field
                        Inventory_Items:setMinDamage(Ori_MinDamage)
                        --print (Ori_MinDamage)
                        --print (Ori_MaxDamage)
                        CMWeaponTrigger = 1
                        getPlayer():Say(getText("UI_CMRB_Message_RevertedItem"))
                    end
            end
            if CMWeaponTrigger == 0 then
            getPlayer():Say(getText("UI_CMRB_Message_LostItem"))
            end
            --Events.OnEquipPrimary.Remove(CheatCoreCM.DoWeaponDamage) 
        end
    end
end

function CheatCoreCM.DoRefillAmmo()
    local player = getPlayer()
    local primary = player:getPrimaryHandItem()
    local secondary = player:getSecondaryHandItem()

    if not primary and not secondary then
        player:Say(getText("UI_CMRB_Message_NoWeaponEquipped"))
        return
    end

    local function refill(item, message)
        ---@diagnostic disable: undefined-field
        if not item:isRanged() then
            player:Say(getText("UI_CMRB_Message_NotRangedWeapon"))
            return
        end
        item:setCurrentAmmoCount(item:getMaxAmmo())
        item:setRoundChambered(true)
        if item:isJammed() then item:setJammed(false) end
        ---@diagnostic enable: undefined-field
        player:Say(message)
    end

    if primary then
        refill(primary, getText("UI_CMRB_Message_RefillAmmoP"))
    end

    if secondary and secondary ~= primary then
        refill(secondary, getText("UI_CMRB_Message_RefillAmmoS"))
    end
end

function CheatCoreCM.DisableAllCheat()
    getPlayer():getModData().IsNoClip = false
    getPlayer():getModData().IsCreativeMode = false
    getPlayer():getModData().IsGod = false
    getPlayer():getModData().IsGhost = false
    getPlayer():getModData().IsActionCheat = false
    getPlayer():getModData().IsMechanicsCheat = false
    getPlayer():getModData().IsHelathCheat = false
    --getPlayer():getModData().IsCraftingCheat = false
    getPlayer():getModData().IsPreventDeath = false
    --getPlayer():getModData().IsInfiniteAmmo = false
    --getPlayer():getModData().IsNoReload = false
    --getPlayer():getModData().IsInfiniteDurability = false
    getPlayer():getModData().IsFly = false
    getPlayer():getModData().IsAllStats = false
    getPlayer():getModData().IsNightVision = false

    CheatCoreCM.IsAmmo = false
    CheatCoreCM.IsRepair = true
    CheatCoreCM.IsMelee = false
    CheatCoreCM.IsSelect = false
    CheatCoreCM.FireBrushEnabled = false
    CheatCoreCM.IsTerraforming = false
    CheatCoreCM.ZombieBrushEnabled = false
    CheatCoreCM.IsDelete = false
    CheatCoreCM.IsNightVision = false
    CheatCoreCM.DeleteWithoutWall = false
    CheatCoreCM.DeleteWithoutDoorWindow = false
    CheatCoreCM.DeleteWithZombie = false
    CheatCoreCM.DeleteWithCorpse = false
    CheatCoreCM.DoPreventDeath = false
    CheatCoreCM.IsReady = false
    --CheatCoreCM.IsCraftingCheat = false

    CheatCoreCM.MasterKey = true
    CheatCoreCM.DoCreativeMode()
    CheatCoreCM.DoGodMode()
    CheatCoreCM.DoNoClipMode()
    CheatCoreCM.DoGhostMode()
    CheatCoreCM.DoMechanicsCheat()
    CheatCoreCM.DoHealthCheat()
    CheatCoreCM.ToggleInstantActions()
    CheatCoreCM.AllStatsDisabled()
    CheatCoreCM.DoNightVision()

    CheatCoreCM.EventDisableKey = 1
    CheatCoreCM.MasterKey = false
end

function CheatCoreCM.ObJectDoorLock(door)
    door:setIsLocked(not door:isLocked())
    if door:checkKeyId() ~= -1 then
        door:setLockedByKey(door:isLocked())
    end
    if door:getKeyId() ~= -1 then
        door:setLockedByKey(door:isLocked())
    end
    getPlayer():getMapKnowledge():setKnownBlockedDoor(door, door:isLocked())

    local doubleDoorObjects = buildUtil.getDoubleDoorObjects(door)
    for i=1,#doubleDoorObjects do
        local object = doubleDoorObjects[i]
        ---@diagnostic disable-next-line: undefined-field
        object:setLockedByKey(door:isLocked())
    end

    local garageDoorObjects = buildUtil.getGarageDoorObjects(door)
    for i=1,#garageDoorObjects do
        local object = garageDoorObjects[i]
        ---@diagnostic disable-next-line: undefined-field
        object:setLockedByKey(door:isLocked())
    end
end

---@type any
PLLGhost = PLLGhost

function CheatCoreCM.SyncVariables()
    -- Removing unsupported mods events --
    if PLLGhost and PLLGhost.setGhost then
        Events.OnPlayerUpdate.Remove(PLLGhost.setGhost)
    end

    if isClient() and not (isAdmin() or isCoopHost()) then return end

    local player = getPlayer()
    local modData = player:getModData()
    local notifyPlayer = {}
    local stringNotice = getText("UI_CMRB_Message_EnabledCheat")

    local function sync(dataKey, coreKey, func, textKey)
        if modData[dataKey] then
            CheatCoreCM[coreKey] = true
            if func then func() end
            if textKey then table.insert(notifyPlayer, getText(textKey)) end
        else
            CheatCoreCM[coreKey] = false
            modData[dataKey] = false
        end
    end

    sync("IsGod", "IsGod", CheatCoreCM.DoGodMode, "UI_CMRB_Message_Current_God")
    sync("IsGhost", "IsGhost", CheatCoreCM.DoGhostMode, "UI_CMRB_Message_Current_Ghost")
    sync("IsCreativeMode", "IsCreativeMode", CheatCoreCM.DoCreativeMode, "UI_CMRB_Message_Current_Creative")
    sync("IsHelathCheat", "IsHelathCheat", CheatCoreCM.DoHealthCheat, "UI_CMRB_Message_Current_Health")
    sync("IsNoClip", "IsNoClip", CheatCoreCM.DoNoClipMode, "UI_CMRB_Message_Current_NoClip")
    sync("IsPreventDeath", "DoPreventDeath", nil, "UI_CMRB_Message_Current_PreventDeath")
    sync("IsInfiniteCarryWeight", "IsInfiniteCarryWeight", CheatCoreCM.DoCarryWeightCheat, "UI_CMRB_MoodAndXP_InfiniteCarryweight")
    sync("IsActionCheat", "IsActionCheat", CheatCoreCM.ToggleInstantActions, "UI_CMRB_Message_Current_ActionCheat")
    sync("IsInfiniteAmmo", "IsAmmo", nil, "UI_CMRB_Current_InfiniteAmmo")
    sync("IsMechanicsCheat", "IsMechanicsCheat", CheatCoreCM.DoMechanicsCheat, "UI_CMRB_Message_Current_Mechanics")
    sync("IsNightVision", "IsNightVision", CheatCoreCM.DoNightVision, "UI_CMRB_Character_NightVision")
    sync("IsFreezeTime", "IsFreezeTime", CheatCoreCM.FreezeTime, "UI_CMRB_Utility_TimeFreeze")
    sync("IsMadMax", "MadMax", CheatCoreCM.DoVehicleGodMode, "UI_CMRB_VehicleControl_Godmode")

    -- Special cases
    if modData.IsFly then
        CheatCoreCM.FlightHeight = modData.FlightHeight or CheatCoreCM.FlightHeight
        CheatCoreCM.IsFly = true
        table.insert(notifyPlayer, getText("UI_CMRB_Message_Current_Fly"))
    else
        modData.IsFly = false
        CheatCoreCM.IsFly = false
    end

    if modData.IsAllStats then
        CheatCoreCM.IsAllStats = true
        CheatCoreCM.AllStatsToggle()
        table.insert(notifyPlayer, getText("UI_CMRB_Message_Current_AllStats"))
    else
        modData.IsAllStats = false
        CheatCoreCM.IsAllStats = false
        CheatCoreCM.AllStatsToggle()
    end

    if #notifyPlayer > 0 then
        stringNotice = stringNotice .. table.concat(notifyPlayer, ", ")
        print("[CHEAT MENU] " .. stringNotice)
        player:Say(stringNotice)
    end
end

function CheatCoreCM.DisableSelectionMode()
    if  CheatCoreCM.IsBarricade or
        CheatCoreCM.FireBrushEnabled or
        CheatCoreCM.IsDelete or
        CheatCoreCM.IsSelect or
        CheatCoreCM.IsTerraforming or
        CheatCoreCM.ZombieBrushEnabled then

        CheatCoreCM.IsBarricade = false
        CheatCoreCM.IsDelete = false
        CheatCoreCM.IsSelect = false
        --CheatCoreCM.IsReady = false
        CheatCoreCM.FireBrushEnabled = false
        CheatCoreCM.IsTerraforming = false
        CheatCoreCM.ZombieBrushEnabled = false
        getPlayer():Say(getText("UI_CMRB_Message_RightClickDeactivation"))
    end
end

Events.OnLoad.Add(CheatCoreCM.SyncVariables);
Events.OnPlayerDeath.Add(CheatCoreCM.DisableAllCheat);
Events.OnEquipPrimary.Add(CheatCoreCM.CheckEquipment);
Events.OnTick.Add(CheatCoreCM.UpdateGhostZombies);
Events.OnPlayerUpdate.Add(CheatCoreCM.DoStatsUpdate);

print("[CHEAT MENU] CheatCore successfully loaded")

-- ░░ Override to disable buggy per-tick cheats ░░
function CheatCoreCM.DoTickCheats()
    if CheatCoreCM.IsAmmo then
        CheatCoreCM.DoInfiniteAmmoMode()
    end
    if CheatCoreCM.DoPreventDeath then
        CheatCoreCM.DoPreventDeathMode()
    end
    if CheatCoreCM.IsInfiniteCarryWeight then
        CheatCoreCM.DoCarryWeightCheat()
    end
    if CheatCoreCM.IsFreezeTime then
        CheatCoreCM.FreezeTime()
    end
    if CheatCoreCM.MadMax then
        CheatCoreCM.DoVehicleGodMode()
    end
end

function CheatCoreCM.DoNightVision()
    local player = getPlayer()
    if not player then return end
    player:setWearingNightVisionGoggles(CheatCoreCM.IsNightVision)
    player:getModData().IsNightVision = CheatCoreCM.IsNightVision
end

-- ░░ Hooks for Instant Actions ░░
local original_adjustMaxTime = ISBaseTimedAction.adjustMaxTime
function ISBaseTimedAction:adjustMaxTime(maxTime)
    if CheatCoreCM.IsActionCheat and self.character == getPlayer() and maxTime ~= -1 then
        return 1
    end
    return original_adjustMaxTime(self, maxTime)
end

local original_getDuration = ISReadABook.getDuration
function ISReadABook:getDuration()
    if CheatCoreCM.IsActionCheat and self.character == getPlayer() then
        return 1
    end
    return original_getDuration(self)
end

local original_ISTimedActionQueue_add = ISTimedActionQueue.add
ISTimedActionQueue.add = function(action)
    if CheatCoreCM.IsActionCheat and action.character == getPlayer() and action.maxTime ~= -1 then
        action.maxTime = 1
    end
    return original_ISTimedActionQueue_add(action)
end
