return {
    ['map'] = {
        ['id'] = 1,
        ['name'] = "Survival",
        ['version'] = "41"
    },
    ['areas'] = {
        {
            ['name'] = "Dixie",
            ['pois'] = {
                {
                    ['name'] = "Tiny Cabin",
                    ['x'] = 11243,
                    ['y'] = 8953
                },
                {
                    ['name'] = "Diner",
                    ['x'] = 11471,
                    ['y'] = 8811
                },
                {
                    ['name'] = "Gas station",
                    ['x'] = 11508,
                    ['y'] = 8832
                },
                {
                    ['name'] = "Picnic dining area",
                    ['x'] = 11556,
                    ['y'] = 8858
                },
                {
                    ['name'] = "Food Market",
                    ['x'] = 11671,
                    ['y'] = 8795
                },
                {
                    ['name'] = "Trailer Park",
                    ['x'] = 11493,
                    ['y'] = 8914
                },
                {
                    ['name'] = "Isolated Forest House",
                    ['x'] = 11600,
                    ['y'] = 9295
                }
            }
        },
        {
            ['name'] = "Scenic Grove",
            ['pois'] = {
                {
                    ['name'] = "U-S Tore It",
                    ['x'] = 5528,
                    ['y'] = 6080
                },
                {
                    ['name'] = "AL's Auto Shop",
                    ['x'] = 5429,
                    ['y'] = 5964
                },
                {
                    ['name'] = "Diner",
                    ['x'] = 5424,
                    ['y'] = 5914
                },
                {
                    ['name'] = "Gas N More",
                    ['x'] = 5418,
                    ['y'] = 5870
                },
                {
                    ['name'] = "Factory",
                    ['x'] = 5570,
                    ['y'] = 5899
                },
                {
                    ['name'] = "Factory Storage",
                    ['x'] = 5617,
                    ['y'] = 5973
                },
                {
                    ['name'] = "Farm",
                    ['x'] = 5699,
                    ['y'] = 5747
                }
            }
        },
        {
            ['id'] = 2,
            ['name'] = "Muldraugh",
            ['pois'] = {
                {
                    ['name'] = "Abandoned cabins",
                    ['x'] = 10969,
                    ['y'] = 9173
                },
                {
                    ['name'] = "Abandoned restaurant",
                    ['x'] = 10619,
                    ['y'] = 10043
                },
                {
                    ['name'] = "Adult Education Center",
                    ['x'] = 10638,
                    ['y'] = 9909
                },
                {
                    ['name'] = "All U Can Eat Buffet",
                    ['x'] = 10621,
                    ['y'] = 9442
                },
                {
                    ['name'] = "Baseball field",
                    ['x'] = 10955,
                    ['y'] = 9944
                },
                {
                    ['name'] = "Big urban warehouse",
                    ['x'] = 10694,
                    ['y'] = 10103
                },
                {
                    ['name'] = "Burger",
                    ['x'] = 10610,
                    ['y'] = 9477
                },
                {
                    ['name'] = "Laundromat",
                    ['x'] = 10612,
                    ['y'] = 9470
                },
                {
                    ['name'] = "Car Repair Shop",
                    ['x'] = 10604,
                    ['y'] = 9411
                },
                {
                    ['name'] = "Muldraugh First Baptist Chapel",
                    ['x'] = 10730,
                    ['y'] = 9715
                },
                {
                    ['name'] = "Holy Grace Church",
                    ['x'] = 10773,
                    ['y'] = 10172
                },
                {
                    ['name'] = "Construction Site",
                    ['x'] = 10078,
                    ['y'] = 9576
                },
                {
                    ['name'] = "Convenience Store",
                    ['x'] = 10843,
                    ['y'] = 10033
                },
                {
                    ['name'] = "Cortman Medical",
                    ['x'] = 10882,
                    ['y'] = 10035
                },
                {
                    ['name'] = "Diner",
                    ['x'] = 10620,
                    ['y'] = 10563
                },
                {
                    ['name'] = "Electronics Store",
                    ['x'] = 10618,
                    ['y'] = 9882
                },
                {
                    ['name'] = "Muldraugh Elementary school",
                    ['x'] = 10614,
                    ['y'] = 9975
                },
                {
                    ['name'] = "Food Market",
                    ['x'] = 10852,
                    ['y'] = 9765
                },
                {
                    ['name'] = "Forest house",
                    ['x'] = 11067,
                    ['y'] = 10641
                },
                {
                    ['name'] = "Fossoil",
                    ['x'] = 10632,
                    ['y'] = 9763
                },
                {
                    ['name'] = "Secure Storage",
                    ['x'] = 10615,
                    ['y'] = 9372
                },
                {
                    ['name'] = "Gas-2-Go",
                    ['x'] = 10671,
                    ['y'] = 10626
                },
                {
                    ['name'] = "Gated community",
                    ['x'] = 10680,
                    ['y'] = 9561
                },
                {
                    ['name'] = "Greene's",
                    ['x'] = 10612,
                    ['y'] = 10263
                },
                {
                    ['name'] = "H. Smith Attorney",
                    ['x'] = 10653,
                    ['y'] = 9653
                },
                {
                    ['name'] = "Isolated Forest House",
                    ['x'] = 11600,
                    ['y'] = 9295
                },
                {
                    ['name'] = "Isolated House",
                    ['x'] = 10944,
                    ['y'] = 9375
                },
                {
                    ['name'] = "Kate and Baldspots safehouse",
                    ['x'] = 10751,
                    ['y'] = 9414
                },
                {
                    ['name'] = "Knox Bank",
                    ['x'] = 10625,
                    ['y'] = 9703
                },
                {
                    ['name'] = "Laundromat",
                    ['x'] = 10920,
                    ['y'] = 9844
                },
                {
                    ['name'] = "McCoy Lumber Mill",
                    ['x'] = 10319,
                    ['y'] = 9595
                },
                {
                    ['name'] = "Waites Motel",
                    ['x'] = 10915,
                    ['y'] = 9763
                },
                {
                    ['name'] = "North Farm",
                    ['x'] = 10835,
                    ['y'] = 9081
                },
                {
                    ['name'] = "Offices",
                    ['x'] = 10678,
                    ['y'] = 10343
                },
                {
                    ['name'] = "Picnic area",
                    ['x'] = 10997,
                    ['y'] = 9645
                },
                {
                    ['name'] = "Pile-o-Crepe",
                    ['x'] = 1062,
                    ['y'] = 9520
                },
                {
                    ['name'] = "Pizza Whirled",
                    ['x'] = 10607,
                    ['y'] = 10119
                },
                {
                    ['name'] = "Police station",
                    ['x'] = 10635,
                    ['y'] = 10417
                },
                {
                    ['name'] = "Railyard",
                    ['x'] = 11655,
                    ['y'] = 9985
                },
                {
                    ['name'] = "Restaurant",
                    ['x'] = 10626,
                    ['y'] = 10522
                },
                {
                    ['name'] = "U-S Tore It (Storage)",
                    ['x'] = 10684,
                    ['y'] = 9829
                },
                {
                    ['name'] = "Small convenience store",
                    ['x'] = 10841,
                    ['y'] = 9534
                },
                {
                    ['name'] = "Stor-A-Max",
                    ['x'] = 10762,
                    ['y'] = 10363
                },
                {
                    ['name'] = "Small warehouse",
                    ['x'] = 10712,
                    ['y'] = 10144
                },
                {
                    ['name'] = "Spiffo's",
                    ['x'] = 10621,
                    ['y'] = 9650
                },
                {
                    ['name'] = "Sunstar Hotel",
                    ['x'] = 10606,
                    ['y'] = 9810
                },
                {
                    ['name'] = "Tattoo 42",
                    ['x'] = 10618,
                    ['y'] = 10155
                },
                {
                    ['name'] = "The Rusty Rifle (Tavern)",
                    ['x'] = 10762,
                    ['y'] = 10556
                },
                {
                    ['name'] = "The McCoy Logging Co.",
                    ['x'] = 10317,
                    ['y'] = 9290
                },
                {
                    ['name'] = "Large Warehouse",
                    ['x'] = 10613,
                    ['y'] = 9321
                },
                {
                    ['name'] = "Muldraugh Train station",
                    ['x'] = 11094,
                    ['y'] = 9238
                },
                {
                    ['name'] = "L&B Warehousing",
                    ['x'] = 10707,
                    ['y'] = 10457
                },
                {
                    ['name'] = "Zippee Market",
                    ['x'] = 10608,
                    ['y'] = 9618
                },
                {
                    ['name'] = "Cafeteria",
                    ['x'] = 10648,
                    ['y'] = 9925
                },
                {
                    ['name'] = "Soccer Field",
                    ['x'] = 10656,
                    ['y'] = 9970
                },
                {
                    ['name'] = "Bookshop",
                    ['x'] = 10608,
                    ['y'] = 10369
                }
            }
        },
        {
            ['id'] = 3,
            ['name'] = "Valley Station",
            ['pois'] = {
                {
                    ['name'] = "J. Tinsley Elementary School",
                    ['x'] = 12870,
                    ['y'] = 4877
                },
                {
                    ['name'] = "Burgers",
                    ['x'] = 12548,
                    ['y'] = 5268
                },
                {
                    ['name'] = "Cafe",
                    ['x'] = 13093,
                    ['y'] = 5453
                },
                {
                    ['name'] = "Sacred Flame Church",
                    ['x'] = 12849,
                    ['y'] = 4964
                },
                {
                    ['name'] = "Construction site #2",
                    ['x'] = 14123,
                    ['y'] = 5493
                },
                {
                    ['name'] = "Construction site",
                    ['x'] = 12582,
                    ['y'] = 5387
                },
                {
                    ['name'] = "Abandoned cabin",
                    ['x'] = 12531,
                    ['y'] = 5232
                },
                {
                    ['name'] = "Restaurant",
                    ['x'] = 12743,
                    ['y'] = 5714
                },
                {
                    ['name'] = "Food Market",
                    ['x'] = 12576,
                    ['y'] = 5736
                },
                {
                    ['name'] = "Ruby Gas",
                    ['x'] = 12743,
                    ['y'] = 5042
                },
                {
                    ['name'] = "Gas-2-Go",
                    ['x'] = 13734,
                    ['y'] = 5643
                },
                {
                    ['name'] = "Knox Creek Hunting Lodge",
                    ['x'] = 13105,
                    ['y'] = 5315
                },
                {
                    ['name'] = "Lookout Tower",
                    ['x'] = 13403,
                    ['y'] = 5338
                },
                {
                    ['name'] = "Knox Bank",
                    ['x'] = 13656,
                    ['y'] = 5745
                },
                {
                    ['name'] = "Pile-o-Crepe",
                    ['x'] = 13602,
                    ['y'] = 5762
                },
                {
                    ['name'] = "Racetrack / Abandoned airfield",
                    ['x'] = 12843,
                    ['y'] = 6405
                },
                {
                    ['name'] = "Shooting Range",
                    ['x'] = 13261,
                    ['y'] = 5441
                },
                {
                    ['name'] = "Guns-a-BlazINN",
                    ['x'] = 13017,
                    ['y'] = 5321
                },
                {
                    ['name'] = "Small dock",
                    ['x'] = 12482,
                    ['y'] = 5298
                },
                {
                    ['name'] = "Small shop",
                    ['x'] = 12630,
                    ['y'] = 5331
                },
                {
                    ['name'] = "StarEplex Cinema",
                    ['x'] = 13647,
                    ['y'] = 5884
                },
                {
                    ['name'] = "Crossroads Mall",
                    ['x'] = 13942,
                    ['y'] = 5924
                },
                {
                    ['name'] = "Zippee market",
                    ['x'] = 13658,
                    ['y'] = 5766
                },
                {
                    ['name'] = "Yummmers",
                    ['x'] = 13575,
                    ['y'] = 5768
                },
                {
                    ['name'] = "Fun-2-3 Childcare",
                    ['x'] = 13585,
                    ['y'] = 5669
                },
                
                {
                    ['name'] = "Valu In$urance",
                    ['x'] = 13666,
                    ['y'] = 5674
                },
                {
                    ['name'] = "Beauty Salon",
                    ['x'] = 13619,
                    ['y'] = 5672
                },
                {
                    ['name'] = "Dressed To The 90s",
                    ['x'] = 13686,
                    ['y'] = 5672
                },
                {
                    ['name'] = "Valu In$urance",
                    ['x'] = 13665,
                    ['y'] = 5671
                },
                {
                    ['name'] = "Sweet Eats!",
                    ['x'] = 13649,
                    ['y'] = 5671
                },
                {
                    ['name'] = "Worm of Books",
                    ['x'] = 13608,
                    ['y'] = 5675
                },
                {
                    ['name'] = "Silken Belles (Hair Salon)",
                    ['x'] = 13621,
                    ['y'] = 5676
                },
                {
                    ['name'] = "A Lake House",
                    ['x'] = 14070,
                    ['y'] = 5200
                },
                {
                    ['name'] = "Small Farm",
                    ['x'] = 14315,
                    ['y'] = 4953
                },
                {
                    ['name'] = "Eternal Light Chapel",
                    ['x'] = 14551,
                    ['y'] = 4970
                },
                {
                    ['name'] = "Medium Warehouse",
                    ['x'] = 12612,
                    ['y'] = 4725
                },
                {
                    ['name'] = "Bus Station",
                    ['x'] = 12733,
                    ['y'] = 5773
                },
                {
                    ['name'] = "East Bridge",
                    ['x'] = 12899,
                    ['y'] = 6900
                },
                {
                    ['name'] = "Big Farm",
                    ['x'] = 13856,
                    ['y'] = 4740
                },
                
                {
                    ['name'] = "Food Market",
                    ['x'] = 13937,
                    ['y'] = 4864
                },
                {
                    ['name'] = "Burgers",
                    ['x'] = 13965,
                    ['y'] = 4866
                },
                {
                    ['name'] = "Farmhouse",
                    ['x'] = 14396,
                    ['y'] = 4568
                }
            }
        },
        {
            ['name'] = "Louisville",
            ['pois'] = {
                {
                    ['name'] = "Checkpoint",
                    ['x'] = 12515,
                    ['y'] = 4362
                },
                {
                    ['name'] = "Military Camp (Southbound)",
                    ['x'] = 12562,
                    ['y'] = 4284
                },
                {
                    ['name'] = "Military Camp (Northbound)",
                    ['x'] = 12488,
                    ['y'] = 4229
                },
                {
                    ['name'] = "Freight Station",
                    ['x'] = 12639,
                    ['y'] = 4358
                },
                {
                    ['name'] = "Residential Quarantine Zone",
                    ['x'] = 12732,
                    ['y'] = 3962
                },
                {
                    ['name'] = "Burgers in Refugee Camp",
                    ['x'] = 12505,
                    ['y'] = 4072
                },
                {
                    ['name'] = "93.2 LBMW Radio in Refugee Camp",
                    ['x'] = 12486,
                    ['y'] = 3918
                },
                {
                    ['name'] = "Pizza Whirled",
                    ['x'] = 12447,
                    ['y'] = 3834
                },
                {
                    ['name'] = "Spiffo's",
                    ['x'] = 12454,
                    ['y'] = 3790
                },
                {
                    ['name'] = "St. Peregrin Hospital",
                    ['x'] = 12461,
                    ['y'] = 3701
                },
                {
                    ['name'] = "Ameriglobe Communications",
                    ['x'] = 12320,
                    ['y'] = 3549
                },
                {
                    ['name'] = "Leafhill Heights Offices",
                    ['x'] = 12255,
                    ['y'] = 3544
                },
                {
                    ['name'] = "Line by Line Design",
                    ['x'] = 12566,
                    ['y'] = 3764
                },
                {
                    ['name'] = "Knoxpack Kitchens",
                    ['x'] = 12631,
                    ['y'] = 3773
                },
                {
                    ['name'] = "Mashie -Signs & Painting-",
                    ['x'] = 12611,
                    ['y'] = 3713
                },
                {
                    ['name'] = "Ivanov Factory & Showroom",
                    ['x'] = 12619,
                    ['y'] = 3636
                },
                {
                    ['name'] = "Steely Revolve Metal Working",
                    ['x'] = 12597,
                    ['y'] = 3654
                },
                {
                    ['name'] = "ValuTech",
                    ['x'] = 12579,
                    ['y'] = 3689
                },
                {
                    ['name'] = "Mass-Genfac Co.",
                    ['x'] = 12604,
                    ['y'] = 3668
                },
                {
                    ['name'] = "Evan Philips Tax & Accounting",
                    ['x'] = 12566,
                    ['y'] = 3626
                },
                {
                    ['name'] = "Valu In$urance",
                    ['x'] = 12566,
                    ['y'] = 3622
                },
                {
                    ['name'] = "Post Office",
                    ['x'] = 12595,
                    ['y'] = 3592
                },
                {
                    ['name'] = "The Kentucky Herald",
                    ['x'] = 12609,
                    ['y'] = 3564
                },
                {
                    ['name'] = "Car Fix-Ation",
                    ['x'] = 12635,
                    ['y'] = 3517
                },
                {
                    ['name'] = "Speedy Legal",
                    ['x'] = 12635,
                    ['y'] = 3503
                },
                {
                    ['name'] = "United Shipping Logistics",
                    ['x'] = 12635,
                    ['y'] = 3704
                },
                {
                    ['name'] = "Discount Account",
                    ['x'] = 12635,
                    ['y'] = 3670
                },
                {
                    ['name'] = "Bow Wow Wow! Dog Nutrition",
                    ['x'] = 12588,
                    ['y'] = 3536
                },
                {
                    ['name'] = "Temp Agency",
                    ['x'] = 12592,
                    ['y'] = 3512
                },
                {
                    ['name'] = "Commander Publishing Inc",
                    ['x'] = 12592,
                    ['y'] = 3504
                },
                {
                    ['name'] = "KPK Consulting Business & Investments",
                    ['x'] = 12636,
                    ['y'] = 3494
                },
                {
                    ['name'] = "Holy Haven Cemetary",
                    ['x'] = 12608,
                    ['y'] = 3382
                },
                {
                    ['name'] = "Interchange (Louisville)",
                    ['x'] = 12513,
                    ['y'] = 3449
                },
                {
                    ['name'] = "Fossoil Gas Station",
                    ['x'] = 12429,
                    ['y'] = 3534
                },
                {
                    ['name'] = "Gated Community",
                    ['x'] = 12392,
                    ['y'] = 3392
                },
                {
                    ['name'] = "Leafhill Heights Elementary School",
                    ['x'] = 12346,
                    ['y'] = 3264
                },
                {
                    ['name'] = "My Sunday Market",
                    ['x'] = 12444,
                    ['y'] = 3112
                },
                {
                    ['name'] = "Mansions",
                    ['x'] = 12261,
                    ['y'] = 2915
                },
                {
                    ['name'] = "Zippee Market",
                    ['x'] = 12234,
                    ['y'] = 3030
                },
                {
                    ['name'] = "Bible Spirit Baptist Church",
                    ['x'] = 12442,
                    ['y'] = 3024
                },
                {
                    ['name'] = "Leafhill Apartment",
                    ['x'] = 12176,
                    ['y'] = 2911
                },
                {
                    ['name'] = "Oak Park Apartments",
                    ['x'] = 12138,
                    ['y'] = 2928
                },
                {
                    ['name'] = "Chapelmount Downs",
                    ['x'] = 12230,
                    ['y'] = 2633
                },
                {
                    ['name'] = "Zlatko's",
                    ['x'] = 12287,
                    ['y'] = 2542
                },
                {
                    ['name'] = "Couven-U-Mart",
                    ['x'] = 12288,
                    ['y'] = 2537
                },
                {
                    ['name'] = "Laundromat",
                    ['x'] = 12309,
                    ['y'] = 2543
                },
                {
                    ['name'] = "Hair Salon",
                    ['x'] = 12316,
                    ['y'] = 2544
                },
                {
                    ['name'] = "Jimmy's Pre-owned Cars",
                    ['x'] = 12384,
                    ['y'] = 2543
                },
                {
                    ['name'] = "Knox Bank",
                    ['x'] = 12541,
                    ['y'] = 2584
                },
                {
                    ['name'] = "GigaMart",
                    ['x'] = 12575,
                    ['y'] = 2557
                },
                {
                    ['name'] = "LSU Rogers Humanities Buliding",
                    ['x'] = 12454,
                    ['y'] = 2251
                },
                {
                    ['name'] = "LSU Attenborough Sciences Building (North)",
                    ['x'] = 12398,
                    ['y'] = 2214
                },
                {
                    ['name'] = "LSU Attenborough Sciences Building (South)",
                    ['x'] = 12397,
                    ['y'] = 2300
                },
                {
                    ['name'] = "LSU West Domitory",
                    ['x'] = 12337,
                    ['y'] = 2262
                },
                {
                    ['name'] = "LSU Student Union",
                    ['x'] = 12342,
                    ['y'] = 2228
                },
                {
                    ['name'] = "LSU Library",
                    ['x'] = 12350,
                    ['y'] = 2140
                },
                {
                    ['name'] = "LSU Main Buliding",
                    ['x'] = 12407,
                    ['y'] = 2159
                },
                {
                    ['name'] = "Louisville State University",
                    ['x'] = 12473,
                    ['y'] = 2212
                },
                {
                    ['name'] = "LSU South Domitory",
                    ['x'] = 12354,
                    ['y'] = 2372
                },
                {
                    ['name'] = "LSU Athletic Center",
                    ['x'] = 12427,
                    ['y'] = 2375
                },
                {
                    ['name'] = "KY-TRansit",
                    ['x'] = 12566,
                    ['y'] = 2413
                },
                {
                    ['name'] = "Liquorty-Split",
                    ['x'] = 12421,
                    ['y'] = 2850
                },
                {
                    ['name'] = "Back to the Nurture",
                    ['x'] = 12420,
                    ['y'] = 2840
                },
                {
                    ['name'] = "Go Flash -Cameras & Flim Development-",
                    ['x'] = 12420,
                    ['y'] = 2830
                },
                {
                    ['name'] = "SweetPea Restaurant",
                    ['x'] = 12423,
                    ['y'] = 2826
                },
                {
                    ['name'] = "Hit Vids",
                    ['x'] = 12431,
                    ['y'] = 2826
                },
                {
                    ['name'] = "Louisville Train Station",
                    ['x'] = 12697,
                    ['y'] = 2348
                },
                {
                    ['name'] = "First Train Inn",
                    ['x'] = 12643,
                    ['y'] = 2360
                },
                {
                    ['name'] = "Coffee Nirvana",
                    ['x'] = 12638,
                    ['y'] = 2334
                },
                {
                    ['name'] = "Zippee Market",
                    ['x'] = 12648,
                    ['y'] = 2297
                },
                {
                    ['name'] = "Liquorty-Split",
                    ['x'] = 12625,
                    ['y'] = 2301
                },
                {
                    ['name'] = "Louisville Transit Center",
                    ['x'] = 12567,
                    ['y'] = 2315
                },
                {
                    ['name'] = "Pile-o-Crepe",
                    ['x'] = 12625,
                    ['y'] = 2242
                },
                {
                    ['name'] = "Millhauser Office Building",
                    ['x'] = 12673,
                    ['y'] = 2245
                },
                {
                    ['name'] = "Markson & Co",
                    ['x'] = 12668,
                    ['y'] = 2232
                },
                {
                    ['name'] = "Colly's Gifts",
                    ['x'] = 12668,
                    ['y'] = 2219
                },
                {
                    ['name'] = "Tastee Foodz",
                    ['x'] = 12668,
                    ['y'] = 2202
                },
                {
                    ['name'] = "ABCDriving School",
                    ['x'] = 12668,
                    ['y'] = 2212,
                    ['z'] = 1
                },
                {
                    ['name'] = "United Shipping Logistics",
                    ['x'] = 12668,
                    ['y'] = 2224,
                    ['z'] = 1
                },
                {
                    ['name'] = "Alliance Data Entry",
                    ['x'] = 12668,
                    ['y'] = 2230,
                    ['z'] = 1
                },
                {
                    ['name'] = "Gas-2-Go",
                    ['x'] = 12709,
                    ['y'] = 2226
                },
                {
                    ['name'] = "Jay's Chicken",
                    ['x'] = 12747,
                    ['y'] = 2236
                },
                {
                    ['name'] = "L&B Warehousing",
                    ['x'] = 12799,
                    ['y'] = 2188
                },
                {
                    ['name'] = "Office #1",
                    ['x'] = 12774,
                    ['y'] = 2166
                },
                {
                    ['name'] = "Office #2",
                    ['x'] = 12755,
                    ['y'] = 2140
                },
                {
                    ['name'] = "Abandoned Factory",
                    ['x'] = 12718,
                    ['y'] = 2130
                },
                {
                    ['name'] = "Urban Warehouse",
                    ['x'] = 12708,
                    ['y'] = 2193
                },
                {
                    ['name'] = "Goodman Legal Services",
                    ['x'] = 12672,
                    ['y'] = 2192
                },
                {
                    ['name'] = "Better Furnishings",
                    ['x'] = 12673,
                    ['y'] = 2167
                },
                {
                    ['name'] = "T.I.S. Construction",
                    ['x'] = 12674,
                    ['y'] = 2139
                },
                {
                    ['name'] = "Milk 'n' More",
                    ['x'] = 12674,
                    ['y'] = 2131
                },
                {
                    ['name'] = "Car-Fix-Ation",
                    ['x'] = 12661,
                    ['y'] = 2114
                },
                {
                    ['name'] = "Louisville Post Office",
                    ['x'] = 12622,
                    ['y'] = 2088
                },
                {
                    ['name'] = "Restaurant",
                    ['x'] = 12617,
                    ['y'] = 2062
                },
                {
                    ['name'] = "Farming Supplies",
                    ['x'] = 12549,
                    ['y'] = 2108
                },
                {
                    ['name'] = "Clothing Shop",
                    ['x'] = 12574,
                    ['y'] = 2109
                },
                {
                    ['name'] = "Forna Della Mamma",
                    ['x'] = 12584,
                    ['y'] = 2087
                },
                {
                    ['name'] = "Taco del Pancho",
                    ['x'] = 12584,
                    ['y'] = 2074
                },
                {
                    ['name'] = "Greene's",
                    ['x'] = 12661,
                    ['y'] = 2114
                },
                {
                    ['name'] = "Filigree Fashions",
                    ['x'] = 12583,
                    ['y'] = 2015
                },
                {
                    ['name'] = "Jaime's Jam Delights",
                    ['x'] = 12583,
                    ['y'] = 2009
                },
                {
                    ['name'] = "Louisville Animal Hospital",
                    ['x'] = 12580,
                    ['y'] = 1989
                },
                {
                    ['name'] = "R. Johnson Office Building",
                    ['x'] = 12649,
                    ['y'] = 2020
                },
                {
                    ['name'] = "Secure Storage",
                    ['x'] = 12706,
                    ['y'] = 2018
                },
                {
                    ['name'] = "Buffet",
                    ['x'] = 12704,
                    ['y'] = 1967
                },
                {
                    ['name'] = "Zippee Market",
                    ['x'] = 12729,
                    ['y'] = 1964
                },
                {
                    ['name'] = "Playground",
                    ['x'] = 12763,
                    ['y'] = 1891
                },
                {
                    ['name'] = "Louisville Fancy Apartment",
                    ['x'] = 12771,
                    ['y'] = 1814
                },
                {
                    ['name'] = "Apartment",
                    ['x'] = 12714,
                    ['y'] = 1842
                },
                {
                    ['name'] = "Recreation Center",
                    ['x'] = 12616,
                    ['y'] = 1850
                },
                {
                    ['name'] = "Seahorse Coffee",
                    ['x'] = 12613,
                    ['y'] = 1900
                },
                {
                    ['name'] = "Toy Store",
                    ['x'] = 12614,
                    ['y'] = 1894
                },
                {
                    ['name'] = "Pizza Whirled",
                    ['x'] = 12614,
                    ['y'] = 1885
                },
                {
                    ['name'] = "Pharmahug",
                    ['x'] = 12613,
                    ['y'] = 1873
                },
                {
                    ['name'] = "Golden Dragon Buffet",
                    ['x'] = 12584,
                    ['y'] = 1892
                },
                {
                    ['name'] = "The Hardy Har Bar",
                    ['x'] = 12587,
                    ['y'] = 1907
                },
                {
                    ['name'] = "Be Beauty",
                    ['x'] = 12585,
                    ['y'] = 1930
                },
                {
                    ['name'] = "Barnard's Book & Emporium",
                    ['x'] = 12562,
                    ['y'] = 1939
                },
                {
                    ['name'] = "Reed Office Building",
                    ['x'] = 12580,
                    ['y'] = 1839
                },
                {
                    ['name'] = "Hugo Plush",
                    ['x'] = 12583,
                    ['y'] = 1813
                },
                {
                    ['name'] = "Di Macro",
                    ['x'] = 12578,
                    ['y'] = 1783
                },
                {
                    ['name'] = "Carton & Sydney Law Services",
                    ['x'] = 12581,
                    ['y'] = 1754
                },
                {
                    ['name'] = "Knox Bank",
                    ['x'] = 12582,
                    ['y'] = 1704
                },
                {
                    ['name'] = "Walter & Perry Legal Firm",
                    ['x'] = 12581,
                    ['y'] = 1677
                },
                {
                    ['name'] = "Tech Store/Furniture",
                    ['x'] = 12522,
                    ['y'] = 1673
                },
                {
                    ['name'] = "Romero Center For The Performing Arts",
                    ['x'] = 12530,
                    ['y'] = 1774
                },
                {
                    ['name'] = "Seahorse Coffee",
                    ['x'] = 12584,
                    ['y'] = 1636
                },
                {
                    ['name'] = "Sweet Sugar Beauty",
                    ['x'] = 12585,
                    ['y'] = 1618
                },
                {
                    ['name'] = "Maison du Boeuf",
                    ['x'] = 12582,
                    ['y'] = 1597
                },
                {
                    ['name'] = "Jewelry Store",
                    ['x'] = 12612,
                    ['y'] = 1623
                },
                {
                    ['name'] = "Bakery & Cafe",
                    ['x'] = 12618,
                    ['y'] = 1639
                },
                {
                    ['name'] = "Office Building",
                    ['x'] = 12647,
                    ['y'] = 1638
                },
                {
                    ['name'] = "Topcrown Plaza",
                    ['x'] = 12664,
                    ['y'] = 1644
                },
                {
                    ['name'] = "Nourish Food Market (Topcrown Plaza)",
                    ['x'] = 12655,
                    ['y'] = 1637
                },
                {
                    ['name'] = "Expresso Espress (Topcrown Plaza)",
                    ['x'] = 12669,
                    ['y'] = 1634
                },
                {
                    ['name'] = "Bar & Restaurant",
                    ['x'] = 12616,
                    ['y'] = 1672
                },
                {
                    ['name'] = "GigaMart Office",
                    ['x'] = 12668,
                    ['y'] = 1677
                },
                {
                    ['name'] = "Food Market",
                    ['x'] = 12620,
                    ['y'] = 1710
                },
                {
                    ['name'] = "Studio Apartment",
                    ['x'] = 12620,
                    ['y'] = 1735
                },
                {
                    ['name'] = "Bank",
                    ['x'] = 12616,
                    ['y'] = 1583
                },
                {
                    ['name'] = "Louisville City Hall",
                    ['x'] = 12576,
                    ['y'] = 1534
                },
                {
                    ['name'] = "City Park",
                    ['x'] = 12642,
                    ['y'] = 1528
                },
                {
                    ['name'] = "County Clerk and Records",
                    ['x'] = 12642,
                    ['y'] = 1477
                },
                {
                    ['name'] = "Brooks Public Library of Louisville",
                    ['x'] = 12575,
                    ['y'] = 1482
                },
                {
                    ['name'] = "Raney & Daye Investment Firm",
                    ['x'] = 12583,
                    ['y'] = 1443
                },
                {
                    ['name'] = "Greenwood Office Building",
                    ['x'] = 12535,
                    ['y'] = 1490
                },
                {
                    ['name'] = "Zippee Market",
                    ['x'] = 12522,
                    ['y'] = 1488
                },
                {
                    ['name'] = "Park",
                    ['x'] = 12532,
                    ['y'] = 1600
                },
                {
                    ['name'] = "Louisville Police Department and Detention Services",
                    ['x'] = 12489,
                    ['y'] = 1586
                },
                {
                    ['name'] = "Fancy Bar & Restaurant",
                    ['x'] = 12615,
                    ['y'] = 1437
                },
                {
                    ['name'] = "Art Gallery of Louisville",
                    ['x'] = 12573,
                    ['y'] = 1391
                },
                {
                    ['name'] = "Cake & Pie Store",
                    ['x'] = 12614,
                    ['y'] = 1407
                },
                {
                    ['name'] = "Bar",
                    ['x'] = 12612,
                    ['y'] = 1369
                },
                {
                    ['name'] = "Sandwitch Store",
                    ['x'] = 12647,
                    ['y'] = 1364
                },
                {
                    ['name'] = "Zippee Market",
                    ['x'] = 12668,
                    ['y'] = 1365
                },
                {
                    ['name'] = "E. Wrayburn Building",
                    ['x'] = 12673,
                    ['y'] = 1391
                },
                {
                    ['name'] = "Main Park",
                    ['x'] = 12729,
                    ['y'] = 1437
                },
                {
                    ['name'] = "St. Michnel's Cathedral",
                    ['x'] = 12771,
                    ['y'] = 1426
                },
                {
                    ['name'] = "The Havisham -Hotel Suites-",
                    ['x'] = 12650,
                    ['y'] = 1325
                },
                {
                    ['name'] = "¡Cafe OLÉ",
                    ['x'] = 12718,
                    ['y'] = 1337
                },
                {
                    ['name'] = "SashaSashay",
                    ['x'] = 12744,
                    ['y'] = 1339
                },
                {
                    ['name'] = "Seat Yourself -Furniture-",
                    ['x'] = 12759,
                    ['y'] = 1338
                },
                {
                    ['name'] = "Hugo Plush",
                    ['x'] = 12783,
                    ['y'] = 1338
                },
                {
                    ['name'] = "Pharmahug (Cardinal Plaza)",
                    ['x'] = 12815,
                    ['y'] = 1336
                },
                {
                    ['name'] = "Cardinal Plaza",
                    ['x'] = 12850,
                    ['y'] = 1324
                },
                {
                    ['name'] = "Yummmers",
                    ['x'] = 12886,
                    ['y'] = 1336
                },
                {
                    ['name'] = "Louisville Expo Center",
                    ['x'] = 12976,
                    ['y'] = 1337
                },
                {
                    ['name'] = "Police Station",
                    ['x'] = 12968,
                    ['y'] = 1367
                },
                {
                    ['name'] = "Roxy's Roller Rink",
                    ['x'] = 12985,
                    ['y'] = 1454
                },
                {
                    ['name'] = "Med U Well -Pharmacy & Medical Clinic-",
                    ['x'] = 12955,
                    ['y'] = 1489
                },
                {
                    ['name'] = "Kickory Bakery Box",
                    ['x'] = 12931,
                    ['y'] = 1490
                },
                {
                    ['name'] = "Restaurant",
                    ['x'] = 12909,
                    ['y'] = 1487
                },
                {
                    ['name'] = "Clothing Store",
                    ['x'] = 12908,
                    ['y'] = 1470
                },
                {
                    ['name'] = "Knoxpack Kitchens",
                    ['x'] = 12909,
                    ['y'] = 1454
                },
                {
                    ['name'] = "Diner",
                    ['x'] = 12916,
                    ['y'] = 1410
                },
                {
                    ['name'] = "BBBQ",
                    ['x'] = 12922,
                    ['y'] = 1339
                },
                {
                    ['name'] = "Knox Distillery",
                    ['x'] = 12922,
                    ['y'] = 1375
                },
                {
                    ['name'] = "Tom Cat Tavern",
                    ['x'] = 12916,
                    ['y'] = 1367
                },
                {
                    ['name'] = "The Real Sweat",
                    ['x'] = 12887,
                    ['y'] = 1368
                },
                {
                    ['name'] = "High Street Apartments",
                    ['x'] = 12853,
                    ['y'] = 1479
                },
                {
                    ['name'] = "Apartments",
                    ['x'] = 12850,
                    ['y'] = 1565
                },
                {
                    ['name'] = "Bateman Office Building",
                    ['x'] = 12790,
                    ['y'] = 1527
                },
                {
                    ['name'] = "Orio Office Place",
                    ['x'] = 12753,
                    ['y'] = 1625
                },
                {
                    ['name'] = "Spiffo's Headquarters",
                    ['x'] = 12714,
                    ['y'] = 1628
                },
                {
                    ['name'] = "Pile-o-Crepe",
                    ['x'] = 12628,
                    ['y'] = 1263
                },
                {
                    ['name'] = "Seahorse Coffee",
                    ['x'] = 12623,
                    ['y'] = 1215
                },
                {
                    ['name'] = "Tim's Bakery",
                    ['x'] = 12641,
                    ['y'] = 1218
                },
                {
                    ['name'] = "Neon Flower Salon",
                    ['x'] = 12655,
                    ['y'] = 1218
                },
                {
                    ['name'] = "Purple+Black",
                    ['x'] = 12673,
                    ['y'] = 1217
                },
                {
                    ['name'] = "The Top Hanger",
                    ['x'] = 12692,
                    ['y'] = 1217
                },
                {
                    ['name'] = "Cally's Gifts",
                    ['x'] = 12708,
                    ['y'] = 1218
                },
                {
                    ['name'] = "Genny's Diner",
                    ['x'] = 12720,
                    ['y'] = 1218
                },
                {
                    ['name'] = "The Plump Cornucopia",
                    ['x'] = 12745,
                    ['y'] = 1220
                },
                {
                    ['name'] = "Sweet Satosfaction",
                    ['x'] = 12763,
                    ['y'] = 1207
                },
                {
                    ['name'] = "American Eats",
                    ['x'] = 12785,
                    ['y'] = 1219
                },
                {
                    ['name'] = "Hit Vids",
                    ['x'] = 12797,
                    ['y'] = 1219
                },
                {
                    ['name'] = "Yuri Design",
                    ['x'] = 12809,
                    ['y'] = 1219
                },
                {
                    ['name'] = "Hair Genesis",
                    ['x'] = 12833,
                    ['y'] = 1219
                },
                {
                    ['name'] = "The Sea Shanty",
                    ['x'] = 12864,
                    ['y'] = 1215
                },
                {
                    ['name'] = "Expresso Espress",
                    ['x'] = 12915,
                    ['y'] = 1226
                },
                {
                    ['name'] = "Riverview Apartments #1",
                    ['x'] = 12937,
                    ['y'] = 1222
                },
                {
                    ['name'] = "Riverview Apartments #2",
                    ['x'] = 12976,
                    ['y'] = 1222
                },
                {
                    ['name'] = "Riverview Apartments #3",
                    ['x'] = 13009,
                    ['y'] = 1221
                },
                {
                    ['name'] = "The Waterfront",
                    ['x'] = 13040,
                    ['y'] = 1218
                },
                {
                    ['name'] = "Eluee Arena",
                    ['x'] = 13062,
                    ['y'] = 1395
                },
                {
                    ['name'] = "Turbo TV",
                    ['x'] = 13081,
                    ['y'] = 1480
                },
                {
                    ['name'] = "Apartments",
                    ['x'] = 13011,
                    ['y'] = 1486
                },
                {
                    ['name'] = "From the Dugout -Gift Shop-(Fossoil Field)",
                    ['x'] = 13045,
                    ['y'] = 1639
                },
                {
                    ['name'] = "Fossoil Field (Baseball)",
                    ['x'] = 12961,
                    ['y'] = 1584
                },
                {
                    ['name'] = "Spiffo's (Fossoil Field)",
                    ['x'] = 13080,
                    ['y'] = 1629
                },
                {
                    ['name'] = "Seahorse Coffee (Fossoil Field)",
                    ['x'] = 13074,
                    ['y'] = 1600
                },
                {
                    ['name'] = "Pizza Whirled East (Fossoil Field)",
                    ['x'] = 13074,
                    ['y'] = 1588
                },
                {
                    ['name'] = "Pizza Whirled North (Fossoil Field)",
                    ['x'] = 12969,
                    ['y'] = 1522
                },
                {
                    ['name'] = "Family Funzone",
                    ['x'] = 13135,
                    ['y'] = 1675
                },
                {
                    ['name'] = "U-S Tore It",
                    ['x'] = 13125,
                    ['y'] = 1730
                },
                {
                    ['name'] = "American Tire",
                    ['x'] = 13118,
                    ['y'] = 1770
                },
                {
                    ['name'] = "Thumbs of Green",
                    ['x'] = 13140,
                    ['y'] = 1781
                },
                {
                    ['name'] = "Club Pamplemousse de la Croix",
                    ['x'] = 13174,
                    ['y'] = 1762
                },
                {
                    ['name'] = "Palette POP -Art Supplies-",
                    ['x'] = 13183,
                    ['y'] = 1749
                },
                {
                    ['name'] = "Have A Butcher's",
                    ['x'] = 13182,
                    ['y'] = 1741
                },
                {
                    ['name'] = "Shaken and Stirred (Bar)",
                    ['x'] = 13182,
                    ['y'] = 1732
                },
                {
                    ['name'] = "Expresso Espress",
                    ['x'] = 13183,
                    ['y'] = 1725
                },
                {
                    ['name'] = "Evan Philips Tax & Accounting",
                    ['x'] = 13183,
                    ['y'] = 1720
                },
                {
                    ['name'] = "Spitfine (Fashion)",
                    ['x'] = 13183,
                    ['y'] = 1712
                },
                {
                    ['name'] = "Sooky's",
                    ['x'] = 13183,
                    ['y'] = 1706
                },
                {
                    ['name'] = "Mead, Drink and Bloody Merry",
                    ['x'] = 13183,
                    ['y'] = 1690
                },
                {
                    ['name'] = "Cafe of Wonders",
                    ['x'] = 13182,
                    ['y'] = 1681
                },
                {
                    ['name'] = "Homeward Real Estate",
                    ['x'] = 13182,
                    ['y'] = 1673
                },
                {
                    ['name'] = "Haircuts 'n More",
                    ['x'] = 13182,
                    ['y'] = 1666
                },
                {
                    ['name'] = "Electron House",
                    ['x'] = 13183,
                    ['y'] = 1643
                },
                {
                    ['name'] = "Sucrafruit Circus",
                    ['x'] = 13183,
                    ['y'] = 1637
                },
                {
                    ['name'] = "Fashionabelle",
                    ['x'] = 13183,
                    ['y'] = 1629
                },
                {
                    ['name'] = "A-1 Laundry",
                    ['x'] = 12531,
                    ['y'] = 7168
                },
                {
                    ['name'] = "Goodman Legal Services",
                    ['x'] = 13182,
                    ['y'] = 1612
                },
                {
                    ['name'] = "Greene's",
                    ['x'] = 13182,
                    ['y'] = 1604
                },
                {
                    ['name'] = "Boxpop Brewery",
                    ['x'] = 13183,
                    ['y'] = 1594
                },
                {
                    ['name'] = "Supper Delight",
                    ['x'] = 13182,
                    ['y'] = 1584
                },
                {
                    ['name'] = "Shoed for the Stars",
                    ['x'] = 13183,
                    ['y'] = 1576
                },
                {
                    ['name'] = "Awl Work and Sew Play",
                    ['x'] = 13182,
                    ['y'] = 1560
                },
                {
                    ['name'] = "E.P. Tools",
                    ['x'] = 13182,
                    ['y'] = 1551
                },
                {
                    ['name'] = "Sunset Pines Funeral Home",
                    ['x'] = 13178,
                    ['y'] = 1527
                },
                {
                    ['name'] = "Jimmy's Pre-owned Cars",
                    ['x'] = 13160,
                    ['y'] = 1461
                },
                {
                    ['name'] = "Upscale Mobility -Auto Dealership-",
                    ['x'] = 13169,
                    ['y'] = 1381
                },
                {
                    ['name'] = "Gas-2-Go",
                    ['x'] = 13133,
                    ['y'] = 1318
                },
                {
                    ['name'] = "The Black Saddle",
                    ['x'] = 13193,
                    ['y'] = 1333
                },
                {
                    ['name'] = "Laundromat",
                    ['x'] = 13213,
                    ['y'] = 1353
                },
                {
                    ['name'] = "Seahorse Coffee",
                    ['x'] = 13214,
                    ['y'] = 1384
                },
                {
                    ['name'] = "Hair Salon",
                    ['x'] = 13214,
                    ['y'] = 1395
                },
                {
                    ['name'] = "Zippee Market",
                    ['x'] = 13212,
                    ['y'] = 1406
                },
                {
                    ['name'] = "Playground",
                    ['x'] = 13305,
                    ['y'] = 1483
                },
                {
                    ['name'] = "Sammie's",
                    ['x'] = 13436,
                    ['y'] = 1465
                },
                {
                    ['name'] = "Pile-o-Crepe",
                    ['x'] = 13425,
                    ['y'] = 1420
                },
                {
                    ['name'] = "Fossoil",
                    ['x'] = 13381,
                    ['y'] = 1422
                },
                {
                    ['name'] = "Pizza Whirled",
                    ['x'] = 13470,
                    ['y'] = 1415
                },
                {
                    ['name'] = "The Grand Ohio Mall",
                    ['x'] = 13570,
                    ['y'] = 1409
                },
                {
                    ['name'] = "Stationery -Teaching Supplies-",
                    ['x'] = 13675,
                    ['y'] = 1573
                },
                {
                    ['name'] = "U-S Tore It",
                    ['x'] = 13659,
                    ['y'] = 1601
                },
                {
                    ['name'] = "Junkyard",
                    ['x'] = 13688,
                    ['y'] = 1676
                },
                {
                    ['name'] = "Liquor Store",
                    ['x'] = 13671,
                    ['y'] = 1732
                },
                {
                    ['name'] = "Pie Store",
                    ['x'] = 13670,
                    ['y'] = 1743
                },
                {
                    ['name'] = "Fire Department",
                    ['x'] = 13720,
                    ['y'] = 1788
                },
                {
                    ['name'] = "Tennis Field",
                    ['x'] = 13694,
                    ['y'] = 1820
                },
                {
                    ['name'] = "Basketball Field",
                    ['x'] = 13661,
                    ['y'] = 1823
                },
                {
                    ['name'] = "Square Apartment",
                    ['x'] = 13425,
                    ['y'] = 1733
                },
                {
                    ['name'] = "Bluegrass State High School",
                    ['x'] = 13056,
                    ['y'] = 1724
                },
                {
                    ['name'] = "Zippee Market",
                    ['x'] = 13067,
                    ['y'] = 1928
                },
                {
                    ['name'] = "Shady Oaks Nursing Home",
                    ['x'] = 13085,
                    ['y'] = 2038
                },
                {
                    ['name'] = "Pharmahug",
                    ['x'] = 13122,
                    ['y'] = 2131
                },
                {
                    ['name'] = "Greene's",
                    ['x'] = 13141,
                    ['y'] = 2131
                },
                {
                    ['name'] = "Nat's Cafe",
                    ['x'] = 13173,
                    ['y'] = 2136
                },
                {
                    ['name'] = "Pizza Whirled",
                    ['x'] = 13222,
                    ['y'] = 2110
                },
                {
                    ['name'] = "Convenience Store",
                    ['x'] = 13253,
                    ['y'] = 2111
                },
                {
                    ['name'] = "Toy Store",
                    ['x'] = 13251,
                    ['y'] = 2123
                },
                {
                    ['name'] = "Clothing Shop",
                    ['x'] = 13251,
                    ['y'] = 2139
                },
                {
                    ['name'] = "Restaurant",
                    ['x'] = 13253,
                    ['y'] = 2164
                },
                {
                    ['name'] = "Diner",
                    ['x'] = 13366,
                    ['y'] = 2284
                },
                {
                    ['name'] = "Milk 'n' More",
                    ['x'] = 13384,
                    ['y'] = 2285
                },
                {
                    ['name'] = "Iroquois Park Center",
                    ['x'] = 13391,
                    ['y'] = 2370
                },
                {
                    ['name'] = "Churus-R-US (Iroquois Park)",
                    ['x'] = 13337,
                    ['y'] = 2494
                },
                {
                    ['name'] = "Iroquois Park Overlook",
                    ['x'] = 13256,
                    ['y'] = 2418
                },
                {
                    ['name'] = "Iroquois Park Lake",
                    ['x'] = 13228,
                    ['y'] = 2587
                },
                {
                    ['name'] = "Bar (Iroquois Park)",
                    ['x'] = 13230,
                    ['y'] = 2657
                },
                {
                    ['name'] = "Playground (Iroquois Park)",
                    ['x'] = 13241,
                    ['y'] = 2681
                },
                {
                    ['name'] = "Basketball Field (Iroquois Park)",
                    ['x'] = 13244,
                    ['y'] = 2720
                },
                {
                    ['name'] = "Horse Training Center",
                    ['x'] = 13059,
                    ['y'] = 2826
                },
                {
                    ['name'] = "Playground",
                    ['x'] = 12964,
                    ['y'] = 2656
                },
                {
                    ['name'] = "Park",
                    ['x'] = 12705,
                    ['y'] = 2717
                },
                {
                    ['name'] = "Supermarket",
                    ['x'] = 12747,
                    ['y'] = 2941
                },
                {
                    ['name'] = "Trails",
                    ['x'] = 12798,
                    ['y'] = 3073
                },
                {
                    ['name'] = "South Louisville Elementary School",
                    ['x'] = 12970,
                    ['y'] = 3220
                },
                {
                    ['name'] = "Small Running track",
                    ['x'] = 13010,
                    ['y'] = 3207
                },
                {
                    ['name'] = "South Louisville Church",
                    ['x'] = 13188,
                    ['y'] = 3164
                },
                {
                    ['name'] = "South Louisville Police Station",
                    ['x'] = 13221,
                    ['y'] = 3098
                },
                {
                    ['name'] = "Pet Health Pawmise",
                    ['x'] = 13211,
                    ['y'] = 3051
                },
                {
                    ['name'] = "Farming Supplies",
                    ['x'] = 13224,
                    ['y'] = 3025
                },
                {
                    ['name'] = "Butcher Shop",
                    ['x'] = 13278,
                    ['y'] = 3029
                },
                {
                    ['name'] = "Bakery",
                    ['x'] = 13278,
                    ['y'] = 3016
                },
                {
                    ['name'] = "Beer & Liquor",
                    ['x'] = 13258,
                    ['y'] = 2981
                },
                {
                    ['name'] = "American Tire",
                    ['x'] = 13288,
                    ['y'] = 2972
                },
                {
                    ['name'] = "Jita Maria's Cantina",
                    ['x'] = 13313,
                    ['y'] = 2978
                },
                {
                    ['name'] = "Hair-o-Genesis",
                    ['x'] = 13333,
                    ['y'] = 2975
                },
                {
                    ['name'] = "Greene's",
                    ['x'] = 13336,
                    ['y'] = 2961
                },
                {
                    ['name'] = "Laundromat",
                    ['x'] = 13342,
                    ['y'] = 2945
                },
                {
                    ['name'] = "Gas-2-Go",
                    ['x'] = 13379,
                    ['y'] = 2956
                },
                {
                    ['name'] = "Canto Records",
                    ['x'] = 13389,
                    ['y'] = 2938
                },
                {
                    ['name'] = "Spiffo's",
                    ['x'] = 13452,
                    ['y'] = 2938
                },
                {
                    ['name'] = "Jay's Chicken",
                    ['x'] = 13465,
                    ['y'] = 2975
                },
                {
                    ['name'] = "Gigamart",
                    ['x'] = 13471,
                    ['y'] = 3048
                },
                {
                    ['name'] = "Gusto D'italia",
                    ['x'] = 13518,
                    ['y'] = 3031
                },
                {
                    ['name'] = "Taco del Pancho",
                    ['x'] = 13534,
                    ['y'] = 3032
                },
                {
                    ['name'] = "Liquorty-Split",
                    ['x'] = 13550,
                    ['y'] = 3032
                },
                {
                    ['name'] = "Food Market",
                    ['x'] = 13566,
                    ['y'] = 3032
                },
                {
                    ['name'] = "Knox Bank",
                    ['x'] = 13608,
                    ['y'] = 3033
                },
                {
                    ['name'] = "Woodworking Shop",
                    ['x'] = 13528,
                    ['y'] = 3087
                },
                {
                    ['name'] = "Clothing Shop",
                    ['x'] = 13554,
                    ['y'] = 3088
                },
                {
                    ['name'] = "Martin's Essentials & Laundry",
                    ['x'] = 13516,
                    ['y'] = 3090
                },
                {
                    ['name'] = "Blue Plate Diner",
                    ['x'] = 13243,
                    ['y'] = 3482
                },
                {
                    ['name'] = "E￠ono Room$",
                    ['x'] = 13234,
                    ['y'] = 3518
                },
                {
                    ['name'] = "Jukebox Bowling",
                    ['x'] = 12446,
                    ['y'] = 2080
                },
                {
                    ['name'] = "5Bux or Less",
                    ['x'] = 12483,
                    ['y'] = 2088
                },
                {
                    ['name'] = "I♥Wok & Rolls",
                    ['x'] = 12495,
                    ['y'] = 2071
                },
                {
                    ['name'] = "Diner",
                    ['x'] = 12493,
                    ['y'] = 2054
                },
                {
                    ['name'] = "LBMW Network",
                    ['x'] = 12340,
                    ['y'] = 2081
                },
                {
                    ['name'] = "Holy Light Baptist Church",
                    ['x'] = 12409,
                    ['y'] = 1939
                },
                {
                    ['name'] = "Spiffo's",
                    ['x'] = 12316,
                    ['y'] = 1942
                },
                {
                    ['name'] = "Motel",
                    ['x'] = 12329,
                    ['y'] = 1882
                },
                {
                    ['name'] = "Medical Center",
                    ['x'] = 12409,
                    ['y'] = 1768
                },
                {
                    ['name'] = "Fire Department",
                    ['x'] = 12369,
                    ['y'] = 1749
                },
                {
                    ['name'] = "Buffet",
                    ['x'] = 12379,
                    ['y'] = 1726
                },
                {
                    ['name'] = "Oak Park Apartments",
                    ['x'] = 12378,
                    ['y'] = 1694
                },
                {
                    ['name'] = "Tattoo 42",
                    ['x'] = 12371,
                    ['y'] = 1645
                },
                {
                    ['name'] = "Barber of Yorke",
                    ['x'] = 12379,
                    ['y'] = 1645
                },
                {
                    ['name'] = "Valu In$urance",
                    ['x'] = 12383,
                    ['y'] = 1630
                },
                {
                    ['name'] = "Bail Bonds",
                    ['x'] = 12383,
                    ['y'] = 1624
                },
                {
                    ['name'] = "Family Fashion",
                    ['x'] = 12382,
                    ['y'] = 1613
                },
                {
                    ['name'] = "Convenience Store",
                    ['x'] = 12405,
                    ['y'] = 1635
                },
                {
                    ['name'] = "Laundromat",
                    ['x'] = 12381,
                    ['y'] = 1585
                },
                {
                    ['name'] = "Conven U Mart",
                    ['x'] = 12383,
                    ['y'] = 1566
                },
                {
                    ['name'] = "Burgers",
                    ['x'] = 12382,
                    ['y'] = 1551
                },
                {
                    ['name'] = "I♥Wok & Rolls",
                    ['x'] = 12382,
                    ['y'] = 1539
                },
                {
                    ['name'] = "Laundromat",
                    ['x'] = 12381,
                    ['y'] = 1528
                },
                {
                    ['name'] = "Book Naked",
                    ['x'] = 12381,
                    ['y'] = 1509
                },
                {
                    ['name'] = "Bar",
                    ['x'] = 12404,
                    ['y'] = 1539
                },
                {
                    ['name'] = "Barg-n-Clothes",
                    ['x'] = 12413,
                    ['y'] = 1561
                },
                {
                    ['name'] = "O' Brien's Kitchen -Home-Cooked Favorites-",
                    ['x'] = 12383,
                    ['y'] = 1482
                },
                {
                    ['name'] = "Phil's Fined & Fair Pawn Shop",
                    ['x'] = 12382,
                    ['y'] = 1470
                },
                {
                    ['name'] = "Church of the Risen Christ",
                    ['x'] = 12408,
                    ['y'] = 1475
                },
                {
                    ['name'] = "Bloomin Coffee",
                    ['x'] = 12442,
                    ['y'] = 1490
                },
                {
                    ['name'] = "MindPeace Insurance",
                    ['x'] = 12456,
                    ['y'] = 1490
                },
                {
                    ['name'] = "Sleep EazZzE Inn",
                    ['x'] = 12491,
                    ['y'] = 1484
                },
                {
                    ['name'] = "Shelter",
                    ['x'] = 12406,
                    ['y'] = 1444
                },
                {
                    ['name'] = "Beeyer's",
                    ['x'] = 12381,
                    ['y'] = 1428
                },
                {
                    ['name'] = "Music Store",
                    ['x'] = 12402,
                    ['y'] = 1390
                },
                {
                    ['name'] = "Factory Bar",
                    ['x'] = 12464,
                    ['y'] = 1392
                },
                {
                    ['name'] = "Loans Cash Jewelry",
                    ['x'] = 12493,
                    ['y'] = 1384
                },
                {
                    ['name'] = "Zac's Hardware",
                    ['x'] = 12381,
                    ['y'] = 1381
                },
                {
                    ['name'] = "Fryer Tooks Fish N' Chips",
                    ['x'] = 12382,
                    ['y'] = 1363
                },
                {
                    ['name'] = "Fun Xtreme",
                    ['x'] = 12373,
                    ['y'] = 1337
                },
                {
                    ['name'] = "Convenience Store",
                    ['x'] = 12354,
                    ['y'] = 1363
                },
                {
                    ['name'] = "Theater",
                    ['x'] = 12336,
                    ['y'] = 1366
                },
                {
                    ['name'] = "Laundry",
                    ['x'] = 12312,
                    ['y'] = 1368
                },
                {
                    ['name'] = "Pawn $$$hop",
                    ['x'] = 12318,
                    ['y'] = 1334
                },
                {
                    ['name'] = "Haircuts 'n More",
                    ['x'] = 12306,
                    ['y'] = 1335
                },
                {
                    ['name'] = "Perfick Potato Co.",
                    ['x'] = 12287,
                    ['y'] = 1364
                },
                {
                    ['name'] = "Jay's Chicken",
                    ['x'] = 12280,
                    ['y'] = 1380
                },
                {
                    ['name'] = "Louisville Animal Shelter",
                    ['x'] = 12276,
                    ['y'] = 1451
                },
                
                {
                    ['name'] = "Construction Site #1",
                    ['x'] = 12318,
                    ['y'] = 1598
                },
                {
                    ['name'] = "Radio Communication Station",
                    ['x'] = 12266,
                    ['y'] = 1710
                },
                {
                    ['name'] = "Container Storages",
                    ['x'] = 12225,
                    ['y'] = 1668
                },
                {
                    ['name'] = "Container Storages #2",
                    ['x'] = 12187,
                    ['y'] = 1686
                },
                {
                    ['name'] = "Newton Fright Warehouse",
                    ['x'] = 12181,
                    ['y'] = 1624
                },
                {
                    ['name'] = "Maps Unlimited",
                    ['x'] = 12233,
                    ['y'] = 1630
                },
                {
                    ['name'] = "Fossoil Gas Station",
                    ['x'] = 12258,
                    ['y'] = 1626
                },
                
                {
                    ['name'] = "Andrei & Son -Hand-created Wallets-",
                    ['x'] = 12230,
                    ['y'] = 1583
                },
                {
                    ['name'] = "AL's Auto Shop",
                    ['x'] = 12269,
                    ['y'] = 1575
                },
                {
                    ['name'] = "Fossoil Office",
                    ['x'] = 12077,
                    ['y'] = 1607
                },
                {
                    ['name'] = "West Louisville Habor Dock #1",
                    ['x'] = 11991,
                    ['y'] = 1666
                },
                {
                    ['name'] = "Rely ★ Manufacturing Co.",
                    ['x'] = 12026,
                    ['y'] = 1855
                },
                {
                    ['name'] = "Scarlet Oak Distillery",
                    ['x'] = 12027,
                    ['y'] = 2047
                },
                {
                    ['name'] = "Zippee Market with Laundromat",
                    ['x'] = 12126,
                    ['y'] = 2039
                },
                {
                    ['name'] = "Valu In$urance",
                    ['x'] = 12106,
                    ['y'] = 2019
                },
                {
                    ['name'] = "Sweet Eats!",
                    ['x'] = 12088,
                    ['y'] = 2019
                },
                {
                    ['name'] = "Martin's Essentials & Laundry with Gas Station",
                    ['x'] = 12090,
                    ['y'] = 2110
                },
                {
                    ['name'] = "Gas-2-Go Office",
                    ['x'] = 12082,
                    ['y'] = 1426
                },
                {
                    ['name'] = "Aitor Wire Company",
                    ['x'] = 12192,
                    ['y'] = 1455
                },
                {
                    ['name'] = "Metalworking Factory",
                    ['x'] = 12178,
                    ['y'] = 1403
                },
                {
                    ['name'] = "Jim's Autoshop",
                    ['x'] = 12241,
                    ['y'] = 1377
                },
                
                {
                    ['name'] = "Beer & Liquor",
                    ['x'] = 12234,
                    ['y'] = 1352
                },
                {
                    ['name'] = "United Shipping Logistics",
                    ['x'] = 12213,
                    ['y'] = 1357
                },
                {
                    ['name'] = "Secure Storage",
                    ['x'] = 12202,
                    ['y'] = 1346
                },
                {
                    ['name'] = "Ready Prep -Army Issue Surplus-",
                    ['x'] = 12241,
                    ['y'] = 1321
                },
                {
                    ['name'] = "Egener EX",
                    ['x'] = 12208,
                    ['y'] = 1281
                },
                {
                    ['name'] = "Mass-Genfac Co.",
                    ['x'] = 12138,
                    ['y'] = 1316
                },
                {
                    ['name'] = "Brac Brick Factory",
                    ['x'] = 12123,
                    ['y'] = 1280
                },
                
                {
                    ['name'] = "Du Case Apartments",
                    ['x'] = 12278,
                    ['y'] = 1287
                },
                {
                    ['name'] = "Laundry",
                    ['x'] = 12310,
                    ['y'] = 1305
                },
                {
                    ['name'] = "The Velvet Jassel",
                    ['x'] = 12327,
                    ['y'] = 1288
                },
                {
                    ['name'] = "Convenience Store",
                    ['x'] = 12304,
                    ['y'] = 1245
                },
                {
                    ['name'] = "Restaurant",
                    ['x'] = 12329,
                    ['y'] = 1245
                },
                {
                    ['name'] = "Red Owl Inn",
                    ['x'] = 12355,
                    ['y'] = 1273
                },
                {
                    ['name'] = "Nite Glo",
                    ['x'] = 12429,
                    ['y'] = 1339
                },
                {
                    ['name'] = "Milk Monarchy",
                    ['x'] = 12522,
                    ['y'] = 1329
                },
                {
                    ['name'] = "The Exquisite Pearl -Fine Jewelry-",
                    ['x'] = 12536,
                    ['y'] = 1339
                },
                {
                    ['name'] = "Laces",
                    ['x'] = 12548,
                    ['y'] = 1333
                },
                {
                    ['name'] = "Posh Box",
                    ['x'] = 12548,
                    ['y'] = 1319
                },
                {
                    ['name'] = "Dressed to the 90s",
                    ['x'] = 12584,
                    ['y'] = 1330
                },
                {
                    ['name'] = "Toyz Toyz Toyz",
                    ['x'] = 12584,
                    ['y'] = 1311
                },
                {
                    ['name'] = "La Vie En Gastronomie",
                    ['x'] = 12584,
                    ['y'] = 1293
                },
                {
                    ['name'] = "Fancy Clothing Shop",
                    ['x'] = 12551,
                    ['y'] = 1251
                },
                {
                    ['name'] = "Book Store",
                    ['x'] = 12535,
                    ['y'] = 1250
                },
                {
                    ['name'] = "Toy Store",
                    ['x'] = 12520,
                    ['y'] = 1250
                },
                {
                    ['name'] = "StarEplex",
                    ['x'] = 12487,
                    ['y'] = 1253
                },
                {
                    ['name'] = "Pizza Whirled",
                    ['x'] = 12489,
                    ['y'] = 1337
                },
                {
                    ['name'] = "Waterfront Park",
                    ['x'] = 12555,
                    ['y'] = 1131
                },
                {
                    ['name'] = "Body Chisel -Gym & Fitness-",
                    ['x'] = 12621,
                    ['y'] = 1161
                },
                {
                    ['name'] = "Churus-R-US",
                    ['x'] = 12648,
                    ['y'] = 1162
                },
                {
                    ['name'] = "The Blue Fox",
                    ['x'] = 12673,
                    ['y'] = 1158
                },
                {
                    ['name'] = "Sheba Jewellers",
                    ['x'] = 12673,
                    ['y'] = 1184
                },
                {
                    ['name'] = "Sanguine Spirits",
                    ['x'] = 12715,
                    ['y'] = 1163
                },
                {
                    ['name'] = "Ch!ef -Steakhouse & Bar-",
                    ['x'] = 12738,
                    ['y'] = 1159
                },
                {
                    ['name'] = "Louisville Boat Club",
                    ['x'] = 12768,
                    ['y'] = 1152
                },
                {
                    ['name'] = "Les Tartes De Mademoiselle Céline",
                    ['x'] = 12754,
                    ['y'] = 1192
                },
                {
                    ['name'] = "Small Restaurant",
                    ['x'] = 13207,
                    ['y'] = 1291
                },
                {
                    ['name'] = "Noteworthy",
                    ['x'] = 13216,
                    ['y'] = 1291
                },
                {
                    ['name'] = "Your Closet",
                    ['x'] = 13224,
                    ['y'] = 1291
                },
                {
                    ['name'] = "Pharmahug",
                    ['x'] = 13238,
                    ['y'] = 1291
                },
                {
                    ['name'] = "Ice Ice Tasty",
                    ['x'] = 13243,
                    ['y'] = 1291
                },
                {
                    ['name'] = "Inkr Alley",
                    ['x'] = 13251,
                    ['y'] = 1291
                },
                {
                    ['name'] = "Hair-o-Genesis",
                    ['x'] = 13291,
                    ['y'] = 1291
                },
                {
                    ['name'] = "The Orange Anchor",
                    ['x'] = 13269,
                    ['y'] = 1291
                },
                {
                    ['name'] = "Scenic Mile -Car Dealership-",
                    ['x'] = 13243,
                    ['y'] = 1322
                },
                {
                    ['name'] = "Knox Bank",
                    ['x'] = 13414,
                    ['y'] = 1356
                },
                {
                    ['name'] = "Window",
                    ['x'] = 13418,
                    ['y'] = 1299
                },
                {
                    ['name'] = "Hit Vids",
                    ['x'] = 13430,
                    ['y'] = 1299
                },
                {
                    ['name'] = "Kegsplosion",
                    ['x'] = 13442,
                    ['y'] = 1299
                },
                {
                    ['name'] = "Clothing Shop",
                    ['x'] = 13462,
                    ['y'] = 1318
                },
                {
                    ['name'] = "Dotty 4 Donuts",
                    ['x'] = 13468,
                    ['y'] = 1353
                },
                {
                    ['name'] = "Clothing Shop",
                    ['x'] = 13179,
                    ['y'] = 1295
                },
                {
                    ['name'] = "Bar",
                    ['x'] = 13180,
                    ['y'] = 1285
                },
                {
                    ['name'] = "Bakery",
                    ['x'] = 13180,
                    ['y'] = 1277
                },
                {
                    ['name'] = "Toy Store",
                    ['x'] = 13179,
                    ['y'] = 1270
                },
                {
                    ['name'] = "Laundry",
                    ['x'] = 13179,
                    ['y'] = 1263
                },
                {
                    ['name'] = "Candy Store",
                    ['x'] = 13179,
                    ['y'] = 1256
                },
                {
                    ['name'] = "Book Store",
                    ['x'] = 13179,
                    ['y'] = 1253
                },
                {
                    ['name'] = "Restaurant",
                    ['x'] = 13179,
                    ['y'] = 1235
                },
                {
                    ['name'] = "Chugg's",
                    ['x'] = 13334,
                    ['y'] = 1255
                },
                {
                    ['name'] = "Louisville Bruiser",
                    ['x'] = 13253,
                    ['y'] = 1256
                },
                {
                    ['name'] = "Dock (North Louisville)",
                    ['x'] = 123,
                    ['y'] = 123
                },
                {
                    ['name'] = "Bridge (To Jeffersonville, Clarksville)",
                    ['x'] = 123,
                    ['y'] = 123
                },
                {
                    ['name'] = "East Construction Site",
                    ['x'] = 13,
                    ['y'] = 123
                },
                {
                    ['name'] = "Black Liqunorice",
                    ['x'] = 13615,
                    ['y'] = 1622
                },
                {
                    ['name'] = "Optima Eyes",
                    ['x'] = 13620,
                    ['y'] = 1600
                },
                {
                    ['name'] = "Family Dentistry",
                    ['x'] = 13614,
                    ['y'] = 1563
                },
                {
                    ['name'] = "Better Furnishings",
                    ['x'] = 13560,
                    ['y'] = 1521
                },
                {
                    ['name'] = "Restaurant",
                    ['x'] = 13568,
                    ['y'] = 1532
                },
                {
                    ['name'] = "Laundromat",
                    ['x'] = 13583,
                    ['y'] = 1532
                },
                {
                    ['name'] = "Gun Store",
                    ['x'] = 13597,
                    ['y'] = 1533
                },
                {
                    ['name'] = "Gas-2-Go",
                    ['x'] = 13610,
                    ['y'] = 1528
                },
                {
                    ['name'] = "KnoxTalk Radio",
                    ['x'] = 13577,
                    ['y'] = 1590
                },
                {
                    ['name'] = "Construction Site",
                    ['x'] = 13569,
                    ['y'] = 1641
                },
                {
                    ['name'] = "Finnegan Research Group",
                    ['x'] = 13601,
                    ['y'] = 1697
                },
                {
                    ['name'] = "Staff Shelter",
                    ['x'] = 13694,
                    ['y'] = 1883
                },
                {
                    ['name'] = "Music Festival",
                    ['x'] = 13760,
                    ['y'] = 1900
                },
                {
                    ['name'] = "Music Stage",
                    ['x'] = 13710,
                    ['y'] = 1963
                },
                {
                    ['name'] = "Romuald Dron Memorial Park",
                    ['x'] = 13860,
                    ['y'] = 1876
                },
                {
                    ['name'] = "Beer & Liquor",
                    ['x'] = 13589,
                    ['y'] = 2149
                },
                {
                    ['name'] = "Bakery",
                    ['x'] = 13584,
                    ['y'] = 2134
                },
                {
                    ['name'] = "Gas-2-Go",
                    ['x'] = 13556,
                    ['y'] = 2132
                },
                {
                    ['name'] = "Cafe d' Eris",
                    ['x'] = 13534,
                    ['y'] = 2148
                },
                {
                    ['name'] = "Greene's",
                    ['x'] = 13511,
                    ['y'] = 2149
                },
                {
                    ['name'] = "Pizza Whirled",
                    ['x'] = 13516,
                    ['y'] = 2112
                },
                {
                    ['name'] = "Wellington Heights Golf Club",
                    ['x'] = 12975,
                    ['y'] = 2247
                },
                {
                    ['name'] = "St. Vincent De Paul Church",
                    ['x'] = 12888,
                    ['y'] = 2858
                },
                {
                    ['name'] = "Zippee Market",
                    ['x'] = 13000,
                    ['y'] = 3119
                },
                {
                    ['name'] = "South Louisville Residential Area",
                    ['x'] = 13503,
                    ['y'] = 3241
                },
                {
                    ['name'] = "East Louisville Residential Area",
                    ['x'] = 14153,
                    ['y'] = 2850
                },
                {
                    ['name'] = "North Louisville Residential Area",
                    ['x'] = 13485,
                    ['y'] = 1859
                },
                {
                    ['name'] = "West Louisville Residential Area",
                    ['x'] = 12198,
                    ['y'] = 2262
                },
                {
                    ['name'] = "Gas-2-Go",
                    ['x'] = 13958,
                    ['y'] = 3265
                },
                {
                    ['name'] = "Milk 'n' More",
                    ['x'] = 13963,
                    ['y'] = 3244
                },
                {
                    ['name'] = "A.A Ron Hunting Supply",
                    ['x'] = 13961,
                    ['y'] = 3235
                },
                {
                    ['name'] = "Brighted Whites",
                    ['x'] = 13964,
                    ['y'] = 3222
                },
                {
                    ['name'] = "Happy Restaurant",
                    ['x'] = 13964,
                    ['y'] = 3215
                },
                {
                    ['name'] = "Beer + Liquor",
                    ['x'] = 13964,
                    ['y'] = 3207
                },
                {
                    ['name'] = "The Cosy Crockpot",
                    ['x'] = 13962,
                    ['y'] = 3194
                },
                {
                    ['name'] = "Homeward Real Estate",
                    ['x'] = 13963,
                    ['y'] = 3171
                },
                {
                    ['name'] = "Barber + Styling",
                    ['x'] = 13958,
                    ['y'] = 3154
                },
                {
                    ['name'] = "ai's Ales And All",
                    ['x'] = 13958,
                    ['y'] = 3131
                },
                {
                    ['name'] = "Legal Services",
                    ['x'] = 13962,
                    ['y'] = 3119
                },
                {
                    ['name'] = "E.P. Tools",
                    ['x'] = 13962,
                    ['y'] = 3108
                },
                {
                    ['name'] = "Fire Department",
                    ['x'] = 13937,
                    ['y'] = 3050
                },
                {
                    ['name'] = "Candytown, USA",
                    ['x'] = 13958,
                    ['y'] = 3154,
                    ['z'] = 1
                },
                {
                    ['name'] = "Family Fashion",
                    ['x'] = 13958,
                    ['y'] = 3144,
                    ['z'] = 1
                },
                {
                    ['name'] = "Valu In$urance",
                    ['x'] = 13958,
                    ['y'] = 3131,
                    ['z'] = 1
                },
                {
                    ['name'] = "The East Farm",
                    ['x'] = 14583,
                    ['y'] = 3053
                },
                {
                    ['name'] = "Triple Warehouse",
                    ['x'] = 13714,
                    ['y'] = 3968
                },
                {
                    ['name'] = "Abandoned Town",
                    ['x'] = 13612,
                    ['y'] = 4083
                },
                {
                    ['name'] = "Military Camp",
                    ['x'] = 13444,
                    ['y'] = 4071
                },
                {
                    ['name'] = "Checkpoint #3",
                    ['x'] = 14534,
                    ['y'] = 4022
                },
                {
                    ['name'] = "Checkpoint #2",
                    ['x'] = 13422,
                    ['y'] = 3989
                },
                {
                    ['name'] = "Lake",
                    ['x'] = 12734,
                    ['y'] = 4202
                },
                {
                    ['name'] = "Experimental Cage",
                    ['x'] = 12490,
                    ['y'] = 4312
                }
            }
        },
        {
            ['id'] = 4,
            ['name'] = "West Point",
            ['pois'] = {
                {
                    ['name'] = "Car Fix-Ation",
                    ['x'] = 11898,
                    ['y'] = 6807
                },
                {
                    ['name'] = "Bridge",
                    ['x'] = 12313,
                    ['y'] = 6733
                },
                {
                    ['name'] = "Burgers",
                    ['x'] = 12080,
                    ['y'] = 7080
                },
                {
                    ['name'] = "Church with Cemetary",
                    ['x'] = 11069,
                    ['y'] = 6710
                },
                {
                    ['name'] = "West Point Church",
                    ['x'] = 11962,
                    ['y'] = 6997
                },
                {
                    ['name'] = "Dock",
                    ['x'] = 11827,
                    ['y'] = 6596
                },
                {
                    ['name'] = "Kindergarten",
                    ['x'] = 11740,
                    ['y'] = 6923
                },
                {
                    ['name'] = "Enigma Books",
                    ['x'] = 11896,
                    ['y'] = 6887
                },
                {
                    ['name'] = "Farmhouse",
                    ['x'] = 11129,
                    ['y'] = 6856
                },
                {
                    ['name'] = "Convenience Store",
                    ['x'] = 11974,
                    ['y'] = 6912
                },
                {
                    ['name'] = "Fossoil",
                    ['x'] = 12070,
                    ['y'] = 7144
                },
                {
                    ['name'] = "GIGA Mart",
                    ['x'] = 12024,
                    ['y'] = 6853
                },
                {
                    ['name'] = "Guns & Ammo",
                    ['x'] = 12068,
                    ['y'] = 6759
                },
                {
                    ['name'] = "Hair-o-Genesis",
                    ['x'] = 11861,
                    ['y'] = 6888
                },
                {
                    ['name'] = "Post Office",
                    ['x'] = 11958,
                    ['y'] = 6911
                },
                {
                    ['name'] = "Food market",
                    ['x'] = 11988,
                    ['y'] = 6915
                },
                {
                    ['name'] = "Small Shack",
                    ['x'] = 10183,
                    ['y'] = 6765
                },
                {
                    ['name'] = "Knox Bank",
                    ['x'] = 11913,
                    ['y'] = 6914
                },
                {
                    ['name'] = "Large Warehouse",
                    ['x'] = 12140,
                    ['y'] = 7084
                },
                {
                    ['name'] = "Laundromat",
                    ['x'] = 11930,
                    ['y'] = 6786
                },
                {
                    ['name'] = "Hotel",
                    ['x'] = 12018,
                    ['y'] = 6917
                },
                {
                    ['name'] = "Pharmahug",
                    ['x'] = 11934,
                    ['y'] = 6805
                },
                {
                    ['name'] = "Picnic area",
                    ['x'] = 12033,
                    ['y'] = 7364
                },
                {
                    ['name'] = "Pizza Whirled",
                    ['x'] = 11667,
                    ['y'] = 7084
                },
                {
                    ['name'] = "Playground",
                    ['x'] = 11418,
                    ['y'] = 6782
                },
                {
                    ['name'] = "Police Station",
                    ['x'] = 11902,
                    ['y'] = 6949
                },
                {
                    ['name'] = "R.B. Mat, Dentist",
                    ['x'] = 11885,
                    ['y'] = 6889
                },
                {
                    ['name'] = "School",
                    ['x'] = 11345,
                    ['y'] = 6784
                },
                {
                    ['name'] = "Seahorse Coffee",
                    ['x'] = 11962,
                    ['y'] = 6879
                },
                {
                    ['name'] = "Spiffo's",
                    ['x'] = 11981,
                    ['y'] = 6815
                },
                {
                    ['name'] = "Storage Lots",
                    ['x'] = 12140,
                    ['y'] = 7029
                },
                {
                    ['name'] = "Constuction Site",
                    ['x'] = 12062,
                    ['y'] = 6918
                },
                {
                    ['name'] = "Corner Shop",
                    ['x'] = 11355,
                    ['y'] = 6725
                },
                {
                    ['name'] = "The Drake",
                    ['x'] = 11910,
                    ['y'] = 6852
                },
                {
                    ['name'] = "Pie Store",
                    ['x'] = 11910,
                    ['y'] = 6867
                },
                {
                    ['name'] = "Thunder Gas",
                    ['x'] = 11825,
                    ['y'] = 6871
                },
                {
                    ['name'] = "Town Hall",
                    ['x'] = 11950,
                    ['y'] = 6887
                },
                {
                    ['name'] = "Twiggy's",
                    ['x'] = 12069,
                    ['y'] = 6805
                },
                {
                    ['name'] = "Zippee Market",
                    ['x'] = 11667,
                    ['y'] = 7071
                },
                {
                    ['name'] = "Furniture Store",
                    ['x'] = 11932,
                    ['y'] = 6941
                },
                {
                    ['name'] = "Restaurant",
                    ['x'] = 11932,
                    ['y'] = 6914
                },
                {
                    ['name'] = "Office Building",
                    ['x'] = 11991,
                    ['y'] = 6942
                },
                {
                    ['name'] = "Office Building #2",
                    ['x'] = 11981,
                    ['y'] = 6889
                },
                {
                    ['name'] = "Commercial Rent",
                    ['x'] = 11666,
                    ['y'] = 7036
                },
                {
                    ['name'] = "Town Park",
                    ['x'] = 11786,
                    ['y'] = 6913
                },
                {
                    ['name'] = "Hardware Store",
                    ['x'] = 11833,
                    ['y'] = 6911
                }
            }
        },
        {
            ['id'] = 18,
            ['name'] = "Rosewood",
            ['pois'] = {
                {
                    ['name'] = "Fossoil",
                    ['x'] = 8285,
                    ['y'] = 12218
                },
                {
                    ['name'] = "Knox Prison",
                    ['x'] = 7718,
                    ['y'] = 11881
                },
                {
                    ['name'] = "Spiffo's",
                    ['x'] = 8074,
                    ['y'] = 11343
                },
                {
                    ['name'] = "Econo Room$",
                    ['x'] = 8078,
                    ['y'] = 11417
                },
                {
                    ['name'] = "Construction Site",
                    ['x'] = 8219,
                    ['y'] = 11841
                },
                {
                    ['name'] = "Zippee Market",
                    ['x'] = 8089,
                    ['y'] = 11561
                },
                {
                    ['name'] = "Gas Station",
                    ['x'] = 8164,
                    ['y'] = 11267
                },
                {
                    ['name'] = "Rosewood Christian Chunch",
                    ['x'] = 8124,
                    ['y'] = 11550
                },
                {
                    ['name'] = "Auto Shop",
                    ['x'] = 8152,
                    ['y'] = 11339
                },
                {
                    ['name'] = "Rosewood Medical",
                    ['x'] = 8094,
                    ['y'] = 11528
                },
                {
                    ['name'] = "Kentucky Court of Justice",
                    ['x'] = 8083,
                    ['y'] = 11657
                },
                {
                    ['name'] = "Elementary School",
                    ['x'] = 8337,
                    ['y'] = 11597
                },
                {
                    ['name'] = "Bright Flag Inn",
                    ['x'] = 8022,
                    ['y'] = 11430
                },
                {
                    ['name'] = "Fashionabelle",
                    ['x'] = 8092,
                    ['y'] = 11492
                },
                {
                    ['name'] = "Rosewood Country Buffet",
                    ['x'] = 8093,
                    ['y'] = 11502
                },
                {
                    ['name'] = "Booknaked",
                    ['x'] = 8093,
                    ['y'] = 11514
                },
                {
                    ['name'] = "Marple & Christie Legal Services",
                    ['x'] = 8094,
                    ['y'] = 11539
                },
                {
                    ['name'] = "Markson & Co",
                    ['x'] = 8094,
                    ['y'] = 11608
                },
                {
                    ['name'] = "Gated Community",
                    ['x'] = 8026,
                    ['y'] = 11525
                },
                {
                    ['name'] = "Small House with Farm Plot",
                    ['x'] = 8341,
                    ['y'] = 11750
                },
                {
                    ['name'] = "Jenny's Table",
                    ['x'] = 8082,
                    ['y'] = 11463
                },
                {
                    ['name'] = "Bail Bonds",
                    ['x'] = 7999,
                    ['y'] = 11453
                },
                {
                    ['name'] = "Haircuts n' More",
                    ['x'] = 8094,
                    ['y'] = 11552
                },
                {
                    ['name'] = "Knox Bank",
                    ['x'] = 8095,
                    ['y'] = 11594
                },
                {
                    ['name'] = "Bus Station",
                    ['x'] = 8244,
                    ['y'] = 12238
                },
                {
                    ['name'] = "Food Market",
                    ['x'] = 8131,
                    ['y'] = 11478
                },
                
                {
                    ['name'] = "Laundromat",
                    ['x'] = 8137,
                    ['y'] = 11502
                },
                {
                    ['name'] = "Fire Department",
                    ['x'] = 8133,
                    ['y'] = 11750
                },
                {
                    ['name'] = "Police Station",
                    ['x'] = 8076,
                    ['y'] = 11742
                },
                {
                    ['name'] = "PizzaWhirled",
                    ['x'] = 8080,
                    ['y'] = 11311
                }
            }
        },
        {
            ['id'] = 19,
            ['name'] = "March Ridge",
            ['pois'] = {
                {
                    ['name'] = "March Ridge Church",
                    ['x'] = 10338,
                    ['y'] = 12788
                },
                {
                    ['name'] = "Cinema",
                    ['x'] = 10167,
                    ['y'] = 12659
                },
                {
                    ['name'] = "Post Office",
                    ['x'] = 10106,
                    ['y'] = 12711
                },
                {
                    ['name'] = "Community Center",
                    ['x'] = 10032,
                    ['y'] = 12746
                },
                {
                    ['name'] = "March Ridge School",
                    ['x'] = 10000,
                    ['y'] = 12663
                },
                {
                    ['name'] = "Nourish Food Market",
                    ['x'] = 10119,
                    ['y'] = 12796
                },
                {
                    ['name'] = "24 Hour Essentials (Gas Station)",
                    ['x'] = 10145,
                    ['y'] = 12791
                },
                {
                    ['name'] = "Seahorse Coffee",
                    ['x'] = 10182,
                    ['y'] = 12807
                },
                {
                    ['name'] = "Family Medical Center",
                    ['x'] = 10159,
                    ['y'] = 12758
                },
                {
                    ['name'] = "Pharmahug",
                    ['x'] = 10144,
                    ['y'] = 12758
                },
                {
                    ['name'] = "Mendy's Eatery",
                    ['x'] = 10101,
                    ['y'] = 12752
                },
                {
                    ['name'] = "Restaurant",
                    ['x'] = 10095,
                    ['y'] = 12750
                },
                {
                    ['name'] = "Filigree Fashions",
                    ['x'] = 10077,
                    ['y'] = 12815
                },
                {
                    ['name'] = "Go-2-Bread",
                    ['x'] = 10077,
                    ['y'] = 12806
                },
                {
                    ['name'] = "Knox Military Apartments",
                    ['x'] = 10082,
                    ['y'] = 12634
                },
                {
                    ['name'] = "United Shipping Logistics",
                    ['x'] = 10077,
                    ['y'] = 12776
                },
                {
                    ['name'] = "Hair Saloon",
                    ['x'] = 10183,
                    ['y'] = 12819
                },
                {
                    ['name'] = "Office",
                    ['x'] = 10182,
                    ['y'] = 12790
                },
                {
                    ['name'] = "Laundromat",
                    ['x'] = 10181,
                    ['y'] = 12784
                },
                {
                    ['name'] = "Hit Vids",
                    ['x'] = 10169,
                    ['y'] = 12730
                },
                {
                    ['name'] = "SuperKlean",
                    ['x'] = 10181,
                    ['y'] = 12733
                }
            }
        },
        {
            ['id'] = 22,
            ['name'] = "Riverside",
            ['pois'] = {
                {
                    ['name'] = "Nails & Nuts Tool Store",
                    ['x'] = 6364,
                    ['y'] = 5327
                },
                {
                    ['name'] = "Riverside Suites",
                    ['x'] = 6357,
                    ['y'] = 5259
                },
                {
                    ['name'] = "Gated Community",
                    ['x'] = 6735,
                    ['y'] = 5448
                },
                {
                    ['name'] = "Enigma books",
                    ['x'] = 6437,
                    ['y'] = 5272
                },
                {
                    ['name'] = "Toy Store",
                    ['x'] = 6452,
                    ['y'] = 5295
                },
                {
                    ['name'] = "Police Station",
                    ['x'] = 6080,
                    ['y'] = 5266
                },
                {
                    ['name'] = "Fossoil Gas Station",
                    ['x'] = 6059,
                    ['y'] = 5301
                },
                {
                    ['name'] = "Riverside School",
                    ['x'] = 6424,
                    ['y'] = 5441
                },
                {
                    ['name'] = "Food Market",
                    ['x'] = 5969,
                    ['y'] = 5392
                },
                {
                    ['name'] = "Bar",
                    ['x'] = 5963,
                    ['y'] = 5422
                },
                {
                    ['name'] = "Pharmahug",
                    ['x'] = 6472,
                    ['y'] = 5272
                },
                {
                    ['name'] = "Spiffo's",
                    ['x'] = 6123,
                    ['y'] = 5305
                },
                {
                    ['name'] = "Riverside Church",
                    ['x'] = 6563,
                    ['y'] = 5375
                },
                {
                    ['name'] = "Laundromat",
                    ['x'] = 6406,
                    ['y'] = 5340
                },
                {
                    ['name'] = "Burgers",
                    ['x'] = 5956,
                    ['y'] = 5265
                },
                {
                    ['name'] = "Churus-R-US",
                    ['x'] = 6474,
                    ['y'] = 5225
                },
                {
                    ['name'] = "Knox Bank",
                    ['x'] = 6514,
                    ['y'] = 5299
                },
                {
                    ['name'] = "Saucy (Clothing Store)",
                    ['x'] = 6404,
                    ['y'] = 5272
                },
                {
                    ['name'] = "Lola Limon (Clothing Store)",
                    ['x'] = 6507,
                    ['y'] = 5272
                },
                {
                    ['name'] = "Gigamart",
                    ['x'] = 6515,
                    ['y'] = 5343
                },
                {
                    ['name'] = "Hit Vids",
                    ['x'] = 6205,
                    ['y'] = 5349
                },
                {
                    ['name'] = "Sweet Pea",
                    ['x'] = 6197,
                    ['y'] = 5348
                },
                {
                    ['name'] = "Go Flash",
                    ['x'] = 6195,
                    ['y'] = 5352
                },
                {
                    ['name'] = "Back To The Nurture",
                    ['x'] = 6194,
                    ['y'] = 5362
                },
                {
                    ['name'] = "Liquorty-Split",
                    ['x'] = 6195,
                    ['y'] = 5371
                },
                {
                    ['name'] = "Dotty 4 Donuts",
                    ['x'] = 6493,
                    ['y'] = 5231
                },
                {
                    ['name'] = "Riparian Entertainment",
                    ['x'] = 6399,
                    ['y'] = 5214
                },
                {
                    ['name'] = "Post Office",
                    ['x'] = 6309,
                    ['y'] = 5271
                },
                {
                    ['name'] = "Nourish Food Market",
                    ['x'] = 6273,
                    ['y'] = 5273
                },
                {
                    ['name'] = "Time 4 Sport",
                    ['x'] = 6261,
                    ['y'] = 5272
                },
                {
                    ['name'] = "Hugo Plush",
                    ['x'] = 6250,
                    ['y'] = 5272
                },
                {
                    ['name'] = "Seat Yourself Furniture",
                    ['x'] = 6239,
                    ['y'] = 5273
                },
                {
                    ['name'] = "General Store",
                    ['x'] = 5969,
                    ['y'] = 5357
                },
                {
                    ['name'] = "Laundromat",
                    ['x'] = 5955,
                    ['y'] = 5391
                },
                {
                    ['name'] = "Morris' Bait Shop",
                    ['x'] = 5921,
                    ['y'] = 5245
                },
                {
                    ['name'] = "Riverwood Boat Club",
                    ['x'] = 6561,
                    ['y'] = 5219
                },
                {
                    ['name'] = "Riverside West Church with Cemetry",
                    ['x'] = 5921,
                    ['y'] = 5245
                },
                {
                    ['name'] = "Slimtax Accounting",
                    ['x'] = 6367,
                    ['y'] = 5321
                },
                {
                    ['name'] = "Spitfine Fashion",
                    ['x'] = 6367,
                    ['y'] = 5313
                }
            }
        },
        {
            ['name'] = "Rural Town",
            ['pois'] = {
                {
                    ['name'] = "Farming and Rural Supplies",
                    ['x'] = 7252,
                    ['y'] = 8321
                },
                {
                    ['name'] = "General Store",
                    ['x'] = 7296,
                    ['y'] = 8253
                },
                
                {
                    ['name'] = "Doctor's Office",
                    ['x'] = 7296,
                    ['y'] = 8388
                },
                {
                    ['name'] = "Police Station",
                    ['x'] = 7252,
                    ['y'] = 8378
                },
                {
                    ['name'] = "E.P. Tools",
                    ['x'] = 7256,
                    ['y'] = 8231
                },
                {
                    ['name'] = "Burgers",
                    ['x'] = 7234,
                    ['y'] = 8203
                },
                {
                    ['name'] = "Rural Town Church",
                    ['x'] = 7387,
                    ['y'] = 8353
                },
                {
                    ['name'] = "Good Book",
                    ['x'] = 7258,
                    ['y'] = 8431
                },
                {
                    ['name'] = "The Horseshoe",
                    ['x'] = 7246,
                    ['y'] = 8522
                },
                {
                    ['name'] = "Laundr-O-Max",
                    ['x'] = 7263,
                    ['y'] = 8497
                },
                {
                    ['name'] = "Food Market",
                    ['x'] = 7257,
                    ['y'] = 8287
                }
            }
        },
        {
            ['id'] = 1,
            ['name'] = "West Highway Stop",
            ['pois'] = {
                {
                    ['name'] = "Gun Shop",
                    ['x'] = 3804,
                    ['y'] = 8509
                },
                {
                    ['name'] = "Camping Supplement",
                    ['x'] = 3801,
                    ['y'] = 8550
                },
                {
                    ['name'] = "Gas N More",
                    ['x'] = 3698,
                    ['y'] = 8494
                },
                {
                    ['name'] = "Diner",
                    ['x'] = 3707,
                    ['y'] = 8463
                }
            }
        },
        {
            ['name'] = "North Highway Stop",
            ['pois'] = {
                {
                    ['name'] = "Barg-n-Clothes",
                    ['x'] = 11599,
                    ['y'] = 8252
                },
                {
                    ['name'] = "Gas-2-Go",
                    ['x'] = 11603,
                    ['y'] = 8308
                },
                {
                    ['name'] = "Spiffo's",
                    ['x'] = 11668,
                    ['y'] = 8302
                },
                {
                    ['name'] = "Molan's Used Cars",
                    ['x'] = 11687,
                    ['y'] = 8367
                }
            }
        },
        {
            ['name'] = "South Highway Stop",
            ['pois'] = {
                {
                    ['name'] = "Warehouses out of town",
                    ['x'] = 10050,
                    ['y'] = 10932
                },
                {
                    ['name'] = "Office #1",
                    ['x'] = 10079,
                    ['y'] = 11031
                },
                {
                    ['name'] = "Factory",
                    ['x'] = 10067,
                    ['y'] = 10891
                },
                {
                    ['name'] = "Abandoned Factory",
                    ['x'] = 10225,
                    ['y'] = 11009
                },
                {
                    ['name'] = "Office #2",
                    ['x'] = 10031,
                    ['y'] = 10846
                },
                {
                    ['name'] = "Car Repair",
                    ['x'] = 10177,
                    ['y'] = 10955
                },
                {
                    ['name'] = "Diner",
                    ['x'] = 10114,
                    ['y'] = 11151
                },
                {
                    ['name'] = "Sawmill",
                    ['x'] = 9993,
                    ['y'] = 10978
                }
            }
        },
        {
            ['id'] = 1,
            ['name'] = "Rural Highway Stop",
            ['pois'] = {
                {
                    ['name'] = "Double small warehouses",
                    ['x'] = 5892,
                    ['y'] = 9861
                },
                {
                    ['name'] = "Church",
                    ['x'] = 5864,
                    ['y'] = 9433
                },
                {
                    ['name'] = "Gas station",
                    ['x'] = 5467,
                    ['y'] = 9709
                },
                {
                    ['name'] = "Lenny's Car Repair",
                    ['x'] = 5470,
                    ['y'] = 9661
                },
                {
                    ['name'] = "Food Market",
                    ['x'] = 5465,
                    ['y'] = 9584
                },
                {
                    ['name'] = "Doctor's Office",
                    ['x'] = 5499,
                    ['y'] = 9582
                },
                {
                    ['name'] = "Jamieton Army Supplies",
                    ['x'] = 5467,
                    ['y'] = 9416
                },
                {
                    ['name'] = "Bar & Restaurant",
                    ['x'] = 5552,
                    ['y'] = 9658
                },
                {
                    ['name'] = "Laundromat",
                    ['x'] = 5480,
                    ['y'] = 9682
                },
                {
                    ['name'] = "County Offices",
                    ['x'] = 5438,
                    ['y'] = 9674
                },
                {
                    ['name'] = "Clothes store",
                    ['x'] = 5501,
                    ['y'] = 9566
                }
            }
        },
        {
            ['name'] = "Country Club",
            ['pois'] = {
                {
                    ['name'] = "Gateway",
                    ['x'] = 5814,
                    ['y'] = 6689
                },
                {
                    ['name'] = "West Maple Country Club (Main Building)",
                    ['x'] = 5737,
                    ['y'] = 6457
                },
                {
                    ['name'] = "West Maple Country Club (Racetrack-side)",
                    ['x'] = 5646,
                    ['y'] = 6562
                },
                {
                    ['name'] = "Horse-Training Field",
                    ['x'] = 5583,
                    ['y'] = 6546
                },
                {
                    ['name'] = "Racetrack",
                    ['x'] = 5582,
                    ['y'] = 6466
                },
                {
                    ['name'] = "Country Club Storage",
                    ['x'] = 5968,
                    ['y'] = 6524
                },
                {
                    ['name'] = "Tennis Field",
                    ['x'] = 5795,
                    ['y'] = 6364
                },
                {
                    ['name'] = "Bar & Restaurant",
                    ['x'] = 6181,
                    ['y'] = 6373
                },
                {
                    ['name'] = "Golf Hole #1",
                    ['x'] = 5945,
                    ['y'] = 6597
                },
                {
                    ['name'] = "Golf Hole #2",
                    ['x'] = 6148,
                    ['y'] = 6589
                },
                
                {
                    ['name'] = "Golf Hole #3",
                    ['x'] = 5945,
                    ['y'] = 6597
                },
                
                {
                    ['name'] = "Golf Hole #4 (Removed)",
                    ['x'] = 6302,
                    ['y'] = 6659
                },
                
                {
                    ['name'] = "Golf Hole #5",
                    ['x'] = 6187,
                    ['y'] = 6514
                },
                {
                    ['name'] = "Golf Hole #6",
                    ['x'] = 6089,
                    ['y'] = 6393
                },
                {
                    ['name'] = "Golf Hole #7",
                    ['x'] = 6286,
                    ['y'] = 6453
                },
                {
                    ['name'] = "Golf Hole #8",
                    ['x'] = 6315,
                    ['y'] = 6326
                },
                {
                    ['name'] = "Golf Hole #9 (Removed)",
                    ['x'] = 6134,
                    ['y'] = 6290
                },
                {
                    ['name'] = "Golf Hole #10",
                    ['x'] = 6059,
                    ['y'] = 6192
                },
                {
                    ['name'] = "Golf Hole #11",
                    ['x'] = 6182,
                    ['y'] = 6202
                },
                {
                    ['name'] = "Golf Hole #12",
                    ['x'] = 6277,
                    ['y'] = 6266
                },
                {
                    ['name'] = "Golf Hole #13",
                    ['x'] = 6278,
                    ['y'] = 6149
                },
                {
                    ['name'] = "Golf Hole #14",
                    ['x'] = 6136,
                    ['y'] = 6149
                },
                {
                    ['name'] = "Golf Hole #15",
                    ['x'] = 5998,
                    ['y'] = 6203
                },
                {
                    ['name'] = "Golf Hole #16",
                    ['x'] = 5969,
                    ['y'] = 6065
                },
                {
                    ['name'] = "Golf Hole #17",
                    ['x'] = 5877,
                    ['y'] = 6206
                },
                {
                    ['name'] = "Golf Hole #18 (Removed)",
                    ['x'] = 6011,
                    ['y'] = 6366
                },
                {
                    ['name'] = "Golf Hole #19",
                    ['x'] = 5862,
                    ['y'] = 6367
                }
            }
        },
        {
            ['name'] = "ETC",
            ['pois'] = {
                {
                    ['name'] = "Farm Food Market",
                    ['x'] = 9071,
                    ['y'] = 12189
                },
                {
                    ['name'] = "Double warehouse #1",
                    ['x'] = 7681,
                    ['y'] = 9345
                },
                
                {
                    ['name'] = "Double Warehouse #2",
                    ['x'] = 8300,
                    ['y'] = 10041
                },
                {
                    ['name'] = "Small Double Warehouse",
                    ['x'] = 6562,
                    ['y'] = 8954
                },
                {
                    ['name'] = "Cabin in the Western Woods",
                    ['x'] = 9667,
                    ['y'] = 8776
                },
                {
                    ['name'] = "Farm to the west",
                    ['x'] = 8599,
                    ['y'] = 8824
                },
                {
                    ['name'] = "Lone forest shack",
                    ['x'] = 9341,
                    ['y'] = 10293
                },
                {
                    ['name'] = "Pony Roam-O",
                    ['x'] = 8559,
                    ['y'] = 8529
                },
                {
                    ['name'] = "Interchange (Muldraugh South)",
                    ['x'] = 10591,
                    ['y'] = 11204
                },
                {
                    ['name'] = "Lookout Tower",
                    ['x'] = 13651,
                    ['y'] = 7145
                },
                {
                    ['name'] = "Farmhouse",
                    ['x'] = 6817,
                    ['y'] = 7720
                },
                {
                    ['name'] = "Packaging Warehouses",
                    ['x'] = 9223,
                    ['y'] = 11855
                },
                {
                    ['name'] = "Army Quarter",
                    ['x'] = 9118,
                    ['y'] = 11814
                },
                {
                    ['name'] = "West Campgrounds",
                    ['x'] = 4761,
                    ['y'] = 7929
                },
                {
                    ['name'] = "C.G.E. Corp",
                    ['x'] = 3874,
                    ['y'] = 6208
                },
                {
                    ['name'] = "Camp Busy Beaver",
                    ['x'] = 5010,
                    ['y'] = 7999
                },
                {
                    ['name'] = "Deerhead Lake -Park Ranger-",
                    ['x'] = 4675,
                    ['y'] = 8604
                },
                {
                    ['name'] = "East Campgrounds",
                    ['x'] = 12481,
                    ['y'] = 8990
                },
                {
                    ['name'] = "Laboratory",
                    ['x'] = 5581,
                    ['y'] = 12483
                }
            }
        }
    }
 }
 