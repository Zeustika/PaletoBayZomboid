---@class TeleportWindow : ISCollapsableWindow
---@field IDs string|nil
---@field Trigger number
---@field OldCoordTrigger number
---@field XInput ISTextEntryBox
---@field YInput ISTextEntryBox
---@field ZInput ISTextEntryBox
---@field InpButton ISButton
---@field titleBarFont UIFont
TeleportWindow = ISCollapsableWindow:derive("TeleportWindow")

---@class TeleportBox : ISPanel
---@field target TeleportWindow
---@field func fun()|nil
---@field hscroll any
TeleportBox = ISPanel:derive("TeleportBox")

TeleportWindow.IDs = nil
TeleportWindow.Trigger = 0
TeleportWindow.OldCoordTrigger = 0

function CheckNumeric(value)
    if value == tostring(tonumber(value)) then
        return true
    elseif value == "" then
        return true
    else
        return false
    end
end

function TeleportWindow:initialise()
    ISCollapsableWindow.initialise(self);
    self:makeChildren()
end

function TeleportWindow.Teleport(Teleport_X, Teleport_Y, Teleport_Z)
    print("[CHEAT MENU] TeleportWindow.Teleport() called with X=" .. Teleport_X .. ", Y=" .. Teleport_Y .. ", Z=" .. Teleport_Z)
    if isClient() then
        SendCommandToServer("/teleportto " .. Teleport_X .. "," .. Teleport_Y .. ","..Teleport_Z);
    else
        local player = getPlayer()
        if player:getVehicle() then
            player:getVehicle():exit(player)
        end
        player:teleportTo(Teleport_X, Teleport_Y, Teleport_Z)
    end
end

function TeleportWindow:SetLocation()
    local player = getPlayer()
    TeleportWindow.OldCoordTrigger = 0

    local function getCoord(input, default)
        local text = input:getText()
        if text == "" then
            TeleportWindow.OldCoordTrigger = TeleportWindow.OldCoordTrigger + 1
            return default
        end
        return CheckNumeric(text) and tonumber(text) or nil
    end

    local X = getCoord(self.XInput, math.floor(player:getX()))
    local Y = getCoord(self.YInput, math.floor(player:getY()))
    local Z = getCoord(self.ZInput, math.floor(player:getZ()))

    if not X or not Y or not Z then
        player:Say(getText("UI_CMRB_Message_CannotTeleport"))
        TeleportWindow.OldCoordTrigger = 0
        return
    end

    local world = getWorld()
    if not world:isValidSquare(math.floor(X), math.floor(Y), math.floor(Z)) then
        player:Say(getText("UI_CMRB_Teleport_Unsafe_OuterBorder"))
        world:update()
        TeleportWindow.Trigger = 0
        TeleportWindow.OldCoordTrigger = 0
        return
    end

    if not world:getMetaGrid():isValidChunk(math.floor(X / 10), math.floor(Y / 10)) then
        player:Say(getText("UI_CMRB_Teleport_Unsafe_NoChunkData"))
        world:update()
        TeleportWindow.Trigger = 0
        TeleportWindow.OldCoordTrigger = 0
        return
    end

    local function executeTeleport()
        TeleportWindow.Teleport(X, Y, Z)
        player:Say(getText("UI_CMRB_Message_TeleportChange") .. "X: " .. X .. ", Y: " .. Y .. ", Z: " .. Z .. ".")
        world:update()
        TeleportWindow.Trigger = 0
        TeleportWindow.OldCoordTrigger = 0
    end

    -- Safety check for high Z teleports (unless all inputs were empty/current)
    if Z > 0 and TeleportWindow.OldCoordTrigger ~= 3 and TeleportWindow.Trigger ~= 1 then
        player:Say(getText("UI_CMRB_Message_TeleportMayUnsafe_1"))
        player:Say(getText("UI_CMRB_Message_TeleportMayUnsafe_2"))
        TeleportWindow.Trigger = TeleportWindow.Trigger + 1
        return
    end

    executeTeleport()
end

function TeleportWindow:makeChildren()
    self.XInput = ISTextEntryBox:new("", 0, self:titleBarHeight()+20, self:getWidth() / 3, self:getHeight() / 3);
    self.XInput:initialise();
    self.XInput:instantiate();
    self.XInput:setMultipleLine(false)
    self.XInput.javaObject:setMaxLines(1);
    self:addChild(self.XInput); -- to center, set border pixel and multiply by border pixel / 2

    self.YInput = ISTextEntryBox:new("", self:getWidth() / 3, self:titleBarHeight()+20, self:getWidth() / 3, self:getHeight() / 3);
    self.YInput:initialise();
    self.YInput:instantiate();
    self.YInput:setMultipleLine(false)
    self.YInput.javaObject:setMaxLines(1);
    self:addChild(self.YInput); -- to center, set border pixel and multiply by border pixel / 2

    self.ZInput = ISTextEntryBox:new("", (self:getWidth() / 3) * 2, self:titleBarHeight()+20, self:getWidth() / 3, self:getHeight() / 3);
    self.ZInput:initialise();
    self.ZInput:instantiate();
    self.ZInput:setMultipleLine(false)
    self.ZInput.javaObject:setMaxLines(1);
    self:addChild(self.ZInput); -- to center, set border pixel and multiply by border pixel / 2

    self.InpButton = ISButton:new(0, self.XInput:getHeight() + self:titleBarHeight()+20, self:getWidth(), self:getHeight() / 3, getText("UI_CMRB_TeleportLocation_Teleport"), self, self.SetLocation); 
    self.InpButton:initialise();
    self.InpButton:instantiate();
    self.InpButton.borderColor = {r=0.4, g=0.4, b=0.4, a=1.0};
    self:addChild(self.InpButton);

    --self:setHeight(self:getHeight() - (self:titleBarHeight() / 2)) 
end

function TeleportWindow:prerender()
    local height = self:getHeight();
    local th = self:titleBarHeight()
    if self.isCollapsed then
        height = th;
    end
    if self.drawFrame then
        self:drawRect(0, 0, self:getWidth(), th, self.backgroundColor.a, self.backgroundColor.r, self.backgroundColor.g, self.backgroundColor.b);
        self:drawTextureScaled(self.titlebarbkg, 2, 1, self:getWidth() - 4, th - 2, 1, 1, 1, 1);
        self:drawRectBorder(0, 0, self:getWidth(), th, self.borderColor.a, self.borderColor.r, self.borderColor.g, self.borderColor.b);
    end
    if self.background and not self.isCollapsed then
        local rh = self:resizeWidgetHeight()
        if not self.resizable or not self.resizeWidget:getIsVisible() then rh = 0 end
        self:drawRect(0, th, self:getWidth(), self.height - th - rh, self.backgroundColor.a, self.backgroundColor.r, self.backgroundColor.g, self.backgroundColor.b);
    end

    if self.clearStentil then
        self:setStencilRect(0,0,self.width, height);
    end

    if self.title ~= nil and self.drawFrame then
        self:drawTextCentre(self.title, self:getWidth() / 2, 1, 1, 1, 1, 1, self.titleBarFont);
    end
        self:drawTextCentre(getText("UI_CMRB_TeleportWindow_X"), (self.XInput.x + self.YInput.x) / 2, self:titleBarHeight()+2, 1, 1, 1, 1, UIFont.Small)
        self:drawTextCentre(getText("UI_CMRB_TeleportWindow_Y"), (self.YInput.x + self.ZInput.x) / 2, self:titleBarHeight()+2, 1, 1, 1, 1, UIFont.Small)
        self:drawTextCentre(getText("UI_CMRB_TeleportWindow_Z"), (self.ZInput.x + self:getWidth()) / 2, self:titleBarHeight()+2, 1, 1, 1, 1, UIFont.Small)
end

function TeleportWindow:destroy()
    self:setVisible(false)
    self:removeFromUIManager()
    TeleportWindow.IDs = nil
end

function TeleportWindow:close()
    self:setVisible(false)
    self:removeFromUIManager()
    TeleportWindow.IDs = nil
end

function TeleportWindow:new(x, y, width, height)
    local o = {}
    o = ISCollapsableWindow:new(x, y, width, height)
    setmetatable(o, self)
    self.__index = self
    o.title = getText("UI_CMRB_Utility_TeleportCoord")
    o.resizable = false
    o.pin = true;
    o.isCollapsed = false;
    o.x = x
    o.y = y
    o.width = width
    o.height = height
    TeleportWindow.IDs = "Teleport"
    --o:noBackground();
    --o.clearStentil = false
    --o.borderColor = {r=0.4, g=0.4, b=0.4, a=0.4};
    return o;
end

function TeleportWindow.makeWindow()
    local window = TeleportWindow:new(100,100,370,100)
    -- Change the window's width, height << later job.
    window:initialise()
    window:addToUIManager()
end

function TeleportBox:initialise()
    ISPanel.initialise(self);
    self:createChildren()
end

function TeleportBox:createChildren()
    --self:addScrollBars(true)
    --self:setScrollWidth(1000)
    self.hscroll:setWidth(self.width - 1)
    --self.hscroll:setHeight(self.height)
    self.hscroll:setAlwaysOnTop(true)
    ---@diagnostic disable-next-line: inject-field
    self.hscroll.target, self.hscroll.func = self.target, self.func

    function self.hscroll:onMouseMove(dx, dy)
        ---@diagnostic disable: need-check-nil
        if self.scrolling then
            local sw = self.parent:getScrollWidth()
            if sw > self.parent:getScrollAreaWidth() then
                local del = self:getWidth() / sw
                local boxheight = del * (self:getWidth()- (20 * 2))
                local dif = self:getWidth() - (20 * 2) - boxheight
                self.pos = self.pos + (dx / dif)
                if self.pos < 0 then
                    self.pos = 0
                end
                if self.pos > 1 then
                    self.pos = 1
                end
                self.parent:setXScroll(-(self.pos * (sw - self.parent:getScrollAreaWidth())))
            end
            if self.func then
                pcall(self.func)
            end
        end
        ---@diagnostic enable: need-check-nil
    end
end

function TeleportBox:new(x, y, width, height, target, func)
    local o = {};
    o = ISPanel:new(x, y, width, height);
    setmetatable(o, self);
    self.__index = self;
    ---@type TeleportBox
    o = o ---@diagnostic disable-line: assign-type-mismatch
    o.x = x
    o.y = y
    o.width = width
    o.height = height
    o.target = target
    o.func = func
    --o:noBackground();
    --o.clearStentil = false
    --o.borderColor = {r=0.4, g=0.4, b=0.4, a=0.4};
    return o;
end
