---@class ISUIColorWindow : ISCollapsableWindow
---@field IDs string|nil
---@field rSlider ISUIColorSlider
---@field gSlider ISUIColorSlider
---@field bSlider ISUIColorSlider
---@field InpButton ISButton
---@field titleBarFont UIFont
ISUIColorWindow = ISCollapsableWindow:derive("ISUIColorWindow")

---@class ISUIColorSlider : ISPanel
---@field target ISUIColorWindow
---@field func fun()|nil
---@field hscroll any
ISUIColorSlider = ISPanel:derive("ISUIColorSlider")

ISUIColorWindow.IDs = nil

function ISUIColorWindow:initialise()
    ISCollapsableWindow.initialise(self);
    self:makeChildren()
end

function ISUIColorWindow:changeColor()
    local rpos = self.rSlider.hscroll.pos
    local gpos = self.gSlider.hscroll.pos
    local bpos = self.bSlider.hscroll.pos

    local vehicle = CheatCoreCM.SelectedVehicle
    if vehicle then
        local script = vehicle:getScript()
            script:setForcedHue(rpos)
            script:setForcedSat(gpos)
            script:setForcedVal(bpos)
        vehicle:setColor(script:getForcedVal(), script:getForcedSat(), script:getForcedHue())
        vehicle:setColorHSV(script:getForcedVal(), script:getForcedSat(), script:getForcedHue())        
       getPlayer():Say(getText("UI_CMRB_Message_VehicleColorChanged"))
    end
end

function ISUIColorWindow:changeSkin()
    local vehicle = CheatCoreCM.SelectedVehicle
    if vehicle then
        local skinIndex = vehicle:getSkinIndex()
        skinIndex = skinIndex + 1
        if skinIndex >= vehicle:getSkinCount() then
            skinIndex = 0
        end
        vehicle:setSkinIndex(skinIndex)
        vehicle:updateSkin()
        local args = { vehicle = vehicle:getId(), index = skinIndex }
        sendClientCommand(getPlayer(), 'vehicle', 'setSkinIndex', args)
        getPlayer():Say(getText("UI_CMRB_Message_VehicleSkinChanged"))
    end
end

function ISUIColorWindow:makeChildren()
    self.rSlider = ISUIColorSlider:new(self.width - self.width / 1.3, self.height / 4, self.width / 1.3, 16, self, nil)
    self.rSlider:initialise()
    self.rSlider.borderColor = {r=0,g=0,b=0,a=0}
    self:addChild(self.rSlider)

    self.gSlider = ISUIColorSlider:new(self.width - self.width / 1.3, self.rSlider.y + 16, self.width / 1.3, 16, self, nil)
    self.gSlider:initialise()
    self.gSlider.borderColor = {r=0,g=0,b=0,a=0}
    self:addChild(self.gSlider)

    self.bSlider = ISUIColorSlider:new(self.width - self.width / 1.3, self.gSlider.y + 16, self.width / 1.3, 16, self, nil)
    self.bSlider:initialise()
    self.bSlider.borderColor = {r=0,g=0,b=0,a=0}
    self:addChild(self.bSlider)

    local buttonY = self.bSlider:getY() + self.bSlider:getHeight() + 10
    local buttonWidth = self:getWidth() / 2
    local buttonHeight = self:getHeight() / 3

    self.InpButton = ISButton:new(0, buttonY, buttonWidth, buttonHeight, getText("UI_CMRB_Window_Set"), self, self.changeColor); 
    self.InpButton:initialise();
    self.InpButton:instantiate();
    self.InpButton.borderColor = {r=0.4, g=0.4, b=0.4, a=1.0};
    self:addChild(self.InpButton);

    self.SkinButton = ISButton:new(buttonWidth, buttonY, buttonWidth, buttonHeight, getText("UI_CMRB_VehicleControl_SkinEditor"), self, self.changeSkin);
    self.SkinButton:initialise();
    self.SkinButton:instantiate();
    self.SkinButton.borderColor = {r=0.4, g=0.4, b=0.4, a=1.0};
    self:addChild(self.SkinButton);

    --[[
    if CheatCoreCM.SelectedVehicle then
        local script = CheatCoreCM.SelectedVehicle:getScript()
        self.rSlider.hscroll.pos = script:getForcedHue() > 0 and script:getForcedHue() or 0
        self.gSlider.hscroll.pos = script:getForcedSat() > 0 and script:getForcedSat() or 0
        self.bSlider.hscroll.pos = script:getForcedVal() > 0 and script:getForcedVal() or 0
    end
    --]]
    --[[
    self.ColorSquare = ISPanel:new((self.width / 2) - self.width / 8, self.bSlider.y + (self.height / 4), self.width / 4, self.height / 4)
    self.ColorSquare:initialise()
    self.ColorSquare.backgroundColor = {r=0.1,g=0.1,b=0.1,a=1}
    self.ColorSquare.borderColor = {r=1,g=1,b=1,a=1}
    self:addChild(self.ColorSquare)
    --]]
    --self.rSlider:setScrollWithParent(false)
    --self.rSlider:setScrollChildren(true)
end

function ISUIColorWindow:prerender()
    local height = self:getHeight();
    local th = self:titleBarHeight()
    if self.isCollapsed then
        height = th;
    end
    if self.drawFrame then
        self:drawRect(0, 0, self:getWidth(), th, self.backgroundColor.a, self.backgroundColor.r, self.backgroundColor.g, self.backgroundColor.b);
        self:drawTextureScaled(self.titlebarbkg, 2, 1, self:getWidth() - 4, th - 2, 1, 1, 1, 1);
        self:drawRectBorder(0, 0, self:getWidth(), th, self.borderColor.a, self.borderColor.r, self.borderColor.g, self.borderColor.b);
    end
    if self.background and not self.isCollapsed then
        local rh = self:resizeWidgetHeight()
        if not self.resizable or not self.resizeWidget:getIsVisible() then rh = 0 end
        self:drawRect(0, th, self:getWidth(), self.height - th - rh, self.backgroundColor.a, self.backgroundColor.r, self.backgroundColor.g, self.backgroundColor.b);
    end
    if self.clearStentil then
        self:setStencilRect(0,0,self.width, height);
    end

    if self.title ~= nil and self.drawFrame then
        self:drawTextCentre(self.title, self:getWidth() / 2, 1, 1, 1, 1, 1, self.titleBarFont);
    end
    if self.rSlider ~= nil then
        self:drawText(getText("UI_CMRB_VehicleControl_ColorBrightness"), 3, self.rSlider.y, 1, 1, 1, 1, UIFont.Small)
        self:drawText(getText("UI_CMRB_VehicleControl_ColorSaturation"), 3, self.gSlider.y, 1, 1, 1, 1, UIFont.Small)
        self:drawText(getText("UI_CMRB_VehicleControl_ColorHue"), 3, self.bSlider.y, 1, 1, 1, 1, UIFont.Small)
    end

    if self.SkinButton then
        local vehicle = CheatCoreCM.SelectedVehicle
        if vehicle and (vehicle:getSkinIndex() == -1 or vehicle:getSkinCount() <= 1) then
            self.SkinButton:setEnable(false)
        else
            self.SkinButton:setEnable(true)
        end
    end
end

function ISUIColorWindow:destroy()
    self:setVisible(false)
    self:removeFromUIManager()
    ISUIColorWindow.IDs = nil
end

function ISUIColorWindow:close()
    self:setVisible(false)
    self:removeFromUIManager()
    ISUIColorWindow.IDs = nil
end

---@param x number
---@param y number
---@param width number
---@param height number
---@return ISUIColorWindow
function ISUIColorWindow:new(x, y, width, height)
    local o = {}
    o = ISCollapsableWindow:new(x, y, width, height)
    setmetatable(o, self)
    self.__index = self
    ---@type ISUIColorWindow
    o = o ---@diagnostic disable-line: assign-type-mismatch
    o.title = getText("UI_CMRB_VehicleControl_ColorEditorWindow")
    o.resizable = false
    o.pin = true;
    o.isCollapsed = false;
    o.x = x
    o.y = y
    o.width = width
    o.height = height
    ISUIColorWindow.IDs = "VehicleColor"
    --o:noBackground();
    --o.clearStentil = false
    --o.borderColor = {r=0.4, g=0.4, b=0.4, a=0.4};
    return o;
end

function ISUIColorWindow.makeWindow()
    local window = ISUIColorWindow:new(50,50,370,140)
    window:initialise()
    window:addToUIManager()
end

function ISUIColorSlider:initialise()
    ISPanel.initialise(self);
    self:createChildren()
end

function ISUIColorSlider:createChildren()
    self:addScrollBars(true)
    self:setScrollWidth(1000)
    self.hscroll:setWidth(self.width - 1)
    --self.hscroll:setHeight(self.height)
    self.hscroll:setAlwaysOnTop(true)
    ---@diagnostic disable-next-line: inject-field
    self.hscroll.target, self.hscroll.func = self.target, self.func

    function self.hscroll:onMouseMove(dx, dy)
        ---@type ISScrollBar
        self = self
        if self.scrolling then
            local sw = self.parent:getScrollWidth()
            if sw > self.parent:getScrollAreaWidth() then
                local del = self:getWidth() / sw
                local boxheight = del * (self:getWidth()- (20 * 2))
                local dif = self:getWidth() - (20 * 2) - boxheight
                self.pos = self.pos + (dx / dif)
                if self.pos < 0 then
                    self.pos = 0
                end
                if self.pos > 1 then
                    self.pos = 1
                end
                self.parent:setXScroll(-(self.pos * (sw - self.parent:getScrollAreaWidth())))
            end
            ---@diagnostic disable-next-line: undefined-field
            if self.func then
                ---@diagnostic disable-next-line: undefined-field
                pcall(self.func)
            end
        end
    end
end

---@param x number
---@param y number
---@param width number
---@param height number
---@param target ISUIColorWindow
---@param func fun()|nil
---@return ISUIColorSlider
function ISUIColorSlider:new(x, y, width, height, target, func)
    local o = {};
    o = ISPanel:new(x, y, width, height);
    setmetatable(o, self);
    self.__index = self;
    ---@type ISUIColorSlider
    o = o ---@diagnostic disable-line: assign-type-mismatch
    o.x = x
    o.y = y
    o.width = width
    o.height = height
    o.target = target
    o.func = func
    --o:noBackground();
    --o.clearStentil = false
    --o.borderColor = {r=0.4, g=0.4, b=0.4, a=0.4};
    return o;
end

--Events.OnLoad.Add(ISUIColorWindow.makeWindow)
