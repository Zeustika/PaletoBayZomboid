require "CheatMenuPhoenix/ItemSpawner/crucibleItem"
require "CheatMenuPhoenix/ItemSpawner/crucibleList"
require "CheatMenuPhoenix/ItemSpawner/crucibleMain"

---@class crucibleCore
---@field items table<string, Item[]>
crucibleCore = {}

crucibleCore.categories = {
    "All",
    "Normal",
    "Weapon",
    "Food",
    "Literature",
    "Drainable",
    "Clothing",
    "Container",
    "WeaponPart",
    "Key",
    --"KeyRing",
    "Moveable",
    "Radio",
    "AlarmClock",
    "AlarmClockClothing"
}
crucibleCore.Wmod = 1 -- width/height modifiers, used during main window creation
crucibleCore.Hmod = 1

crucibleCore.amount = crucibleCore.amount or 1

---@param num number
---@param percentage number
---@param subt boolean|nil
---@return number
function crucibleCore.scale(num,percentage, subt)
    if subt then
        return num - (num * percentage)
    else
        return num + (num * percentage)
    end
end

function crucibleCore.getItems()
    crucibleCore.items = {}
    crucibleCore.items["All"] = {}

    local items = getAllItems()
    local sz = items:size()

    for i = sz-1,0,-1 do
        local item = items:get(i)

        if item ~= nil and item:getDisplayName() ~= "Blooo" then
            local itemType = item:getItemType()
            if itemType ~= nil and item:getIcon() ~= nil then
                local itemTypeStr = itemType:toString()
                local invItem = instanceItem(item:getFullName())

                crucibleCore.items[itemTypeStr] = crucibleCore.items[itemTypeStr] or {}
                table.insert(crucibleCore.items[itemTypeStr], item)
                table.insert(crucibleCore.items["All"], item)

                if invItem then
                    if invItem:getDisplayCategory() then
                        crucibleCore.items[invItem:getDisplayCategory()] = crucibleCore.items[invItem:getDisplayCategory()] or {}
                        table.insert(crucibleCore.items[invItem:getDisplayCategory()], item)
                    end
                end
            end
        end
    end
    crucibleCore.sort(function (a, b) return string.lower(a:getDisplayName()) < string.lower(b:getDisplayName()) end)
end

function crucibleCore.sort(func)
    for _k,v in pairs(crucibleCore.items) do
        table.sort(v, func) -- sort alphabetically
    end
end

function crucibleCore.resolveTexture(item,invItem)
--print (item, invitem)
    local tex = getTexture("Item_" .. item:getIcon()) or getTexture("media/textures/Item_" .. item:getIcon() .. ".png") or nil
    if invItem ~= nil and tonumber(string.match(getCore():getVersionNumber(), "%d+")) >= 41 then
        if invItem:getIconsForTexture() then
            local txs = invItem:getIconsForTexture()
            if txs ~= nil then
                if txs:get(0) ~= nil then
                ---@diagnostic disable-next-line: undefined-field
                tex = getTexture("media/textures/Item_" .. txs:get(0) .. ".png") or getTexture("Item_" .. txs:get(0)) 
                end
            end
        end
    end
    if tex == nil then
        tex = getTexture("media/UI/crucibleUI/question_mark.png")
    end
    return tex
end

--Events.OnLoad.Add(crucibleCore.makeWindow)
