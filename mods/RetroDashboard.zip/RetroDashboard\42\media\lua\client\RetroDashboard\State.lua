-- RetroDashboard/State.lua
-- Per-machine збереження масштабу й одиниць у ~/Zomboid/Lua/RetroDashboard/.
--
-- ⚠ РОЗШИРЕННЯ .txt, НЕ .lua — і це не стиль, а вимога гри.
-- getFileWriter (LuaManager$GlobalObject) звіряє розширення через
-- ZomboidFileSystem.getFileExtension з набором дозволених; у класі фігурують
-- лише txt/log. Десь у 42.20 запис .lua перестав проходити — МОВЧКИ: writer не
-- nil, помилки в консолі нема, файл просто не оновлюється. Симптом для гравця —
-- «UI scaling and Speed units changes do not save between sessions» (репорти
-- 2026-08). Доказ на диску: усі .lua-стани модів заморожені червнем, тоді як
-- .txt (у тому числі в підтеках) пишуться донині — тобто підтека ні до чого.
RetroDashboard = RetroDashboard or {}
RetroDashboard.State = {}

local FILE     = "RetroDashboard/settings.txt"
local FILE_OLD = "RetroDashboard/settings.lua"   -- до v0.2.2; читаємо для міграції

RetroDashboard.State.VERSION = 1

local function defaults()
    return { version = RetroDashboard.State.VERSION, scale = 1.0, units = "mph" }
end

-- Прочитати й розібрати таблицю з файлу. nil, якщо файлу нема або він битий.
local function readTable(path)
    local reader = getFileReader(path, false)
    if not reader then return nil end
    local body = {}
    local line = reader:readLine()
    while line do body[#body + 1] = line; line = reader:readLine() end
    reader:close()
    -- у файлі лежить голий конструктор таблиці, тож дописуємо return
    local chunk = loadstring("return " .. table.concat(body, "\n"))
    if not chunk then return nil end
    local ok, parsed = pcall(chunk)
    if ok and type(parsed) == "table" then return parsed end
    return nil
end

function RetroDashboard.State.load()
    local d = defaults()
    local parsed = readTable(FILE)
    local migrated = false
    if not parsed then
        parsed = readTable(FILE_OLD)      -- налаштування зі старих версій
        migrated = parsed ~= nil
    end
    if parsed then
        if type(parsed.scale) == "number" then d.scale = parsed.scale end
        -- units опційне: файли до 0.2.0 його не мають, лишається дефолт "mph"
        if parsed.units == "mph" or parsed.units == "kmh" then d.units = parsed.units end
    end
    d.migrated = migrated
    return d
end

function RetroDashboard.State.save()
    local writer = getFileWriter(FILE, true, false)
    if not writer then
        print("[RetroDashboard] settings write failed: getFileWriter nil")
        return
    end
    writer:write(string.format('{\n  ["version"] = %d,\n  ["scale"] = %s,\n  ["units"] = %q,\n}',
        RetroDashboard.State.VERSION, tostring(RetroDashboard.scale), RetroDashboard.units or "mph"))
    writer:close()
end

return RetroDashboard.State
