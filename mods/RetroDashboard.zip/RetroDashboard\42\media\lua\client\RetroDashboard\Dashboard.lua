-- RetroDashboard/Dashboard.lua
-- Monkey-patch ванільного ISVehicleDashboard: повна заміна вигляду.
require "Vehicles/ISUI/ISVehicleDashboard"
require "ISUI/ISContextMenu"
require "RetroDashboard/Coords"
require "RetroDashboard/Layers"
require "RetroDashboard/State"
require "RetroDashboard/Tooltips"

RetroDashboard = RetroDashboard or {}
local C = RetroDashboard.Coords

-- Чи точка (локальні координати панелі) у масштабованому прямокутнику зони.
-- Оголошено тут, бо потрібне і :render (підказки), і :onMouseDown.
local function hitZone(btn, S, x, y)
    local bx, by = btn.x * S, btn.y * S
    local bw, bh = btn.w * S, btn.h * S
    return x >= bx and x <= bx + bw and y >= by and y <= by + bh
end

-- Глобальний масштаб (Task 10 під'єднає збереження). Дефолт 100%.
RetroDashboard.scale = RetroDashboard.scale or 1.0

-- Одиниці спідометра: "mph" | "kmh". Дефолт mph (зберігає поточну поведінку).
-- Завантажується зі State у RetroDashboard_Init на OnGameStart.
RetroDashboard.units = RetroDashboard.units or "mph"

-- Одноразове підняття налаштувань із диска.
--
-- Штатно це робить OnGameStart (RetroDashboard_Init). Але якщо та подія до нас
-- не дійшла, масштаб МОВЧКИ лишався б 100% — для гравця це виглядає як «розмір
-- не зберігається після перезапуску». Тому тягнемо ще й ліниво, при створенні
-- першої панелі: спрацьовує той, хто перший, прапорець не дає читати двічі.
function RetroDashboard.ensureLoaded()
    if RetroDashboard.loaded then return end
    RetroDashboard.loaded = true
    local ok, s = pcall(RetroDashboard.State.load)
    if ok and type(s) == "table" then
        RetroDashboard.scale = s.scale or RetroDashboard.scale or 1.0
        RetroDashboard.units = s.units or RetroDashboard.units or "mph"
        -- налаштування прийшли зі старого .lua-файла: одразу перекладаємо їх у
        -- .txt, інакше при наступному запуску вони знову читались би зі старого
        if s.migrated then pcall(RetroDashboard.State.save) end
    end
end

-- Розмір панелі в ЦІЛИХ пікселях.
--
-- 212 * 0.9 = 190.8 — дробова висота. Рамку панелі й намальовану текстуру
-- растеризатор округлює незалежно, тож нижній рядок лишався незафарбованим:
-- крізь приборку просвічував світ («at 90% scale one pixel at the bottom of the
-- panel is transparent», репорти 2026-08). При 100% і 125% числа цілі — тому
-- баг і ловився лише на 90% та менших кроках.
--
-- Одне джерело розміру для :new, :onResolutionChange і :render — інакше рамка
-- і текстура знову розійдуться на пів пікселя.
function RetroDashboard.panelSize()
    local S = RetroDashboard.scale
    return math.floor(C.CANVAS_W * S + 0.5), math.floor(C.CANVAS_H * S + 0.5)
end

-- Ніч: 18:00–06:00 (CALIBRATE діапазон за смаком).
function RetroDashboard.isNight()
    local gt = getGameTime()
    if not gt then return false end
    local h = gt:getHour()
    return h >= 18 or h < 6
end

local DASH = ISVehicleDashboard

-- :new — лишаємо ванільну ініціалізацію (playerNum, character, gauges),
-- але одразу довантажуємо наші текстури й фіксуємо ширину полотна.
local vanillaNew = DASH.new
function DASH:new(playerNum, chr)
    local o = vanillaNew(self, playerNum, chr)
    RetroDashboard.ensureLoaded()   -- до setWidth: панель одразу в збереженому масштабі
    o.rd_bgDay   = RetroDashboard.tex("bg_day")
    o.rd_bgNight = RetroDashboard.tex("bg_night")
    o.rd_ambient = RetroDashboard.tex("ambient_night")
    local pw, ph = RetroDashboard.panelSize()
    o:setWidth(pw)
    o:setHeight(ph)
    return o
end

-- :createChildren — викликаємо ванільне СТВОРЕННЯ дітей (textures, gauges, btn_*),
-- а потім ДЕТАЧИМО їх від дерева рендера. Чому не "просто порожньо":
--   * Vanilla код і чужі моди (Tsar's Common Library та похідні від ISVehicleDashboard)
--     звертаються до self.fuelGauge / self.engineGauge / self.lightsTex / ... в
--     своїх prerender'ах. Якщо ці поля nil → `attempted index: setVisible of
--     non-table: null` (зокрема TCL_ISVehicleDashboard.lua:7 → краш при вході
--     в авто, репорт від користувача 2026-06).
--   * clearChildren() прибирає дітей із дерева рендера (javaObject:ClearChildren()),
--     але НЕ чіпає поля-посилання (self.fuelGauge тощо — то окрема таблиця, не
--     self.children). Тож API-контракт цілий (поля існують, setVisible/setX/...
--     валідні), а діти ніколи не малюються — навіть якщо чужий мод зробить їм
--     setVisible(true) (TCL це робить щокадру у своєму prerender). Наш
--     :prerender / :render малюють усе самі через drawTextureScaled.
--   * NB: НЕ ітеруємо getChildren() з :size()/:get() — getChildren() повертає
--     Lua-ТАБЛИЦЮ {[id]=елемент}, а не Java-список; :size() на ній кидає
--     "attempt to call a nil value (method 'size')", цикл падає і діти лишаються
--     ВИДИМИМИ (баг 8b5545a → артефакти ванільних gauge/лейбла "S" поверх нашого
--     дашборда). clearChildren — це валідний метод ISUIElement, без ітерації.
local vanillaCreateChildren = DASH.createChildren
function DASH:createChildren()
    if vanillaCreateChildren then
        pcall(vanillaCreateChildren, self)
    end
    if self.clearChildren then
        pcall(function() self:clearChildren() end)
    end
end

-- :setVehicle — спрощена версія: тільки прив'язка машини й видимість.
function DASH:setVehicle(vehicle)
    self.vehicle = vehicle
    if not vehicle then
        self:removeFromUIManager()
        return
    end
    local part = vehicle:getPartById("GasTank")
    if part and part:isContainer() and part:getContainerContentType() then
        self.gasTank = part
    else
        self.gasTank = nil
    end
    self.dispSpeed = nil   -- скинути згладжування стрілок для нової машини
    self.dispRpm = nil
    self.dispFuel = nil    -- скинути згладжування палива для нової машини
    self.rd_regSet = nil   -- круїз іншої машини — квантуємо заново
    self.rd_tankSide = nil -- бік бака читається зі скрипта нової машини
    self.rd_nightFade = nil   -- без хибного фейду підсвітки на вході
    self.rd_prevKey = nil     -- без хибного звуку ключа на вході
    self.rd_flickerT = nil    -- скинути мигання
    self:setVisible(true)
    self:addToUIManager()
    self:onResolutionChange()
    if not ISUIHandler.allUIVisible then
        self:removeFromUIManager()
    end
end

-- Бік паливної горловини: "left" | "right" | "none".
--
-- Основне джерело — ВАНІЛЬНІ методи `leftSideFuel()Z` / `rightSideFuel()Z` на
-- BaseVehicle (перевірено по jar). Саме ними ванільна приборка вирішує, яку
-- стрілку показати біля датчика палива (ISVehicleDashboard:setVehicle), тож наша
-- стрілка гарантовано збігається з ванільною — байдуже, яка там угода про знак.
--
-- Запасний шлях, якщо методів раптом нема: `area GasTank { xywh = x y w h }` зі
-- скрипта авто, де знак x = борт. Що означає знак — звірено з сидіннями в тих
-- самих скриптах: SeatFrontLeft x=+0.6703, SeatFrontRight x=-0.6703, отже
-- +x = ЛІВИЙ борт. По скриптах B42: 118 авто з баком ліворуч, 16 праворуч (малі
-- седани, stepvan), 1 фактично по центру (sports, x=-0.001) — там стрілки нема.
--
-- Для машини це незмінне, тож рахуємо один раз і кешуємо на self.
function DASH:rdTankSide()
    if self.rd_tankSide ~= nil then return self.rd_tankSide end
    local v = self.vehicle
    local side = "none"

    local ok, res = pcall(function()
        if v.leftSideFuel and v:leftSideFuel() then return "left" end
        if v.rightSideFuel and v:rightSideFuel() then return "right" end
        return nil
    end)
    if ok and res then
        side = res
    else
        -- фолбек по скрипту: getScript():getAreaById("GasTank"):getX()
        -- (getX віддає боксований Double, звідси tonumber)
        local okx, x = pcall(function()
            local script = v and v:getScript()
            local area = script and script:getAreaById("GasTank")
            return area and area:getX() or nil
        end)
        x = okx and tonumber(x) or nil
        -- поріг 0.05 відсікає «формально не нуль» (sports: -0.001)
        if x and x > 0.05 then side = "left"
        elseif x and x < -0.05 then side = "right" end
    end

    self.rd_tankSide = side
    return side
end

-- Круїз-контроль у поточних одиницях: пере-квантування значення регулятора.
--
-- Ваніль тримає getRegulatorSpeed() у КМ/ГОД (float) і крокує рівно по 5 км/год.
-- У mph-режимі це давало б рвану лесенку (3, 6, 9, 12…), а до фікса ще й пряму
-- розбіжність: стрілка в милях, а число круїзу — сирі кілометри.
--
-- Рішення: після КОЖНОЇ чужої зміни регулятора округлюємо його до найближчих
-- C.CRUISE_STEP одиниць (5 mph або 5 км/год) і пишемо назад у км/год. Крок ваніллі
-- (5 км/год = 3.1 mph) більший за півкроку в милях (2.5), тож кожне натискання
-- гарантовано зсуває рівно на одну поділку — залипань «натиснув, а не змінилось» нема.
--
-- Пишемо ЛИШЕ у водія: setRegulatorSpeed(F) синхронізується мережею через
-- VehicleProperties, пасажирам туди лізти не можна. self.rd_regSet тримає останнє
-- НАШЕ значення — поки ваніль його не змінила (з допуском на double→float), не чіпаємо.
function DASH:rdQuantizeCruise()
    local v = self.vehicle
    if not v or not self.character then return end
    local okd, isDriver = pcall(function() return v:isDriver(self.character) end)
    if not okd or not isDriver then return end

    local okr, rs = pcall(function() return v:getRegulatorSpeed() end)
    if not okr or type(rs) ~= "number" or rs <= 0 then
        self.rd_regSet = nil   -- круїз вимкнено — наступне вмикання квантуємо заново
        return
    end
    if self.rd_regSet and math.abs(rs - self.rd_regSet) < 0.01 then return end

    local kmh = RetroDashboard.units == "kmh"
    local step = C.CRUISE_STEP
    local val = kmh and rs or rs * C.MPH_PER_KMH          -- в активних одиницях
    local snapped = math.floor(val / step + 0.5) * step
    if snapped < step then
        if self.rd_regSet == nil then
            -- щойно ввімкнули круїз на малій швидкості: ваніль ставить поточну
            -- швидкість, ми піднімаємо до мінімальної поділки замість гасіння
            snapped = step
        else
            -- «−» з мінімальної поділки: ваніль на цьому місці гасить круїз
            -- (5 → 0 → setRegulator(false)) — повторюємо цю ж поведінку в милях
            pcall(function() v:setRegulatorSpeed(0) end)
            pcall(function() v:setRegulator(false) end)
            self.rd_regSet = nil
            return
        end
    end

    -- Стеля ваніллі: вона відмовляється додавати вище getMaxSpeed()+20 км/год,
    -- тож округлення вгору не має заганяти нас за неї — інакше «+» перестане діяти.
    local okm, maxSpeed = pcall(function() return v:getMaxSpeed() end)
    if okm and type(maxSpeed) == "number" then
        local ceilKmh = maxSpeed + 20
        local ceilVal = kmh and ceilKmh or ceilKmh * C.MPH_PER_KMH
        while snapped > ceilVal and snapped > step do snapped = snapped - step end
    end

    local target = kmh and snapped or snapped * C.KMH_PER_MPH
    if math.abs(target - rs) > 0.01 then
        pcall(function() v:setRegulatorSpeed(target) end)
    end
    self.rd_regSet = target
end

-- :prerender — згладжування стрілок (плавний набір/скид замість стрибків,
-- напр. при перемиканні передачі). Зберігаємо показуване значення на self і
-- щокадру наближаємо його до цільового. FPS-незалежне експ. згладжування.
function DASH:prerender()
    if not self.vehicle then return end
    -- Само-синхронізація позиції з масштабом: render() читає RetroDashboard.scale
    -- наживо, а X/Y задає onResolutionChange. При завантаженні гри в авто ванільний
    -- OnGameStart позиціонує приборку (через наш setVehicle) ДО того, як наш
    -- OnGameStart підвантажить збережений масштаб → панель у вибраному масштабі,
    -- але з координатами для 100%. Ловимо розбіжність і репозиціонуємо (також
    -- лікує будь-який інший desync позиції↔масштабу).
    if self.rd_positionedScale ~= RetroDashboard.scale then
        self:onResolutionChange()
    end
    local v = self.vehicle
    local tSpeed, tRpm = 0, 0
    if v:isEngineRunning() then
        local kmh = math.abs(v:getCurrentSpeedKmHour())
        -- km/h без конвертації; mph = km/h × 0.621371. Шкала 0–120 та сама.
        tSpeed = (RetroDashboard.units == "kmh") and kmh or kmh * C.MPH_PER_KMH
        tRpm = v:getEngineSpeed()
    end
    if self.dispSpeed == nil then self.dispSpeed = tSpeed end
    if self.dispRpm == nil then self.dispRpm = tRpm end
    local fps = 30
    local okf, perf = pcall(function() return getPerformance():getUIRenderFPS() end)
    if okf and perf and perf > 1 then fps = perf end
    local a = 1 - (1 - C.NEEDLE_SMOOTH) ^ (30 / fps)
    self.dispSpeed = self.dispSpeed + (tSpeed - self.dispSpeed) * a
    self.dispRpm = self.dispRpm + (tRpm - self.dispRpm) * a

    -- круїз: тримаємо значення регулятора кратним кроку в активних одиницях
    self:rdQuantizeCruise()

    -- паливо: дані бака достовірні лише коли авто активне (двигун/ключ). У
    -- неактивному стані getContainerContent/getRemainingFuelPercentage віддає
    -- нерепрезентативне значення (особливо в MP) — показувало хибно повний бак,
    -- а при активації різко падало до реального. Тому в неактивному стані
    -- тримаємо останнє відоме, а перехід згладжуємо асиметрично (наповнення
    -- повільне, спад швидший), як ваніль ISVehicleDashboard:prerender — без стрибків.
    local fuelActive = v:isEngineRunning() or v:isKeysInIgnition()
    local tFuel = self.dispFuel or 0
    if self.gasTank and fuelActive then
        local okc, ratio = pcall(function()
            local cap = self.gasTank:getContainerCapacity()
            return (cap and cap > 0) and (self.gasTank:getContainerContentAmount() / cap) or 0
        end)
        if okc and ratio then tFuel = ratio end
    end
    tFuel = math.max(0, math.min(1, tFuel))
    if self.dispFuel == nil then
        self.dispFuel = tFuel                                   -- старт: без слоу-філу
    elseif self.dispFuel < tFuel then
        self.dispFuel = math.min(self.dispFuel + 0.015 * (30 / fps), tFuel)
    elseif self.dispFuel > tFuel then
        self.dispFuel = math.max(self.dispFuel - 0.05 * (30 / fps), tFuel)
    end

    -- день/ніч: авто за часом + ручний override, який авто-скидається на межі
    -- (їхали вночі, настав день → перемкнеться авто, навіть якщо було вручну).
    local autoNight = RetroDashboard.isNight()
    if self.rd_lastAuto ~= nil and autoNight ~= self.rd_lastAuto then
        self.rd_manual = nil
    end
    self.rd_lastAuto = autoNight
    if self.rd_manual ~= nil then self.rd_night = self.rd_manual else self.rd_night = autoNight end

    -- крос-фейд підсвітки до цільового стану (день=0, ніч=1): швидко, але плавно
    local target = self.rd_night and 1 or 0
    if self.rd_nightFade == nil then self.rd_nightFade = target end
    local fa = 1 - (1 - C.NIGHT_FADE) ^ (30 / fps)
    self.rd_nightFade = self.rd_nightFade + (target - self.rd_nightFade) * fa

    -- звук вставлення/виймання ключа на зміні стану
    local ks = RetroDashboard.keyState(self)
    if self.rd_prevKey == nil then self.rd_prevKey = ks end
    if ks ~= self.rd_prevKey then
        if self.character then
            if (ks == "in" or ks == "on") and self.rd_prevKey == "empty" then
                self.character:playSound(C.SND_KEY_IN)
            elseif ks == "empty" then
                self.character:playSound(C.SND_KEY_OUT)
            end
        end
        self.rd_prevKey = ks
    end

    -- мигання підсвітки при ударі: множник альфи нічного шару (1=норма, 0=гасне)
    self.rd_flickerMul = 1
    if self.rd_flickerT and self.rd_flickerT > 0 then
        self.rd_flickerT = self.rd_flickerT - 1 / fps
        local elapsed = C.FLICKER_DUR - self.rd_flickerT
        local seg = math.floor(elapsed / C.FLICKER_BLINK)
        self.rd_flickerMul = (seg % 2 == 0) and 0 or 1
        if self.rd_flickerT <= 0 then self.rd_flickerMul = 1 end
    end
end

-- Малює спрайт-стрілку, повернуту на angleDeg і масштабовану на S, навколо
-- (cx, cy) у локальних координатах панелі. tex 64x200; (tpx,tpy) — pivot у
-- текстурі. Використовуємо drawTextureAllPoint (DrawTextureAngle не масштабує).
function RetroDashboard.drawNeedle(self, tex, cx, cy, angleDeg, S, tpx, tpy)
    -- drawTextureAllPoint малює в АБСОЛЮТНИХ екранних координатах (на відміну
    -- від drawTextureScaled/drawRect, які локальні). Тому додаємо абсолютну
    -- позицію панелі — інакше стрілка «літає» у кутку екрана.
    local ox, oy = self:getAbsoluteX(), self:getAbsoluteY()
    local w, h = 64, 200
    local rad = math.rad(angleDeg)
    local cosA, sinA = math.cos(rad), math.sin(rad)
    local corners = {
        { -tpx,      -tpy },       -- TL
        {  w - tpx,  -tpy },       -- TR
        {  w - tpx,   h - tpy },   -- BR
        { -tpx,       h - tpy },   -- BL
    }
    local p = {}
    for i = 1, 4 do
        local lx, ly = corners[i][1] * S, corners[i][2] * S
        p[i] = {
            ox + cx + (lx * cosA - ly * sinA),
            oy + cy + (lx * sinA + ly * cosA),
        }
    end
    self:drawTextureAllPoint(tex,
        p[1][1], p[1][2], p[2][1], p[2][2],
        p[3][1], p[3][2], p[4][1], p[4][2],
        1, 1, 1, 1)
end

-- speed -> кут; rpm -> кут (лінійно по діапазону). speed у поточних одиницях
-- (mph або km/h) — шкала однакова. CALIBRATE start/sweep у Coords.
function RetroDashboard.speedAngle(speed)
    local f = math.max(0, math.min(1, speed / C.SPEED_DIAL_MAX))
    return C.SPEED_START_DEG + f * C.SPEED_SWEEP_DEG
end
function RetroDashboard.rpmAngle(rpm)
    local span = C.RPM_MAX - C.RPM_MIN
    local f = math.max(0, math.min(1, (rpm - C.RPM_MIN) / span))
    return C.RPM_START_DEG + f * C.RPM_SWEEP_DEG
end

-- Гліфи Digital Numbers: char -> файл у glyphs/. nil = не малюємо (пропуск).
local GLYPH_KEYS = {
    ["0"]="g_0",["1"]="g_1",["2"]="g_2",["3"]="g_3",["4"]="g_4",["5"]="g_5",
    ["6"]="g_6",["7"]="g_7",["8"]="g_8",["9"]="g_9",
    ["N"]="g_N",["R"]="g_R",["P"]="g_P",["D"]="g_D",
}

-- Малює рядок гліфами (x,y — дизайн-координати лівого-верхнього; *S всередині).
-- Колір/трек з C.GLYPH. drawTextureScaled — локальні координати панелі.
function RetroDashboard.drawGlyphs(self, str, x, y, S, dim)
    local G = C.GLYPH
    local m = dim and 0.3 or 1.0                 -- тьмяний варіант (вимк. круїз)
    local w = G.nativeW * G.designScale * S
    local h = G.nativeH * G.designScale * S
    local adv = (G.nativeW * G.designScale + G.track) * S
    local cx, cy = x * S, y * S
    for i = 1, #str do
        local key = GLYPH_KEYS[string.sub(str, i, i)]
        if key then
            self:drawTextureScaled(RetroDashboard.tex("glyphs/" .. key), cx, cy, w, h, 1, G.r * m, G.g * m, G.b * m)
        end
        cx = cx + adv
    end
end

-- :render — фон + emissive-шари (z-порядок) + ambient зверху вночі.
function DASH:render()
    if not self.vehicle then return end
    local S = RetroDashboard.scale
    -- ті самі цілі розміри, що й у рамки панелі: текстура має лягати в неї
    -- край-у-край, інакше вертається напівпіксельна щілина знизу
    local W, H = RetroDashboard.panelSize()

    -- 1) фон: крос-фейд день↔ніч (плавна підсвітка), rd_nightFade у :prerender
    local fade = self.rd_nightFade
    if fade == nil then fade = ((self.rd_night or RetroDashboard.isNight()) and 1) or 0 end
    local night = fade >= 0.5
    local renderFade = fade * (self.rd_flickerMul or 1)   -- мигання при ударі
    self:drawTextureScaled(self.rd_bgDay, 0, 0, W, H, 1, 1, 1, 1)
    if renderFade > 0.001 then
        self:drawTextureScaled(self.rd_bgNight, 0, 0, W, H, renderFade, 1, 1, 1)
    end

    -- 1b) напис одиниць: фон більше не містить запеченого напису, тож завжди
    -- малюємо активний оверлей (label_mph або label_kmph) поверх фону. Одна
    -- текстура на день/ніч. Guard на nil: якщо ассета нема — просто не малюємо.
    local labelTex = RetroDashboard.tex(
        RetroDashboard.units == "kmh" and "label_kmph" or "label_mph")
    if labelTex then self:drawTextureScaled(labelTex, 0, 0, W, H, 1, 1, 1, 1) end

    -- 2) emissive-індикатори за зростанням z (реєстр уже в порядку z)
    for _, layer in ipairs(RetroDashboard.Layers.emissive) do
        if layer.isOn(self) then
            self:drawTextureScaled(RetroDashboard.tex(layer.file), 0, 0, W, H, 1, 1, 1, 1)
        end
    end

    -- 3a) стрілки (значення згладжені в :prerender)
    do
        local speed = self.dispSpeed or 0
        local rpm = self.dispRpm or 0
        local needle = night and RetroDashboard.tex("needle_night")
                             or RetroDashboard.tex("needle_day")
        local sp = C.speedNeedle
        RetroDashboard.drawNeedle(self, needle, sp.pivotX * S, sp.pivotY * S,
            RetroDashboard.speedAngle(speed), S, sp.texPivotX, sp.texPivotY)
        local rp = C.rpmNeedle
        RetroDashboard.drawNeedle(self, needle, rp.pivotX * S, rp.pivotY * S,
            RetroDashboard.rpmAngle(rpm), S, rp.texPivotX, rp.texPivotY)
    end

    -- 3b) паливо: сегментний бар (8 секцій) + іконка
    do
        -- згладжене значення (0..1), пораховане в :prerender з гейтом на
        -- активність авто (двигун/ключ) — без хибно повного бака й без стрибків.
        local fill = self.dispFuel or 0
        local pct = fill * 100
        local fb = C.fuelBar
        local litCount = math.ceil(fill * fb.count)
        for i = 1, fb.count do
            local sx = (fb.x + (i - 1) * (fb.segW + fb.gap)) * S
            local sy = fb.y * S
            local isRed = i <= fb.redCount
            local c, a                                 -- колір за позицією й станом
            if i <= litCount then
                c, a = isRed and C.FUEL_LIT_RED or C.FUEL_LIT_AMBER, C.FUEL_LIT_ALPHA
            else
                c, a = isRed and C.FUEL_DIM_RED or C.FUEL_DIM_AMBER, C.FUEL_DIM_ALPHA
            end
            self:drawRect(sx, sy, fb.segW * S, fb.segH * S, a, c.r, c.g, c.b)
        end
        -- іконка пального — повноекранний PNG: оранж >=20%, червона <20%.
        -- Суфікс — стрілка на борт із горловиною (як на справжніх приборках);
        -- для авто з баком по центру беремо варіант без стрілки.
        local side = self:rdTankSide()
        local suffix = (side == "left" and "_left") or (side == "right" and "_right") or ""
        local base = (pct < 20) and "fuel_icon_red" or "fuel_icon_orange"
        local icon = RetroDashboard.tex(base .. suffix) or RetroDashboard.tex(base)
        if icon then self:drawTextureScaled(icon, 0, 0, W, H, 1, 1, 1, 1) end
    end

    -- 3c) гліфи Digital Numbers: передача + круїз-швидкість
    do
        local v = self.vehicle
        local gear = "P"
        if v:isEngineRunning() then
            local ok, val = pcall(function() return v:getTransmissionNumberLetter() end)
            if ok and val and val ~= "" then gear = tostring(val) end
        end
        RetroDashboard.drawGlyphs(self, gear, C.gear.x, C.gear.y, S)
        -- круїз: завжди показуємо; тьмяно коли вимкнено. Право-вирівняний:
        -- 2-значне число стоїть на cruise.x, кожен зайвий розряд зсуває вліво.
        -- getRegulatorSpeed() — завжди КМ/ГОД; у mph-режимі конвертуємо, інакше
        -- стрілка йшла б у милях, а число круїзу лишалось кілометровим (баг v0.1.0).
        local reg = 0
        local okr, rs = pcall(function() return v:getRegulatorSpeed() end)
        if okr and type(rs) == "number" then
            local val = (RetroDashboard.units == "kmh") and rs or rs * C.MPH_PER_KMH
            reg = math.floor(val + 0.5)   -- округлення, а не floor: double→float дає 29.99…
        end
        local s = tostring(reg)
        local advD = C.GLYPH.nativeW * C.GLYPH.designScale + C.GLYPH.track
        local cruiseX = C.cruise.x + (2 - #s) * advD
        RetroDashboard.drawGlyphs(self, s, cruiseX, C.cruise.y, S, not v:isRegulator())
    end

    -- 4) ambient permanent (нічний топ-шар) ВИМКНЕНО: при текстурній компресії
    -- плавний градієнт перетворюється на монотонну пляму. Повернути, якщо
    -- вирішимо проблему компресії.
    -- if night then self:drawTextureScaled(self.rd_ambient, 0, 0, W, H, 1, 1, 1, 1) end

    -- 5) підказка про деталь під курсором (найвищий шар)
    self:rdDrawTooltip(S, W, H)
end

-- Підказка при наведенні на іконку. Малюємо самі: ванільний mouseovertext живе
-- на дочірніх віджетах, які ми відчепили (clearChildren) — його ніхто не покаже.
--
-- Кадр тримаємо В МЕЖАХ полотна приборки: PZ не гарантує, що намальоване за
-- межами елемента буде видно, тож замість «летючої» підказки притискаємо її
-- до курсора й затискаємо в панель. Панель 1148x212 — місця вистачає.
function DASH:rdDrawTooltip(S, W, H)
    if not self.vehicle then return end
    if not self:isMouseOver() then return end
    local mx, my = self:getMouseX(), self:getMouseY()

    local key
    for k, btn in pairs(C.buttons) do
        if hitZone(btn, S, mx, my) then
            key = k
            break
        end
    end
    if not key then return end

    local lines = RetroDashboard.Tooltips.get(key, self.vehicle, self)
    if not lines then return end

    local tm = getTextManager()
    local font = UIFont.Small
    local lineH = tm:getFontHeight(font)
    local padX, padY = 10 * S, 6 * S
    local tw = 0
    for _, s in ipairs(lines) do
        tw = math.max(tw, tm:MeasureStringX(font, s))
    end
    local bw = tw + padX * 2
    local bh = lineH * #lines + padY * 2

    -- над курсором; якщо не влазить — під ним. Далі затискаємо в полотно.
    local bx = mx - bw / 2
    local by = my - bh - 12 * S
    if by < 0 then by = my + 16 * S end
    bx = math.max(0, math.min(bx, W - bw))
    by = math.max(0, math.min(by, H - bh))

    self:drawRect(bx, by, bw, bh, 0.92, 0.05, 0.04, 0.03)          -- підкладка
    self:drawRectBorder(bx, by, bw, bh, 0.55, C.GLYPH.r, C.GLYPH.g, C.GLYPH.b)
    for i, s in ipairs(lines) do
        -- заголовок бурштиновий, деталі приглушені — щоб читалось з першого погляду
        local a = (i == 1) and 1.0 or 0.82
        local r, g, b = C.GLYPH.r, C.GLYPH.g, C.GLYPH.b
        if i > 1 then r, g, b = 0.93, 0.90, 0.84 end
        self:drawText(s, bx + padX, by + padY + (i - 1) * lineH, r, g, b, a, font)
    end
end

-- :onResolutionChange — притиснути панель до низу-центру з урахуванням масштабу.
function DASH:onResolutionChange()
    local S = RetroDashboard.scale
    local screenLeft   = getPlayerScreenLeft(self.playerNum)
    local screenTop    = getPlayerScreenTop(self.playerNum)
    local screenWidth  = getPlayerScreenWidth(self.playerNum)
    local screenHeight = getPlayerScreenHeight(self.playerNum)
    -- Цілі ширина/висота + цілі X/Y: нижній край панелі збігається з низом
    -- екрана рівно, без напівпіксельної щілини (див. RetroDashboard.panelSize).
    local pw, ph = RetroDashboard.panelSize()
    self:setWidth(pw)
    self:setHeight(ph)
    self:setX(math.floor(screenLeft + (screenWidth - pw) / 2 + 0.5))
    self:setY(math.floor(screenTop + screenHeight - ph + 0.5))
    self.rd_positionedScale = S   -- масштаб, під який порахована позиція (див. prerender)
end

-- ЛКМ по панелі: знайти зону й викликати її обробник (ванільний або наш).
-- Ванільні onClick* і наш rdToggleDayNight — усі методи ISVehicleDashboard.
function DASH:onMouseDown(x, y)
    if not self.vehicle then return false end
    local S = RetroDashboard.scale
    for _, btn in pairs(C.buttons) do
        if btn.handler and hitZone(btn, S, x, y) then
            local fn = ISVehicleDashboard[btn.handler]
            if fn then fn(self); return true end
        end
    end
    return false
end

-- Ручний тумблер день/ніч: фліпає поточний режим (авто-скинеться на межі).
function DASH:rdToggleDayNight()
    local cur = self.rd_night
    if cur == nil then cur = RetroDashboard.isNight() end
    self.rd_manual = not cur
    self.rd_night = self.rd_manual
    getSoundManager():playUISound(C.SND_BACKLIGHT)
end

-- ПКМ по панелі → контекстне меню з пресетами масштабу.
local SCALE_PRESETS = { 0.50, 0.75, 0.90, 1.00, 1.10, 1.25, 1.50 }
function DASH:onRightMouseDown(x, y)
    local menu = ISContextMenu.get(self.playerNum, self:getAbsoluteX() + x, self:getAbsoluteY() + y)
    local sub = ISContextMenu:getNew(menu)
    local parent = menu:addOption(getText("ContextMenu_RetroDash_Scale"), nil, nil)
    menu:addSubMenu(parent, sub)
    for _, p in ipairs(SCALE_PRESETS) do
        local opt = sub:addOption(tostring(math.floor(p * 100 + 0.5)) .. "%", self, DASH.onPickScale, p)
        if math.abs(RetroDashboard.scale - p) < 0.001 then
            sub:setOptionChecked(opt, true)
        end
    end

    -- Підменю одиниць швидкості: KM/H vs MPH, галочка на активному.
    local uParent = menu:addOption(getText("ContextMenu_RetroDash_Units"), nil, nil)
    local uSub = ISContextMenu:getNew(menu)
    menu:addSubMenu(uParent, uSub)
    local uKmh = uSub:addOption(getText("ContextMenu_RetroDash_Units_Kmh"), self, DASH.onPickUnits, "kmh")
    local uMph = uSub:addOption(getText("ContextMenu_RetroDash_Units_Mph"), self, DASH.onPickUnits, "mph")
    uSub:setOptionChecked(uKmh, RetroDashboard.units == "kmh")
    uSub:setOptionChecked(uMph, RetroDashboard.units ~= "kmh")

    return true
end

function DASH:onPickScale(scale)
    RetroDashboard.scale = scale
    RetroDashboard.State.save()
    self:onResolutionChange()
end

-- Вибір одиниць спідометра. Геометрія приборки не змінюється — без
-- onResolutionChange. Валідуємо вхід до "mph"/"kmh".
function DASH:onPickUnits(units)
    RetroDashboard.units = (units == "kmh") and "kmh" or "mph"
    -- крок круїзу рахується в активних одиницях → після перемикання значення
    -- регулятора треба переквантувати під нову шкалу (наступний :prerender)
    self.rd_regSet = nil
    RetroDashboard.State.save()
end

-- Старт мигання підсвітки (викликається з damageFlick при ударі).
function DASH:rdStartFlicker()
    self.rd_flickerT = C.FLICKER_DUR
end

-- Перевизначаємо ванільний damageFlick: замість мигання кнопок — мигання
-- підсвітки нашого дашборда. Детекцію удару робить ванільний damageChecker
-- (OnTick, лишився активним), що викликає цю функцію через таблицю класу.
function ISVehicleDashboard.damageFlick(character)
    if not (instanceof(character, 'IsoPlayer') and character:isLocalPlayer()) then return end
    local dash = getPlayerVehicleDashboard(character:getPlayerNum())
    if dash then dash:rdStartFlicker() end
end
