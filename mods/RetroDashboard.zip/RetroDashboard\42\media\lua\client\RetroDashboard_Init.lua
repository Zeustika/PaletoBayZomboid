-- RetroDashboard: client entry point.
RetroDashboard = RetroDashboard or {}

require "RetroDashboard/State"
require "RetroDashboard/Dashboard"

-- Штатна точка завантаження налаштувань. Дублює її ensureLoaded() при створенні
-- панелі — на випадок, якщо ця подія до нас не дійшла (див. Dashboard.lua).
Events.OnGameStart.Add(function()
    RetroDashboard.ensureLoaded()
    print("[RetroDashboard] client loaded (v0.2.2) scale=" .. tostring(RetroDashboard.scale)
        .. " units=" .. tostring(RetroDashboard.units))
end)
