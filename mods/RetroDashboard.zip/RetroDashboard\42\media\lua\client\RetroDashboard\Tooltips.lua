-- RetroDashboard/Tooltips.lua
-- Підказки про стан деталей при наведенні на іконки приборки.
--
-- Ваніль тримає такі тексти на дочірніх віджетах (`self.engineTex.mouseovertext`),
-- але ми ті віджети відчіпляємо через clearChildren (див. Dashboard.lua), тож їхній
-- mouseover ніколи не спрацює — малюємо підказки самі.
--
-- Тексти беремо з ВАНІЛЬНИХ ключів локалізації, тому підказки одразу говорять
-- усіма мовами гри, без нашого перекладу:
--   Tooltip_Dashboard_*            — назви/стани (Engine status, Door locks, ...)
--   IGUI_VehiclePart<PartId>       — назва деталі («Left Headlight»)
--   IGUI_invpanel_Condition/_Remaining — «Condition» / «Remaining»
-- Свої ключі (Tooltip_RetroDash_*) додаємо лише там, де у ваніллі відповідника нема.
require "RetroDashboard/Coords"

RetroDashboard = RetroDashboard or {}
RetroDashboard.Tooltips = RetroDashboard.Tooltips or {}
local T = RetroDashboard.Tooltips

-- Стан деталі у відсотках. getCondition() віддає int 0..100 (перевірено по
-- VehiclePart.class: getCondition()I). Нема деталі — нема рядка.
local function cond(v, id)
    local p = v and v:getPartById(id)
    if not p then return nil end
    local ok, c = pcall(function() return p:getCondition() end)
    return ok and tonumber(c) or nil
end

local function partName(id, fallback)
    local s = getText("IGUI_VehiclePart" .. id)
    -- getText повертає сам ключ, якщо перекладу нема
    if not s or s == "" or s == "IGUI_VehiclePart" .. id then return fallback or id end
    return s
end

local function pct(label, value)
    return label .. ": " .. tostring(math.floor(value + 0.5)) .. "%"
end

-- Заряд батареї 0..1. Ваніль читає його двома шляхами: з предмета-акумулятора
-- (getCurrentUsesFloat, так робить ISVehicleMechanics) і з машини
-- (getBatteryCharge, так робить ванільна приборка). Предмет точніший — він є
-- джерелом; getBatteryCharge лишаємо запасним.
local function batteryCharge(v)
    local p = v and v:getPartById("Battery")
    if p then
        local ok, val = pcall(function()
            local item = p:getInventoryItem()
            return item and item:getCurrentUsesFloat() or nil
        end)
        if ok and tonumber(val) then return tonumber(val) end
    end
    local ok, val = pcall(function() return v:getBatteryCharge() end)
    return ok and tonumber(val) or nil
end

-- Білдери рядків підказки для кожної зони C.buttons. Повертають масив рядків
-- (перший — заголовок) або nil, якщо для цієї машини показувати нічого.
T.builders = {
    engine = function(v)
        local lines = { getText("Tooltip_Dashboard_Engine") }
        local c = cond(v, "Engine")
        if c then lines[#lines + 1] = pct(getText("IGUI_invpanel_Condition"), c) end
        return lines
    end,

    battery = function(v)
        local lines = { partName("Battery", getText("Tooltip_Dashboard_Battery")) }
        local c = cond(v, "Battery")
        if c then lines[#lines + 1] = pct(getText("IGUI_invpanel_Condition"), c) end
        local charge = batteryCharge(v)
        if charge then lines[#lines + 1] = pct(getText("IGUI_invpanel_Remaining"), charge * 100) end
        return lines
    end,

    lights = function(v)
        local lines = { getText("Tooltip_Dashboard_Headlights") }
        local l, r = cond(v, "HeadlightLeft"), cond(v, "HeadlightRight")
        if l then lines[#lines + 1] = pct(partName("HeadlightLeft"), l) end
        if r then lines[#lines + 1] = pct(partName("HeadlightRight"), r) end
        return lines
    end,

    door = function(v)
        local lines = { getText("Tooltip_Dashboard_LockedDoors") }
        local ok, locked = pcall(function() return v:areAllDoorsLocked() end)
        if ok then
            lines[#lines + 1] = getText(locked and "Tooltip_RetroDash_Locked"
                                               or "Tooltip_RetroDash_Unlocked")
        end
        return lines
    end,

    trunk = function(v)
        local ok, locked = pcall(function() return v:isTrunkLocked() end)
        if not ok then return nil end
        return { getText(locked and "Tooltip_Dashboard_TrunkLocked"
                                or "Tooltip_Dashboard_TrunkUnlocked") }
    end,

    radio = function(v)
        local lines = { partName("Radio", getText("Tooltip_Dashboard_Radio")) }
        local p = v and v:getPartById("Radio")
        if not p then return lines end
        local ok, on = pcall(function()
            local dd = p:getDeviceData()
            return dd and dd:getIsTurnedOn() or false
        end)
        if ok then
            lines[#lines + 1] = getText(on and "Tooltip_RetroDash_On" or "Tooltip_RetroDash_Off")
        end
        local c = cond(v, "Radio")
        if c then lines[#lines + 1] = pct(getText("IGUI_invpanel_Condition"), c) end
        return lines
    end,

    air = function(v)
        local lines = { partName("Heater", getText("Tooltip_Dashboard_Heater")) }
        -- climateState уже враховує active+напрямок температури (див. Layers.lua)
        local state = RetroDashboard.climateState({ vehicle = v })
        lines[#lines + 1] = getText(
            state == "hot"  and "Tooltip_RetroDash_Heating" or
            state == "cold" and "Tooltip_RetroDash_Cooling" or "Tooltip_RetroDash_Off")
        local c = cond(v, "Heater")
        if c then lines[#lines + 1] = pct(getText("IGUI_invpanel_Condition"), c) end
        return lines
    end,

    ignition = function(v, dash)
        local state = RetroDashboard.keyState({ vehicle = v })
        if state == "hotwired" then return { getText("Tooltip_Dashboard_Hotwired") } end
        if state ~= "empty" then return { getText("Tooltip_Dashboard_KeysIgnition") } end
        -- ключа в замку нема: ваніль розрізняє «є ключ у кишені» й «ключа нема»
        local has = false
        local chr = dash and dash.character
        if chr then
            local ok, res = pcall(function()
                return chr:getInventory():haveThisKeyId(v:getKeyId())
            end)
            has = ok and res or false
        end
        return { getText(has and "Tooltip_Dashboard_PutKeysInIgnition"
                             or "Tooltip_Dashboard_NoKey") }
    end,

    daynight = function()
        return { getText("Tooltip_RetroDash_Backlight") }
    end,
}

-- Рядки для зони або nil. Помилка в білдері не має валити рендер приборки.
function T.get(key, vehicle, dash)
    local b = T.builders[key]
    if not b or not vehicle then return nil end
    local ok, lines = pcall(b, vehicle, dash)
    if not ok or type(lines) ~= "table" or #lines == 0 then return nil end
    return lines
end

return RetroDashboard.Tooltips
