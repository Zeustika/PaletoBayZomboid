if VehicleZoneDistribution then

VehicleZoneDistribution.parkingstall.vehicles["Base.Trailer87Scamp16"] = {index = -1, spawnChance = 1};
VehicleZoneDistribution.parkingstall.vehicles["Base.Trailer87Scamp13"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.parkingstall.vehicles["Base.Trailer54FlyingCloud22"] = {index = -1, spawnChance = 1};
VehicleZoneDistribution.parkingstall.vehicles["Base.Trailer61Bambi16"] = {index = -1, spawnChance = 2};

VehicleZoneDistribution.trailerpark.vehicles["Base.Trailer87Scamp16"] = {index = -1, spawnChance = 4};
VehicleZoneDistribution.trailerpark.vehicles["Base.Trailer87Scamp13"] = {index = -1, spawnChance = 3};
VehicleZoneDistribution.trailerpark.vehicles["Base.Trailer61Bambi16"] = {index = -1, spawnChance = 4};
VehicleZoneDistribution.trailerpark.vehicles["Base.Trailer54FlyingCloud22"] = {index = -1, spawnChance = 3};

VehicleZoneDistribution.bad.vehicles["Base.Trailer61Bambi16"] = {index = -1, spawnChance = 1};
VehicleZoneDistribution.bad.vehicles["Base.Trailer87Scamp13"] = {index = -1, spawnChance = 2};

VehicleZoneDistribution.junkyard.vehicles["Base.Trailer87Scamp16"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.junkyard.vehicles["Base.Trailer87Scamp13"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.junkyard.vehicles["Base.Trailer61Bambi16"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.junkyard.vehicles["Base.Trailer54FlyingCloud22"] = {index = -1, spawnChance = 2};

VehicleZoneDistribution.trafficjamn.vehicles["Base.Trailer87Scamp16"] = {index = -1, spawnChance = 3};
VehicleZoneDistribution.trafficjams.vehicles["Base.Trailer87Scamp16"] = {index = -1, spawnChance = 1};
VehicleZoneDistribution.trafficjamw.vehicles["Base.Trailer87Scamp13"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.trafficjame.vehicles["Base.Trailer87Scamp13"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.trafficjamn.vehicles["Base.Trailer61Bambi16"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.trafficjame.vehicles["Base.Trailer61Bambi16"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.trafficjamw.vehicles["Base.Trailer54FlyingCloud22"] = {index = -1, spawnChance = 2};
VehicleZoneDistribution.trafficjame.vehicles["Base.Trailer54FlyingCloud22"] = {index = -1, spawnChance = 3};

end