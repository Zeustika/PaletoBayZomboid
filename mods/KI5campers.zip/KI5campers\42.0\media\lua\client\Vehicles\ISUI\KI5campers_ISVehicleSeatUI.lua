require('Vehicles/ISUI/ISVehicleSeatUI')

ImageScale["Trailer87Scamp16_"] = 0.9
SeatOffsetX["Base.Trailer87Scamp16"] = 0;
SeatOffsetY["Base.Trailer87Scamp16"] = 50;

ImageScale["Trailer87Scamp13_"] = 1.0
SeatOffsetX["Base.Trailer87Scamp13"] = 0;
SeatOffsetY["Base.Trailer87Scamp13"] = 80;

ImageScale["Trailer61Bambi16_"] = 0.9
SeatOffsetX["Base.Trailer61Bambi16"] = 0;
SeatOffsetY["Base.Trailer61Bambi16"] = 50;

ImageScale["Trailer54FlyingCloud22_"] = 0.6
SeatOffsetX["Base.Trailer54FlyingCloud22"] = 0;
SeatOffsetY["Base.Trailer54FlyingCloud22"] = 50;