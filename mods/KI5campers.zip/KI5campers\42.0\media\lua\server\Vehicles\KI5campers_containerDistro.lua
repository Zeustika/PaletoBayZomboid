local distributionTable = VehicleDistributions[1]

VehicleDistributions.KI5CRGloveBox = {
    rolls = 1,
    items = {
        "Base.87ScampCamperMagazine", 60,
        "Base.Pen", 4,
        "Base.Pencil", 4,
        "Base.Cigarettes", 5,
        "Base.Lighter", 5,
        "Base.Matches", 3,
        "Base.Tissue", 2,
    },
    junk = ClutterTables.GloveBoxJunk,
}

VehicleDistributions.KI5CRFloorDist = {
    rolls = 2,
    items = {
        "Base.BallPeenHammer", 1,
        "Base.PipeWrench", 1,
        "Base.Rope", 1,
        "Base.Saw", 1,
        "Base.Screwdriver", 1,
        "Base.Pen", 4,
        "Base.Pencil", 4,
        "Base.Cigarettes", 5,
        "Base.Lighter", 5,
        "Base.Matches", 3,
        "Base.Tissue", 2,
        "Base.KI5CamperMat", 10,
    }
}

VehicleDistributions.KI5CRToolboxDist = {
    rolls = 2,
    items = {
        "Base.BallPeenHammer", 5,
        "Base.PipeWrench", 3,
        "Base.Screwdriver", 7,
        "Base.Wrench", 6,
        "Base.Screwdriver", 6,
        "Base.Jack", 4,
    }
}

VehicleDistributions.KI5CRScampDist = {

	KI5CRFloor = VehicleDistributions.KI5CRFloorDist;
    KI5CRCabsSide = VehicleDistributions.GloveBox;
    KI5CRCabsTop = VehicleDistributions.GloveBox;
    KI5CRCabsBottom = VehicleDistributions.KI5CRGloveBox;
    KI5CRToolbox = VehicleDistributions.KI5CRToolboxDist;

}

distributionTable["Trailer87Scamp16"] = { Normal = VehicleDistributions.KI5CRScampDist; }
distributionTable["Trailer87Scamp13"] = { Normal = VehicleDistributions.KI5CRScampDist; }
distributionTable["Trailer61Bambi16"] = { Normal = VehicleDistributions.KI5CRScampDist; }
distributionTable["Trailer54FlyingCloud22"] = { Normal = VehicleDistributions.KI5CRScampDist; }