require "DAMN_MechOverlay";
--
--##########Trailer87Scamp16##########
--
DAMN.MechOverlay:addParts({
    ["Base.Trailer87Scamp16"] = "Trailer87Scamp16_",
}, {
    Battery = {img="battery", x=13,y=76,x2=55,y2=108},
    --
    SuspensionFrontLeft = {img="suspension_front_left", x=13,y=220,x2=55,y2=259},
    SuspensionFrontRight = {img="suspension_front_right", x=228,y=220,x2=270,y2=259},
    --
    TireFrontLeft = {img="wheel_front_left", x=13,y=259,x2=55,y2=297},
    TireFrontRight = {img="wheel_front_right", x=228,y=259,x2=270,y2=297},
    --
    DoorFrontRight = {img="door_front_right", x=195,y=163,x2=200,y2=206},

    --
    WindowFrontRight = {img="window_front_right", x=200,y=172,x2=205,y2=198},
    WindowRearLeft = {img="window_rear_left", x=76,y=234,x2=82,y2=273},
    WindowRearRight = {img="window_rear_right", x=200,y=234,x2=205,y2=273},
    WindowBackLeft = {img="window_back_left", x=76,y=297,x2=82,y2=341},
    WindowBackRight = {img="window_back_right", x=200,y=297,x2=205,y2=341},
    --
    WindshieldRear = {img="window_rear_windshield", x=100,y=371,x2=180,y2=377},
    --
}, 10, 10);
--
--##########Trailer87Scamp13##########
--
DAMN.MechOverlay:addParts({
    ["Base.Trailer87Scamp13"] = "Trailer87Scamp13_",
}, {
    Battery = {img="battery", x=13,y=76,x2=55,y2=108},
    --
    SuspensionFrontLeft = {img="suspension_front_left", x=13,y=220,x2=55,y2=259},
    SuspensionFrontRight = {img="suspension_front_right", x=228,y=220,x2=270,y2=259},
    --
    TireFrontLeft = {img="wheel_front_left", x=13,y=259,x2=55,y2=297},
    TireFrontRight = {img="wheel_front_right", x=228,y=259,x2=270,y2=297},
    --
    DoorFrontRight = {img="door_front_right", x=195,y=163,x2=200,y2=206},

    --
    WindowFrontRight = {img="window_front_right", x=200,y=172,x2=205,y2=198},
    WindowBackLeft = {img="window_back_left", x=76,y=238,x2=82,y2=284},
    WindowBackRight = {img="window_back_right", x=200,y=238,x2=205,y2=284},
    --
    WindshieldRear = {img="window_rear_windshield", x=100,y=312,x2=180,y2=319},
    --
}, 10, 10);
--
--##########Trailer61Bambi16##########
--
DAMN.MechOverlay:addParts({
    ["Base.Trailer61Bambi16"] = "Trailer61Bambi16_",
}, {
    Battery = {img="battery", x=227,y=327,x2=268,y2=358},
    --
    SuspensionFrontLeft = {img="suspension_front_left", x=13,y=220,x2=55,y2=259},
    SuspensionFrontRight = {img="suspension_front_right", x=228,y=220,x2=270,y2=259},
    --
    TireFrontLeft = {img="wheel_front_left", x=13,y=259,x2=55,y2=297},
    TireFrontRight = {img="wheel_front_right", x=228,y=259,x2=270,y2=297},
    --
    DoorFrontRight = {img="door_front_right", x=190,y=163,x2=200,y2=206},

    --
    WindowFrontLeft = {img="window_front_left", x=76,y=177,x2=81,y2=236},
    WindowFrontRight = {img="window_front_right", x=199,y=174,x2=205,y2=195},
    WindowRearLeft = {img="window_rear_left", x=76,y=240,x2=81,y2=299},

    --
    Windshield = {img="window_windshield", x=103,y=128,x2=178,y2=134},
    WindshieldRear = {img="window_rear_windshield", x=110,y=372,x2=170,y2=377},
    --
}, 10, 10);
--
--##########Trailer54FlyingCloud22##########
--
DAMN.MechOverlay:addParts({
    ["Base.Trailer54FlyingCloud22"] = "Trailer54FlyingCloud22_",
}, {
    Battery = {img="battery", x=227,y=327,x2=268,y2=358},
    --
    SuspensionFrontLeft = {img="suspension_front_left", x=13,y=220,x2=55,y2=259},
    SuspensionFrontRight = {img="suspension_front_right", x=228,y=220,x2=270,y2=259},
    --
    TireFrontLeft = {img="wheel_front_left", x=13,y=259,x2=55,y2=297},
    TireFrontRight = {img="wheel_front_right", x=228,y=259,x2=270,y2=297},
    --
    DoorFrontRight = {img="door_front_right", x=190,y=236,x2=206,y2=279},

    --
    WindowFrontLeft = {img="window_front_left", x=76,y=179,x2=81,y2=228},
    WindowFrontRight = {img="window_front_right", x=199,y=179,x2=205,y2=228},
    WindowMiddleLeft = {img="window_middle_left", x=76,y=231,x2=81,y2=280},
    WindowRearLeft = {img="window_rear_left", x=76,y=384,x2=81,y2=417},
    WindowRearRight = {img="window_rear_right", x=199,y=384,x2=205,y2=417},

    --
    Windshield = {img="window_windshield", x=108,y=128,x2=175,y2=134},
    WindshieldRear = {img="window_rear_windshield", x=112,y=501,x2=172,y2=506},
    --
}, 10, 10);
--