--***********************************************************
--**                   KI5 / bikinihorst                   **
--***********************************************************

require "Hooks/DAMN_EnterAnimations";
require "Hooks/DAMN_VehicleMenu";


DAMN = DAMN or {};
KI5CR = KI5CR or {};

    DAMN.EnterAnimations:registerVehicleScript("Base.Trailer87Scamp16", function(seatIndex, player)
        if seatIndex == 0
        then
            return {
                ["damnPosition"] = "passenger",
                ["damnRole"] = "",
            };
        elseif seatIndex == 1
        then
            return {
                ["damnPosition"] = "facingBack",
                ["damnRole"] = "",
            };
        elseif seatIndex == 2
        then
            return {
                ["damnPosition"] = "facingBack",
                ["damnRole"] = "",
            };
        elseif seatIndex == 3
        then
            return {
                ["damnPosition"] = "facingBack",
                ["damnRole"] = "",
            };
        elseif seatIndex == 4
        then
            return {
                ["damnPosition"] = "passenger",
                ["damnRole"] = "",
            };
        else
            return {
                ["damnPosition"] = "lyingSide",
                ["damnRole"] = "",
            };
        end
    end);

    DAMN.EnterAnimations:registerVehicleScript("Base.Trailer87Scamp13", function(seatIndex, player)
        if seatIndex == 0
        then
            return {
                ["damnPosition"] = "passenger",
                ["damnRole"] = "",
            };
        elseif seatIndex == 1
        then
            return {
                ["damnPosition"] = "facingBack",
                ["damnRole"] = "",
            };
        elseif seatIndex == 2
        then
            return {
                ["damnPosition"] = "facingBack",
                ["damnRole"] = "",
            };
        else
            return {
                ["damnPosition"] = "lyingSide",
                ["damnRole"] = "",
            };
        end
    end);

    DAMN.EnterAnimations:registerVehicleScript("Base.Trailer61Bambi16", function(seatIndex, player)
        if seatIndex == 0
        then
            return {
                ["damnPosition"] = "passenger",
                ["damnRole"] = "",
            };
        elseif seatIndex == 1
        then
            return {
                ["damnPosition"] = "lyingSide",
                ["damnRole"] = "",
            };
        elseif seatIndex == 2
        then
            return {
                ["damnPosition"] = "lyingSide90",
                ["damnRole"] = "",
            };
        elseif seatIndex == 3
        then
            return {
                ["damnPosition"] = "facingRight",
                ["damnRole"] = "",
            };
        else
            return {
                ["damnPosition"] = "facingLeft",
                ["damnRole"] = "",
            };
        end
    end);

    DAMN.EnterAnimations:registerVehicleScript("Base.Trailer54FlyingCloud22", function(seatIndex, player)
        if seatIndex == 0
        then
            return {
                ["damnPosition"] = "passenger",
                ["damnRole"] = "",
            };
        elseif seatIndex == 1
        then
            return {
                ["damnPosition"] = "lyingSide",
                ["damnRole"] = "",
            };
        elseif seatIndex == 2
        then
            return {
                ["damnPosition"] = "lyingSide90",
                ["damnRole"] = "",
            };
        elseif seatIndex == 3
        then
            return {
                ["damnPosition"] = "facingBack",
                ["damnRole"] = "",
            };
        elseif seatIndex == 4
        then
            return {
                ["damnPosition"] = "passenger",
                ["damnRole"] = "",
            };
        else
            return {
                ["damnPosition"] = "facingLeft",
                ["damnRole"] = "",
            };
        end
    end);

DAMN.VehicleMenu:registerConditionalSlice(function(radialMenu, playerObj, vehicle, vehicleScriptName)
    if vehicleScriptName == "Base.Trailer87Scamp16"
    or vehicleScriptName == "Base.Trailer87Scamp13"
    or vehicleScriptName == "Base.Trailer61Bambi16"
    or vehicleScriptName == "Base.Trailer54FlyingCloud22"
    then
        
        local part = vehicle:getPartById("DAMNTrailerAwning");

        if part and DAMN.Parts:partIsInstalled(part)
        then
            local door = part:getDoor();

            if door:isOpen()
            then
                radialMenu:addSlice(getText("IGUI_DAMN_CLOSE_AWNING"), getTexture("media/textures/Slice_KI5CR_awning.png"), function()
                    vehicle:playPartAnim(part, "Close");
                    door:setOpen(false);
                end);
            else
                radialMenu:addSlice(getText("IGUI_DAMN_OPEN_AWNING"), getTexture("media/textures/Slice_KI5CR_awning.png"), function()
                    vehicle:playPartAnim(part, "Open");
                    door:setOpen(true);
                end);
            end
        end
    end
end, "toggle_DAMNTrailerAwning");