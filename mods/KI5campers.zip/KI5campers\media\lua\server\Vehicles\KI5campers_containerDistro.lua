local distributionTable = VehicleDistributions[1]

VehicleDistributions.KI5CRFloorDist = {
    rolls = 2,
    items = {
        "Base.BallPeenHammer", 6,
        "Base.PipeWrench", 6,
        "Base.Rope", 8,
        "Base.Saw", 8,
        "Base.Screwdriver", 10,
        "Base.KI5CamperMat", 15,
    }
}

VehicleDistributions.KI5CRToolboxDist = {
    rolls = 2,
    items = {
        "Base.BallPeenHammer", 5,
        "Base.PipeWrench", 3,
        "Base.Screwdriver", 7,
        "Base.Wrench", 6,
        "Base.Screwdriver", 6,
        "Base.Jack", 4,
    }
}

VehicleDistributions.KI5CRScampDist = {

	KI5CRFloor = VehicleDistributions.KI5CRFloorDist;
    KI5CRCabsSide = VehicleDistributions.GloveBox;
    KI5CRCabsTop = VehicleDistributions.GloveBox;
    KI5CRCabsBottom = VehicleDistributions.GloveBox;
    KI5CRToolbox = VehicleDistributions.KI5CRToolboxDist;

}

distributionTable["Trailer87Scamp16"] = { Normal = VehicleDistributions.KI5CRScampDist; }
distributionTable["Trailer87Scamp13"] = { Normal = VehicleDistributions.KI5CRScampDist; }
distributionTable["Trailer61Bambi16"] = { Normal = VehicleDistributions.KI5CRScampDist; }
distributionTable["Trailer54FlyingCloud22"] = { Normal = VehicleDistributions.KI5CRScampDist; }