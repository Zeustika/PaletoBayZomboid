require "DAMN_Armor_Shared";

--***********************************************************
--**                   KI5 / bikinihorst                   **
--***********************************************************
--v2.0.0

KI5CR = KI5CR or {};

function KI5CR.activeArmor(player, vehicle)
   
		--

		for partId, armorPartId in pairs({
                ["WindshieldFront"] = "DAMNWindshieldFrontArmor",
				["WindowFrontLeft"] = "DAMNFrontLeftArmor",
				["WindowFrontRight"] = "DAMNFrontRightArmor",
                ["WindowMiddleLeft"] = "DAMNMiddleLeftArmor",
				["WindowRearLeft"] = "DAMNRearLeftArmor",
				["WindowRearRight"] = "DAMNRearRightArmor",
				["WindowBackLeft"] = "DAMNBackLeftArmor",
				["WindowBackRight"] = "DAMNBackRightArmor",
                ["WindshieldRear"] = "DAMNWindshieldRearArmor",
			}) do
				local part = vehicle:getPartById(partId);
				local protection = vehicle:getPartById(armorPartId);
				if protection and protection:getInventoryItem() and part and part:getModData()
				then
					local partCond = tonumber(part:getModData().saveCond);
					if protection:getCondition() > 0 and partCond and part:getCondition() < partCond
					then
						DAMN.Armor:setPartCondition(part, partCond);
                        local cond = protection:getCondition() - ZombRandBetween(0,2)
						DAMN.Armor:setPartCondition(protection, cond);
					end
				end
			end

        --

        for i, nodisplay in ipairs ({"TireRearLeft", "TireRearRight"})
				do
					if vehicle:getPartById(nodisplay) then
						local part = vehicle:getPartById(nodisplay)
					    	if part:getCondition() < 100 then
					    		DAMN.Armor:setPartCondition(part, 100);
							end
					end
			end

		--

		for partId, armorPartId in pairs({
				["HeadlightRearLeft"] = "DAMNBumperRear",
				["HeadlightRearRight"] = "DAMNBumperRear",
			}) do
				local part = vehicle:getPartById(partId);
				local protection = vehicle:getPartById(armorPartId);
				if protection and protection:getInventoryItem() and part and part:getModData()
				then
					local partCond = tonumber(part:getModData().saveCond);
					if protection:getCondition() > 0 and partCond and part:getCondition() < partCond
					then
						DAMN.Armor:setPartCondition(part, partCond);
					end
				end
			end

		--

		for i, freezeState in ipairs ({"DAMNSpareTire", "DAMNTrailerJack", "DAMNTrailerAwning", "DAMNPropaneTankOne","DAMNPropaneTankTwo", "Battery"})
				do
					if vehicle:getPartById(freezeState) then
						local part = vehicle:getPartById(freezeState)
						local freezeCond = tonumber(part:getModData().saveCond)
					    	if freezeCond and part:getCondition() < freezeCond then
					    		DAMN.Armor:setPartCondition(part, freezeCond);
							end
					end
			end

        --
end

DAMN.Armor:add("Base.Trailer87Scamp13", KI5CR.activeArmor);
DAMN.Armor:add("Base.Trailer87Scamp16", KI5CR.activeArmor);
DAMN.Armor:add("Base.Trailer61Bambi16", KI5CR.activeArmor);
DAMN.Armor:add("Base.Trailer54FlyingCloud22", KI5CR.activeArmor);