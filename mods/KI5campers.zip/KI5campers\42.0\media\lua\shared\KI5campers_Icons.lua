ContainerButtonIcons = ContainerButtonIcons or {}

local t = {}
t.floor = getTexture("media/textures/Container_KI5CR_floor.png")
t.cabs = getTexture("media/textures/Container_KI5CR_cabs_side.png")
t.cabt = getTexture("media/textures/Container_KI5CR_cabs_top.png")
t.cabb = getTexture("media/textures/Container_KI5CR_cabs_bottom.png")
t.seat = getTexture("media/textures/Item_KI5CR_seat0.png")
t.bed = getTexture("media/textures/Item_KI5CR_bed0.png")
t.toolb = getTexture("media/textures/Container_KI5CR_toolbox.png")

ContainerButtonIcons.KI5CRFloor = t.floor
ContainerButtonIcons.KI5CRCabsSide = t.cabs
ContainerButtonIcons.KI5CRCabsTop = t.cabt
ContainerButtonIcons.KI5CRCabsBottom = t.cabb

ContainerButtonIcons.SeatFrontL = t.seat
ContainerButtonIcons.SeatFrontR = t.seat
ContainerButtonIcons.SeatRearL = t.seat
ContainerButtonIcons.SeatRearR = t.seat

ContainerButtonIcons.DAMNBedOne = t.bed
ContainerButtonIcons.DAMNBedTwo = t.bed

ContainerButtonIcons.KI5CRToolbox = t.toolb