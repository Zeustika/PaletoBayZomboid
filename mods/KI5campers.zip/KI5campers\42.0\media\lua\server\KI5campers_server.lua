require "DAMN_Parts";
require "DAMN_Spawns";

--***********************************************************
--**                   KI5 / bikinihorst                   **
--***********************************************************

DAMN.Parts:processConfigV2("KI5CR", {
    ["BumperRear"] = {
		partId = "DAMNBumperRear",
		itemToModel = {
			["Base.87ScampCamperBumperRear0"] = "BumperRear0",
		},
		default = "trve_random",
		noPartChance = 50,
	},
    ["BumperRearB"] = {
		partId = "DAMNBumperRear",
		itemToModel = {
			["Base.61airstreamCamperBumperRear0"] = "BumperRear0",
		},
		default = "trve_random",
		noPartChance = 50,
	},
    ["BumperRearC"] = {
		partId = "DAMNBumperRear",
		itemToModel = {
			["Base.54airstreamCamperBumperRear0"] = "BumperRear0",
		},
		default = "trve_random",
		noPartChance = 50,
	},
    ["WindshieldArmor"] = {
		partId = "DAMNWindshieldArmor",
		itemToModel = {
            ["Base.KI5CamperWindowArmorLarge0"] = "winda",
		},
	},
	["FrontLeftArmor"] = {
		partId = "DAMNFrontLeftArmor",
		itemToModel = {
            ["Base.KI5CamperWindowArmorSmall0"] = "leftWindowa",
            ["Base.KI5CamperWindowArmorLarge0"] = "leftWindowb",
		},
	},
	["FrontRightArmor"] = {
		partId = "DAMNFrontRightArmor",
		itemToModel = {
            ["Base.KI5CamperWindowArmorSmall0"] = "rightWindowa",
            ["Base.KI5CamperWindowArmorMedium0"] = "rightWindowb",
            ["Base.KI5CamperWindowArmorLarge0"] = "rightWindowc",
		},
	},
    ["MiddleLeftArmor"] = {
		partId = "DAMNMiddleLeftArmor",
		itemToModel = {
            ["Base.KI5CamperWindowArmorMedium0"] = "leftWindowma",
		},
	},
	["RearLeftArmor"] = {
		partId = "DAMNRearLeftArmor",
		itemToModel = {
            ["Base.KI5CamperWindowArmorSmall0"] = "leftWindowra",
            ["Base.KI5CamperWindowArmorLarge0"] = "leftWindowrb",
		},
	},
	["RearRightArmor"] = {
		partId = "DAMNRearRightArmor",
		itemToModel = {
            ["Base.KI5CamperWindowArmorSmall0"] = "rightWindowra",
		},
	},
    ["BackLeftArmor"] = {
		partId = "DAMNBackLeftArmor",
		itemToModel = {
            ["Base.KI5CamperWindowArmorMedium0"] = "leftWindowba",
		},
	},
	["BackRightArmor"] = {
		partId = "DAMNBackRightArmor",
		itemToModel = {
            ["Base.KI5CamperWindowArmorMedium0"] = "rightWindowba",
		},
	},
    ["WindshieldRearArmor"] = {
		partId = "DAMNWindshieldRearArmor",
		itemToModel = {
            ["Base.KI5CamperWindowArmorLarge0"] = "windra",
            ["Base.KI5CamperWindowArmorSmall0"] = "windrb",
		},
	},
    ["PropaneTankOne"] = {
		partId = "DAMNPropaneTankOne",
		itemToModel = {
            ["Base.PropaneTank"] = "prop1",
		},
        default = "trve_random",
		noPartChance = 50,
	},
    ["PropaneTankTwo"] = {
		partId = "DAMNPropaneTankTwo",
		itemToModel = {
            ["Base.PropaneTank"] = "prop2",
		},
        default = "trve_random",
		noPartChance = 50,
	},
    ["SpareTire"] = {
		partId = "DAMNSpareTire",
		itemToModel = {
			["damnCraft.SmallTire1"] = "Spare0",
            ["damnCraft.SmallTire2"] = "Spare1",
		},
		default = "trve_random",
		noPartChance = 33,
	},
	["TireFrontLeft"] = {
		partId = "TireFrontLeft",
		itemToModel = {
			["damnCraft.SmallTire1"] = "Tire0",
            ["damnCraft.SmallTire2"] = "Tire1",
		},
	},
	["TireFrontRight"] = {
		partId = "TireFrontRight",
		itemToModel = {
			["damnCraft.SmallTire1"] = "Tire0",
            ["damnCraft.SmallTire2"] = "Tire1",
		},
	},
	["TireRearLeft"] = {
		partId = "TireRearLeft",
		itemToModel = {
			["damnCraft.SmallTire1"] = "Tire0",
            ["damnCraft.SmallTire2"] = "Tire1",
		},
	},
	["TireRearRight"] = {
		partId = "TireRearRight",
		itemToModel = {
			["damnCraft.SmallTire1"] = "Tire0",
            ["damnCraft.SmallTire2"] = "Tire1",
		},
	},
});

function KI5CR.ContainerAccess.InnerStorage(vehicle, part, chr)
    if chr:getVehicle() == vehicle then
        local seat = vehicle:getSeat(chr)
        return seat > 0;
    elseif chr:getVehicle() then
        return false
    else
        if not vehicle:isInArea(part:getArea(), chr) then return false end
        local doorPart = vehicle:getPartById("DoorFrontRight")
        if doorPart and doorPart:getInventoryItem() then
            if doorPart:getDoor() and not doorPart:getDoor():isOpen() then
                return false
            end
        end return true
    end
end
