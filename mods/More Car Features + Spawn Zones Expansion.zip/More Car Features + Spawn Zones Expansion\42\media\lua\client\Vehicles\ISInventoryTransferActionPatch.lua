--DEPRECIATED: IMPLEMENTED FIX USING isTransferIntoVehicleSeatFromOutside !!!

--Just a general client side patching file now

--STOP TRANSFERING OF CORPSES DIRECTLY INTO INVENTORY
local ISGrabCorpseItemIsValid = ISGrabCorpseItem.isValid
function ISGrabCorpseItem:isValid()
    local isValidOriginal = ISGrabCorpseItemIsValid(self)

	if isValidOriginal and self.character:getVehicle() and self.item and (self.item:getFullType() == "Base.CorpseMale" or self.item:getFullType() == "Base.CorpseFemale") then
		return false
	end

    return isValidOriginal
end

--ALLOWS FOR TAKING CORPSES OUT OF SEATS WITHOUT DOORS BUT ARE OPEN (truck beds with seats)
--YES the same timed action for a completely different purpose
local ISGrabCorpseItemIsValid = ISGrabCorpseItem.isValid
function ISGrabCorpseItem:isValid()
    local isValidOriginal = ISGrabCorpseItemIsValid(self)

	if not isValidOriginal then
		local container = self.item:getContainer()
		local part = container:getVehiclePart()
		if part and container:isVehicleSeat() then
			local vehicle = part:getVehicle()
			if not vehicle:canAccessContainer(part:getIndex(), self.character) then
				if vehicle:getScriptName():contains("PickUpTruck") and part:getContainerSeatNumber() > 1 and Vehicles.ContainerAccess.TruckBedOpen(vehicle, part, self.character) then
					isValidOriginal = true
				end
			end
		end
	end

    return isValidOriginal
end
