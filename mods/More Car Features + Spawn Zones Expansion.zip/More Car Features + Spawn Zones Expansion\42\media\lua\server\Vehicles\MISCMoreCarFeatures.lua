MoreCarFeatures = MoreCarFeatures or {}

function MoreCarFeatures.getVehicleDir(v)
	local y = v:getAngleY()
	if y < 0.00001 and y > 0 then
		y = 0.0001
	elseif y > -0.00001 and y < 0 then
		y = -0.0001
	end
	local angle = y - 90
	if math.abs(v:getAngleZ()) > 90 then  angle = 90 - y end
	return -angle*(math.pi/180)
end

local activatedMods = getActivatedMods()

--local vehicle = getPlayer():getNearVehicle() for partIndex=1,vehicle:getPartCount() do local part = vehicle:getPartByIndex(partIndex-1); print(part:getId()) end

if not isServer() then
	--Manages which vehicles can be entered/exited through the trunk by seeing if the code runs for it from the script
	MoreCarFeatures.canEnterExitVehicleTrunk = {}
	local VehiclesContainerAccessTruckBedOpenInside = Vehicles.ContainerAccess.TruckBedOpenInside
	function Vehicles.ContainerAccess.TruckBedOpenInside(vehicle, part, chr)
		local fullVName = vehicle:getScript():getFullName()
		if not MoreCarFeatures.canEnterExitVehicleTrunk[fullVName] then
			MoreCarFeatures.canEnterExitVehicleTrunk[fullVName] = true
		end

		return VehiclesContainerAccessTruckBedOpenInside(vehicle, part, chr)
	end

	MoreCarFeatures.canEnterExitVehicleTrunkKI51 = {}
	MoreCarFeatures.canEnterExitVehicleTrunkKI52 = {}
	MoreCarFeatures.canEnterExitVehicleTrunkKI53 = {}
	local function onInitGlobalModData()	--KI5 Versions / DAMNLIB
		if activatedMods:contains("damnlib") then	--3171167894
			local DAMNContainerAccessTrunkInner = DAMN.ContainerAccess.TrunkInner
			function DAMN.ContainerAccess.TrunkInner(vehicle, part, chr)
				local fullVName = vehicle:getScript():getFullName()
				if not MoreCarFeatures.canEnterExitVehicleTrunkKI51[fullVName] then
					MoreCarFeatures.canEnterExitVehicleTrunkKI51[fullVName] = true
				end

				return DAMNContainerAccessTrunkInner(vehicle, part, chr)
			end

			local DAMNContainerAccessTrunkSecondRow = DAMN.ContainerAccess.TrunkSecondRow
			function DAMN.ContainerAccess.TrunkSecondRow(vehicle, part, chr)
				local fullVName = vehicle:getScript():getFullName()
				if not MoreCarFeatures.canEnterExitVehicleTrunkKI52[fullVName] then
					MoreCarFeatures.canEnterExitVehicleTrunkKI52[fullVName] = true
				end

				return DAMNContainerAccessTrunkSecondRow(vehicle, part, chr)
			end

			local DAMNContainerAccessTrunkThirdRow = DAMN.ContainerAccess.TrunkThirdRow
			function DAMN.ContainerAccess.TrunkThirdRow(vehicle, part, chr)
				local fullVName = vehicle:getScript():getFullName()
				if not MoreCarFeatures.canEnterExitVehicleTrunkKI53[fullVName] then
					MoreCarFeatures.canEnterExitVehicleTrunkKI53[fullVName] = true
				end

				return DAMNContainerAccessTrunkThirdRow(vehicle, part, chr)
			end
		end
	end
	Events.OnInitGlobalModData.Add(onInitGlobalModData)

end


--Jackie Jaye's Van
if not isServer() then ISCarMechanicsOverlay.CarList["Base.VanRadioJJ"] = {imgPrefix="van_", x=10, y=0} end	--mechanics / car seat UI

VehicleDistributions[1]["VanRadioJJ"] = { Normal = VehicleDistributions.Radio }								--item distribution list, for containers

if not isClient() and not (activatedMods:contains("NoVanillaVehicles") or activatedMods:contains("VVR")) then
	Events.OnInitGlobalModData.Add(function()
		if not ModData.getOrCreate("MCF_UniqueVehiclesSpawned")["Base.VanRadioJJ"] then
			local function addJJVanAndTrailer(chunk)
				if chunk and chunk:containsPoint(12488, 3904) then
					if chunk:isNewChunk() then	--new chunk is a seperate if then statement to handle mid save adding of the mod, if the area isn't new, pretend like the vehicle was created (unfortunately)
						local jjvan = addVehicleDebug("Base.VanRadioJJ", IsoDirections.S, -1, chunk:getGridSquare(2, 6, 0))
						local jjtrailer = addVehicleDebug("Base.TrailerAdvert", IsoDirections.S, 3, chunk:getGridSquare(2, 1, 0))
						jjvan:addKeyToGloveBox()
						jjvan:setLocked(false)
						jjvan:addPointConstraint(nil, jjtrailer, "trailer", "trailer")
					end
					ModData.getOrCreate("MCF_UniqueVehiclesSpawned")["Base.VanRadioJJ"] = true	
					Events.LoadChunk.Remove(addJJVanAndTrailer)
				end
			end
			Events.LoadChunk.Add(addJJVanAndTrailer)
		end
	end)
end


if not isClient() then
	--Based on Copy Building Key crafting recipe
	function RecipeCodeOnCreate.copyVehicleKey(CraftRecipeData, playerObj)
		local item = CraftRecipeData:getViableItem(0)
	--	local cloneItem = item:createCloneItem()		--Doesn't work in MP or outside of debug? (returns nil)
		local cloneItem = instanceItem(item:getScriptItem():getFullName())
		cloneItem:setKeyId(item:getKeyId())
	--	cloneItem:setName(item:getName())				--Client side only
		playerObj:getInventory():addItem(cloneItem)
		sendAddItemToContainer(playerObj:getInventory(), cloneItem)
	end

	function RecipeCodeOnCreate.CraftTireStack(CraftRecipeData, playerObj)	--Unused
		local tires = CraftRecipeData:getAllInputItems()
		local totalTires = tires:size()
		local tireStack

		if totalTires == 1 then
			tireStack = "_48"
		elseif totalTires == 2 then
			tireStack = "_50"
		elseif totalTires == 3 then
			tireStack = "_51"
		elseif totalTires == 4 then
			tireStack = "_52"
		end
		tireStack = instanceItem("Moveables.location_business_machinery_01"..tireStack)

		local tireToMD = {}
		for i=0, totalTires-1 do
			local tire = tires:get(i)
			local tireToVar = {tire:getScriptItem():getFullName(), tire:getCondition(), math.max(tire:getItemCapacity(), 0), tire:getMaxCapacity()}
			table.insert(tireToMD, tireToVar)
		end
		tireStack:getModData().TireStackContents = tireToMD
		--tireStack:transmitModData()	Transmit not needed if item not added yet, also it errors

		local charInv = playerObj:getInventory()
		charInv:AddItem(tireStack)
		sendAddItemToContainer(charInv, tireStack)
	end

	function RecipeCodeOnCreate.smeltIronOrSteelLargePlus(CraftRecipeData, playerObj)	--add 0.25
		local inputCrucible = CraftRecipeData:getViableItem(0)
		local outputCrucible = CraftRecipeData:getFirstCreatedItem()
		local finalUses = 0.25
		if inputCrucible:getScriptItem():getName():contains("Steel") then
			finalUses = finalUses + inputCrucible:getCurrentUsesFloat()
		end
		outputCrucible:setCurrentUsesFloat(finalUses)
		outputCrucible:syncItemFields()
	end
	--(normal large adds 0.2, medium plus 0.15, medium 0.1, and I'll just assume what small does)
	function RecipeCodeOnCreate.smeltIronOrSteelVeryLarge(CraftRecipeData, playerObj)	--add 0.3
		local inputCrucible = CraftRecipeData:getViableItem(0)
		local outputCrucible = CraftRecipeData:getFirstCreatedItem()
		local finalUses = 0.3
		if inputCrucible:getScriptItem():getName():contains("Steel") then
			finalUses = finalUses + inputCrucible:getCurrentUsesFloat()
		end
		outputCrucible:setCurrentUsesFloat(finalUses)
		outputCrucible:syncItemFields()
	end
end


--Pick Up Trucks with seats in the truck bed
if not isServer() then
	--Entering pickup truck bed seat animation override
	local ISPathFindActionPathToVehicleSeat = ISPathFindAction.pathToVehicleSeat
	function ISPathFindAction:pathToVehicleSeat(character, vehicle, seat)
		local o = ISPathFindActionPathToVehicleSeat(self, character, vehicle, seat)

		if vehicle and vehicle:getScriptName():contains("PickUpTruck") and seat and seat > 1 then
			local areaId = vehicle:getPassengerArea(seat)
			local part
			if areaId:contains("Left") then
				part = vehicle:getPartById("TireRearLeft")
			elseif areaId:contains("Right") then
				part = vehicle:getPartById("TireRearRight")
			end
			if part then
				o.ignoreAction = true
				ISTimedActionQueue.add(ISPathFindAction:pathToVehicleArea(character, vehicle, part:getArea()))
			end
		end

		return o
	end

	local ISEnterVehicleWaitToStart = ISEnterVehicle.waitToStart
	function ISEnterVehicle:waitToStart()
		if self.enteringTruckBed then
			self.character:faceThisObject(self.vehicle)
			return self.character:shouldBeTurning()
		end

		return ISEnterVehicleWaitToStart(self)
	end

	local ISEnterVehicleStart = ISEnterVehicle.start
	function ISEnterVehicle:start()
		ISEnterVehicleStart(self)

		if self.enteringTruckBed then
			local areaId = self.vehicle:getPassengerArea(self.seat)
			local part
			if areaId:contains("Left") then
				part = self.vehicle:getPartById("TireRearLeft")
				self.character:SetVariable("TruckBedSeat_ChevalierD6_PickUp_Left", "true")
			elseif areaId:contains("Right") then
				part = self.vehicle:getPartById("TireRearRight")
				self.character:SetVariable("TruckBedSeat_ChevalierD6_PickUp_Right", "true")
			else
				self.enteringTruckBed = false
				return
			end

			self.started = false
			self.character:ClearVariable("bEnteringVehicle")
			self.vehicle:exit(self.character)

			local shouldBeAt = self.vehicle:getAreaCenter(part:getArea())
			local setTicks = 3
			local function spamSetPos()	--For MP mostly
				setTicks = setTicks - 1
				self.character:setX(shouldBeAt:getX())
				self.character:setY(shouldBeAt:getY())
				if setTicks > 0 then return end
				Events.OnTick.Remove(spamSetPos)
			end
			Events.OnTick.Add(spamSetPos)
		end
	end

	local ISEnterVehicleUpdate = ISEnterVehicle.update
	function ISEnterVehicle:update()
		if self.enteringTruckBed then
			if self.character:GetVariable("EnterAnimationFinished") == "true" then
				self.character:ClearVariable("TruckBedSeat_ChevalierD6_PickUp_Left")
				self.character:ClearVariable("TruckBedSeat_ChevalierD6_PickUp_Right")
				self.vehicle:enter(self.seat, self.character)
				self.started = true
			end
		end

		ISEnterVehicleUpdate(self)
	end

	local ISEnterVehicleStop = ISEnterVehicle.stop
	function ISEnterVehicle:stop()
		if self.enteringTruckBed then
			self.character:ClearVariable("TruckBedSeat_ChevalierD6_PickUp_Left")
			self.character:ClearVariable("TruckBedSeat_ChevalierD6_PickUp_Right")
			self.character:ClearVariable("EnterAnimationFinished")
		end

		ISEnterVehicleStop(self)
	end

	local ISEnterVehicleNew = ISEnterVehicle.new
	function ISEnterVehicle:new(character, vehicle, seat)
		local o = ISEnterVehicleNew(self, character, vehicle, seat)
		o.enteringTruckBed = vehicle:getScriptName():contains("PickUpTruck") and seat > 1
		return o
	end
end

function Vehicles.ContainerAccess.TruckBedOpenOutside(vehicle, part, chr)
	local inVehicle = chr:getVehicle()
	if inVehicle then
		if inVehicle == vehicle then
			return not vehicle:getPassengerArea(vehicle:getSeat(chr)):contains("SeatFront")
		end
		return false
	end
	return vehicle:isInArea(part:getArea(), chr)
end

--Doesn't work as expected unfortunately... (outdated numberes, recheck in my script files)
--local function addBackSeatsToPickUpTrucks()
--	local vehicleScripts = getScriptManager():getAllVehicleScripts()
--	for i = 0, vehicleScripts:size() - 1 do
--		local vehicleScript = vehicleScripts:get(i)
--		if vehicleScript then
--			local vsName = vehicleScript:getName()
--			if vsName == "PickUpTruck" or vsName == "PickUpTruck_Camo" or vsName == "PickUpTruckLightsFire" or vsName == "PickUpTruckLightsRanger" or vsName == "PickUpTruckLightsAirportSecurity" or vsName == "PickUpTruckMccoy" or vsName == "PickUpTruckLightsAirport" or vsName == "PickUpTruckJPLandscaping" or vsName == "PickUpTruckLightsFossoil" then
--				vehicleScript:Load(vsName, [[{template! = PickUpTruckMCF,}]])
--				vehicleScript:Load(vsName, [[{template = PassengerSeat6,}]])
--				vehicleScript:Load(vsName,
--				[[{
--					passenger FrontLeft
--					{
--						switchSeat RearLeft { }
--						switchSeat RearRight { }
--						switchSeat MiddleLeft { }
--						switchSeat MiddleRight { }
--					}
--				}]])
--				vehicleScript:Load(vsName,
--				[[{
--					passenger FrontRight
--					{
--						switchSeat RearLeft { }
--						switchSeat RearRight { }
--						switchSeat MiddleLeft { }
--						switchSeat MiddleRight { }
--					}
--				}]])
--				vehicleScript:Load(vsName,
--				[[{
--					passenger RearLeft
--					{ 
--						position inside
--						{
--							offset = 0.1758 -0.0549 -0.9341,
--							rotate = 0.0000 0.0000 0.0000,
--						}
--						position outside
--						{
--							offset = 0.5934 -0.4670 0.1813,
--							rotate = 0.0000 0.0000 0.0000,
--							area = SeatRearLeft,
--						}
--						switchSeat FrontLeft { }
--						switchSeat FrontRight { }
--					}
--				}]])
--				vehicleScript:Load(vsName,
--				[[{
--					passenger RearRight
--					{
--						position inside
--						{
--							offset = -0.1758 -0.0549 -0.9341,
--							rotate = 0.0000 0.0000 0.0000,
--						}
--						position outside
--						{
--							offset = -0.5934 -0.4670 0.1813,
--							rotate = 0.0000 0.0000 0.0000,
--							area = SeatRearRight,
--						}
--						switchSeat FrontLeft { }
--						switchSeat FrontRight { }
--					}
--				}]])
--				vehicleScript:Load(vsName,
--				[[{
--					passenger MiddleLeft
--					{
--						position inside
--						{
--							offset = 0.1758 -0.0549 -0.4396,
--							rotate = 0.0000 0.0000 0.0000,
--						}
--						position outside
--						{
--							offset = 0.5934 -0.4670 0.1813,
--							rotate = 0.0000 0.0000 0.0000,
--							area = SeatMiddleLeft,
--						}
--						switchSeat FrontLeft { }
--						switchSeat FrontRight { }
--					}
--				}]])
--				vehicleScript:Load(vsName,
--				[[{
--					passenger MiddleRight
--					{
--						position inside
--						{
--							offset = -0.1758 -0.0549 -0.4398,
--							rotate = 0.0000 0.0000 0.0000,
--						}
--						position outside
--						{
--							offset = -0.5934 -0.4670 0.1813,
--							rotate = 0.0000 0.0000 0.0000,
--							area = SeatMiddleRight,
--						}
--						switchSeat FrontLeft { }
--						switchSeat FrontRight { }
--					}
--				}]])
--				vehicleScript:Load(vsName, [[{ area SeatRearLeft { xywh = 0.6703 -0.7527 0.4725 0.4725, } }]])
--				vehicleScript:Load(vsName, [[{ area SeatRearRight { xywh = -0.6703 -0.7527 0.4725 0.4725, } }]])
--				vehicleScript:Load(vsName, [[{ area SeatMiddleLeft { xywh = 0.6703 -0.2802 0.4725 0.4725, } }]])
--				vehicleScript:Load(vsName, [[{ area SeatMiddleRight { xywh = -0.6703 -0.2802 0.4725 0.4725, } }]])
--			--	vehicleScript:Load(vsName,
--			--	[[{
--			--	}]])
--			end
--		end
--	end
--end
--Events.OnInitGlobalModData.Add(addBackSeatsToPickUpTrucks)


--Requires either a function overwrite or scripting a new trunk part, which I'm not doing. I just edited the advert trailer script itself and added it in there.
--local function addAdvertStorage()
--	local vehicleScripts = getScriptManager():getAllVehicleScripts()
--	for i = 0, vehicleScripts:size() - 1 do
--		local vehicleScript = vehicleScripts:get(i)
--		if vehicleScript then
--			local vsName = vehicleScript:getName()
--			if vsName == "TrailerAdvert" then
--			--	vehicleScript:Load(vsName, [[{***NAME OF VALUE TO CHANGE/ADD*** = ]] .. ***NEW VALUE*** .. [[,}]])
--				vehicleScript:Load(vsName, [[{area TruckBed { xywh = 0.0 0.0 0.9 6.0, } }]])
--				vehicleScript:Load(vsName, [[{template = Trunk/part/TrailerTrunk,}]])
--				break
--			end
--		end
--	end
--end
--Events.OnInitGlobalModData.Add(addAdvertStorage)

--cd "C:\Program Files (x86)\Steam\steamapps\common\ProjectZomboid"
--start ProjectZomboid64.exe -nosteam -debug