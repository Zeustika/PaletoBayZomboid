NewVZones = NewVZones or {}

local function GamestaChangeVZones()
	local activatedMods = getActivatedMods()
	local ChangeVehicleZone = NewVZones.changeVZone
--test
	--ChangeVehicleZone(17106, 526, "nil")

--Vanilla Random Bug Fix
	--ChangeVehicleZone(988, 6900, "nil") FIXED IN B42.20 STABLE RELEASE

--Zone Changes
	if SandboxVars.GamestaVehicleZones.trafficjamsExtra then		--rewritten major vanilla traffic jams
		ChangeVehicleZone(10594, 10568, "nullified_trafficjam")
		ChangeVehicleZone(10594, 10612, "nullified_trafficjam")
		ChangeVehicleZone(10594, 10629, "nullified_trafficjam")
		ChangeVehicleZone(10593, 10676, "nullified_trafficjam")
		ChangeVehicleZone(10600, 10671, "nullified_trafficjam")
		ChangeVehicleZone(10606, 10606, "nullified_trafficjam")
		ChangeVehicleZone(10624, 10601, "nullified_trafficjam")
		ChangeVehicleZone(10627, 10616, "nullified_trafficjam")
		ChangeVehicleZone(10647, 10613, "nullified_trafficjam")
		ChangeVehicleZone(10649, 10660, "nullified_trafficjam")

		ChangeVehicleZone(10585, 11120, "nullified_trafficjam")
		ChangeVehicleZone(10593, 11132, "nullified_trafficjam")
		ChangeVehicleZone(10585, 11203, "nullified_trafficjam")
		ChangeVehicleZone(10599, 11198, "nullified_trafficjam")
		ChangeVehicleZone(10570, 11198, "nullified_trafficjam")
		ChangeVehicleZone(10555, 11205, "nullified_trafficjam")

		ChangeVehicleZone(11265, 8757, "rtrafficjamw")
		ChangeVehicleZone(11246, 8765, "rtrafficjame")
		ChangeVehicleZone(11637, 8658, "rtrafficjams")
		ChangeVehicleZone(11645, 8637, "rtrafficjamn")

		ChangeVehicleZone(517, 9893, "rtrafficjame")
		ChangeVehicleZone(552, 9893, "trafficjamw")
		ChangeVehicleZone(573, 9891, "rtrafficjamw")
	end

--Army to Military
	if not activatedMods:contains("VMZNEW") then
		local hasMilitaryVehicles = false
		for doesntmatter, whocares in pairs(VehicleZoneDistribution.military.vehicles) do
			ChangeVehicleZone(12539, 4208, "military")
			ChangeVehicleZone(12542, 4221, "military")
			ChangeVehicleZone(12495, 4257, "military")
			ChangeVehicleZone(12580, 4332, "military")

			ChangeVehicleZone(13428, 3782, "military_vehicles")

			ChangeVehicleZone(14530, 3773, "military_vehicles")

			ChangeVehicleZone(967, 11503, "nil")
			ChangeVehicleZone(971, 11503, "nil")
			ChangeVehicleZone(979, 11503, "nil")
			ChangeVehicleZone(983, 11503, "nil")
			ChangeVehicleZone(963, 11503, "military_vehicles", 12, nil, 962, nil)
			ChangeVehicleZone(975, 11503, "military", 9, nil, 976, nil)

			ChangeVehicleZone(2579, 10912, "military_vehicles")
			ChangeVehicleZone(2585, 10917, "military_vehicles")
			ChangeVehicleZone(2591, 10917, "military_vehicles")
			ChangeVehicleZone(2596, 10912, "military_vehicles")

			hasMilitaryVehicles = true
			break
		end
		if not hasMilitaryVehicles then
			ChangeVehicleZone(967, 11503, "nil")
			ChangeVehicleZone(971, 11503, "nil")
			ChangeVehicleZone(979, 11503, "nil")
			ChangeVehicleZone(983, 11503, "nil")
			ChangeVehicleZone(963, 11503, "police", 12, nil, 962, nil)
			ChangeVehicleZone(975, 11503, "ranger", 9, nil, 976, nil)

			ChangeVehicleZone(2579, 10912, "police")
			ChangeVehicleZone(2585, 10917, "police")
			ChangeVehicleZone(2591, 10917, "police")
			ChangeVehicleZone(2596, 10912, "police")
		end
	end

--West Point
	--Parallel Parking
	ChangeVehicleZone(11861, 6892, "parallelstall")
	ChangeVehicleZone(11868, 6892, "parallelstall")
	ChangeVehicleZone(11874, 6892, "parallelstall")
	ChangeVehicleZone(11879, 6892, "parallelstall")
	ChangeVehicleZone(11885, 6892, "parallelstall")
	ChangeVehicleZone(11891, 6892, "parallelstall")
	ChangeVehicleZone(11897, 6892, "parallelstall")

	ChangeVehicleZone(11861, 6905, "parallelstall")
	ChangeVehicleZone(11868, 6905, "parallelstall")
	ChangeVehicleZone(11874, 6905, "parallelstall")
	ChangeVehicleZone(11880, 6905, "parallelstall")
	ChangeVehicleZone(11886, 6905, "parallelstall")
	ChangeVehicleZone(11892, 6905, "parallelstall")
	ChangeVehicleZone(11898, 6905, "parallelstall")
	--END

	--School Parkinglot
	--ChangeVehicleZone(11384, 6766, "parkingstall")
	--ChangeVehicleZone(11384, 6769, "parkingstall")
	--ChangeVehicleZone(11384, 6772, "parkingstall")
	--ChangeVehicleZone(11384, 6775, "parkingstall")
	--ChangeVehicleZone(11384, 6778, "parkingstall")
	--ChangeVehicleZone(11384, 6781, "parkingstall")
	--ChangeVehicleZone(11384, 6784, "parkingstall")

	ChangeVehicleZone(11364, 6808, "parkingstall")
	ChangeVehicleZone(11364, 6811, "parkingstall")
	ChangeVehicleZone(11364, 6814, "parkingstall")
	ChangeVehicleZone(11364, 6817, "parkingstall")
	ChangeVehicleZone(11364, 6820, "parkingstall")
	ChangeVehicleZone(11364, 6823, "medium")
	ChangeVehicleZone(11364, 6826, "medium")
	ChangeVehicleZone(11364, 6829, "medium")
	ChangeVehicleZone(11364, 6832, "medium")

	ChangeVehicleZone(11374, 6814, "parkingstall")
	ChangeVehicleZone(11374, 6817, "parkingstall")
	ChangeVehicleZone(11374, 6820, "parkingstall")
	ChangeVehicleZone(11374, 6823, "parkingstall")
	ChangeVehicleZone(11374, 6826, "medium")
	ChangeVehicleZone(11374, 6829, "medium")
	ChangeVehicleZone(11374, 6832, "medium")

	ChangeVehicleZone(11379, 6814, "parkingstall")
	ChangeVehicleZone(11379, 6817, "parkingstall")
	ChangeVehicleZone(11379, 6820, "parkingstall")
	ChangeVehicleZone(11379, 6823, "parkingstall")
	ChangeVehicleZone(11379, 6826, "bad")
	ChangeVehicleZone(11379, 6829, "bad")
	ChangeVehicleZone(11379, 6832, "bad")

	ChangeVehicleZone(11389, 6817, "bad")
	ChangeVehicleZone(11389, 6820, "bad")
	ChangeVehicleZone(11389, 6823, "bad")
	ChangeVehicleZone(11389, 6826, "bad")
	ChangeVehicleZone(11389, 6829, "bad")
	ChangeVehicleZone(11389, 6832, "bad")
	--END

	ChangeVehicleZone(11099, 6686, "parkingstall", nil, 9, nil, 6680)
	ChangeVehicleZone(11099, 6695, "parkingstall", nil, 6)
	ChangeVehicleZone(11099, 6701, "parkingstall", nil, 6)
	ChangeVehicleZone(11099, 6707, "police", nil, 6)

	ChangeVehicleZone(11260, 6618, "medium")
	ChangeVehicleZone(11276, 6618, "medium")

	ChangeVehicleZone(11615, 6635, "bad")
	ChangeVehicleZone(11610, 6635, "bad")
	ChangeVehicleZone(11604, 6636, "bad")

	ChangeVehicleZone(11341, 6724, "parallelstall")
	ChangeVehicleZone(11343, 6736, "parkingstall")
	ChangeVehicleZone(11346, 6736, "parkingstall")
	ChangeVehicleZone(11349, 6736, "parkingstall")
	ChangeVehicleZone(11352, 6736, "parkingstall")
	ChangeVehicleZone(11355, 6736, "parkingstall")
	ChangeVehicleZone(11358, 6736, "parkingstall")
	ChangeVehicleZone(11361, 6736, "parkingstall")

	ChangeVehicleZone(11663, 7021, "parallelstall")
	ChangeVehicleZone(11670, 7021, "parallelstall")

	ChangeVehicleZone(11686, 7054, "parallelstall")
	ChangeVehicleZone(11686, 7057, "parallelstall")
	ChangeVehicleZone(11686, 7060, "parallelstall")
	ChangeVehicleZone(11686, 7063, "parallelstall")
	ChangeVehicleZone(11686, 7066, "parallelstall")
	ChangeVehicleZone(11686, 7069, "parallelstall")
	ChangeVehicleZone(11686, 7072, "parallelstall")
	ChangeVehicleZone(11686, 7075, "parallelstall")
	ChangeVehicleZone(11686, 7078, "parallelstall")
	ChangeVehicleZone(11686, 7081, "parallelstall")
	ChangeVehicleZone(11686, 7084, "parallelstall")
	ChangeVehicleZone(11686, 7087, "parallelstall")
	ChangeVehicleZone(11686, 7090, "parallelstall")
	ChangeVehicleZone(11686, 7093, "parallelstall", nil, 12, nil, 7111)

	ChangeVehicleZone(11743, 6943, "parallelstall", nil, 6, 11743, 6940)
	ChangeVehicleZone(11757, 6958, "parallelstall", nil, 6, 11757, 6955)

	ChangeVehicleZone(11780, 6800, "police")
	ChangeVehicleZone(11780, 6803, "police")
	ChangeVehicleZone(11780, 6809, "police")
	ChangeVehicleZone(11798, 6784, "prison")
	ChangeVehicleZone(11801, 6784, "prison")
	ChangeVehicleZone(11804, 6784, "prison")
	ChangeVehicleZone(11807, 6784, "prison")
	ChangeVehicleZone(11810, 6784, "prison")
	ChangeVehicleZone(11804, 6794, "prison")
	ChangeVehicleZone(11807, 6794, "prison")
	ChangeVehicleZone(11810, 6794, "prison")

	ChangeVehicleZone(11828, 6878, "nullified_gasstation")
	ChangeVehicleZone(11824, 6882, "nullified_gasstation")

	ChangeVehicleZone(11862, 6628, "medium", 6, nil, 11856, 6627)
	ChangeVehicleZone(11859, 6628, "bad", 6, nil)
	ChangeVehicleZone(11840, 6627, "bad", 6, nil, 11841, nil)
	ChangeVehicleZone(11837, 6627, "bad", nil, nil, nil, 6628)

	ChangeVehicleZone(11903, 6792, "bad")
	ChangeVehicleZone(11906, 6792, "bad")
	ChangeVehicleZone(11909, 6792, "bad")
	ChangeVehicleZone(11912, 6792, "bad")
	ChangeVehicleZone(11896, 6814, "bad")

	ChangeVehicleZone(11854, 6945, "bad")
	ChangeVehicleZone(11857, 6945, "bad")
	ChangeVehicleZone(11860, 6945, "bad")
	ChangeVehicleZone(11863, 6945, "bad")
	ChangeVehicleZone(11866, 6945, "bad")
	ChangeVehicleZone(11869, 6945, "bad")

	ChangeVehicleZone(11968, 6779, "spiffo")
	ChangeVehicleZone(11971, 6779, "spiffo")
	ChangeVehicleZone(11956, 6798, "spiffo")

	ChangeVehicleZone(11966, 6938, "parallelstall")
	ChangeVehicleZone(11966, 6943, "parallelstall")
	ChangeVehicleZone(11966, 6948, "parallelstall")

	ChangeVehicleZone(11953, 6996, "good")
	ChangeVehicleZone(11953, 6999, "good")
	ChangeVehicleZone(11953, 7002, "good")
	ChangeVehicleZone(11953, 7005, "good")
	ChangeVehicleZone(11953, 7008, "good")

	ChangeVehicleZone(11935, 6996, "medium")
	ChangeVehicleZone(11935, 6999, "medium")
	ChangeVehicleZone(11935, 7002, "medium")
	ChangeVehicleZone(11935, 7005, "medium")
	ChangeVehicleZone(11935, 7008, "medium")
	ChangeVehicleZone(11935, 7011, "medium")
	ChangeVehicleZone(11935, 7014, "medium", nil, 9)

	ChangeVehicleZone(11935, 7024, "nil")
	ChangeVehicleZone(11938, 7024, "nil")
	ChangeVehicleZone(11941, 7024, "bad")
	ChangeVehicleZone(11944, 7024, "bad")
	ChangeVehicleZone(11947, 7024, "bad")
	ChangeVehicleZone(11950, 7024, "bad")
	ChangeVehicleZone(11953, 7024, "bad")
	ChangeVehicleZone(11956, 7024, "bad")
	ChangeVehicleZone(11959, 7024, "bad")
	ChangeVehicleZone(11962, 7024, "bad")
	ChangeVehicleZone(11965, 7024, "bad")
	ChangeVehicleZone(11968, 7024, "bad")
	ChangeVehicleZone(11971, 7024, "bad")
	ChangeVehicleZone(11974, 7024, "bad")
	ChangeVehicleZone(11977, 7024, "bad")
	ChangeVehicleZone(11980, 7024, "bad")

	ChangeVehicleZone(12044, 6824, "bad")
	ChangeVehicleZone(12047, 6824, "bad")
	ChangeVehicleZone(12050, 6824, "bad")
	ChangeVehicleZone(12053, 6824, "bad")
	ChangeVehicleZone(12056, 6824, "bad")
	ChangeVehicleZone(12074, 6824, "parallelstall")
	ChangeVehicleZone(12077, 6824, "parallelstall")
	ChangeVehicleZone(12080, 6824, "parallelstall")

	ChangeVehicleZone(12079, 6844, "bad")
	ChangeVehicleZone(12079, 6847, "bad")
	ChangeVehicleZone(12079, 6850, "bad")
	ChangeVehicleZone(12079, 6853, "bad")
	ChangeVehicleZone(12079, 6856, "bad")
	ChangeVehicleZone(12079, 6859, "bad")
	ChangeVehicleZone(12079, 6862, "bad")
	ChangeVehicleZone(12079, 6865, "bad")
	ChangeVehicleZone(12079, 6868, "bad")
	ChangeVehicleZone(12079, 6871, "bad")
	ChangeVehicleZone(12079, 6874, "bad")
	ChangeVehicleZone(12079, 6877, "bad")
	ChangeVehicleZone(12079, 6880, "bad")
	ChangeVehicleZone(12079, 6883, "bad")

	ChangeVehicleZone(12023, 6947, "bad")
	ChangeVehicleZone(12026, 6947, "bad")
	ChangeVehicleZone(12029, 6947, "bad")
	ChangeVehicleZone(12032, 6947, "bad")
	ChangeVehicleZone(12035, 6947, "bad")
	ChangeVehicleZone(12038, 6947, "bad")
	ChangeVehicleZone(12041, 6947, "bad")
	ChangeVehicleZone(12044, 6947, "bad")
	ChangeVehicleZone(12047, 6947, "bad")
	ChangeVehicleZone(12050, 6947, "bad")

	ChangeVehicleZone(12115, 6793, "bad")
	ChangeVehicleZone(12115, 6796, "bad")
	ChangeVehicleZone(12115, 6799, "bad")
	ChangeVehicleZone(12115, 6802, "bad")
	ChangeVehicleZone(12115, 6805, "bad")
	ChangeVehicleZone(12115, 6808, "bad")
	ChangeVehicleZone(12115, 6811, "bad")
	ChangeVehicleZone(12115, 6814, "bad")

	ChangeVehicleZone(12147, 6807, "parallelstall")

	ChangeVehicleZone(12113, 6838, "parallelstall")

	ChangeVehicleZone(12131, 6913, "bad")
	ChangeVehicleZone(12134, 6913, "bad")
	ChangeVehicleZone(12137, 6913, "bad")
	ChangeVehicleZone(12140, 6913, "bad")
	ChangeVehicleZone(12143, 6913, "bad")
	ChangeVehicleZone(12146, 6913, "bad")

	ChangeVehicleZone(12131, 6928, "bad")
	ChangeVehicleZone(12134, 6928, "bad")
	ChangeVehicleZone(12137, 6928, "bad")
	ChangeVehicleZone(12140, 6928, "bad")
	ChangeVehicleZone(12143, 6928, "bad")
	ChangeVehicleZone(12146, 6928, "bad")

	ChangeVehicleZone(12131, 6935, "medium")
	ChangeVehicleZone(12134, 6935, "medium")
	ChangeVehicleZone(12137, 6935, "medium")
	ChangeVehicleZone(12140, 6935, "medium")
	ChangeVehicleZone(12143, 6935, "medium")
	ChangeVehicleZone(12146, 6935, "medium")

	ChangeVehicleZone(12131, 6950, "medium")
	ChangeVehicleZone(12134, 6950, "medium")
	ChangeVehicleZone(12137, 6950, "medium")
	ChangeVehicleZone(12140, 6950, "medium")
	ChangeVehicleZone(12143, 6950, "medium")
	ChangeVehicleZone(12146, 6950, "medium")

	ChangeVehicleZone(12117, 7029, "parallelstall")

	ChangeVehicleZone(12133, 7143, "bad")
	ChangeVehicleZone(12136, 7143, "bad")
	ChangeVehicleZone(12139, 7143, "bad")
	ChangeVehicleZone(12142, 7143, "bad")
	ChangeVehicleZone(12145, 7143, "bad")
	ChangeVehicleZone(12148, 7143, "bad")
	ChangeVehicleZone(12151, 7143, "bad")
	ChangeVehicleZone(12154, 7143, "bad")
	ChangeVehicleZone(12157, 7143, "bad")
	ChangeVehicleZone(12160, 7143, "bad")

	ChangeVehicleZone(12142, 7132, "bad")
	ChangeVehicleZone(12145, 7132, "bad")
	ChangeVehicleZone(12148, 7132, "bad")
	ChangeVehicleZone(12151, 7132, "bad")
	ChangeVehicleZone(12154, 7132, "bad")

	ChangeVehicleZone(12142, 7127, "bad")
	ChangeVehicleZone(12145, 7127, "bad")
	ChangeVehicleZone(12148, 7127, "bad")
	ChangeVehicleZone(12151, 7127, "bad")
	ChangeVehicleZone(12154, 7127, "bad")

	ChangeVehicleZone(12142, 7116, "medium")
	ChangeVehicleZone(12145, 7116, "medium")
	ChangeVehicleZone(12148, 7116, "medium")
	ChangeVehicleZone(12151, 7116, "medium")
	ChangeVehicleZone(12154, 7116, "medium")
	ChangeVehicleZone(12157, 7116, "medium")
	ChangeVehicleZone(12160, 7116, "medium")

	ChangeVehicleZone(12048, 7129, "fossoil")
	ChangeVehicleZone(12051, 7129, "fossoil")
	ChangeVehicleZone(12054, 7129, "fossoil")

	ChangeVehicleZone(12009, 7135, "nil")
	ChangeVehicleZone(12037, 7121, "nil")
	ChangeVehicleZone(12037, 7148, "nil")
	ChangeVehicleZone(12039, 7157, "nil")

	ChangeVehicleZone(12264, 6983, "bad")
	ChangeVehicleZone(12267, 6983, "bad")
	ChangeVehicleZone(12270, 6983, "bad")
	ChangeVehicleZone(12273, 6983, "bad")
	ChangeVehicleZone(12276, 6983, "bad")
	ChangeVehicleZone(12279, 6983, "bad")
	ChangeVehicleZone(12282, 6983, "bad")
	ChangeVehicleZone(12285, 6983, "bad")
	ChangeVehicleZone(12288, 6983, "medium", nil, 5)
	ChangeVehicleZone(12291, 6983, "medium")
	ChangeVehicleZone(12294, 6983, "medium")
	ChangeVehicleZone(12297, 6983, "medium", 3, nil)

	ChangeVehicleZone(12045, 7390, "medium")
	ChangeVehicleZone(12048, 7390, "medium")
	ChangeVehicleZone(12054, 7390, "medium")
	ChangeVehicleZone(12064, 7390, "medium")
	ChangeVehicleZone(12067, 7390, "medium")
	ChangeVehicleZone(12070, 7390, "medium")
	ChangeVehicleZone(12073, 7390, "medium")
	ChangeVehicleZone(12076, 7390, "medium")

	ChangeVehicleZone(12045, 7401, "bad")
	ChangeVehicleZone(12051, 7401, "bad")
	ChangeVehicleZone(12054, 7401, "bad")
	ChangeVehicleZone(12064, 7401, "bad")
	ChangeVehicleZone(12070, 7401, "bad")

--Muldraugh
	--Dixie
	ChangeVehicleZone(11695, 8273, "spiffo")
	ChangeVehicleZone(11695, 8276, "spiffo")
	ChangeVehicleZone(11695, 8279, "spiffo")
	ChangeVehicleZone(11678, 8317, "parkinglot")
	ChangeVehicleZone(11657, 8317, "spiffo")
	ChangeVehicleZone(11660, 8317, "spiffo")
	ChangeVehicleZone(11663, 8317, "spiffo")

	--ChangeVehicleZone(11661, 8337, "usedcarsdealership")
	--ChangeVehicleZone(11664, 8337, "usedcarsdealership")
	--ChangeVehicleZone(11667, 8337, "usedcarsdealership")
	--ChangeVehicleZone(11670, 8337, "usedcarsdealership")
	--ChangeVehicleZone(11673, 8337, "usedcarsdealership")
	--ChangeVehicleZone(11676, 8337, "usedcarsdealership")
	--ChangeVehicleZone(11679, 8337, "usedcarsdealership")
	--ChangeVehicleZone(11682, 8337, "usedcarsdealership")

	--ChangeVehicleZone(11656, 8342, "usedcarsdealership")
	--ChangeVehicleZone(11656, 8345, "usedcarsdealership")
	--ChangeVehicleZone(11656, 8348, "usedcarsdealership")
	--ChangeVehicleZone(11656, 8351, "usedcarsdealership")
	--ChangeVehicleZone(11656, 8354, "usedcarsdealership")
	--ChangeVehicleZone(11656, 8357, "usedcarsdealership")
	--ChangeVehicleZone(11656, 8360, "usedcarsdealership")
	--ChangeVehicleZone(11656, 8363, "usedcarsdealership")
	--ChangeVehicleZone(11656, 8366, "usedcarsdealership")
	--ChangeVehicleZone(11656, 8369, "usedcarsdealership")

	ChangeVehicleZone(11668, 8348, "usedcarsdealership")
	ChangeVehicleZone(11668, 8351, "usedcarsdealership")
	ChangeVehicleZone(11668, 8354, "usedcarsdealership")
	ChangeVehicleZone(11668, 8357, "usedcarsdealership")
	ChangeVehicleZone(11668, 8360, "usedcarsdealership")
	ChangeVehicleZone(11668, 8363, "usedcarsdealership")
	ChangeVehicleZone(11668, 8366, "usedcarsdealership")

	ChangeVehicleZone(11674, 8348, "usedcarsdealership")
	ChangeVehicleZone(11674, 8351, "usedcarsdealership")
	ChangeVehicleZone(11674, 8354, "usedcarsdealership")
	ChangeVehicleZone(11674, 8357, "usedcarsdealership")
	ChangeVehicleZone(11674, 8360, "usedcarsdealership")
	ChangeVehicleZone(11674, 8363, "usedcarsdealership")
	ChangeVehicleZone(11674, 8366, "usedcarsdealership")

	ChangeVehicleZone(11506, 8830, "nullified_gasstation")
	--END

	ChangeVehicleZone(10612, 9252, "bad")
	ChangeVehicleZone(10615, 9252, "bad")
	ChangeVehicleZone(10618, 9252, "bad")
	ChangeVehicleZone(10621, 9252, "bad")
	ChangeVehicleZone(10624, 9252, "bad")
	ChangeVehicleZone(10627, 9252, "bad")
	ChangeVehicleZone(10630, 9252, "parallelstall", 6, nil)

	ChangeVehicleZone(10613, 9264, "bad", nil, nil, nil, 9263)
	ChangeVehicleZone(10616, 9264, "bad", nil, nil, nil, 9263)
	ChangeVehicleZone(10619, 9264, "bad", nil, nil, nil, 9263)
	ChangeVehicleZone(10622, 9264, "bad", nil, nil, nil, 9263)
	ChangeVehicleZone(10625, 9264, "bad", nil, nil, nil, 9263)
	ChangeVehicleZone(10628, 9264, "bad", nil, nil, nil, 9263)

	ChangeVehicleZone(10617, 9275, "massgenfac")
	ChangeVehicleZone(10620, 9275, "massgenfac")
	ChangeVehicleZone(10623, 9275, "massgenfac")
	ChangeVehicleZone(10617, 9280, "massgenfac")
	ChangeVehicleZone(10620, 9280, "massgenfac")
	ChangeVehicleZone(10623, 9280, "massgenfac")

	ChangeVehicleZone(10655, 9316, "nil")
	ChangeVehicleZone(10662, 9316, "nil")

	ChangeVehicleZone(10312, 9346, "medium")
	ChangeVehicleZone(10315, 9346, "medium")
	ChangeVehicleZone(10318, 9346, "medium")
	ChangeVehicleZone(10321, 9346, "medium")
	ChangeVehicleZone(10324, 9346, "medium")
	ChangeVehicleZone(10327, 9346, "medium")
	ChangeVehicleZone(10330, 9346, "medium")
	ChangeVehicleZone(10333, 9346, "medium")
	ChangeVehicleZone(10336, 9346, "medium")
	ChangeVehicleZone(10341, 9390, "bad")
	ChangeVehicleZone(10341, 9393, "bad")
	ChangeVehicleZone(10341, 9396, "bad")
	ChangeVehicleZone(10341, 9399, "bad")
	ChangeVehicleZone(10341, 9402, "bad")
	ChangeVehicleZone(10341, 9405, "bad")
	ChangeVehicleZone(10341, 9408, "bad")
	ChangeVehicleZone(10341, 9411, "bad")
	ChangeVehicleZone(10341, 9414, "bad")
	ChangeVehicleZone(10352, 9390, "bad")
	ChangeVehicleZone(10352, 9393, "bad")
	ChangeVehicleZone(10352, 9396, "bad")
	ChangeVehicleZone(10352, 9399, "bad")
	ChangeVehicleZone(10352, 9402, "bad")
	ChangeVehicleZone(10352, 9405, "bad")
	ChangeVehicleZone(10352, 9408, "bad")
	ChangeVehicleZone(10352, 9411, "bad")
	ChangeVehicleZone(10352, 9414, "bad")

	ChangeVehicleZone(10736, 9582, "medium", nil, 15, nil, 9579)

	ChangeVehicleZone(10874, 9540, "bad")
	ChangeVehicleZone(10877, 9540, "bad")
	ChangeVehicleZone(10880, 9540, "bad")
	ChangeVehicleZone(10873, 9549, "bad", 9, nil, 10872, nil)

	ChangeVehicleZone(10635, 9635, "bad")
	ChangeVehicleZone(10635, 9638, "bad")
	ChangeVehicleZone(10635, 9641, "bad")
	ChangeVehicleZone(10635, 9644, "bad")
	ChangeVehicleZone(10635, 9647, "medium")
	ChangeVehicleZone(10635, 9650, "medium")
	ChangeVehicleZone(10635, 9653, "medium")
	ChangeVehicleZone(10635, 9656, "good")
	ChangeVehicleZone(10614, 9665, "advertising")
	ChangeVehicleZone(10620, 9665, "spiffo")
	ChangeVehicleZone(10623, 9665, "spiffo")
	ChangeVehicleZone(10629, 9665, "spiffo")
	ChangeVehicleZone(10632, 9665, "spiffo")

	ChangeVehicleZone(10898, 9752, "nil")
	ChangeVehicleZone(10901, 9752, "nil")
	ChangeVehicleZone(10914, 9761, "parallelstall")
	ChangeVehicleZone(10917, 9761, "parallelstall")

	ChangeVehicleZone(10630, 9791, "bad")
	ChangeVehicleZone(10633, 9791, "bad")
	ChangeVehicleZone(10636, 9791, "bad")
	ChangeVehicleZone(10639, 9791, "bad")
	ChangeVehicleZone(10642, 9791, "bad")
	ChangeVehicleZone(10645, 9791, "bad")
	ChangeVehicleZone(10648, 9791, "bad")
	ChangeVehicleZone(10651, 9791, "bad")

	ChangeVehicleZone(10915, 9802, "lectromax")

	ChangeVehicleZone(10634, 9836, "bad")
	ChangeVehicleZone(10637, 9836, "bad")
	ChangeVehicleZone(10640, 9836, "bad")
	ChangeVehicleZone(10643, 9836, "bad")
	ChangeVehicleZone(10646, 9836, "bad")
	ChangeVehicleZone(10649, 9836, "bad")
	ChangeVehicleZone(10652, 9836, "bad")

	ChangeVehicleZone(10644, 9874, "medium")
	ChangeVehicleZone(10644, 9877, "medium")
	ChangeVehicleZone(10644, 9880, "medium")
	ChangeVehicleZone(10644, 9883, "medium")
	ChangeVehicleZone(10644, 9886, "medium")
	ChangeVehicleZone(10644, 9889, "medium")
	ChangeVehicleZone(10644, 9892, "medium")

	ChangeVehicleZone(10607, 9915, "parallelstall")
	ChangeVehicleZone(10610, 9915, "parallelstall")
	ChangeVehicleZone(10613, 9915, "parallelstall")
	ChangeVehicleZone(10631, 9916, nil, nil, nil, nil, 9915)
	ChangeVehicleZone(10607, 9928, "bad")
	ChangeVehicleZone(10610, 9928, "bad")
	ChangeVehicleZone(10613, 9928, "bad")
	ChangeVehicleZone(10616, 9928, "bad")
	ChangeVehicleZone(10619, 9928, "bad")
	ChangeVehicleZone(10622, 9928, "bad")

	ChangeVehicleZone(10646, 9951, "parallelstall")
	ChangeVehicleZone(10646, 9954, "parallelstall")
	ChangeVehicleZone(10646, 9957, "parallelstall")
	ChangeVehicleZone(10646, 9960, "parallelstall")
	ChangeVehicleZone(10646, 9963, "parallelstall")
	ChangeVehicleZone(10646, 9970, "parallelstall")
	ChangeVehicleZone(10646, 9973, "parallelstall")
	ChangeVehicleZone(10646, 9976, "parallelstall")
	ChangeVehicleZone(10646, 9979, "parallelstall")
	ChangeVehicleZone(10646, 9982, "parallelstall")
	ChangeVehicleZone(10646, 9985, "parallelstall")

	ChangeVehicleZone(10607, 10025, "bad")
	ChangeVehicleZone(10610, 10025, "bad")
	ChangeVehicleZone(10613, 10025, "bad")
	ChangeVehicleZone(10616, 10025, "bad")
	ChangeVehicleZone(10619, 10025, "bad")

	ChangeVehicleZone(10749, 10185, "medium")
	ChangeVehicleZone(10752, 10185, "medium")
	ChangeVehicleZone(10755, 10185, "medium")
	ChangeVehicleZone(10758, 10185, "medium")
	ChangeVehicleZone(10761, 10185, "medium")
	ChangeVehicleZone(10745, 10194, "bad")
	ChangeVehicleZone(10748, 10194, "bad")
	ChangeVehicleZone(10751, 10194, "bad")
	ChangeVehicleZone(10754, 10194, "bad")
	ChangeVehicleZone(10757, 10194, "bad")
	ChangeVehicleZone(10760, 10194, "bad")
	ChangeVehicleZone(10763, 10194, "bad")
	ChangeVehicleZone(10766, 10194, "bad")

	ChangeVehicleZone(10603, 10234, "bad")
	ChangeVehicleZone(10606, 10234, "bad")
	ChangeVehicleZone(10609, 10234, "bad")
	ChangeVehicleZone(10612, 10234, "carpenter")
	ChangeVehicleZone(10615, 10234, "carpenter")

	ChangeVehicleZone(10612, 10267, "nil")

	ChangeVehicleZone(10634, 10301, "parallelstall")
	ChangeVehicleZone(10634, 10304, "parallelstall")
	ChangeVehicleZone(10634, 10307, "parallelstall")
	ChangeVehicleZone(10634, 10310, "parallelstall")
	ChangeVehicleZone(10634, 10313, "parallelstall")
	ChangeVehicleZone(10634, 10316, "parallelstall")
	ChangeVehicleZone(10634, 10319, "parallelstall")
	ChangeVehicleZone(10634, 10322, "parallelstall")
	ChangeVehicleZone(10634, 10325, "parallelstall")
	ChangeVehicleZone(10634, 10328, "parallelstall")
	ChangeVehicleZone(10634, 10331, "parallelstall")
	ChangeVehicleZone(10634, 10334, "parallelstall")
	ChangeVehicleZone(10634, 10337, "parallelstall")
	ChangeVehicleZone(10634, 10340, "parallelstall")

	ChangeVehicleZone(10688, 10325, "medium")
	ChangeVehicleZone(10688, 10328, "medium")
	ChangeVehicleZone(10688, 10331, "medium")
	ChangeVehicleZone(10688, 10334, "medium")
	ChangeVehicleZone(10688, 10337, "medium")
	ChangeVehicleZone(10688, 10340, "medium")
	ChangeVehicleZone(10688, 10343, "medium")
	ChangeVehicleZone(10707, 10355, "bad")
	ChangeVehicleZone(10707, 10358, "bad")
	ChangeVehicleZone(10707, 10361, "bad")
	ChangeVehicleZone(10707, 10364, "bad")
	ChangeVehicleZone(10707, 10367, "bad")
	ChangeVehicleZone(10707, 10370, "bad")
	ChangeVehicleZone(10707, 10373, "bad")

	ChangeVehicleZone(10603, 10417, "bad")
	ChangeVehicleZone(10603, 10420, "bad")
	ChangeVehicleZone(10603, 10423, "bad")
	ChangeVehicleZone(10603, 10426, "medium")
	ChangeVehicleZone(10603, 10429, "medium")
	ChangeVehicleZone(10603, 10432, "medium")
	ChangeVehicleZone(10603, 10435, "parallelstall")
	ChangeVehicleZone(10603, 10438, "parallelstall")
	ChangeVehicleZone(10603, 10441, "parallelstall")
	ChangeVehicleZone(10613, 10435, "parallelstall")
	ChangeVehicleZone(10613, 10438, "parallelstall")
	ChangeVehicleZone(10613, 10441, "parallelstall")

	ChangeVehicleZone(10665, 10418, "police")
	ChangeVehicleZone(10665, 10421, "police")
	ChangeVehicleZone(10650, 10432, "medium")
	ChangeVehicleZone(10650, 10435, "medium")
	ChangeVehicleZone(10650, 10438, "medium")
	ChangeVehicleZone(10650, 10441, "medium")

	ChangeVehicleZone(10608, 10493, "parallelstall")
	ChangeVehicleZone(10608, 10496, "parallelstall")
	ChangeVehicleZone(10608, 10499, "parallelstall")
	ChangeVehicleZone(10608, 10502, "parallelstall")
	ChangeVehicleZone(10608, 10505, "parallelstall")
	ChangeVehicleZone(10608, 10508, "parallelstall")
	ChangeVehicleZone(10617, 10493, "medium")
	ChangeVehicleZone(10617, 10496, "medium")
	ChangeVehicleZone(10617, 10499, "medium")
	ChangeVehicleZone(10617, 10502, "medium")
	ChangeVehicleZone(10617, 10505, "medium")
	ChangeVehicleZone(10617, 10508, "medium")

	ChangeVehicleZone(10758, 10572, "parallelstall", nil, 6, nil, 10569)
	ChangeVehicleZone(10758, 10575, "medium")
	ChangeVehicleZone(10758, 10578, "medium")
	ChangeVehicleZone(10758, 10581, "medium")
	ChangeVehicleZone(10758, 10584, "medium")
	ChangeVehicleZone(10768, 10560, "parallelstall")
	ChangeVehicleZone(10768, 10563, "medium")
	ChangeVehicleZone(10768, 10566, "medium")
	ChangeVehicleZone(10768, 10569, "medium")
	ChangeVehicleZone(10768, 10572, "medium")
	ChangeVehicleZone(10768, 10575, "medium")

	ChangeVehicleZone(10740, 10593, "parallelstall")

	ChangeVehicleZone(10694, 10582, "farm")
	ChangeVehicleZone(10696, 10591, "farm")
	ChangeVehicleZone(10701, 10597, "farm")
	ChangeVehicleZone(10695, 10602, "farm")

	ChangeVehicleZone(10656, 10622, "nullified_gasstation")
	ChangeVehicleZone(10656, 10628, "nullified_gasstation")
	ChangeVehicleZone(10650, 10635, "nil")

	ChangeVehicleZone(11632, 10210, "medium", nil, 5)
	ChangeVehicleZone(11635, 10210, "medium", nil, 5)
	ChangeVehicleZone(11638, 10210, "medium", nil, 5)
	ChangeVehicleZone(11641, 10210, "medium", nil, 5)
	ChangeVehicleZone(11644, 10210, "medium", nil, 5)
	ChangeVehicleZone(11647, 10210, "medium", nil, 5)
	ChangeVehicleZone(11650, 10210, "medium", nil, 5)
	ChangeVehicleZone(11653, 10210, "medium", nil, 5)
	ChangeVehicleZone(11656, 10210, "medium", nil, 5)
	ChangeVehicleZone(11659, 10210, "medium", nil, 5)
	ChangeVehicleZone(11662, 10210, "medium", nil, 5)
	ChangeVehicleZone(11665, 10210, "medium", nil, 5)
	ChangeVehicleZone(11626, 10227, "bad", nil, 5, nil, 10226)
	ChangeVehicleZone(11629, 10227, "bad", nil, 5, nil, 10226)
	ChangeVehicleZone(11632, 10227, "bad", nil, 5, nil, 10226)
	ChangeVehicleZone(11635, 10227, "bad", nil, 5, nil, 10226)
	ChangeVehicleZone(11638, 10227, "bad", nil, 5, nil, 10226)
	ChangeVehicleZone(11641, 10227, "bad", nil, 5, nil, 10226)
	ChangeVehicleZone(11644, 10227, "bad", nil, 5, nil, 10226)
	ChangeVehicleZone(11647, 10227, "bad", nil, 5, nil, 10226)
	ChangeVehicleZone(11650, 10227, "bad", nil, 5, nil, 10226)
	ChangeVehicleZone(11653, 10227, "bad", nil, 5, nil, 10226)
	ChangeVehicleZone(11656, 10227, "bad", nil, 5, nil, 10226)
	ChangeVehicleZone(11659, 10227, "bad", nil, 5, nil, 10226)
	ChangeVehicleZone(11662, 10227, "bad", nil, 5, nil, 10226)
	ChangeVehicleZone(11665, 10227, "bad", nil, 5, nil, 10226)

	--Industrial Area
	ChangeVehicleZone(10010, 10821, "bad")
	ChangeVehicleZone(10018, 10821, "nil")

	ChangeVehicleZone(10042, 10829, "medium")
	ChangeVehicleZone(10055, 10829, "bad", nil, 24)

	ChangeVehicleZone(9975, 10910, "bad")
	ChangeVehicleZone(9987, 10923, "medium")

	ChangeVehicleZone(10009, 10976, "medium")
	ChangeVehicleZone(9999, 10984, "bad")
	ChangeVehicleZone(10008, 10990, "bad")
	ChangeVehicleZone(10014, 10990, "bad")
	ChangeVehicleZone(10023, 10996, "nil")

	ChangeVehicleZone(10030, 11001, "bad")
	ChangeVehicleZone(10030, 11011, "medium")
	ChangeVehicleZone(10054, 11011, "medium")

	ChangeVehicleZone(10115, 10864, "medium")

	ChangeVehicleZone(10116, 10898, "bad")

	ChangeVehicleZone(10069, 10906, "bad")
	ChangeVehicleZone(10063, 10918, "bad")

	ChangeVehicleZone(10170, 10929, "bad")

	ChangeVehicleZone(10174, 10970, "bad")

	ChangeVehicleZone(10222, 10961, "nil")
	ChangeVehicleZone(10231, 10961, "nil")
	ChangeVehicleZone(10236, 10961, "nil")
	ChangeVehicleZone(10245, 10961, "nil")
	--END

--Rosewood
	--Parallel Parking
	ChangeVehicleZone(8020, 11503, "parallelstall")

	ChangeVehicleZone(8033, 11480, "parallelstall")

	ChangeVehicleZone(8037, 11572, "parallelstall")
	ChangeVehicleZone(8075, 11572, "parallelstall")

	ChangeVehicleZone(8099, 11492, "parallelstall")
	ChangeVehicleZone(8099, 11595, "parallelstall")

	ChangeVehicleZone(8122, 11572, "parallelstall", 20, nil)
	ChangeVehicleZone(8151, 11572, "parallelstall", 25, nil)
	ChangeVehicleZone(8122, 11583, "parallelstall", 20, nil)
	--END

	--Drive-In
	ChangeVehicleZone(8405, 12219, "sport")
	ChangeVehicleZone(8405, 12224, "sport")
	ChangeVehicleZone(8405, 12229, "sport")
	ChangeVehicleZone(8405, 12234, "sport")
	ChangeVehicleZone(8405, 12239, "sport")
	ChangeVehicleZone(8405, 12244, "sport")
	ChangeVehicleZone(8405, 12249, "sport")
	ChangeVehicleZone(8405, 12254, "sport")

	ChangeVehicleZone(8413, 12214, "good")
	ChangeVehicleZone(8413, 12219, "good")
	ChangeVehicleZone(8413, 12224, "good")
	ChangeVehicleZone(8413, 12229, "good")
	ChangeVehicleZone(8413, 12234, "good")
	ChangeVehicleZone(8413, 12239, "good")
	ChangeVehicleZone(8413, 12244, "good")
	ChangeVehicleZone(8413, 12249, "good")
	ChangeVehicleZone(8413, 12254, "good")
	ChangeVehicleZone(8413, 12259, "good")
	ChangeVehicleZone(8413, 12264, "good")

	ChangeVehicleZone(8421, 12204, "good")
	ChangeVehicleZone(8421, 12209, "good")
	ChangeVehicleZone(8421, 12214, "good")
	ChangeVehicleZone(8421, 12219, "good")
	ChangeVehicleZone(8421, 12224, "good")
	ChangeVehicleZone(8421, 12229, "good")
	ChangeVehicleZone(8421, 12234, "good")
	ChangeVehicleZone(8421, 12239, "good")
	ChangeVehicleZone(8421, 12244, "good")
	ChangeVehicleZone(8421, 12249, "good")
	ChangeVehicleZone(8421, 12254, "good")
	ChangeVehicleZone(8421, 12259, "good")
	ChangeVehicleZone(8421, 12264, "good")
	ChangeVehicleZone(8421, 12269, "good")
	ChangeVehicleZone(8421, 12274, "good")

	ChangeVehicleZone(8429, 12199, "medium")
	ChangeVehicleZone(8429, 12204, "medium")
	ChangeVehicleZone(8429, 12209, "medium")
	ChangeVehicleZone(8429, 12214, "medium")
	ChangeVehicleZone(8429, 12219, "medium")
	ChangeVehicleZone(8429, 12224, "medium")
	ChangeVehicleZone(8429, 12229, "medium")
	ChangeVehicleZone(8429, 12234, "medium")
	ChangeVehicleZone(8429, 12239, "medium")
	ChangeVehicleZone(8429, 12244, "medium")
	ChangeVehicleZone(8429, 12249, "medium")
	ChangeVehicleZone(8429, 12254, "medium")
	ChangeVehicleZone(8429, 12259, "medium")
	ChangeVehicleZone(8429, 12264, "medium")
	ChangeVehicleZone(8429, 12269, "medium")
	ChangeVehicleZone(8429, 12274, "medium")
	ChangeVehicleZone(8429, 12279, "medium")

	ChangeVehicleZone(8437, 12199, "medium")
	ChangeVehicleZone(8437, 12204, "medium")
	ChangeVehicleZone(8437, 12209, "medium")
	ChangeVehicleZone(8437, 12214, "medium")
	ChangeVehicleZone(8437, 12219, "medium")
	ChangeVehicleZone(8437, 12224, "medium")
	ChangeVehicleZone(8437, 12229, "medium")
	ChangeVehicleZone(8437, 12234, "medium")
	ChangeVehicleZone(8437, 12239, "medium")
	ChangeVehicleZone(8437, 12244, "medium")
	ChangeVehicleZone(8437, 12249, "medium")
	ChangeVehicleZone(8437, 12254, "medium")
	ChangeVehicleZone(8437, 12259, "medium")
	ChangeVehicleZone(8437, 12264, "medium")
	ChangeVehicleZone(8437, 12269, "medium")
	ChangeVehicleZone(8437, 12274, "medium")
	ChangeVehicleZone(8437, 12279, "medium")

	ChangeVehicleZone(8445, 12199, "bad")
	ChangeVehicleZone(8445, 12204, "bad")
	ChangeVehicleZone(8445, 12209, "bad")
	ChangeVehicleZone(8445, 12214, "bad")
	ChangeVehicleZone(8445, 12219, "bad")
	ChangeVehicleZone(8445, 12224, "bad")
	ChangeVehicleZone(8445, 12229, "bad")
	ChangeVehicleZone(8445, 12234, "bad")
	ChangeVehicleZone(8445, 12239, "bad")
	ChangeVehicleZone(8445, 12244, "bad")
	ChangeVehicleZone(8445, 12249, "bad")
	ChangeVehicleZone(8445, 12254, "bad")
	ChangeVehicleZone(8445, 12259, "bad")
	ChangeVehicleZone(8445, 12264, "bad")
	ChangeVehicleZone(8445, 12269, "bad")
	ChangeVehicleZone(8445, 12274, "bad")
	ChangeVehicleZone(8445, 12279, "bad")

	ChangeVehicleZone(8453, 12199, "bad")
	ChangeVehicleZone(8453, 12204, "bad")
	ChangeVehicleZone(8453, 12209, "bad")
	ChangeVehicleZone(8453, 12214, "bad")
	ChangeVehicleZone(8453, 12219, "bad")
	ChangeVehicleZone(8453, 12224, "bad")
	ChangeVehicleZone(8453, 12229, "bad")
	ChangeVehicleZone(8453, 12234, "bad")
	ChangeVehicleZone(8453, 12239, "bad")
	ChangeVehicleZone(8453, 12244, "bad")
	ChangeVehicleZone(8453, 12249, "bad")
	ChangeVehicleZone(8453, 12254, "bad")
	ChangeVehicleZone(8453, 12259, "bad")
	ChangeVehicleZone(8453, 12264, "bad")
	ChangeVehicleZone(8453, 12269, "bad")
	ChangeVehicleZone(8453, 12274, "bad")
	ChangeVehicleZone(8453, 12279, "bad")
	--END

	--PRISON
	ChangeVehicleZone(7791, 11910, "medium")

	ChangeVehicleZone(7724, 11738, "medium")
	ChangeVehicleZone(7736, 11738, "bad")
	ChangeVehicleZone(7741, 11738, "bad")
	ChangeVehicleZone(7753, 11738, "medium")

	ChangeVehicleZone(7656, 11852, "medium")
	ChangeVehicleZone(7668, 11852, "bad")
	ChangeVehicleZone(7635, 11877, "medium")
	ChangeVehicleZone(7635, 11892, "bad")

	ChangeVehicleZone(7534, 11803, "medium")
	ChangeVehicleZone(7525, 11820, "medium")
	ChangeVehicleZone(7507, 11753, "bad")
	--END

	ChangeVehicleZone(7971, 11154, "nil")
	ChangeVehicleZone(7988, 11158, "nil")
	ChangeVehicleZone(8011, 11158, "nil")

	ChangeVehicleZone(8033, 11152, "bad")

	ChangeVehicleZone(7965, 11252, "medium")
	ChangeVehicleZone(7965, 11288, "bad")
	ChangeVehicleZone(7973, 11312, "bad")

	ChangeVehicleZone(8062, 11232, "bad")
	ChangeVehicleZone(8067, 11232, "bad")
	ChangeVehicleZone(8078, 11232, "bad")

	ChangeVehicleZone(8095, 11310, "bad")
	ChangeVehicleZone(8060, 11370, "bad")

	ChangeVehicleZone(7978, 11367, "bad")

	ChangeVehicleZone(8094, 11400, "bad")

	ChangeVehicleZone(8094, 11447, "bad")

	ChangeVehicleZone(8016, 11438, "bad")

	ChangeVehicleZone(8047, 11489, "bad")

	ChangeVehicleZone(8071, 11506, "parallelstall")

	ChangeVehicleZone(8182, 11216, "knoxtelecomms")

	ChangeVehicleZone(8222, 11252, "nil")

	ChangeVehicleZone(8276, 11234, "bad")
	ChangeVehicleZone(8276, 11242, "bad")

	ChangeVehicleZone(8298, 11293, "bad")

	ChangeVehicleZone(8324, 11309, "bad")

	ChangeVehicleZone(8229, 11283, "medium")
	ChangeVehicleZone(8271, 11309, "bad")
	ChangeVehicleZone(8242, 11343, "good")
	ChangeVehicleZone(8200, 11343, "medium")
	ChangeVehicleZone(8200, 11355, "bad")
	ChangeVehicleZone(8200, 11360, "bad")

	ChangeVehicleZone(8182, 11309, "bad")

	ChangeVehicleZone(8177, 11311, "bad")

	ChangeVehicleZone(8176, 11370, "farm")

	ChangeVehicleZone(8118, 11391, "bad")

	ChangeVehicleZone(8158, 11487, "medium")

	ChangeVehicleZone(8218, 11517, "bad")

	ChangeVehicleZone(8162, 11609, "bad")
	ChangeVehicleZone(8162, 11620, "bad")
	ChangeVehicleZone(8162, 11625, "bad")

	ChangeVehicleZone(8151, 11687, "bad")

	ChangeVehicleZone(8322, 11480, "bad")

	ChangeVehicleZone(8013, 11627, "bad")
	ChangeVehicleZone(8013, 11651, "medium")

	ChangeVehicleZone(8050, 11702, "parkingstall")

	ChangeVehicleZone(8123, 11754, "parkingstall")
	ChangeVehicleZone(8123, 11766, "parkingstall")

	ChangeVehicleZone(8264, 11790, "bad")
	ChangeVehicleZone(8264, 11817, "bad")

	ChangeVehicleZone(8270, 12142, "nil")
	ChangeVehicleZone(8276, 12257, nil, 15, nil)

	ChangeVehicleZone(8283, 12272, "bad", 27, nil)
	ChangeVehicleZone(8310, 12272, "bad", 9, nil)
	ChangeVehicleZone(8322, 12272, "bad", nil, nil, 8325, nil)
	ChangeVehicleZone(8289, 12299, "bad", 27, nil, 8286, nil)
	ChangeVehicleZone(8313, 12299, "bad", 18, nil)

--Fallas Lake
	--Parallel Parking
	ChangeVehicleZone(7270, 8168, "parallelstall", nil, 30)
	ChangeVehicleZone(7270, 8192, "parallelstall", nil, 15, nil, 8207)
	ChangeVehicleZone(7281, 8286, "parallelstall")
	ChangeVehicleZone(7270, 8422, "parallelstall")
	--END

	ChangeVehicleZone(7254, 8179, "bad")

	ChangeVehicleZone(7306, 8175, "nullified_gasstation")
	ChangeVehicleZone(7306, 8179, "nullified_gasstation")
	ChangeVehicleZone(7315, 8175, "nullified_gasstation")

	ChangeVehicleZone(7326, 8223, "bad")

	ChangeVehicleZone(7301, 8237, "bad")

	ChangeVehicleZone(7321, 8242, "bad")

	ChangeVehicleZone(7236, 8255, "bad", nil, 24)
	ChangeVehicleZone(7236, 8294, "bad")

	ChangeVehicleZone(7289, 8282, "bad")
	ChangeVehicleZone(7289, 8294, "medium")

	ChangeVehicleZone(7368, 8283, "nil")
	ChangeVehicleZone(7335, 8305, "medium")

	ChangeVehicleZone(7258, 8383, "prison")

	ChangeVehicleZone(7318, 8331, "bad")

	ChangeVehicleZone(7306, 8400, "ambulance")
	ChangeVehicleZone(7306, 8382, "parkingstall")
	ChangeVehicleZone(7320, 8400, "medium", nil, 12, nil, 8397)

	ChangeVehicleZone(7443, 8287, "medium")
	ChangeVehicleZone(7443, 8299, "bad")

	ChangeVehicleZone(7461, 8328, "bad")

	ChangeVehicleZone(7383, 8366, "bad")
	ChangeVehicleZone(7396, 8366, "bad")

	ChangeVehicleZone(7424, 8350, "bad")
	ChangeVehicleZone(7427, 8350, "bad")

	ChangeVehicleZone(7416, 8401, "bad")
	ChangeVehicleZone(7416, 8405, "bad")
	ChangeVehicleZone(7416, 8411, "bad")

	ChangeVehicleZone(7146, 8456, "bad")

	ChangeVehicleZone(7259, 8474, "nil")
	ChangeVehicleZone(7262, 8474, "nil")
	ChangeVehicleZone(7270, 8482, "nil")
	ChangeVehicleZone(7270, 8476, "parallelstall", nil, 22, nil, 8471)

	ChangeVehicleZone(7239, 8515, "bad")

	ChangeVehicleZone(7179, 8520, "bad")
	ChangeVehicleZone(7179, 8536, "medium")

--Riverside
	--Parallel Parking
	ChangeVehicleZone(6320, 5231, "parallelstall")
	ChangeVehicleZone(6320, 5237, "parallelstall")
	ChangeVehicleZone(6320, 5243, "parallelstall")
	ChangeVehicleZone(6320, 5249, "parallelstall")
	ChangeVehicleZone(6320, 5255, "parallelstall")
	ChangeVehicleZone(6320, 5261, "parallelstall")

	ChangeVehicleZone(6396, 5276, "parallelstall")
	ChangeVehicleZone(6402, 5276, "parallelstall")
	ChangeVehicleZone(6408, 5276, "parallelstall")
	ChangeVehicleZone(6414, 5276, "parallelstall")
	ChangeVehicleZone(6420, 5276, "parallelstall")
	ChangeVehicleZone(6426, 5276, "parallelstall")
	ChangeVehicleZone(6432, 5276, "parallelstall")
	ChangeVehicleZone(6428, 5276, "parallelstall")

	ChangeVehicleZone(6396, 5287, "parallelstall")
	ChangeVehicleZone(6402, 5287, "parallelstall")
	ChangeVehicleZone(6408, 5287, "parallelstall")
	ChangeVehicleZone(6414, 5287, "parallelstall")
	ChangeVehicleZone(6420, 5287, "parallelstall")

	ChangeVehicleZone(6462, 5276, "parallelstall")
	ChangeVehicleZone(6468, 5276, "parallelstall")
	ChangeVehicleZone(6474, 5276, "parallelstall")
	ChangeVehicleZone(6480, 5276, "parallelstall")
	ChangeVehicleZone(6486, 5276, "parallelstall")
	ChangeVehicleZone(6492, 5276, "parallelstall")
	ChangeVehicleZone(6498, 5276, "parallelstall")
	ChangeVehicleZone(6504, 5276, "parallelstall")
	ChangeVehicleZone(6510, 5276, "parallelstall")

	ChangeVehicleZone(6454, 5287, "parallelstall")
	ChangeVehicleZone(6460, 5287, "parallelstall")
	ChangeVehicleZone(6466, 5287, "parallelstall")
	ChangeVehicleZone(6472, 5287, "parallelstall")
	ChangeVehicleZone(6478, 5287, "parallelstall")
	ChangeVehicleZone(6484, 5287, "parallelstall")

	ChangeVehicleZone(6498, 5287, "parallelstall")
	ChangeVehicleZone(6504, 5287, "parallelstall")
	ChangeVehicleZone(6510, 5287, "parallelstall")

	ChangeVehicleZone(6428, 5404, "parallelstall")
	ChangeVehicleZone(6433, 5404, "parallelstall")
	ChangeVehicleZone(6439, 5404, "parallelstall")
	ChangeVehicleZone(6445, 5404, "parallelstall")
	ChangeVehicleZone(6451, 5404, "parallelstall")
	ChangeVehicleZone(6457, 5404, "parallelstall")
	ChangeVehicleZone(6463, 5404, "parallelstall")
	ChangeVehicleZone(6469, 5404, "parallelstall")
	ChangeVehicleZone(6475, 5404, "parallelstall")
	ChangeVehicleZone(6481, 5404, "parallelstall")
	ChangeVehicleZone(6487, 5404, "parallelstall")
	ChangeVehicleZone(6493, 5404, "parallelstall")
	ChangeVehicleZone(6499, 5404, "parallelstall")
	ChangeVehicleZone(6505, 5404, "parallelstall")
	ChangeVehicleZone(6511, 5404, "parallelstall")
	--END

	ChangeVehicleZone(5491, 5879, "parkingstall")
	ChangeVehicleZone(5503, 5885, "parkingstall")
	ChangeVehicleZone(5509, 5885, "parkingstall")
	ChangeVehicleZone(5520, 5879, "parkingstall")
	ChangeVehicleZone(5579, 5962, "parkingstall")
	ChangeVehicleZone(5591, 5962, "parkingstall")

	ChangeVehicleZone(5801, 5418, "bad")

	ChangeVehicleZone(6083, 5203, "ranger")
	ChangeVehicleZone(6081, 5235, "prison")
	ChangeVehicleZone(6081, 5240, "prison")
	ChangeVehicleZone(6095, 5243, "parkingstall")
	ChangeVehicleZone(6095, 5252, "parkingstall")

	ChangeVehicleZone(6163, 5219, "bad")

	ChangeVehicleZone(6198, 5235, "medium")
	ChangeVehicleZone(6209, 5259, "sport")
	ChangeVehicleZone(6272, 5201, "bad")

	ChangeVehicleZone(6109, 5246, "parkingstall")

	ChangeVehicleZone(6057, 5306, "nullified_gasstation")
	ChangeVehicleZone(6064, 5300, "nullified_gasstation")
	ChangeVehicleZone(6093, 5292, "fossoil")

	ChangeVehicleZone(6115, 5292, "advertising")
	ChangeVehicleZone(6101, 5295, "spiffo")
	ChangeVehicleZone(6101, 5298, "spiffo")
	ChangeVehicleZone(6101, 5301, "spiffo")
	ChangeVehicleZone(6108, 5329, "parkingstall")
	ChangeVehicleZone(6126, 5329, "parkingstall")

	ChangeVehicleZone(6129, 5353, "medium")

	ChangeVehicleZone(6222, 5293, "medium")
	ChangeVehicleZone(6222, 5323, "medium")

	ChangeVehicleZone(6123, 5465, "farm")

	ChangeVehicleZone(6334, 5230, "good")
	ChangeVehicleZone(6334, 5241, "sport")

	ChangeVehicleZone(6359, 5231, "bad")
	ChangeVehicleZone(6372, 5231, "medium")

	ChangeVehicleZone(6463, 5234, "bad")

	ChangeVehicleZone(6336, 5313, "bad")

	ChangeVehicleZone(6360, 5419, "medium")

	ChangeVehicleZone(6406, 5338, "bad")

	ChangeVehicleZone(6476, 5313, "postal")

	ChangeVehicleZone(6649, 5234, "ambulance")
	ChangeVehicleZone(6660, 5234, "ambulance")
	ChangeVehicleZone(6670, 5234, "ambulance")

	ChangeVehicleZone(6797, 5389, nil, nil, nil, 6790, 5390)
	ChangeVehicleZone(6791, 5458, "carpenter")

	ChangeVehicleZone(7133, 6151, "bad")

	ChangeVehicleZone(7184, 6108, "nullified_gasstation")

--

	ChangeVehicleZone(12454, 3527, "nil")
	ChangeVehicleZone(12458, 3533, "nil")
	ChangeVehicleZone(12908, 3012, "nil")
	ChangeVehicleZone(3567, 10910, "nil")
	ChangeVehicleZone(2327, 14481, "nil")
	ChangeVehicleZone(2335, 14475, "nil")

	ChangeVehicleZone(1661, 5762, "nullified_gasstation")

	ChangeVehicleZone(3712, 8487, "nullified_gasstation")

	ChangeVehicleZone(517, 9893, "rtrafficjame")
	ChangeVehicleZone(552, 9893, "trafficjamw")
	ChangeVehicleZone(573, 9891, "rtrafficjamw")

	ChangeVehicleZone(12360, 2547, "parkingstall")
	ChangeVehicleZone(12401, 2528, "usedcarsdealership")
	ChangeVehicleZone(12414, 2528, "usedcarsdealership")

	ChangeVehicleZone(13140, 1481, "usedcarsdealership")
	ChangeVehicleZone(13182, 1446, "usedcarsdealership")

	ChangeVehicleZone(4126, 9377, "good")
	ChangeVehicleZone(4087, 9369, "good")
	ChangeVehicleZone(4121, 9369, "good")
	ChangeVehicleZone(4097, 9384, "good")
	ChangeVehicleZone(4072, 9392, "medium")
	ChangeVehicleZone(4106, 9420, "medium")
	ChangeVehicleZone(4174, 9420, "medium")
	ChangeVehicleZone(4071, 9426, "medium")
	ChangeVehicleZone(4133, 9436, "good")
	ChangeVehicleZone(4072, 9463, "good")
	ChangeVehicleZone(4106, 9467, "good")
	ChangeVehicleZone(4142, 9467, "medium")
	ChangeVehicleZone(4178, 9468, "good")

	ChangeVehicleZone(12603, 3589, "parkingstall")

	ChangeVehicleZone(2210, 13873, "lectromax")

	ChangeVehicleZone(3099, 14482, "massgenfac")

	ChangeVehicleZone(12080, 1312, "parkingstall")
	ChangeVehicleZone(12080, 1318, "parkingstall")
	ChangeVehicleZone(12080, 1339, "parkingstall")
	ChangeVehicleZone(12085, 1312, "parkingstall")
	ChangeVehicleZone(12096, 1306, "parkingstall")

	ChangeVehicleZone(1573, 5589, "trailerpark")
	ChangeVehicleZone(1549, 5603, "trailerpark")
	ChangeVehicleZone(1588, 5615, "trailerpark")
	ChangeVehicleZone(1557, 5624, "trailerpark")
	ChangeVehicleZone(1587, 5635, "trailerpark")
	ChangeVehicleZone(1589, 5640, "trailerpark")
	ChangeVehicleZone(1555, 5642, "trailerpark")
	ChangeVehicleZone(1571, 5649, "trailerpark")
	ChangeVehicleZone(1575, 5653, "trailerpark")
	ChangeVehicleZone(1553, 5663, "trailerpark")
	ChangeVehicleZone(1554, 5667, "trailerpark")
	ChangeVehicleZone(1596, 5673, "trailerpark")
	ChangeVehicleZone(1589, 5693, "trailerpark")

	ChangeVehicleZone(10065, 12668, "bad")
	ChangeVehicleZone(10065, 12678, "bad")

	ChangeVehicleZone(2483, 14046, "parkingstall")
	ChangeVehicleZone(2478, 14083, "parkingstall")

	ChangeVehicleZone(421, 9841, "bad")
	ChangeVehicleZone(421, 9846, "bad")

	ChangeVehicleZone(12912, 2116, "ambulance")

	ChangeVehicleZone(12462, 3695, "police")
	ChangeVehicleZone(12461, 3706, "police")

	ChangeVehicleZone(12403, 1778, "ambulance")

	ChangeVehicleZone(2060, 6254, "parkingstall")
	ChangeVehicleZone(2079, 6261, "parkingstall")

	ChangeVehicleZone(2483, 14046, "parkingstall")
	ChangeVehicleZone(2472, 14072, "parkingstall")
	ChangeVehicleZone(2478, 14083, "parkingstall")

	ChangeVehicleZone(2483, 13949, "parkingstall")
	ChangeVehicleZone(2496, 13928, "parkingstall")
	ChangeVehicleZone(2496, 13940, "parkingstall")
	ChangeVehicleZone(2496, 13957, "parkingstall")
	ChangeVehicleZone(2496, 13963, "parkingstall")

	ChangeVehicleZone(1434, 5862, "prison")
	ChangeVehicleZone(1428, 5850, "parkingstall")

	ChangeVehicleZone(12451, 1624, "police")
	ChangeVehicleZone(12452, 1615, "prison")

	ChangeVehicleZone(12943, 1421, "police")

	ChangeVehicleZone(13068, 2807, "police")
	ChangeVehicleZone(13068, 2810, "police")
	ChangeVehicleZone(13068, 2813, "police")

	ChangeVehicleZone(13245, 3079, "police")

	ChangeVehicleZone(13788, 2553, "police")

	ChangeVehicleZone(13419, 2381, "ranger")

	ChangeVehicleZone(5460, 9525, "ranger")

	ChangeVehicleZone(12646, 1863, "parkingstall")
	ChangeVehicleZone(12672, 1873, "parkingstall")

	ChangeVehicleZone(12310, 1917, "spiffo")

	ChangeVehicleZone(12733, 1598, "spiffo")

	ChangeVehicleZone(12429, 3806, "spiffo")

	ChangeVehicleZone(13248, 3016, "transit")

	ChangeVehicleZone(12531, 2364, "transit")

	ChangeVehicleZone(15457, 3121, "parkingstall")
	ChangeVehicleZone(15463, 3132, "parkingstall")
	ChangeVehicleZone(15530, 3144, "postal")

	ChangeVehicleZone(674, 9849, "postal")
	ChangeVehicleZone(674, 9853, "postal")
	ChangeVehicleZone(690, 9869, "postal")
	ChangeVehicleZone(690, 9872, "postal")
	ChangeVehicleZone(684, 9875, "postal")
	ChangeVehicleZone(687, 9875, "postal")

	ChangeVehicleZone(10125, 12723, "postal")
	ChangeVehicleZone(10140, 12717, "postal")

	ChangeVehicleZone(2433, 14519, "parkingstall")
	ChangeVehicleZone(2447, 14545, "postal")

	ChangeVehicleZone(2283, 14479, "advertising")

	ChangeVehicleZone(2201, 6483, "advertising")

	ChangeVehicleZone(415, 9907, "advertising")

	ChangeVehicleZone(3824, 14444, "nil")
	ChangeVehicleZone(3824, 14447, "nil")
	ChangeVehicleZone(3834, 14444, "nil")
	ChangeVehicleZone(3834, 14447, "nil")
	ChangeVehicleZone(3834, 14468, "nil")
	ChangeVehicleZone(3834, 14471, "nil")
	ChangeVehicleZone(3834, 14474, "nil")
	ChangeVehicleZone(3824, 14438, "parkingstall", 5, 39)
	ChangeVehicleZone(3834, 14441, "parkingstall", 5, 36)

	ChangeVehicleZone(15302, 2975, "airportservice")

	ChangeVehicleZone(15574, 2501, "ambulance")

	ChangeVehicleZone(15502, 2494, "parkingstall")
	ChangeVehicleZone(15453, 2471, "parkingstall")

	ChangeVehicleZone(662, 9568, "farm")

	ChangeVehicleZone(798, 10825, "farm")

	ChangeVehicleZone(1252, 12032, "bad")
	ChangeVehicleZone(1257, 12032, "bad")

	ChangeVehicleZone(1259, 11847, "farm")

	ChangeVehicleZone(1291, 14665, "bad")

	ChangeVehicleZone(1331, 12301, "farm")

	ChangeVehicleZone(1420, 10316, "farm")

	ChangeVehicleZone(1446, 10885, "farm")

	ChangeVehicleZone(1552, 14463, "bad")
	ChangeVehicleZone(1552, 14467, "bad")

	ChangeVehicleZone(1612, 12074, "farm")

	ChangeVehicleZone(1651, 7945, "farm")
	ChangeVehicleZone(1650, 7961, "farm")

	ChangeVehicleZone(1694, 8604, "nil")

	ChangeVehicleZone(1721, 10347, "farm")

	ChangeVehicleZone(1728, 11248, "farm")

	ChangeVehicleZone(1871, 12472, "farm")
	ChangeVehicleZone(1877, 12478, "farm")

	ChangeVehicleZone(2019, 11662, "farm")
	ChangeVehicleZone(2019, 11669, "farm")

	ChangeVehicleZone(2165, 12062, "farm")

	ChangeVehicleZone(2271, 11847, "farm")
	ChangeVehicleZone(2288, 11847, "farm")

	ChangeVehicleZone(2781, 10949, "farm")

	ChangeVehicleZone(3110, 12087, "farm")
	ChangeVehicleZone(3183, 12120, "parkingstall")

	ChangeVehicleZone(3687, 10886, "farm")

	ChangeVehicleZone(3873, 11559, "farm")

	ChangeVehicleZone(3957, 5809, "farm")
	ChangeVehicleZone(3963, 5809, "farm")

	ChangeVehicleZone(4012, 13659, "parkingstall")

	ChangeVehicleZone(4170, 11119, "farm")

	ChangeVehicleZone(14314, 4980, "farm")
	ChangeVehicleZone(14330, 4960, "farm")

	ChangeVehicleZone(14554, 3047, "farm")

	ChangeVehicleZone(9102, 9316, "parkingstall")

	ChangeVehicleZone(9318, 8987, "parkingstall")
	ChangeVehicleZone(9340, 8982, "parkingstall")

	ChangeVehicleZone(8573, 8534, "parkingstall")
	ChangeVehicleZone(8579, 8534, "parkingstall")
	ChangeVehicleZone(8588, 8534, "parkingstall")

	ChangeVehicleZone(3668, 5781, "nil")
	ChangeVehicleZone(3668, 5790, "nil")
	ChangeVehicleZone(3668, 5799, "nil")
	ChangeVehicleZone(3668, 5808, "nil")
	ChangeVehicleZone(3683, 5784, "nil")
	ChangeVehicleZone(3683, 5805, "nil")

--parkingstall to bad (for balancing, random angles, and more camo vehicles)
	ChangeVehicleZone(1081, 12969, "bad")
	ChangeVehicleZone(1080, 12979, "bad")
	ChangeVehicleZone(1068, 12998, "bad")
	ChangeVehicleZone(1068, 13009, "bad")
	ChangeVehicleZone(1131, 12980, "bad")
	ChangeVehicleZone(1208, 12975, "bad")
	ChangeVehicleZone(1208, 13129, "bad")
	ChangeVehicleZone(1225, 13129, "bad")
	ChangeVehicleZone(1226, 12993, "bad")
	ChangeVehicleZone(1235, 12975, "bad")

	ChangeVehicleZone(3481, 10953, "bad")
	ChangeVehicleZone(3554, 10953, "bad")
	ChangeVehicleZone(3504, 10957, "bad")
	ChangeVehicleZone(3511, 10957, "bad")
	ChangeVehicleZone(3518, 10957, "bad")
	ChangeVehicleZone(3525, 10957, "bad")
	ChangeVehicleZone(3532, 10957, "bad")
	ChangeVehicleZone(3539, 10957, "bad")
	ChangeVehicleZone(3547, 10957, "bad")

	ChangeVehicleZone(3711, 8455, "bad")
	ChangeVehicleZone(3687, 8510, "bad")
	ChangeVehicleZone(3796, 8574, "bad")
	ChangeVehicleZone(3813, 8553, "farm")
	
	ChangeVehicleZone(2513, 10847, "bad")
	ChangeVehicleZone(2519, 10854, "bad")
	ChangeVehicleZone(2527, 10847, "bad")
	ChangeVehicleZone(2565, 10847, "bad")
	ChangeVehicleZone(2569, 10854, "bad")
	ChangeVehicleZone(2587, 10847, "bad")
	ChangeVehicleZone(2594, 10847, "bad")
	ChangeVehicleZone(2600, 10847, "bad")
	ChangeVehicleZone(2611, 10853, "bad")
	ChangeVehicleZone(2617, 10853, "bad")
	ChangeVehicleZone(2618, 10847, "bad")
	ChangeVehicleZone(2630, 10847, "bad")
	ChangeVehicleZone(2646, 10847, "bad")
	ChangeVehicleZone(2667, 10847, "bad")
	ChangeVehicleZone(2679, 10855, "bad")
	ChangeVehicleZone(2682, 10847, "bad")

--Houses
--Brandenburg
	--Parallel Parking
	ChangeVehicleZone(2055, 5819, "parallelstall")
	ChangeVehicleZone(2055, 5824, "parallelstall")
	ChangeVehicleZone(2055, 5829, "parallelstall")
	ChangeVehicleZone(2055, 5834, "parallelstall")
	ChangeVehicleZone(2055, 5839, "parallelstall")

	ChangeVehicleZone(2055, 5854, "parallelstall")
	ChangeVehicleZone(2055, 5859, "parallelstall")
	ChangeVehicleZone(2055, 5864, "parallelstall")
	ChangeVehicleZone(2055, 5869, "parallelstall")
	ChangeVehicleZone(2055, 5874, "parallelstall")
	ChangeVehicleZone(2055, 5879, "parallelstall")
	ChangeVehicleZone(2055, 5884, "parallelstall")
	ChangeVehicleZone(2055, 5889, "parallelstall")

	ChangeVehicleZone(2055, 5937, "parallelstall")
	ChangeVehicleZone(2055, 5942, "parallelstall")
	ChangeVehicleZone(2055, 5947, "parallelstall")

	ChangeVehicleZone(2055, 5962, "parallelstall")
	ChangeVehicleZone(2055, 5967, "parallelstall")
	ChangeVehicleZone(2055, 5972, "parallelstall")
	ChangeVehicleZone(2055, 5977, "parallelstall")
	ChangeVehicleZone(2055, 5982, "parallelstall")
	ChangeVehicleZone(2055, 5987, "parallelstall")
	ChangeVehicleZone(2055, 5992, "parallelstall")

	ChangeVehicleZone(2055, 6002, "parallelstall")
	ChangeVehicleZone(2055, 6007, "parallelstall")
	ChangeVehicleZone(2055, 6012, "parallelstall")

	ChangeVehicleZone(2077, 5797, "parallelstall")
	ChangeVehicleZone(2082, 5797, "parallelstall")
	ChangeVehicleZone(2087, 5797, "parallelstall")
	ChangeVehicleZone(2092, 5797, "parallelstall")

	ChangeVehicleZone(2102, 5797, "parallelstall")
	ChangeVehicleZone(2107, 5797, "parallelstall")
	ChangeVehicleZone(2112, 5797, "parallelstall")
	ChangeVehicleZone(2117, 5797, "parallelstall")
	ChangeVehicleZone(2122, 5797, "parallelstall")
	ChangeVehicleZone(2127, 5797, "parallelstall")
	ChangeVehicleZone(2132, 5797, "parallelstall")
	ChangeVehicleZone(2137, 5797, "parallelstall")
	ChangeVehicleZone(2142, 5797, "parallelstall")
	ChangeVehicleZone(2147, 5797, "parallelstall")
	ChangeVehicleZone(2152, 5797, "parallelstall")
	ChangeVehicleZone(2157, 5797, "parallelstall")
	--END

	ChangeVehicleZone(1617, 5688, "bad")
	ChangeVehicleZone(1667, 5723, "bad")
	ChangeVehicleZone(1654, 5784, "bad")
	ChangeVehicleZone(1656, 5815, "bad")
	ChangeVehicleZone(1654, 5850, "bad")
	ChangeVehicleZone(1602, 5901, "bad")
	ChangeVehicleZone(1566, 5898, "bad")
	ChangeVehicleZone(1560, 5947, "bad")
	ChangeVehicleZone(1570, 5984, "bad")
	ChangeVehicleZone(1621, 5983, "bad")
	ChangeVehicleZone(1651, 5982, "bad")
	ChangeVehicleZone(1565, 6012, "bad")
	ChangeVehicleZone(1600, 6018, "bad")
	ChangeVehicleZone(1671, 6007, "bad")
	ChangeVehicleZone(1716, 6010, "bad")
	ChangeVehicleZone(1737, 6007, "bad")
	ChangeVehicleZone(1758, 6021, "bad")
	ChangeVehicleZone(1758, 6035, "bad")
	ChangeVehicleZone(1861, 6005, "bad")
	ChangeVehicleZone(1878, 6004, "bad")
	ChangeVehicleZone(1560, 6057, "bad")
	ChangeVehicleZone(1560, 6078, "bad")
	ChangeVehicleZone(1647, 6112, "bad")
	ChangeVehicleZone(1680, 6111, "bad")
	ChangeVehicleZone(1735, 6073, "bad")
	ChangeVehicleZone(1738, 6115, "bad")
	ChangeVehicleZone(1760, 6099, "bad")
	ChangeVehicleZone(1827, 6110, "bad")
	ChangeVehicleZone(1861, 6114, "bad")
	ChangeVehicleZone(1910, 6110, "bad")
	ChangeVehicleZone(1858, 6134, "bad")
	ChangeVehicleZone(1903, 6137, "bad")
	ChangeVehicleZone(1857, 6224, "bad")
	ChangeVehicleZone(1951, 6192, "bad")
	ChangeVehicleZone(1952, 6245, "bad")
	ChangeVehicleZone(1646, 6183, "bad")
	ChangeVehicleZone(1687, 6219, "bad")
	ChangeVehicleZone(1735, 6241, "bad")
	ChangeVehicleZone(1796, 6276, "bad")
	ChangeVehicleZone(1829, 6278, "bad")
	ChangeVehicleZone(1872, 6274, "bad")
	ChangeVehicleZone(1895, 6278, "bad")
	ChangeVehicleZone(1909, 6274, "bad")
	ChangeVehicleZone(1949, 6276, "bad")
	ChangeVehicleZone(1911, 5760, "bad")
	ChangeVehicleZone(1926, 5771, "bad")
	ChangeVehicleZone(1878, 5814, "bad")
	ChangeVehicleZone(1951, 5814, "bad")
	ChangeVehicleZone(1951, 5841, "bad")
	ChangeVehicleZone(1951, 5868, "bad")
	ChangeVehicleZone(1952, 5895, "bad")
	ChangeVehicleZone(1978, 5815, "bad")
	ChangeVehicleZone(1978, 5869, "bad")
	ChangeVehicleZone(1978, 5896, "bad")
	ChangeVehicleZone(1951, 5950, "bad")
	ChangeVehicleZone(1954, 5977, "bad")
	ChangeVehicleZone(1951, 6004, "bad")
	ChangeVehicleZone(1951, 6031, "bad")
	ChangeVehicleZone(1951, 6058, "bad")
	ChangeVehicleZone(1951, 6085, "bad")
	ChangeVehicleZone(1979, 6116, "bad")
	ChangeVehicleZone(1998, 6113, "bad")
	ChangeVehicleZone(2047, 6111, "bad")
	ChangeVehicleZone(2073, 6116, "bad")
	
	ChangeVehicleZone(2120, 5914, "bad")
	ChangeVehicleZone(2135, 5914, "bad")
	ChangeVehicleZone(2150, 5914, "bad")
	ChangeVehicleZone(2103, 5936, "bad")
	ChangeVehicleZone(2103, 5951, "bad")
	ChangeVehicleZone(2103, 5966, "bad")
	ChangeVehicleZone(2122, 5944, "bad")
	ChangeVehicleZone(2122, 5959, "bad")
	ChangeVehicleZone(2122, 5974, "bad")
	ChangeVehicleZone(2159, 5943, "bad")
	ChangeVehicleZone(2159, 5958, "bad")
	ChangeVehicleZone(2159, 5973, "bad")
	ChangeVehicleZone(2261, 5910, "bad")
	ChangeVehicleZone(2263, 5934, "bad")
	ChangeVehicleZone(2261, 5958, "bad")
	ChangeVehicleZone(2261, 5981, "bad")
	ChangeVehicleZone(2141, 6014, "bad")
	ChangeVehicleZone(2160, 6013, "bad")
	ChangeVehicleZone(2184, 6014, "bad")
	ChangeVehicleZone(2138, 6036, "bad")
	ChangeVehicleZone(2137, 6059, "bad")
	ChangeVehicleZone(2161, 6040, "bad")
	ChangeVehicleZone(2184, 6040, "bad")
	ChangeVehicleZone(2181, 6058, "bad")
	ChangeVehicleZone(2125, 6079, "bad")
	ChangeVehicleZone(2139, 6096, "bad")
	ChangeVehicleZone(2161, 6096, "bad")
	ChangeVehicleZone(2124, 6213, "bad")
	ChangeVehicleZone(2124, 6233, "bad")
	ChangeVehicleZone(2124, 6253, "bad")
	ChangeVehicleZone(2143, 6251, "bad")
	ChangeVehicleZone(2123, 6273, "bad")
	ChangeVehicleZone(2122, 6295, "bad")
	ChangeVehicleZone(2145, 6295, "bad")
	ChangeVehicleZone(2168, 6295, "bad")

	ChangeVehicleZone(2413, 6492, "bad")
	ChangeVehicleZone(2446, 6493, "bad")
	ChangeVehicleZone(2495, 6500, "bad")
	ChangeVehicleZone(2487, 6395, "bad")
	ChangeVehicleZone(2493, 6322, "bad")
	ChangeVehicleZone(2345, 5864, "bad")
	ChangeVehicleZone(2363, 5863, "bad")
	ChangeVehicleZone(2465, 5853, "bad")
	ChangeVehicleZone(2560, 5849, "bad")
	ChangeVehicleZone(2551, 5779, "bad")
	ChangeVehicleZone(2580, 5743, "bad")
	ChangeVehicleZone(2752, 5903, "bad")
	ChangeVehicleZone(2891, 5808, "bad")
	ChangeVehicleZone(3066, 5993, "bad")
	ChangeVehicleZone(3100, 5787, "bad")
	ChangeVehicleZone(3128, 5766, "bad")
	ChangeVehicleZone(3151, 5925, "bad")

	ChangeVehicleZone(2676, 6388, "trailerpark")
	ChangeVehicleZone(2681, 6350, "trailerpark")
	ChangeVehicleZone(2704, 6302, "trailerpark")
	ChangeVehicleZone(2702, 6341, "trailerpark")
	ChangeVehicleZone(2710, 6367, "trailerpark")
	ChangeVehicleZone(2704, 6383, "trailerpark")
	ChangeVehicleZone(2737, 6320, "trailerpark")
	ChangeVehicleZone(2738, 6327, "trailerpark")
	ChangeVehicleZone(2761, 6318, "trailerpark")
	ChangeVehicleZone(2764, 6342, "trailerpark")

--Ekron
	--WEST SIDE
	ChangeVehicleZone(293, 9821, "good")

	ChangeVehicleZone(309, 9876, "medium")

	ChangeVehicleZone(338, 9842, "bad")
	ChangeVehicleZone(333, 9842, "bad")
	ChangeVehicleZone(333, 9848, "bad")
	ChangeVehicleZone(338, 9851, "bad")

	ChangeVehicleZone(376, 9865, "good")

	ChangeVehicleZone(421, 9841, "bad")
	ChangeVehicleZone(421, 9846, "bad")

	ChangeVehicleZone(368, 9765, "carpenter")
	ChangeVehicleZone(375, 9765, "bad")

	ChangeVehicleZone(375, 9735, "medium")

	ChangeVehicleZone(377, 9705, "good")

	ChangeVehicleZone(381, 9662, "bad")

	ChangeVehicleZone(385, 9643, "medium")

	ChangeVehicleZone(416, 9683, "bad")

	ChangeVehicleZone(391, 9751, "good")

	ChangeVehicleZone(466, 9770, "medium")

	ChangeVehicleZone(481, 9718, "medium")

	ChangeVehicleZone(502, 9796, "medium")

	ChangeVehicleZone(528, 9703, "good")

	ChangeVehicleZone(522, 9577, "bad")
	--END

	--EAST SIDE
	ChangeVehicleZone(562, 9666, "medium")

	ChangeVehicleZone(587, 9721, "bad")
	ChangeVehicleZone(587, 9727, "bad")

	ChangeVehicleZone(604, 9742, "medium")

	ChangeVehicleZone(637, 9693, "bad")

	ChangeVehicleZone(644, 9568, "nil")
	ChangeVehicleZone(647, 9568, "bad")
	ChangeVehicleZone(650, 9568, "bad")
	ChangeVehicleZone(653, 9568, "bad")
	ChangeVehicleZone(656, 9568, "bad")
	ChangeVehicleZone(659, 9568, "bad")
	ChangeVehicleZone(662, 9568, "bad")

	ChangeVehicleZone(670, 9684, "good")

	ChangeVehicleZone(678, 9787, "medium")
	ChangeVehicleZone(678, 9797, "medium")

	ChangeVehicleZone(689, 9724, "medium")

	ChangeVehicleZone(698, 9611, "medium")

	ChangeVehicleZone(712, 9612, "medium")

	ChangeVehicleZone(725, 9667, "medium")

	ChangeVehicleZone(759, 9666, "medium")

	ChangeVehicleZone(802, 9613, "medium")

	ChangeVehicleZone(809, 9496, "trailerpark")

	ChangeVehicleZone(816, 9522, "bad")

	ChangeVehicleZone(853, 9669, "bad")

	ChangeVehicleZone(861, 9683, "nil")
	ChangeVehicleZone(861, 9702, "nil")

	ChangeVehicleZone(905, 9605, "trailerpark")
	ChangeVehicleZone(908, 9609, "trailerpark")
	ChangeVehicleZone(926, 9581, "bad")
	ChangeVehicleZone(926, 9594, "bad")
	ChangeVehicleZone(937, 9609, "bad")
	ChangeVehicleZone(936, 9617, "bad")
	ChangeVehicleZone(929, 9626, "bad")

	ChangeVehicleZone(919, 9905, "good")
	ChangeVehicleZone(921, 9939, "good")
	ChangeVehicleZone(919, 9975, "good")
	--END

--Irvington
	ChangeVehicleZone(1807, 14510, "bad")
	ChangeVehicleZone(1809, 14538, "bad")
	ChangeVehicleZone(1811, 14583, "bad")
	ChangeVehicleZone(1859, 14509, "bad")
	ChangeVehicleZone(1880, 14509, "bad")
	ChangeVehicleZone(1883, 14571, "bad")
	ChangeVehicleZone(1922, 14524, "bad")
	ChangeVehicleZone(1937, 14509, "bad")
	ChangeVehicleZone(1955, 14509, "bad")
	ChangeVehicleZone(1983, 14512, "bad")
	ChangeVehicleZone(1989, 14540, "bad")
	ChangeVehicleZone(1914, 14587, "medium")
	ChangeVehicleZone(1952, 14576, "bad")
	ChangeVehicleZone(1987, 14585, "bad")
	ChangeVehicleZone(1897, 14280, "bad")
	ChangeVehicleZone(1911, 14305, "medium")
	ChangeVehicleZone(1939, 14277, "bad")
	ChangeVehicleZone(1951, 14282, "bad")
	ChangeVehicleZone(1962, 14308, "bad")
	ChangeVehicleZone(1981, 14308, "bad")
	ChangeVehicleZone(1988, 14349, "bad")
	ChangeVehicleZone(2015, 14278, "medium")
	ChangeVehicleZone(2047, 14270, "bad")
	ChangeVehicleZone(2058, 14279, "bad")
	ChangeVehicleZone(2096, 14281, "bad")
	ChangeVehicleZone(2086, 14346, "bad")
	ChangeVehicleZone(2110, 14307, "bad")
	ChangeVehicleZone(2130, 14281, "bad")
	ChangeVehicleZone(2138, 14307, "bad")
	ChangeVehicleZone(2151, 14278, "bad")
	ChangeVehicleZone(2183, 14261, "bad")
	ChangeVehicleZone(2192, 14308, "bad")
	ChangeVehicleZone(2190, 14338, "bad")
	ChangeVehicleZone(1922, 14424, "bad")
	ChangeVehicleZone(1923, 14387, "bad")
	ChangeVehicleZone(1934, 14410, "bad")
	ChangeVehicleZone(1960, 14413, "bad")
	ChangeVehicleZone(1984, 14423, "bad")
	ChangeVehicleZone(1983, 14387, "bad")
	ChangeVehicleZone(2007, 14419, "bad")
	ChangeVehicleZone(2026, 14385, "bad")
	ChangeVehicleZone(2041, 14411, "bad")
	ChangeVehicleZone(2065, 14383, "bad")
	ChangeVehicleZone(2081, 14387, "bad")
	ChangeVehicleZone(2087, 14413, "bad")
	ChangeVehicleZone(2086, 14447, "bad")
	ChangeVehicleZone(2110, 14415, "bad")
	ChangeVehicleZone(2125, 14385, "bad")
	ChangeVehicleZone(2138, 14410, "bad")
	ChangeVehicleZone(2144, 14388, "bad")
	ChangeVehicleZone(2156, 14385, "bad")
	ChangeVehicleZone(2179, 14385, "bad")
	ChangeVehicleZone(2187, 14424, "bad")
	ChangeVehicleZone(2181, 14455, "bad")
	ChangeVehicleZone(1924, 14471, "bad")
	ChangeVehicleZone(1942, 14484, "bad")
	ChangeVehicleZone(1986, 14480, "bad")
	ChangeVehicleZone(2009, 14482, "bad")
	ChangeVehicleZone(2014, 14511, "bad")
	ChangeVehicleZone(2037, 14511, "bad")
	ChangeVehicleZone(2044, 14480, "bad")
	ChangeVehicleZone(2058, 14513, "bad")
	ChangeVehicleZone(2080, 14514, "bad")
	ChangeVehicleZone(2080, 14471, "bad")
	ChangeVehicleZone(2111, 14475, "bad")
	ChangeVehicleZone(2119, 14484, "bad")
	ChangeVehicleZone(2136, 14479, "bad")
	ChangeVehicleZone(2161, 14482, "bad")
	ChangeVehicleZone(2192, 14484, "bad")
	ChangeVehicleZone(1979, 14656, "bad")
	ChangeVehicleZone(1987, 14672, "bad")

	ChangeVehicleZone(2191, 14030, "bad")
	ChangeVehicleZone(2224, 14065, "bad")
	ChangeVehicleZone(2213, 14084, "bad")
	ChangeVehicleZone(2247, 14082, "bad")
	ChangeVehicleZone(2291, 14074, "bad")
	ChangeVehicleZone(2230, 14009, "medium")
	ChangeVehicleZone(2286, 14016, "bad")
	ChangeVehicleZone(2304, 13947, "bad")
	ChangeVehicleZone(2312, 13973, "bad")
	ChangeVehicleZone(2312, 13992, "bad")
	ChangeVehicleZone(2309, 14027, "bad")
	ChangeVehicleZone(2347, 13944, "bad")
	ChangeVehicleZone(2381, 13984, "bad")
	ChangeVehicleZone(2385, 13997, "bad")
	ChangeVehicleZone(2383, 14035, "bad")
	ChangeVehicleZone(2418, 14011, "bad")
	ChangeVehicleZone(2412, 14048, "bad")
	ChangeVehicleZone(2432, 14082, "bad")
	ChangeVehicleZone(2461, 14021, "bad")
	ChangeVehicleZone(2414, 14110, "bad")
	ChangeVehicleZone(2442, 14119, "bad")
	ChangeVehicleZone(2413, 14148, "bad")
	ChangeVehicleZone(2410, 14172, "bad")
	ChangeVehicleZone(2443, 14181, "bad")
	ChangeVehicleZone(2484, 14150, "bad")
	ChangeVehicleZone(2485, 14128, "bad")
	ChangeVehicleZone(2461, 14215, "bad")
	ChangeVehicleZone(2409, 14274, "bad")

	ChangeVehicleZone(2218, 14120, "medium")
	ChangeVehicleZone(2242, 14130, "medium")
	ChangeVehicleZone(2237, 14163, "medium")
	ChangeVehicleZone(2241, 14205, "good")
	ChangeVehicleZone(2241, 14209, "medium")
	ChangeVehicleZone(2241, 14226, "medium")
	ChangeVehicleZone(2217, 14265, "medium")
	ChangeVehicleZone(2243, 14264, "medium")
	ChangeVehicleZone(2261, 14130, "medium")
	ChangeVehicleZone(2287, 14131, "good")
	ChangeVehicleZone(2259, 14170, "good")
	ChangeVehicleZone(2261, 14200, "medium")
	ChangeVehicleZone(2257, 14240, "medium")
	ChangeVehicleZone(2261, 14272, "medium")
	ChangeVehicleZone(2288, 14273, "good")
	ChangeVehicleZone(2313, 14123, "good")
	ChangeVehicleZone(2340, 14123, "medium")
	ChangeVehicleZone(2315, 14169, "medium")
	ChangeVehicleZone(2340, 14168, "medium")
	ChangeVehicleZone(2313, 14195, "medium")
	ChangeVehicleZone(2338, 14196, "medium")
	ChangeVehicleZone(2313, 14230, "good")
	ChangeVehicleZone(2341, 14231, "medium")
	ChangeVehicleZone(2313, 14271, "medium")
	ChangeVehicleZone(2340, 14273, "medium")
	ChangeVehicleZone(2362, 14130, "medium")
	ChangeVehicleZone(2385, 14131, "good")
	ChangeVehicleZone(2360, 14161, "medium")
	ChangeVehicleZone(2385, 14161, "medium")
	ChangeVehicleZone(2359, 14206, "medium")
	ChangeVehicleZone(2384, 14206, "medium")
	ChangeVehicleZone(2361, 14230, "medium")
	ChangeVehicleZone(2387, 14230, "medium")
	ChangeVehicleZone(2361, 14265, "medium")
	ChangeVehicleZone(2386, 14264, "good")

	ChangeVehicleZone(2515, 14110, "bad")
	ChangeVehicleZone(2513, 14149, "bad")
	ChangeVehicleZone(2517, 14170, "bad")
	ChangeVehicleZone(2544, 14181, "bad")
	ChangeVehicleZone(2565, 14109, "bad")
	ChangeVehicleZone(2574, 14116, "bad")
	ChangeVehicleZone(2587, 14153, "bad")
	ChangeVehicleZone(2573, 14178, "bad")
	ChangeVehicleZone(2615, 14109, "bad")
	ChangeVehicleZone(2642, 14110, "bad")
	ChangeVehicleZone(2693, 14117, "bad")
	ChangeVehicleZone(2627, 14181, "bad")
	ChangeVehicleZone(2666, 14183, "bad")
	ChangeVehicleZone(2685, 14166, "bad")
	ChangeVehicleZone(2526, 14218, "bad")
	ChangeVehicleZone(2540, 14217, "bad")
	ChangeVehicleZone(2567, 14216, "bad")
	ChangeVehicleZone(2518, 14271, "bad")
	ChangeVehicleZone(2585, 14282, "bad")
	ChangeVehicleZone(2586, 14255, "bad")
	ChangeVehicleZone(2616, 14210, "bad")
	ChangeVehicleZone(2630, 14229, "bad")
	ChangeVehicleZone(2655, 14240, "bad")
	ChangeVehicleZone(2671, 14212, "bad")
	ChangeVehicleZone(2610, 14250, "bad")
	ChangeVehicleZone(2665, 14278, "bad")
	ChangeVehicleZone(2533, 14309, "bad")
	ChangeVehicleZone(2562, 14312, "bad")
	ChangeVehicleZone(2577, 14311, "bad")
	ChangeVehicleZone(2647, 14310, "bad")
	ChangeVehicleZone(2669, 14308, "medium")

	ChangeVehicleZone(2414, 14381, "bad")
	ChangeVehicleZone(2374, 14403, "bad")
	ChangeVehicleZone(2242, 14556, "bad")
	ChangeVehicleZone(2152, 14642, "bad")
	ChangeVehicleZone(2129, 14660, "bad")
	ChangeVehicleZone(1985, 14798, "medium")
	ChangeVehicleZone(1828, 15117, "medium")
	ChangeVehicleZone(1988, 15039, "bad")
	ChangeVehicleZone(2080, 14826, "bad")
	ChangeVehicleZone(2107, 14798, "bad")
	ChangeVehicleZone(2199, 14817, "bad")
	ChangeVehicleZone(2251, 14853, "bad")
	ChangeVehicleZone(2269, 14834, "bad")
	ChangeVehicleZone(2270, 14756, "bad")
	ChangeVehicleZone(2305, 14798, "bad")
	ChangeVehicleZone(2303, 14722, "bad")
	ChangeVehicleZone(2380, 14721, "bad")
	ChangeVehicleZone(2480, 14619, "medium")
	ChangeVehicleZone(2735, 14937, "bad")
	ChangeVehicleZone(2835, 14937, "bad")
	ChangeVehicleZone(2953, 14943, "medium")
	ChangeVehicleZone(3269, 14890, "bad")

	ChangeVehicleZone(2618, 14525, "bad")
	ChangeVehicleZone(2652, 14525, "bad")
	ChangeVehicleZone(2684, 14526, "bad")
	ChangeVehicleZone(2711, 14526, "bad")
	ChangeVehicleZone(2740, 14527, "bad")
	ChangeVehicleZone(2761, 14525, "bad")
	ChangeVehicleZone(2797, 14526, "bad")
	ChangeVehicleZone(2829, 14528, "bad")
	ChangeVehicleZone(2836, 14559, "bad")
	ChangeVehicleZone(2825, 14601, "bad")
	ChangeVehicleZone(2831, 14615, "bad")
	ChangeVehicleZone(2831, 14636, "bad")
	ChangeVehicleZone(2856, 14527, "bad")
	ChangeVehicleZone(2898, 14528, "bad")
	ChangeVehicleZone(2924, 14525, "bad")
	ChangeVehicleZone(2861, 14572, "bad")
	ChangeVehicleZone(2910, 14574, "bad")
	ChangeVehicleZone(2860, 14605, "bad")
	ChangeVehicleZone(2859, 14621, "bad")
	ChangeVehicleZone(2902, 14604, "bad")
	ChangeVehicleZone(2925, 14603, "bad")
	ChangeVehicleZone(2878, 14647, "bad")
	ChangeVehicleZone(2890, 14647, "bad")
	ChangeVehicleZone(2921, 14656, "bad")
	ChangeVehicleZone(2857, 14685, "bad")
	ChangeVehicleZone(2900, 14675, "bad")
	ChangeVehicleZone(2937, 14672, "bad")
	ChangeVehicleZone(2970, 14710, "bad")
	ChangeVehicleZone(2967, 14651, "medium")
	ChangeVehicleZone(2967, 14616, "bad")
	ChangeVehicleZone(2965, 14597, "bad")
	ChangeVehicleZone(2965, 14561, "bad")
	ChangeVehicleZone(2977, 14528, "bad")
	ChangeVehicleZone(3006, 14527, "bad")
	ChangeVehicleZone(3007, 14560, "bad")
	ChangeVehicleZone(3011, 14610, "bad")
	ChangeVehicleZone(3013, 14654, "bad")
	ChangeVehicleZone(3010, 14670, "bad")
	ChangeVehicleZone(3013, 14714, "bad")
	ChangeVehicleZone(3009, 14757, "bad")
	ChangeVehicleZone(3009, 14823, "bad")
	ChangeVehicleZone(2982, 14835, "bad")
	ChangeVehicleZone(2964, 14826, "medium")
	ChangeVehicleZone(2979, 14853, "bad")
	ChangeVehicleZone(3038, 14823, "bad")
	ChangeVehicleZone(3045, 14774, "bad")
	ChangeVehicleZone(3046, 14735, "bad")
	ChangeVehicleZone(3047, 14688, "bad")
	ChangeVehicleZone(3038, 14616, "bad")
	ChangeVehicleZone(3039, 14591, "bad")
	ChangeVehicleZone(3045, 14560, "bad")
	ChangeVehicleZone(3087, 14589, "bad")
	ChangeVehicleZone(3084, 14625, "bad")
	ChangeVehicleZone(3111, 14616, "bad")
	ChangeVehicleZone(3121, 14578, "bad")
	ChangeVehicleZone(3110, 14550, "bad")

	ChangeVehicleZone(2450, 13867, "bad")
	ChangeVehicleZone(2464, 13867, "bad")
	ChangeVehicleZone(2501, 13864, "bad")
	ChangeVehicleZone(2545, 13864, "bad")
	ChangeVehicleZone(2580, 13867, "bad")
	ChangeVehicleZone(2584, 13901, "bad")
	ChangeVehicleZone(2580, 13937, "bad")
	ChangeVehicleZone(2582, 13964, "bad")
	ChangeVehicleZone(2654, 13870, "bad")
	ChangeVehicleZone(2684, 13869, "bad")
	ChangeVehicleZone(2626, 13919, "bad")
	ChangeVehicleZone(2652, 13920, "bad")
	ChangeVehicleZone(2688, 13916, "bad")
	ChangeVehicleZone(2619, 13942, "bad")
	ChangeVehicleZone(2642, 13944, "bad")
	ChangeVehicleZone(2694, 13946, "bad")
	ChangeVehicleZone(2623, 13998, "bad")
	ChangeVehicleZone(2666, 14010, "bad")
	ChangeVehicleZone(2662, 14044, "bad")
	ChangeVehicleZone(2713, 13864, "bad")
	ChangeVehicleZone(2738, 13902, "bad")
	ChangeVehicleZone(2799, 13904, "bad")
	ChangeVehicleZone(2805, 13863, "bad")
	ChangeVehicleZone(2713, 13942, "bad")
	ChangeVehicleZone(2709, 13965, "bad")
	ChangeVehicleZone(2757, 13930, "bad")
	ChangeVehicleZone(2776, 13969, "bad")
	ChangeVehicleZone(2821, 13963, "bad")
	ChangeVehicleZone(2851, 13943, "bad")
	ChangeVehicleZone(2867, 13856, "bad")

	ChangeVehicleZone(2379, 13790, "bad")
	ChangeVehicleZone(2377, 13760, "bad")
	ChangeVehicleZone(2413, 13719, "bad")
	ChangeVehicleZone(2381, 13674, "bad")
	ChangeVehicleZone(2433, 13523, "bad")
	ChangeVehicleZone(2453, 13469, "bad")
	ChangeVehicleZone(2546, 13736, "bad")
	ChangeVehicleZone(2574, 13676, "bad")
	ChangeVehicleZone(2604, 13647, "bad")
	ChangeVehicleZone(2667, 13587, "bad")
	ChangeVehicleZone(2882, 13412, "bad")
	ChangeVehicleZone(2983, 13458, "bad")
	ChangeVehicleZone(2927, 13258, "bad")
	ChangeVehicleZone(3529, 13476, "bad")
	ChangeVehicleZone(3543, 13484, "bad")
	ChangeVehicleZone(3552, 13484, "bad")
	ChangeVehicleZone(3698, 13442, "bad")
	ChangeVehicleZone(3918, 13763, "bad")
	ChangeVehicleZone(3918, 13826, "bad")
	ChangeVehicleZone(3927, 14087, "bad")

	ChangeVehicleZone(2888, 14312, "bad")
	ChangeVehicleZone(2918, 14315, "bad")
	ChangeVehicleZone(2939, 14318, "bad")
	ChangeVehicleZone(4028, 14476, "bad")
	ChangeVehicleZone(4042, 14470, "bad")
	ChangeVehicleZone(4079, 14519, "bad")
	ChangeVehicleZone(4140, 14531, "bad")
	ChangeVehicleZone(4473, 14469, "bad")
	ChangeVehicleZone(1825, 13441, "bad")

--Echo Creek
	ChangeVehicleZone(3402, 10974, "bad")
	ChangeVehicleZone(3402, 11003, "bad")
	ChangeVehicleZone(3401, 11065, "medium")
	ChangeVehicleZone(3465, 10968, "bad")
	ChangeVehicleZone(3490, 10967, "bad")
	ChangeVehicleZone(3526, 10974, "bad")
	ChangeVehicleZone(3526, 10983, "medium")
	ChangeVehicleZone(3569, 10981, "bad")
	ChangeVehicleZone(3444, 11006, "bad")
	ChangeVehicleZone(3462, 11034, "bad")
	ChangeVehicleZone(3470, 11014, "bad")
	ChangeVehicleZone(3550, 11015, "bad")
	ChangeVehicleZone(3548, 11104, "bad")
	ChangeVehicleZone(3578, 11121, "bad")
	ChangeVehicleZone(3544, 11127, "bad")
	ChangeVehicleZone(3569, 11140, "bad")
	ChangeVehicleZone(3580, 11179, "bad")
	ChangeVehicleZone(3580, 11310, "bad")
	ChangeVehicleZone(3688, 10961, "bad")
	ChangeVehicleZone(3718, 10959, "bad")
	ChangeVehicleZone(3750, 10964, "bad")
	ChangeVehicleZone(3749, 11005, "bad")
	ChangeVehicleZone(3751, 11073, "bad")
	ChangeVehicleZone(4170, 11119, "bad")
	ChangeVehicleZone(4183, 11127, "bad")
	ChangeVehicleZone(4184, 11169, "bad")
	ChangeVehicleZone(4178, 11245, "bad")
	ChangeVehicleZone(4174, 11294, "bad")
	ChangeVehicleZone(4187, 11323, "bad")
	ChangeVehicleZone(4181, 11360, "bad")
	ChangeVehicleZone(4185, 11576, "bad")
	ChangeVehicleZone(4180, 11594, "bad")
	ChangeVehicleZone(4176, 11662, "bad")
	ChangeVehicleZone(4178, 11721, "bad")

	ChangeVehicleZone(3418, 10881, "trailerpark")
	ChangeVehicleZone(3432, 10908, "trailerpark")
	ChangeVehicleZone(3447, 10899, "trailerpark")
	ChangeVehicleZone(3466, 10908, "trailerpark")
	ChangeVehicleZone(3471, 10877, "trailerpark")
	ChangeVehicleZone(3483, 10906, "trailerpark")
	ChangeVehicleZone(3487, 10874, "trailerpark")
	ChangeVehicleZone(3499, 10903, "trailerpark")
	ChangeVehicleZone(3504, 10880, "trailerpark")
	ChangeVehicleZone(3517, 10902, "trailerpark")
	ChangeVehicleZone(3535, 10902, "trailerpark")

--Riverside
	--HOUSE ZONES WERE PROPERLY DEFINIED ACROSS THE ENTIRE TOWN, SOMEHOW
	ChangeVehicleZone(5738, 5247, "medium", nil, nil, nil, 5246)

	ChangeVehicleZone(5755, 5219, "bad")

	ChangeVehicleZone(5740, 5293, "medium")


--Fallas Lake
	--WEST SIDE
	ChangeVehicleZone(7074, 8089, "good")
	ChangeVehicleZone(7053, 8101, "bad")

	ChangeVehicleZone(7124, 8195, "medium")

	ChangeVehicleZone(7094, 8221, "medium")

	ChangeVehicleZone(7093, 8250, "carpenter", nil, nil, 7124, 8277)

	ChangeVehicleZone(7165, 8189, "bad")

	ChangeVehicleZone(7193, 8196, "nil")

	ChangeVehicleZone(7207, 8216, "medium")

	ChangeVehicleZone(7219, 8272, "trailerpark")

	ChangeVehicleZone(7201, 8293, "medium")

	ChangeVehicleZone(7155, 8222, "bad")

	ChangeVehicleZone(7170, 8226, "medium")

	ChangeVehicleZone(7165, 8250, "medium")

	ChangeVehicleZone(7177, 8265, "good", nil, nil, 7205, 8272)

	ChangeVehicleZone(7174, 8292, "medium")

	ChangeVehicleZone(7127, 8274, "bad")

	ChangeVehicleZone(7118, 8288, "medium")

	ChangeVehicleZone(7136, 8325, "medium")

	ChangeVehicleZone(7130, 8346, "bad")

	ChangeVehicleZone(7146, 8361, "good")

	ChangeVehicleZone(7124, 8378, "medium")

	ChangeVehicleZone(7091, 8385, "good")

	ChangeVehicleZone(7201, 8336, "medium")

	ChangeVehicleZone(7202, 8370, "nil")

	ChangeVehicleZone(7193, 8401, "good", nil, 6, 7176, 8399)
	ChangeVehicleZone(7204, 8392, "good")

	ChangeVehicleZone(7228, 8374, "bad")

	ChangeVehicleZone(7241, 8385, "bad")
	ChangeVehicleZone(7242, 8394, "medium")

	ChangeVehicleZone(7184, 8457, "bad", nil, nil, 7184, 8463)

	ChangeVehicleZone(7011, 8454, "medium")

	ChangeVehicleZone(6939, 8557, "medium")
	--END

	--EAST SIDE
	ChangeVehicleZone(7356, 8253, "bad")
	ChangeVehicleZone(7360, 8255, "farm")

	ChangeVehicleZone(7367, 8266, "bad")

	ChangeVehicleZone(7380, 8265, "bad")

	ChangeVehicleZone(7412, 8259, "medium")

	ChangeVehicleZone(7360, 8392, "bad")

	ChangeVehicleZone(7291, 8431, "bad")

	ChangeVehicleZone(7301, 8476, "medium")
	ChangeVehicleZone(7311, 8477, "good")

	ChangeVehicleZone(7314, 8486, "bad")

	ChangeVehicleZone(7302, 8544, "medium")

	ChangeVehicleZone(7351, 8533, "good")
	ChangeVehicleZone(7348, 8547, "medium")

	ChangeVehicleZone(7503, 8501, "medium")
	--END

--Rosewood
	--WEST SIDE
	--Gated Community
	ChangeVehicleZone(7896, 11484, "medium")

	ChangeVehicleZone(7888, 11517, "sport")

	ChangeVehicleZone(7937, 11534, "good", nil, nil, 7938, 11533)

	ChangeVehicleZone(7937, 11546, "medium")
	ChangeVehicleZone(7938, 11561, "medium")
	--END

	ChangeVehicleZone(7939, 11386, "bad")

	ChangeVehicleZone(7991, 11413, "bad")
	ChangeVehicleZone(7995, 11420, "medium")

	ChangeVehicleZone(7912, 11445, "medium")

	ChangeVehicleZone(7937, 11440, "good")
	ChangeVehicleZone(7947, 11445, "medium")

	ChangeVehicleZone(7963, 11452, "medium")
	ChangeVehicleZone(7963, 11464, "medium")

	ChangeVehicleZone(7973, 11460, "medium")

	ChangeVehicleZone(7898, 11495, "nil")

	ChangeVehicleZone(7996, 11566, "bad")

	ChangeVehicleZone(8014, 11605, "bad")

	ChangeVehicleZone(7986, 11732, "bad")
	ChangeVehicleZone(8003, 11750, "trailerpark")

	ChangeVehicleZone(8058, 11397, "bad")

	ChangeVehicleZone(8054, 11420, "junkyard")
	ChangeVehicleZone(8054, 11431, "bad")

	ChangeVehicleZone(8048, 11436, "bad")

	ChangeVehicleZone(8031, 11522, "medium")

	ChangeVehicleZone(8045, 11549, "bad")
	--END
	
	--EAST SIDE
	ChangeVehicleZone(8219, 11539, nil, 6, nil)

	ChangeVehicleZone(8311, 11538, "trailerpark")

	ChangeVehicleZone(8336, 11560, "bad")

	ChangeVehicleZone(8364, 11552, "medium")

	ChangeVehicleZone(8392, 11562, "medium")

	ChangeVehicleZone(8404, 11537, "good")

	ChangeVehicleZone(8429, 11535, "medium")

	ChangeVehicleZone(8440, 11556, "medium")

	ChangeVehicleZone(8468, 11556, "good")
	ChangeVehicleZone(8469, 11563, "medium")

	ChangeVehicleZone(8507, 11548, "good")

	ChangeVehicleZone(8197, 11589, "medium")

	ChangeVehicleZone(8236, 11592, "medium")
	ChangeVehicleZone(8236, 11601, "sport")

	ChangeVehicleZone(8246, 11610, "trailerpark")

	ChangeVehicleZone(8218, 11635, "good")

	ChangeVehicleZone(8245, 11643, "medium")

	ChangeVehicleZone(8271, 11604, "bad")
	ChangeVehicleZone(8277, 11604, "medium")

	ChangeVehicleZone(8297, 11627, "medium")

	ChangeVehicleZone(8277, 11633, "bad")

	ChangeVehicleZone(8278, 11654, "medium")

	ChangeVehicleZone(8190, 11681, "medium")

	ChangeVehicleZone(8226, 11692, "medium")

	ChangeVehicleZone(8237, 11678, "bad")

	ChangeVehicleZone(8252, 11708, "medium")

	ChangeVehicleZone(8226, 11707, "bad")
	ChangeVehicleZone(8226, 11719, "medium")

	ChangeVehicleZone(8280, 11702, "medium")

	ChangeVehicleZone(8284, 11713, "medium")

	ChangeVehicleZone(8310, 11694, "bad")

	ChangeVehicleZone(8338, 11684, "sport")

	ChangeVehicleZone(8318, 11718, "medium")
	ChangeVehicleZone(8350, 11729, "bad")

	ChangeVehicleZone(8349, 11749, "good")

	ChangeVehicleZone(8326, 11788, "bad")
	ChangeVehicleZone(8341, 11802, "trailerpark")

	ChangeVehicleZone(8453, 11745, "good")

	ChangeVehicleZone(8430, 11811, "bad")
	ChangeVehicleZone(8431, 11820, "good")
	--END

	ChangeVehicleZone(8475, 11894, "sport")
	ChangeVehicleZone(8476, 11902, "good")

	ChangeVehicleZone(8476, 11992, "medium")

	ChangeVehicleZone(8413, 12021, "good")
	ChangeVehicleZone(8412, 12029, "sport", nil, nil, 8413, 12028)

	ChangeVehicleZone(8421, 12131, "trailerpark")
	ChangeVehicleZone(8439, 12144, "bad")

	--Farmers Market Area
	ChangeVehicleZone(9158, 12162, "medium")
	ChangeVehicleZone(9182, 12139, "farm")

	ChangeVehicleZone(8890, 12105, "bad")
	ChangeVehicleZone(8966, 12120, "medium")

	ChangeVehicleZone(8801, 11614, "medium")
	--END

	--Farm Houses / Out of Town Houses (other/else)
	ChangeVehicleZone(8016, 11890, "bad")
	ChangeVehicleZone(8032, 11883, "farm")

	ChangeVehicleZone(8078, 11896, "farm")
	ChangeVehicleZone(8078, 11914, "bad")
	ChangeVehicleZone(8076, 11949, "medium")

	ChangeVehicleZone(8134, 11892, "trailerpark")
	ChangeVehicleZone(8144, 11903, "bad")

	ChangeVehicleZone(8154, 12037, "medium")

	ChangeVehicleZone(7985, 12065, "medium")

	ChangeVehicleZone(7924, 12141, "medium")

	ChangeVehicleZone(8090, 12224, "farm")
	ChangeVehicleZone(8115, 12215, "medium")

	ChangeVehicleZone(7524, 12363, "bad")

	ChangeVehicleZone(7575, 12395, "bad")

	ChangeVehicleZone(7690, 12273, "medium")

	ChangeVehicleZone(7978, 12334, "farm")
	ChangeVehicleZone(7984, 12334, "good")

	ChangeVehicleZone(8037, 12404, "medium")

	ChangeVehicleZone(8193, 12377, "farm")

	ChangeVehicleZone(8765, 12426, "bad")
	ChangeVehicleZone(8765, 12432, "farm")

	ChangeVehicleZone(9028, 12381, "medium")

	ChangeVehicleZone(9080, 12427, "good")

--March Ridge
	ChangeVehicleZone(10249, 12626, "bad")
	ChangeVehicleZone(10265, 12627, "bad")
	ChangeVehicleZone(10277, 12626, "bad")
	ChangeVehicleZone(10290, 12626, "bad")
	ChangeVehicleZone(10300, 12627, "bad")
	ChangeVehicleZone(10325, 12628, "bad")
	ChangeVehicleZone(10245, 12673, "bad")
	ChangeVehicleZone(10262, 12672, "bad")
	ChangeVehicleZone(10276, 12673, "bad")
	ChangeVehicleZone(10292, 12673, "bad")
	ChangeVehicleZone(10306, 12672, "bad")
	ChangeVehicleZone(10322, 12672, "bad")

	ChangeVehicleZone(10248, 12685, "bad")
	ChangeVehicleZone(10261, 12686, "bad")
	ChangeVehicleZone(10276, 12686, "bad")
	ChangeVehicleZone(10291, 12685, "bad")
	ChangeVehicleZone(10306, 12685, "bad")
	ChangeVehicleZone(10320, 12686, "bad")
	ChangeVehicleZone(10248, 12734, "bad")
	ChangeVehicleZone(10264, 12734, "bad")
	ChangeVehicleZone(10275, 12733, "bad")
	ChangeVehicleZone(10288, 12733, "bad")
	ChangeVehicleZone(10306, 12733, "bad")
	ChangeVehicleZone(10319, 12734, "bad")

	ChangeVehicleZone(10352, 12632, "bad")
	ChangeVehicleZone(10353, 12643, "bad")
	ChangeVehicleZone(10352, 12666, "bad")
	ChangeVehicleZone(10352, 12695, "bad")
	ChangeVehicleZone(10352, 12709, "bad")
	ChangeVehicleZone(10351, 12725, "bad")
	ChangeVehicleZone(10369, 12647, "bad")
	ChangeVehicleZone(10370, 12664, "bad")
	ChangeVehicleZone(10370, 12696, "bad")
	ChangeVehicleZone(10371, 12710, "bad")
	ChangeVehicleZone(10370, 12725, "bad")
	ChangeVehicleZone(10371, 12756, "bad")
	ChangeVehicleZone(10370, 12771, "bad")
	ChangeVehicleZone(10370, 12788, "bad")

	ChangeVehicleZone(10403, 12670, "bad")
	ChangeVehicleZone(10419, 12672, "bad")
	ChangeVehicleZone(10433, 12671, "bad")
	ChangeVehicleZone(10452, 12672, "bad")
	ChangeVehicleZone(10404, 12686, "bad")
	ChangeVehicleZone(10418, 12686, "bad")
	ChangeVehicleZone(10432, 12686, "bad")
	ChangeVehicleZone(10452, 12687, "bad")
	ChangeVehicleZone(10402, 12732, "bad")
	ChangeVehicleZone(10416, 12732, "bad")
	ChangeVehicleZone(10433, 12732, "bad")
	ChangeVehicleZone(10450, 12732, "bad")
	ChangeVehicleZone(10464, 12732, "bad")
	
	ChangeVehicleZone(9882, 12621, "medium")
	ChangeVehicleZone(9883, 12626, "medium")
	ChangeVehicleZone(9881, 12653, "medium")
	ChangeVehicleZone(9882, 12659, "medium")
	ChangeVehicleZone(9880, 12685, "medium")
	ChangeVehicleZone(9918, 12680, "medium")

	ChangeVehicleZone(9882, 12863, "medium")
	ChangeVehicleZone(9916, 12709, "medium")
	ChangeVehicleZone(9912, 12837, "medium")

	ChangeVehicleZone(9945, 12819, "medium")
	ChangeVehicleZone(9945, 12824, "medium")
	ChangeVehicleZone(9971, 12754, "medium")
	ChangeVehicleZone(9969, 12786, "medium")
	ChangeVehicleZone(9968, 12818, "medium")
	ChangeVehicleZone(9970, 12850, "medium")

	ChangeVehicleZone(10006, 12852, "medium")
	ChangeVehicleZone(10009, 12882, "medium")
	ChangeVehicleZone(10015, 12878, "medium")
	ChangeVehicleZone(10042, 12873, "medium")

	ChangeVehicleZone(9827, 12877, "medium")
	ChangeVehicleZone(9854, 12874, "medium")
	ChangeVehicleZone(9823, 12917, "medium")
	ChangeVehicleZone(9828, 12917, "medium")
	ChangeVehicleZone(9855, 12917, "medium")

	ChangeVehicleZone(9872, 12915, "medium")
	ChangeVehicleZone(9904, 12916, "medium")
	ChangeVehicleZone(9963, 12916, "medium")
	ChangeVehicleZone(9968, 12917, "medium")
	ChangeVehicleZone(9873, 12953, "medium")
	ChangeVehicleZone(9900, 12950, "medium")
	ChangeVehicleZone(9964, 12951, "medium")

	ChangeVehicleZone(9873, 12994, "medium")
	ChangeVehicleZone(9900, 12994, "medium")
	ChangeVehicleZone(9904, 12995, "medium")
	ChangeVehicleZone(9909, 13043, "medium")
	ChangeVehicleZone(9910, 13048, "medium")
	ChangeVehicleZone(9911, 13080, "medium")
	ChangeVehicleZone(9907, 13107, "medium")
	ChangeVehicleZone(9911, 13112, "medium")
	ChangeVehicleZone(9881, 13107, "medium")
	ChangeVehicleZone(9883, 13080, "medium")

	ChangeVehicleZone(9937, 12991, "medium")
	ChangeVehicleZone(9964, 12993, "medium")
	ChangeVehicleZone(9969, 12991, "medium")
	ChangeVehicleZone(9943, 13042, "medium")
	ChangeVehicleZone(9942, 13075, "medium")
	ChangeVehicleZone(9943, 13107, "medium")
	ChangeVehicleZone(9970, 13017, "medium")
	ChangeVehicleZone(9967, 13076, "medium")
	ChangeVehicleZone(9967, 13108, "medium")
	ChangeVehicleZone(9969, 13113, "medium")

	ChangeVehicleZone(10009, 12917, "medium")
	ChangeVehicleZone(10006, 12951, "medium")
	ChangeVehicleZone(10005, 13015, "medium")
	ChangeVehicleZone(10005, 13047, "medium")
	ChangeVehicleZone(10004, 13111, "medium")
	ChangeVehicleZone(10008, 13116, "medium")
	ChangeVehicleZone(10032, 12957, "medium")
	ChangeVehicleZone(10029, 12984, "medium")
	ChangeVehicleZone(10031, 13016, "medium")
	ChangeVehicleZone(10033, 13021, "medium")
	ChangeVehicleZone(10030, 13080, "medium")
	ChangeVehicleZone(10034, 13086, "medium")
	ChangeVehicleZone(10031, 13112, "medium")

--Muldraugh
	ChangeVehicleZone(10823, 9111, "farm")
	ChangeVehicleZone(10823, 9114, "bad", nil, nil, nil, 9115)

	ChangeVehicleZone(10660, 9373, "medium")

	ChangeVehicleZone(10660, 9398, "bad")

	ChangeVehicleZone(10656, 9407, "bad")

	ChangeVehicleZone(10699, 9365, "bad")

	ChangeVehicleZone(10686, 9378, "bad")

	ChangeVehicleZone(10686, 9397, "medium")

	ChangeVehicleZone(10688, 9409, "medium")

	ChangeVehicleZone(10777, 9429, "bad")

	ChangeVehicleZone(10819, 9448, "bad", nil, nil, 10821)

	ChangeVehicleZone(10829, 9412, "bad", nil, nil, 10827, nil)

	ChangeVehicleZone(10839, 9399, "bad", nil, nil, nil, 9401)

	ChangeVehicleZone(10882, 9447, "bad", nil, 6, nil, 9446)

	ChangeVehicleZone(10883, 9411, "bad")

	ChangeVehicleZone(10906, 9394, "bad")

	ChangeVehicleZone(10915, 9416, "bad")

	ChangeVehicleZone(10913, 9444, "bad")

	ChangeVehicleZone(10960, 9372, "bad")

	ChangeVehicleZone(10699, 9458, "bad")

	ChangeVehicleZone(10672, 9489, "bad")

	ChangeVehicleZone(10693, 9493, "medium")

	ChangeVehicleZone(10722, 9491, "bad")

	ChangeVehicleZone(10744, 9485, "bad")

	ChangeVehicleZone(10758, 9493, "medium")

	ChangeVehicleZone(10682, 9518, "bad")

	ChangeVehicleZone(10690, 9524, "bad")

	ChangeVehicleZone(10802, 9493, "bad")

	ChangeVehicleZone(10831, 9467, "bad")

	ChangeVehicleZone(10864, 9502, "bad")

	ChangeVehicleZone(10895, 9476, "bad")

	ChangeVehicleZone(10895, 9498, "bad", nil, nil, nil, 9493)

	ChangeVehicleZone(10827, 9520, "medium")

	ChangeVehicleZone(10950, 9512, "bad")

	ChangeVehicleZone(10958, 9492, "bad")

	ChangeVehicleZone(10975, 9461, "medium", nil, 6)

	ChangeVehicleZone(11025, 9424, "medium")

	--Gated Community #1
	ChangeVehicleZone(10722, 9523, "good")

	ChangeVehicleZone(10713, 9555, "good")

	ChangeVehicleZone(10688, 9554, "good")

	ChangeVehicleZone(10666, 9555, "medium")

	ChangeVehicleZone(10659, 9568, "good")

	ChangeVehicleZone(10682, 9568, "good")

	ChangeVehicleZone(10711, 9568, "good")

	ChangeVehicleZone(10739, 9560, "good")

	ChangeVehicleZone(10740, 9535, "good")
	--END

	ChangeVehicleZone(10668, 9605, "bad")
	ChangeVehicleZone(10667, 9612, "bad")

	ChangeVehicleZone(10691, 9616, "bad")

	ChangeVehicleZone(10759, 9620, "medium")

	ChangeVehicleZone(10775, 9665, "medium")
	ChangeVehicleZone(10775, 9669, "medium")

	ChangeVehicleZone(10771, 9706, "medium")

	ChangeVehicleZone(10772, 9726, "bad", nil, nil, 10773, 9725)

	ChangeVehicleZone(10785, 9765, "bad")

	ChangeVehicleZone(10828, 9754, "farm", nil, 11, nil, 9749)

	--Trailer Park Area
	ChangeVehicleZone(10891, 9638, "bad")

	ChangeVehicleZone(10880, 9668, "bad", nil, nil, 10884, 9669)

	ChangeVehicleZone(10890, 9687, "bad")

	ChangeVehicleZone(10889, 9699, "bad")

	ChangeVehicleZone(10889, 9718, "bad")

	ChangeVehicleZone(10914, 9640, "bad")

	ChangeVehicleZone(10915, 9672, "bad")

	ChangeVehicleZone(10903, 9681, "bad")

	ChangeVehicleZone(10943, 9675, "bad")

	ChangeVehicleZone(10955, 9678, "bad")

	ChangeVehicleZone(10971, 9673, "bad")

	ChangeVehicleZone(10951, 9693, "bad")

	ChangeVehicleZone(10970, 9693, "bad", nil, nil, nil, 9694)

	ChangeVehicleZone(10987, 9693, "bad")

	ChangeVehicleZone(10938, 9733, "bad")

	ChangeVehicleZone(10989, 9726, "bad")

	ChangeVehicleZone(10946, 9761, "bad")

	ChangeVehicleZone(10960, 9757, "bad")

	ChangeVehicleZone(10939, 9780, "bad")

	ChangeVehicleZone(10960, 9778, "bad")
	--END

	ChangeVehicleZone(10650, 9671, "bad")

	ChangeVehicleZone(10651, 9702, "bad")

	ChangeVehicleZone(10658, 9712, "bad")

	ChangeVehicleZone(10684, 9648, "medium")

	ChangeVehicleZone(10685, 9671, "medium", nil, nil, 10686, 9672)

	ChangeVehicleZone(10686, 9684, "bad", nil, nil, 10688, nil)

	ChangeVehicleZone(10660, 9747, "bad")

	ChangeVehicleZone(10675, 9779, "bad")

	ChangeVehicleZone(10703, 9771, "bad")

	ChangeVehicleZone(10683, 9793, "bad")

	ChangeVehicleZone(10720, 9754, "bad")

	ChangeVehicleZone(10732, 9774, "bad")

	ChangeVehicleZone(10735, 9815, "bad")

	ChangeVehicleZone(10773, 9797, "medium")

	ChangeVehicleZone(10757, 9844, "medium")

	ChangeVehicleZone(10779, 9840, "medium")

	ChangeVehicleZone(10844, 9794, "bad")

	ChangeVehicleZone(10839, 9857, "bad")

	ChangeVehicleZone(10890, 9851, "bad")

	ChangeVehicleZone(10672, 9869, "bad")

	ChangeVehicleZone(10685, 9870, "bad")

	ChangeVehicleZone(10698, 9871, "bad")

	ChangeVehicleZone(10683, 9891, "bad")

	ChangeVehicleZone(10692, 9897, "bad")

	ChangeVehicleZone(10682, 9915, "bad")

	ChangeVehicleZone(10678, 9932, "bad", nil, nil, 10677, nil)

	ChangeVehicleZone(10710, 9917, "bad")

	ChangeVehicleZone(10722, 9891, "bad")

	ChangeVehicleZone(10774, 9867, "bad", nil, nil, nil, 9871)
	ChangeVehicleZone(10771, 9870, "bad", nil, nil, nil, 9871)

	ChangeVehicleZone(10752, 9886, "bad")

	ChangeVehicleZone(10749, 9904, "bad")

	ChangeVehicleZone(10777, 9924, "bad")
	ChangeVehicleZone(10777, 9930, "medium")

	ChangeVehicleZone(10861, 9883, "bad")

	ChangeVehicleZone(10861, 9934, "bad")

	ChangeVehicleZone(10862, 9954, "bad")

	ChangeVehicleZone(10877, 9892, "bad")

	ChangeVehicleZone(10880, 9912, "bad")

	ChangeVehicleZone(10879, 9936, "bad")

	ChangeVehicleZone(10874, 9961, "bad")

	ChangeVehicleZone(10681, 9963, "medium")

	ChangeVehicleZone(10714, 9953, "bad")

	ChangeVehicleZone(10720, 9982, "bad")

	ChangeVehicleZone(10743, 9984, "bad")

	ChangeVehicleZone(10657, 10030, "bad")

	ChangeVehicleZone(10661, 10048, "nil")
	ChangeVehicleZone(10667, 10049, "bad")

	ChangeVehicleZone(10718, 10024, "bad", nil, nil, nil, 10025)

	ChangeVehicleZone(10727, 10025, "bad")

	ChangeVehicleZone(10683, 10045, "medium")

	ChangeVehicleZone(10702, 10057, "trailerpark")

	ChangeVehicleZone(10727, 10054, "bad", nil, nil, nil, 10046)

	ChangeVehicleZone(10774, 9950, "bad")

	ChangeVehicleZone(10767, 9986, "medium")

	ChangeVehicleZone(10792, 9994, "medium")

	ChangeVehicleZone(10819, 9980, "medium")

	ChangeVehicleZone(10815, 10016, "parallelstall")	--random business house

	ChangeVehicleZone(10778, 10015, "bad")

	ChangeVehicleZone(10778, 10034, "medium")

	ChangeVehicleZone(10810, 10045, "medium")

	ChangeVehicleZone(10872, 9991, "bad", nil, nil, 10873, 9992)

	ChangeVehicleZone(10902, 9992, "bad")

	ChangeVehicleZone(10901, 10016, "trailerpark")

	ChangeVehicleZone(10899, 10035, "bad")

	ChangeVehicleZone(10656, 10085, "bad")

	ChangeVehicleZone(10662, 10089, "bad")

	ChangeVehicleZone(10679, 10112, "bad")

	ChangeVehicleZone(10652, 10115, "medium")

	ChangeVehicleZone(10656, 10147, "bad", 6, nil, nil, 10146)
	ChangeVehicleZone(10673, 10152, "farm")

	ChangeVehicleZone(10695, 10083, "medium")

	ChangeVehicleZone(10710, 10073, "medium")

	ChangeVehicleZone(10729, 10079, "medium")

	ChangeVehicleZone(10757, 10102, "bad")

	ChangeVehicleZone(10756, 10123, "bad")

	ChangeVehicleZone(10771, 10129, "bad")

	ChangeVehicleZone(10788, 10115, "bad")
	ChangeVehicleZone(10817, 10108, "farm")

	ChangeVehicleZone(10769, 10088, "bad")

	ChangeVehicleZone(10777, 10092, "good")

	ChangeVehicleZone(10793, 10057, "bad")

	ChangeVehicleZone(10805, 10058, "bad")

	--Gated Community #2
	ChangeVehicleZone(10879, 10091, "good")

	ChangeVehicleZone(10882, 10117, "good")

	ChangeVehicleZone(10906, 10127, "good")

	ChangeVehicleZone(10884, 10147, "good")

	ChangeVehicleZone(10846, 10142, "good")

	ChangeVehicleZone(10846, 10177, "medium", nil, 6, 10844, nil)

	ChangeVehicleZone(10863, 10186, nil, nil, nil, 10864, 10187)
	--END

	ChangeVehicleZone(10656, 10176, "medium")

	ChangeVehicleZone(10675, 10178, "medium")

	ChangeVehicleZone(10695, 10163, "medium")

	ChangeVehicleZone(10712, 10165, "bad")

	ChangeVehicleZone(10710, 10193, "bad")

	ChangeVehicleZone(10710, 10206, "bad")

	ChangeVehicleZone(10688, 10215, "medium")

	ChangeVehicleZone(10666, 10216, "medium")

	ChangeVehicleZone(10653, 10217, "medium")

	ChangeVehicleZone(10650, 10231, "medium", nil, nil, 10651, nil)

	ChangeVehicleZone(10666, 10245, "medium", nil, nil, nil, 10240)

	ChangeVehicleZone(10684, 10232, "medium", nil, nil, nil, 10229)

	ChangeVehicleZone(10726, 10228, "parallelstall")

	ChangeVehicleZone(10644, 10272, "bad")

	ChangeVehicleZone(10663, 10276, "bad")

	ChangeVehicleZone(10697, 10277, "medium", nil, nil, nil, 10271)

	ChangeVehicleZone(10709, 10271, "bad", nil, nil, nil, 10273)

	ChangeVehicleZone(10665, 10291, "bad")

	ChangeVehicleZone(10671, 10296, "medium")

	ChangeVehicleZone(10690, 10294, "medium")

	ChangeVehicleZone(10723, 10288, "bad")

	ChangeVehicleZone(10649, 10321, "bad")

	ChangeVehicleZone(10655, 10329, "bad")

	ChangeVehicleZone(10644, 10356, "bad", nil, nil, 10643, 10354)

	ChangeVehicleZone(10664, 10357, "bad")

	ChangeVehicleZone(10745, 10215, "medium", nil, 12, nil, 10210)

	ChangeVehicleZone(10779, 10215, "medium")

	ChangeVehicleZone(10752, 10235, "medium")

	ChangeVehicleZone(10769, 10231, "medium")

	ChangeVehicleZone(10773, 10260, "bad")

	ChangeVehicleZone(10757, 10289, "bad")

	ChangeVehicleZone(10766, 10289, "bad")

	ChangeVehicleZone(10775, 10298, "wtfisthis")

	ChangeVehicleZone(10842, 10245, "bad")

	ChangeVehicleZone(10865, 10238, "bad")

	ChangeVehicleZone(10860, 10284, "bad")

	ChangeVehicleZone(10832, 10293, "bad")

	ChangeVehicleZone(10820, 10305, "bad")

	--Behind PD Area
	ChangeVehicleZone(10661, 10374, "bad")

	ChangeVehicleZone(10677, 10383, "bad")

	ChangeVehicleZone(10686, 10411, "bad")

	ChangeVehicleZone(10687, 10423, "bad")

	ChangeVehicleZone(10689, 10444, "bad")

	ChangeVehicleZone(10668, 10452, "bad")

	ChangeVehicleZone(10676, 10464, "bad")

	ChangeVehicleZone(10694, 10471, "bad")

	ChangeVehicleZone(10700, 10473, "bad")
	--END

	ChangeVehicleZone(10720, 10520, "bad")

	ChangeVehicleZone(10722, 10529, "bad")

	ChangeVehicleZone(10721, 10574, "bad")

	ChangeVehicleZone(10729, 10628, "bad")

	ChangeVehicleZone(10750, 10628, "bad")

	ChangeVehicleZone(10757, 10622, "bad")

--West Point
	ChangeVehicleZone(10930, 6653, "bad")

	ChangeVehicleZone(10971, 6653, "bad")

	ChangeVehicleZone(11022, 6718, "bad")

	ChangeVehicleZone(11045, 6718, "bad")

	ChangeVehicleZone(11166, 6753, "farm")
	ChangeVehicleZone(11180, 6739, "bad")

	ChangeVehicleZone(11150, 6719, "medium")

	ChangeVehicleZone(11199, 6695, "bad")

	ChangeVehicleZone(11209, 6736, "bad")

	ChangeVehicleZone(11222, 6776, "bad", nil, nil, 11217, 6777)

	ChangeVehicleZone(11224, 6783, "bad")

	ChangeVehicleZone(11222, 6849, "bad")

	ChangeVehicleZone(11221, 6855, "bad")

	ChangeVehicleZone(11244, 6773, "bad")

	ChangeVehicleZone(11241, 6779, "bad")

	ChangeVehicleZone(11243, 6824, "medium")

	ChangeVehicleZone(11238, 6869, "bad")

	ChangeVehicleZone(11136, 6875, "medium", nil, 6)

	ChangeVehicleZone(11186, 6875, "medium", nil, 6, nil, 6874)

	ChangeVehicleZone(11298, 6672, "bad")

	ChangeVehicleZone(11319, 6664, "bad")

	ChangeVehicleZone(11340, 6658, "bad")

	ChangeVehicleZone(11419, 6675, "bad")

	ChangeVehicleZone(11437, 6673, "bad")

	ChangeVehicleZone(11504, 6709, "bad")

	ChangeVehicleZone(11512, 6735, "medium")

	ChangeVehicleZone(11295, 6715, "bad")

	ChangeVehicleZone(11310, 6730, "bad")

	ChangeVehicleZone(11395, 6731, "bad")

	ChangeVehicleZone(11406, 6731, "medium")

	ChangeVehicleZone(11429, 6734, "bad")

	ChangeVehicleZone(11485, 6769, "bad")

	ChangeVehicleZone(11491, 6803, "medium")

	ChangeVehicleZone(11442, 6834, "bad")

	ChangeVehicleZone(11513, 6841, "medium")

	ChangeVehicleZone(11465, 6874, "medium")

	ChangeVehicleZone(11492, 6880, "bad")

	ChangeVehicleZone(11501, 6883, "medium")

	ChangeVehicleZone(11288, 6861, "medium")

	ChangeVehicleZone(11320, 6863, "bad")

	ChangeVehicleZone(11359, 6857, "medium")

	ChangeVehicleZone(11384, 6861, "medium")

	ChangeVehicleZone(11385, 6875, "bad", nil, nil, 11386, 6877)

	ChangeVehicleZone(11344, 6879, "bad")

	ChangeVehicleZone(11333, 6878, "bad")

	ChangeVehicleZone(11293, 6880, "bad")

	ChangeVehicleZone(11288, 6881, "medium")

	ChangeVehicleZone(11421, 6913, "bad")

	ChangeVehicleZone(11443, 6918, "bad", nil, nil, 11444, 6917)

	ChangeVehicleZone(11490, 6915, "bad")

	ChangeVehicleZone(11514, 6911, "sport")

	ChangeVehicleZone(11538, 6911, "medium")

	ChangeVehicleZone(11419, 6938, "medium")

	ChangeVehicleZone(11445, 6929, "bad", 6, nil, 11442, nil)

	ChangeVehicleZone(11465, 6929, "bad")

	ChangeVehicleZone(11474, 6933, "medium")

	ChangeVehicleZone(11498, 6934, "medium")

	ChangeVehicleZone(11524, 6931, "bad")

	ChangeVehicleZone(11422, 7030, "bad")

	ChangeVehicleZone(11430, 7039, "farm")

	ChangeVehicleZone(11436, 6999, "bad", 12, nil, 11437, 6998)

	ChangeVehicleZone(11438, 6979, "bad")

	ChangeVehicleZone(11439, 6970, "bad", nil, 6, nil, 6968)

	ChangeVehicleZone(11489, 6971, "medium")

	ChangeVehicleZone(11513, 6962, "bad")

	ChangeVehicleZone(11531, 6962, "good")

	ChangeVehicleZone(11471, 6984, "bad")

	ChangeVehicleZone(11505, 6992, "bad", 6, nil)

	ChangeVehicleZone(11563, 6960, "bad")

	ChangeVehicleZone(11547, 7013, "bad")

	ChangeVehicleZone(11548, 7033, "medium")

	ChangeVehicleZone(11563, 7036, "bad")

	ChangeVehicleZone(11590, 7003, "bad")

	ChangeVehicleZone(11590, 6981, "bad")

	ChangeVehicleZone(11590, 6971, "bad")

	ChangeVehicleZone(11313, 6925, "nil")

	ChangeVehicleZone(11366, 6964, "farm", nil, nil, 11368, nil)

	ChangeVehicleZone(11371, 7016, "bad", nil, 6, 11376, 7022)

	ChangeVehicleZone(11406, 7068, "bad")

	ChangeVehicleZone(11443, 7054, "bad")

	ChangeVehicleZone(11471, 7041, "medium")

	ChangeVehicleZone(11535, 7067, "nil")

	ChangeVehicleZone(11567, 7061, "bad")

	ChangeVehicleZone(11605, 7023, "bad", nil, nil, 11615, 7017)
	ChangeVehicleZone(11608, 7027, "bad", nil, 6, nil, 7024)

	ChangeVehicleZone(11618, 6997, "bad")

	ChangeVehicleZone(11612, 6962, "good", nil, nil, 11615, 6962)

	ChangeVehicleZone(11652, 6969, "medium")

	ChangeVehicleZone(11669, 6977, "bad")
	ChangeVehicleZone(11675, 6977, "bad")

	ChangeVehicleZone(11674, 7004, "good")

	ChangeVehicleZone(11708, 6978, "medium", nil, 6, 11710, 6976)

	ChangeVehicleZone(11716, 7004, "medium", nil, nil, 11717, nil)

	ChangeVehicleZone(11575, 6915, "medium")

	ChangeVehicleZone(11583, 6915, "medium", nil, nil, nil, 6916)

	ChangeVehicleZone(11602, 6914, "medium")

	ChangeVehicleZone(11573, 6933, "bad")

	ChangeVehicleZone(11583, 6937, "bad")

	ChangeVehicleZone(11601, 6935, "bad")

	ChangeVehicleZone(11649, 6915, "medium")

	ChangeVehicleZone(11669, 6913, "bad")

	ChangeVehicleZone(11688, 6916, "bad")

	ChangeVehicleZone(11637, 6933, "bad")

	ChangeVehicleZone(11656, 6931, "medium")

	ChangeVehicleZone(11687, 6933, "bad", nil, nil, 11688, 6931)

	ChangeVehicleZone(11578, 6851, "bad", nil, nil, 11579, 6853)
	ChangeVehicleZone(11578, 6843, "carpenter")

	ChangeVehicleZone(11603, 6853, "bad")

	ChangeVehicleZone(11622, 6846, "bad")

	ChangeVehicleZone(11643, 6848, "bad")

	ChangeVehicleZone(11662, 6851, "bad")

	ChangeVehicleZone(11669, 6854, "bad")

	ChangeVehicleZone(11578, 6875, "medium")

	ChangeVehicleZone(11604, 6879, "bad")

	ChangeVehicleZone(11625, 6878, "bad")

	ChangeVehicleZone(11652, 6875, "bad")

	ChangeVehicleZone(11659, 6881, "bad")

	ChangeVehicleZone(11681, 6883, "bad")

	ChangeVehicleZone(11569, 6778, "bad")

	ChangeVehicleZone(11560, 6797, "bad")

	ChangeVehicleZone(11562, 6804, "medium")

	ChangeVehicleZone(11606, 6774, "bad", nil, nil, nil, 6772)

	ChangeVehicleZone(11649, 6785, "medium")

	ChangeVehicleZone(11671, 6784, "medium")

	ChangeVehicleZone(11682, 6797, "bad", nil, nil, 11685, nil)

	ChangeVehicleZone(11610, 6815, "medium")

	ChangeVehicleZone(11636, 6818, "medium")

	ChangeVehicleZone(11642, 6818, "medium")

	ChangeVehicleZone(11610, 6733, "medium")

	ChangeVehicleZone(11605, 6688, "bad")

	ChangeVehicleZone(11643, 6656, "bad")

	ChangeVehicleZone(11659, 6695, "medium")

	ChangeVehicleZone(11632, 6704, "bad")

	ChangeVehicleZone(11635, 6716, "bad")

	ChangeVehicleZone(11626, 6727, "farm")

	ChangeVehicleZone(11656, 6753, "bad")

	ChangeVehicleZone(11680, 6754, "bad")

	ChangeVehicleZone(11665, 6730, "medium")

	ChangeVehicleZone(11722, 6694, "bad")

	ChangeVehicleZone(11741, 6692, "bad")

	ChangeVehicleZone(11757, 6665, "bad")
	ChangeVehicleZone(11757, 6673, "medium")

	ChangeVehicleZone(11788, 6667, "medium")

	ChangeVehicleZone(11828, 6682, "medium")
	ChangeVehicleZone(11828, 6689, "bad")

	ChangeVehicleZone(11871, 6693, "bad")

	ChangeVehicleZone(11882, 6690, "bad")

	ChangeVehicleZone(11904, 6694, "medium")

	ChangeVehicleZone(11929, 6730, "medium")

	ChangeVehicleZone(11952, 6754, "bad")

	ChangeVehicleZone(11971, 6756, "bad")

	ChangeVehicleZone(11996, 6747, "bad")

	ChangeVehicleZone(12038, 6741, "good")

	ChangeVehicleZone(12054, 6740, "good")

	ChangeVehicleZone(11727, 6737, "bad")

	ChangeVehicleZone(11732, 6758, "bad")

	ChangeVehicleZone(11756, 6724, "bad")

	ChangeVehicleZone(11833, 6729, "medium")

	ChangeVehicleZone(11770, 6760, "bad")

	ChangeVehicleZone(11794, 6753, "bad")

	ChangeVehicleZone(11833, 6746, "medium", nil, nil, 11832, nil)

	ChangeVehicleZone(11856, 6720, "bad")

	ChangeVehicleZone(11857, 6736, "bad")

	ChangeVehicleZone(11857, 6754, "bad")

	ChangeVehicleZone(11899, 6737, "bad")

	ChangeVehicleZone(11907, 6752, "bad")

	ChangeVehicleZone(11733, 6788, "bad")

	ChangeVehicleZone(11732, 6815, "medium")

	ChangeVehicleZone(11754, 6823, "medium")

	ChangeVehicleZone(11758, 6785, "medium")

	ChangeVehicleZone(11732, 6855, "medium")

	ChangeVehicleZone(11720, 6873, "medium")

	ChangeVehicleZone(11750, 6860, "bad")

	ChangeVehicleZone(11787, 6977, "medium")

	ChangeVehicleZone(11843, 6981, "good")

	ChangeVehicleZone(11856, 6985, "medium")

	ChangeVehicleZone(11900, 7001, "bad")
	ChangeVehicleZone(11907, 7003, "bad")

	ChangeVehicleZone(11905, 7021, "medium")

	ChangeVehicleZone(11875, 7027, "medium")

	ChangeVehicleZone(11855, 7046, "good")

	ChangeVehicleZone(11875, 7068, "medium")

	ChangeVehicleZone(11900, 7063, "bad")

	ChangeVehicleZone(11910, 7058, "medium")

	ChangeVehicleZone(11943, 7042, "good")

	ChangeVehicleZone(11978, 7059, "bad")

	ChangeVehicleZone(11980, 7071, "medium", 6, nil, 11979, 7070)

	ChangeVehicleZone(12014, 7075, "medium", nil, 6, 12015, 7074)

	ChangeVehicleZone(12020, 7049, "medium")

	ChangeVehicleZone(12015, 7026, "bad", nil, 6, 12014, 7023)

	ChangeVehicleZone(12012, 7002, "bad")

	ChangeVehicleZone(12010, 6979, "bad")

--Valley Station
	ChangeVehicleZone(12492, 5049, "trailerpark")
	ChangeVehicleZone(12507, 5056, "trailerpark")
	ChangeVehicleZone(12503, 5081, "trailerpark")

	ChangeVehicleZone(12504, 5140, "bad")
	ChangeVehicleZone(12516, 5141, "bad")
	ChangeVehicleZone(12551, 5140, "bad")
	ChangeVehicleZone(12573, 5140, "bad")
	ChangeVehicleZone(12581, 5139, "bad")
	ChangeVehicleZone(12604, 5141, "bad")
	ChangeVehicleZone(12509, 5178, "bad")
	ChangeVehicleZone(12528, 5177, "bad")
	ChangeVehicleZone(12540, 5178, "bad")
	ChangeVehicleZone(12592, 5178, "bad")
	ChangeVehicleZone(12600, 5177, "bad")

	ChangeVehicleZone(12590, 5213, "bad")
	ChangeVehicleZone(12602, 5212, "bad")
	ChangeVehicleZone(12623, 5219, "bad")
	ChangeVehicleZone(12593, 5250, "bad")
	ChangeVehicleZone(12605, 5251, "bad")
	ChangeVehicleZone(12623, 5250, "bad")
	ChangeVehicleZone(12588, 5290, "bad")
	ChangeVehicleZone(12587, 5298, "bad")
	ChangeVehicleZone(12584, 5331, "bad")
	ChangeVehicleZone(12639, 5365, "bad")

	ChangeVehicleZone(12633, 5444, "bad")
	ChangeVehicleZone(12574, 5449, "bad")
	ChangeVehicleZone(12585, 5457, "bad")
	ChangeVehicleZone(12588, 5475, "bad")
	ChangeVehicleZone(12640, 5529, "bad")
	ChangeVehicleZone(12591, 5539, "bad")
	ChangeVehicleZone(12635, 5560, "bad")
	ChangeVehicleZone(12586, 5561, "bad")
	ChangeVehicleZone(12638, 5603, "bad")
	ChangeVehicleZone(12565, 5628, "medium")
	ChangeVehicleZone(12623, 5642, "medium")
	ChangeVehicleZone(12570, 5659, "bad")
	ChangeVehicleZone(12572, 5674, "bad")
	ChangeVehicleZone(12627, 5682, "bad")
	ChangeVehicleZone(12619, 5691, "bad")
	ChangeVehicleZone(12610, 5739, "bad")
	ChangeVehicleZone(12631, 5737, "bad")
	ChangeVehicleZone(12639, 5722, "bad")

	ChangeVehicleZone(12640, 5787, "bad")
	ChangeVehicleZone(12612, 5793, "bad")
	ChangeVehicleZone(12569, 5847, "bad")
	ChangeVehicleZone(12575, 5882, "bad")
	ChangeVehicleZone(12580, 5920, "bad")
	ChangeVehicleZone(12580, 5965, "bad")
	
	ChangeVehicleZone(12750, 4952, "trailerpark")
	ChangeVehicleZone(12775, 4991, "trailerpark")
	
	ChangeVehicleZone(13050, 5151, "bad")
	ChangeVehicleZone(13058, 5147, "medium")
	ChangeVehicleZone(13050, 5197, "bad")
	ChangeVehicleZone(13051, 5223, "bad")
	ChangeVehicleZone(13052, 5243, "bad")
	ChangeVehicleZone(13046, 5254, "bad")
	
	ChangeVehicleZone(14031, 4944, "bad")
	ChangeVehicleZone(14054, 4935, "bad")
	ChangeVehicleZone(14129, 4948, "bad")
	ChangeVehicleZone(14055, 5018, "bad")
	ChangeVehicleZone(14015, 5020, "bad")
	ChangeVehicleZone(14027, 5064, "bad")
	ChangeVehicleZone(14029, 5081, "bad")
	ChangeVehicleZone(14112, 5023, "medium")
	ChangeVehicleZone(14114, 5084, "medium")

	ChangeVehicleZone(13881, 5477, "good")
	ChangeVehicleZone(13898, 5476, "medium")
	ChangeVehicleZone(13918, 5475, "medium")
	ChangeVehicleZone(13936, 5475, "medium")
	ChangeVehicleZone(13945, 5475, "medium")
	ChangeVehicleZone(13886, 5520, "medium")
	ChangeVehicleZone(13919, 5520, "good")
	ChangeVehicleZone(13938, 5519, "medium")
	ChangeVehicleZone(13946, 5521, "medium")

	ChangeVehicleZone(14011, 5476, "medium")
	ChangeVehicleZone(14030, 5477, "medium")
	ChangeVehicleZone(14049, 5477, "medium")
	ChangeVehicleZone(14057, 5477, "medium")
	ChangeVehicleZone(14006, 5517, "good")
	ChangeVehicleZone(14014, 5517, "medium")
	ChangeVehicleZone(14046, 5517, "medium")
	ChangeVehicleZone(14054, 5518, "medium")
	ChangeVehicleZone(14072, 5516, "medium")

	ChangeVehicleZone(14081, 5563, "medium")
	ChangeVehicleZone(14080, 5572, "good")
	ChangeVehicleZone(14123, 5547, "medium")
	ChangeVehicleZone(14122, 5571, "medium")
	ChangeVehicleZone(14123, 5579, "good")

--Modded Replacements
	if activatedMods:contains("87fordB700") then
		ChangeVehicleZone(2066, 6243, "nil")

		ChangeVehicleZone(13074, 1772, "nil")

		ChangeVehicleZone(13017, 3109, "nil")

		ChangeVehicleZone(13562, 2824, "nil")

		ChangeVehicleZone(12732, 2139, "nil")

		ChangeVehicleZone(6500, 5309, "nil")

		ChangeVehicleZone(11898, 6926, "special_banktruck")

		ChangeVehicleZone(10655, 9316, "nil")
		ChangeVehicleZone(10662, 9316, "nil")
	else
		ChangeVehicleZone(2066, 6243, "parkingstall")
	end

--	if activatedMods:contains("isoContainers") then
--		ChangeVehicleZone(00000, 00000, "special_kntnrs")
--	end

--Junkyards
--Brandenburg
	ChangeVehicleZone(2088, 5886, "carpenter")

	ChangeVehicleZone(2087, 6542, "carpenter")
	ChangeVehicleZone(2063, 6552, "carpenter")

	ChangeVehicleZone(2120, 6438, "carpenter")
	ChangeVehicleZone(2131, 6440, "carpenter")

	ChangeVehicleZone(2219, 6449, "parkingstall")
	ChangeVehicleZone(2291, 6453, "parkingstall")
	ChangeVehicleZone(2278, 6477, "carpenter")

	ChangeVehicleZone(2173, 6607, "junkyard")
	ChangeVehicleZone(2122, 6615, "junkyard")
	ChangeVehicleZone(2198, 6621, "junkyard")
	ChangeVehicleZone(2164, 6623, "junkyard")
	ChangeVehicleZone(2110, 6630, "junkyard")
	ChangeVehicleZone(2139, 6632, "junkyard")
	ChangeVehicleZone(2233, 6637, "junkyard")
	ChangeVehicleZone(2181, 6637, "junkyard")
	ChangeVehicleZone(2178, 6638, "junkyard")
	ChangeVehicleZone(2213, 6639, "junkyard")
	ChangeVehicleZone(2193, 6645, "junkyard")
	ChangeVehicleZone(2159, 6650, "junkyard")
	ChangeVehicleZone(2215, 6651, "junkyard")
	ChangeVehicleZone(2156, 6665, "junkyard")
	ChangeVehicleZone(2206, 6676, "junkyard")
	ChangeVehicleZone(2128, 6684, "junkyard")
	ChangeVehicleZone(2171, 6685, "junkyard")
	ChangeVehicleZone(2193, 6686, "junkyard")
	ChangeVehicleZone(2231, 6689, "junkyard")
	ChangeVehicleZone(2119, 6697, "junkyard")
	ChangeVehicleZone(2148, 6704, "junkyard")
	ChangeVehicleZone(2203, 6705, "junkyard")
	ChangeVehicleZone(2128, 6715, "junkyard")
	ChangeVehicleZone(2127, 6729, "junkyard")
	ChangeVehicleZone(2143, 6747, "junkyard")
	ChangeVehicleZone(2116, 6757, "junkyard")
	ChangeVehicleZone(2170, 6772, "junkyard")
	ChangeVehicleZone(2226, 6773, "junkyard")
	ChangeVehicleZone(2149, 6774, "junkyard")
	ChangeVehicleZone(2107, 6790, "junkyard")
	ChangeVehicleZone(2122, 6818, "junkyard")

--Ekron
	ChangeVehicleZone(1008, 9696, "junkyard")
	ChangeVehicleZone(1018, 9696, "junkyard")
	ChangeVehicleZone(1006, 9705, "junkyard")
	ChangeVehicleZone(1016, 9705, "junkyard")
	ChangeVehicleZone(1008, 9714, "junkyard")
	ChangeVehicleZone(1018, 9715, "junkyard")
	ChangeVehicleZone(1008, 9723, "junkyard")
	ChangeVehicleZone(1017, 9724, "junkyard")

--Irvington
	ChangeVehicleZone(1815, 14733, "parkingstall")
	ChangeVehicleZone(1828, 14739, "carpenter")

	ChangeVehicleZone(2004, 14767, "carpenter")

	ChangeVehicleZone(2066, 14622, "carpenter")
	ChangeVehicleZone(2076, 14629, "parkingstall")

	ChangeVehicleZone(2126, 14874, "carpenter")

	ChangeVehicleZone(2924, 13418, "carpenter")
	ChangeVehicleZone(2931, 13409, "parkingstall")

	if activatedMods:contains("isoContainers") then
		ChangeVehicleZone(1809, 13340, "special_kntnr")
		ChangeVehicleZone(1809, 13360, "special_kntnr")
		ChangeVehicleZone(1809, 13402, "special_kntnr")
		ChangeVehicleZone(1816, 13336, "special_kntnr")
		ChangeVehicleZone(1823, 13332, "special_kntnr")
		ChangeVehicleZone(1818, 13344, "special_kntnr")
		ChangeVehicleZone(1817, 13352, "special_kntnr")
		ChangeVehicleZone(1818, 13375, "special_kntnr")
		ChangeVehicleZone(1825, 13413, "special_kntnr")
		ChangeVehicleZone(1829, 13337, "special_kntnr")
		ChangeVehicleZone(1832, 13328, "special_kntnr")
		ChangeVehicleZone(1851, 13337, "special_kntnr")
		ChangeVehicleZone(1865, 13326, "special_kntnr")

		ChangeVehicleZone(1839, 13416, "special_kntnr")
		ChangeVehicleZone(1843, 13424, "special_kntnr")
		ChangeVehicleZone(1842, 13431, "special_kntnr")
		ChangeVehicleZone(1851, 13423, "special_kntnr")
		ChangeVehicleZone(1855, 13427, "special_kntnr")
		ChangeVehicleZone(1854, 13435, "special_kntnr")
		ChangeVehicleZone(1862, 13435, "special_kntnr")
		ChangeVehicleZone(1861, 13442, "special_kntnr")
		ChangeVehicleZone(1872, 13440, "special_kntnr")
		ChangeVehicleZone(1907, 13440, "special_kntnr")
		ChangeVehicleZone(1937, 13439, "special_kntnr")
		ChangeVehicleZone(1946, 13441, "special_kntnr")
		ChangeVehicleZone(1987, 13437, "special_kntnr")
		ChangeVehicleZone(1993, 13416, "special_kntnr")
		ChangeVehicleZone(2000, 13416, "special_kntnr")
		ChangeVehicleZone(2001, 13431, "special_kntnr")
		ChangeVehicleZone(2014, 13424, "special_kntnr")

		ChangeVehicleZone(1878, 13328, "special_kntnr")
		ChangeVehicleZone(1886, 13329, "special_kntnr")
		ChangeVehicleZone(1895, 13329, "special_kntnr")
		ChangeVehicleZone(1894, 13337, "special_kntnr")
		ChangeVehicleZone(1918, 13329, "special_kntnr")

		ChangeVehicleZone(1938, 13321, "special_kntnr")
		ChangeVehicleZone(1945, 13329, "special_kntnr")
		ChangeVehicleZone(1946, 13337, "special_kntnr")
		ChangeVehicleZone(1957, 13328, "special_kntnr")
		ChangeVehicleZone(1975, 13337, "special_kntnr")
		ChangeVehicleZone(2003, 13327, "special_kntnr")
		ChangeVehicleZone(2011, 13336, "special_kntnr")
		ChangeVehicleZone(2026, 13326, "special_kntnr")
		ChangeVehicleZone(2040, 13327, "special_kntnr")
		ChangeVehicleZone(2038, 13339, "special_kntnr")
		ChangeVehicleZone(2049, 13325, "special_kntnr")

		ChangeVehicleZone(2060, 13325, "special_kntnr")
		ChangeVehicleZone(2064, 13337, "special_kntnr")
		ChangeVehicleZone(2079, 13340, "special_kntnr")
		ChangeVehicleZone(2085, 13340, "special_kntnr")
		ChangeVehicleZone(2084, 13347, "special_kntnr")
		ChangeVehicleZone(2087, 13352, "special_kntnr")
		ChangeVehicleZone(2086, 13384, "special_kntnr")
		ChangeVehicleZone(2068, 13415, "special_kntnr")
		ChangeVehicleZone(2060, 13415, "special_kntnr")
	else
		ChangeVehicleZone(1809, 13340, "junkyard")
		ChangeVehicleZone(1809, 13360, "junkyard")
		ChangeVehicleZone(1809, 13402, "junkyard")
		ChangeVehicleZone(1816, 13336, "junkyard")
		ChangeVehicleZone(1823, 13332, "junkyard")
		ChangeVehicleZone(1818, 13344, "junkyard")
		ChangeVehicleZone(1817, 13352, "junkyard")
		ChangeVehicleZone(1818, 13375, "junkyard")
		ChangeVehicleZone(1825, 13413, "junkyard")
		ChangeVehicleZone(1829, 13337, "junkyard")
		ChangeVehicleZone(1832, 13328, "junkyard")
		ChangeVehicleZone(1851, 13337, "junkyard")
		ChangeVehicleZone(1865, 13326, "junkyard")

		ChangeVehicleZone(1839, 13416, "junkyard")
		ChangeVehicleZone(1843, 13424, "junkyard")
		ChangeVehicleZone(1842, 13431, "junkyard")
		ChangeVehicleZone(1851, 13423, "junkyard")
		ChangeVehicleZone(1855, 13427, "junkyard")
		ChangeVehicleZone(1854, 13435, "junkyard")
		ChangeVehicleZone(1862, 13435, "junkyard")
		ChangeVehicleZone(1861, 13442, "junkyard")
		ChangeVehicleZone(1872, 13440, "junkyard")
		ChangeVehicleZone(1907, 13440, "junkyard")
		ChangeVehicleZone(1937, 13439, "junkyard")
		ChangeVehicleZone(1946, 13441, "junkyard")
		ChangeVehicleZone(1987, 13437, "junkyard")
		ChangeVehicleZone(1993, 13416, "junkyard")
		ChangeVehicleZone(2000, 13416, "junkyard")
		ChangeVehicleZone(2001, 13431, "junkyard")
		ChangeVehicleZone(2014, 13424, "junkyard")

		ChangeVehicleZone(1878, 13328, "junkyard")
		ChangeVehicleZone(1886, 13329, "junkyard")
		ChangeVehicleZone(1895, 13329, "junkyard")
		ChangeVehicleZone(1894, 13337, "junkyard")
		ChangeVehicleZone(1918, 13329, "junkyard")

		ChangeVehicleZone(1938, 13321, "junkyard")
		ChangeVehicleZone(1945, 13329, "junkyard")
		ChangeVehicleZone(1946, 13337, "junkyard")
		ChangeVehicleZone(1957, 13328, "junkyard")
		ChangeVehicleZone(1975, 13337, "junkyard")
		ChangeVehicleZone(2003, 13327, "junkyard")
		ChangeVehicleZone(2011, 13336, "junkyard")
		ChangeVehicleZone(2026, 13326, "junkyard")
		ChangeVehicleZone(2040, 13327, "junkyard")
		ChangeVehicleZone(2038, 13339, "junkyard")
		ChangeVehicleZone(2049, 13325, "junkyard")

		ChangeVehicleZone(2060, 13325, "junkyard")
		ChangeVehicleZone(2064, 13337, "junkyard")
		ChangeVehicleZone(2079, 13340, "junkyard")
		ChangeVehicleZone(2085, 13340, "junkyard")
		ChangeVehicleZone(2084, 13347, "junkyard")
		ChangeVehicleZone(2087, 13352, "junkyard")
		ChangeVehicleZone(2086, 13384, "junkyard")
		ChangeVehicleZone(2068, 13415, "junkyard")
		ChangeVehicleZone(2060, 13415, "junkyard")
	end

	ChangeVehicleZone(1832, 13351, "junkyard")
	ChangeVehicleZone(1831, 13370, "junkyard")
	ChangeVehicleZone(1840, 13353, "junkyard")
	ChangeVehicleZone(1838, 13379, "junkyard")
	ChangeVehicleZone(1856, 13349, "junkyard")
	ChangeVehicleZone(1854, 13380, "junkyard")
	ChangeVehicleZone(1867, 13350, "junkyard")
	ChangeVehicleZone(1864, 13356, "junkyard")
	ChangeVehicleZone(1863, 13379, "junkyard")
	ChangeVehicleZone(1864, 13384, "junkyard")

	ChangeVehicleZone(1860, 13418, "junkyard")
	ChangeVehicleZone(1867, 13416, "junkyard")
	ChangeVehicleZone(1869, 13426, "junkyard")
	ChangeVehicleZone(1896, 13416, "junkyard")
	ChangeVehicleZone(1903, 13425, "junkyard")
	ChangeVehicleZone(1910, 13415, "junkyard")
	ChangeVehicleZone(1930, 13423, "junkyard")

	ChangeVehicleZone(1878, 13351, "junkyard")
	ChangeVehicleZone(1879, 13368, "junkyard")
	ChangeVehicleZone(1887, 13351, "junkyard")
	ChangeVehicleZone(1889, 13383, "junkyard")
	ChangeVehicleZone(1888, 13402, "junkyard")
	ChangeVehicleZone(1906, 13350, "junkyard")
	ChangeVehicleZone(1904, 13359, "junkyard")
	ChangeVehicleZone(1917, 13361, "junkyard")
	ChangeVehicleZone(1930, 13356, "junkyard")
	ChangeVehicleZone(1902, 13374, "junkyard")
	ChangeVehicleZone(1910, 13375, "junkyard")
	ChangeVehicleZone(1916, 13385, "junkyard")
	ChangeVehicleZone(1909, 13394, "junkyard")
	ChangeVehicleZone(1908, 13403, "junkyard")
	ChangeVehicleZone(1930, 13373, "junkyard")

	ChangeVehicleZone(1944, 13348, "junkyard")
	ChangeVehicleZone(1945, 13361, "junkyard")
	ChangeVehicleZone(1956, 13349, "junkyard")
	ChangeVehicleZone(1974, 13361, "junkyard")
	ChangeVehicleZone(1945, 13375, "junkyard")
	ChangeVehicleZone(1954, 13375, "junkyard")
	ChangeVehicleZone(1956, 13387, "junkyard")
	ChangeVehicleZone(1953, 13403, "junkyard")
	ChangeVehicleZone(1967, 13374, "junkyard")
	ChangeVehicleZone(1966, 13402, "junkyard")
	ChangeVehicleZone(1979, 13374, "junkyard")
	ChangeVehicleZone(1946, 13416, "junkyard")
	ChangeVehicleZone(1946, 13426, "junkyard")
	ChangeVehicleZone(1980, 13419, "junkyard")
	ChangeVehicleZone(1992, 13349, "junkyard")
	ChangeVehicleZone(1993, 13380, "junkyard")
	ChangeVehicleZone(2000, 13350, "junkyard")
	ChangeVehicleZone(2000, 13359, "junkyard")
	ChangeVehicleZone(2004, 13368, "junkyard")
	ChangeVehicleZone(2004, 13391, "junkyard")
	ChangeVehicleZone(2003, 13402, "junkyard")
	ChangeVehicleZone(2014, 13368, "junkyard")
	ChangeVehicleZone(2027, 13361, "junkyard")
	ChangeVehicleZone(2028, 13378, "junkyard")
	ChangeVehicleZone(2028, 13390, "junkyard")
	ChangeVehicleZone(2027, 13402, "junkyard")
	ChangeVehicleZone(2033, 13351, "junkyard")
	ChangeVehicleZone(2037, 13364, "junkyard")
	ChangeVehicleZone(2037, 13379, "junkyard")
	ChangeVehicleZone(2045, 13360, "junkyard")
	ChangeVehicleZone(2048, 13366, "junkyard")

	ChangeVehicleZone(2059, 13350, "junkyard")
	ChangeVehicleZone(2058, 13360, "junkyard")
	ChangeVehicleZone(2073, 13351, "junkyard")
	ChangeVehicleZone(2060, 13375, "junkyard")
	ChangeVehicleZone(2061, 13402, "junkyard")
	ChangeVehicleZone(2068, 13373, "junkyard")
	ChangeVehicleZone(2074, 13372, "junkyard")

	--

	ChangeVehicleZone(2911, 12609, "junkyard")
	ChangeVehicleZone(2912, 12634, "junkyard")
	ChangeVehicleZone(2911, 12665, "junkyard")
	ChangeVehicleZone(2924, 12601, "junkyard")
	ChangeVehicleZone(2923, 12611, "junkyard")
	ChangeVehicleZone(2921, 12624, "junkyard")
	ChangeVehicleZone(2924, 12653, "junkyard")
	ChangeVehicleZone(2923, 12669, "junkyard")
	ChangeVehicleZone(2932, 12652, "junkyard")
	ChangeVehicleZone(2941, 12616, "junkyard")
	ChangeVehicleZone(2946, 12635, "junkyard")
	ChangeVehicleZone(2941, 12659, "junkyard")
	ChangeVehicleZone(2953, 12614, "junkyard")
	ChangeVehicleZone(2949, 12661, "junkyard")
	ChangeVehicleZone(2966, 12602, "junkyard")
	ChangeVehicleZone(2965, 12623, "junkyard")
	ChangeVehicleZone(2963, 12675, "junkyard")

	ChangeVehicleZone(2513, 14430, "junkyard")
	ChangeVehicleZone(2516, 14437, "junkyard")
	ChangeVehicleZone(2532, 14430, "junkyard")
	ChangeVehicleZone(2530, 14439, "junkyard")
	ChangeVehicleZone(2537, 14449, "junkyard")

	ChangeVehicleZone(3044, 14527, "junkyard")
	ChangeVehicleZone(3074, 14528, "junkyard")
	ChangeVehicleZone(3036, 14540, "junkyard")
	ChangeVehicleZone(3067, 14539, "junkyard")
	ChangeVehicleZone(3068, 14555, "junkyard")
	ChangeVehicleZone(3075, 14541, "junkyard")
	ChangeVehicleZone(3086, 14537, "junkyard")
	ChangeVehicleZone(3087, 14558, "junkyard")

--Muldraugh
	ChangeVehicleZone(10823, 9614, "junkyard")
	ChangeVehicleZone(10823, 9635, "junkyard")
	ChangeVehicleZone(10824, 9689, "junkyard")
	ChangeVehicleZone(10832, 9617, "junkyard")
	ChangeVehicleZone(10831, 9636, "junkyard")
	ChangeVehicleZone(10833, 9662, "junkyard")
	ChangeVehicleZone(10838, 9636, "junkyard")
	ChangeVehicleZone(10839, 9662, "junkyard")
	ChangeVehicleZone(10845, 9612, "junkyard")
	ChangeVehicleZone(10848, 9638, "junkyard")
	ChangeVehicleZone(10850, 9661, "junkyard")
	ChangeVehicleZone(10854, 9638, "junkyard")
	ChangeVehicleZone(10855, 9650, "junkyard")
	ChangeVehicleZone(10857, 9661, "junkyard")

	ChangeVehicleZone(10757, 10473, "junkyard")
	ChangeVehicleZone(10747, 10493, "junkyard")
	ChangeVehicleZone(10745, 10502, "junkyard")
	ChangeVehicleZone(10745, 10512, "junkyard")
	ChangeVehicleZone(10745, 10518, "junkyard")

--Echo Creek
	ChangeVehicleZone(3426, 10968, "carpenter")

	ChangeVehicleZone(2460, 10989, "junkyard")
	ChangeVehicleZone(2486, 10982, "junkyard")
	ChangeVehicleZone(2455, 11039, "junkyard")
	ChangeVehicleZone(2491, 11037, "junkyard")

end
Events.OnLoadedMapZones.Add(GamestaChangeVZones)
