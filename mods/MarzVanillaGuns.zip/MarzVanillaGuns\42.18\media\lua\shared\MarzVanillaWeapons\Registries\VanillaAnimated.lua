local Animations    = require("WeaponSystems/Utils/Animations")

local fn            = { attachments = { open = "Base.OpenBolt", locked = "Base.CloseBolt" } }
local fn_sidebyside = {
    MultipleAttachments = {
        Barrel = {
            partType = "Barrel",
            variants = {
                ["Base.Side_By_Side_Barrel_Close"]         = { open = "Base.Side_By_Side_Barrel_Open", locked = "Base.Side_By_Side_Barrel_Close" },
                ["Base.Side_By_Side_Barrel_Open"]          = { open = "Base.Side_By_Side_Barrel_Open", locked = "Base.Side_By_Side_Barrel_Close" },
                ["Base.Side_By_Side_Barrel_Sawnoff_Close"] = { open = "Base.Side_By_Side_Barrel_Sawnoff_Open", locked = "Base.Side_By_Side_Barrel_Sawnoff_Close" },
                ["Base.Side_By_Side_Barrel_Sawnoff_Open"]  = { open = "Base.Side_By_Side_Barrel_Sawnoff_Open", locked = "Base.Side_By_Side_Barrel_Sawnoff_Close" },
            },
        },
    }
}

Animations.RegisterMultipleWeaponsWithAnimatedParts({
    ["Base.Pistol"] = fn,
    ["Base.PistolGlock"] = fn,
    ["Base.Pistolm93r"] = fn,
    ["Base.Pistol2"] = fn,
    ["Base.Pistol3"] = fn,
    ["Base.AssaultRifle"] = fn,
    ["Base.AssaultRifle2"] = fn,
    ["Base.AssaultRifleAK47"] = fn,
    ["Base.AssaultRifleA3"] = fn,
    ["Base.AssaultRifleM4"] = fn,
    ["Base.SR25_Rifle"] = fn,
    ["Base.Shotgun"] = fn,
    ["Base.ShotgunSawnoff"] = fn,
    ["Base.VarmintRifle"] = fn,
    ["Base.HuntingRifle"] = fn,
    ["Base.MSR7T_Rifle"] = fn,
    ["Base.JS3T_Shotgun"] = fn,
    ["Base.JS14_Rifle"] = fn,
    ["Base.L92_Carbine"] = fn,
    ["Base.L94_Rifle"] = fn,
    ["Base.TrapperCarbine"] = fn,
    ["Base.MP5_SMG"] = fn,
    ["Base.MP5SD_SMG"] = fn,
    ["Base.Side_By_Side"] = fn_sidebyside,
    ["Base.AC556"] = fn,
})
