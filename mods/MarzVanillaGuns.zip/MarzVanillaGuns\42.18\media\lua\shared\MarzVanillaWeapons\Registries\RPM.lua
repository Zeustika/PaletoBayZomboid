local RateOfFire = require("WeaponSystems/utils/RateOfFire")

RateOfFire.RegisterMultipleWeapons({
    ["Base.AssaultRifle"] = {
        rpm             = 800,
        burstCount      = 3,
        enableSpread    = true,
        sustainedSpread = 0.10,
        maxSpread       = 2.5,
    },
    ["Base.AssaultRifleA3"] = {
        rpm             = 800,
        burstCount      = 3,
        enableSpread    = true,
        sustainedSpread = 0.10,
        maxSpread       = 2.5,
    },
    ["Base.AssaultRifleM4"] = {
        rpm             = 800,
        burstCount      = 3,
        enableSpread    = true,
        sustainedSpread = 0.10,
        maxSpread       = 2.5,
    },
    ["Base.AK47"] = {
        rpm             = 650,
        burstCount      = 3,
        enableSpread    = true,
        sustainedSpread = 0.10,
        maxSpread       = 2.5,
    },
    ["Base.Pistolm93r"] = {
        rpm             = 950,
        burstCount      = 3,
        enableSpread    = true,
        sustainedSpread = 0.10,
        maxSpread       = 2.5,
    },
    ["Base.JS5_smg"] = {
        rpm             = 850,
        burstCount      = 3,
        enableSpread    = true,
        sustainedSpread = 0.10,
        maxSpread       = 2.5,
    },
    ["Base.MP5_SMG"] = {
        rpm             = 850,
        burstCount      = 3,
        enableSpread    = true,
        sustainedSpread = 0.10,
        maxSpread       = 2.5,
    },
    ["Base.MP5SD_SMG"] = {
        rpm             = 850,
        burstCount      = 3,
        enableSpread    = true,
        sustainedSpread = 0.10,
        maxSpread       = 2.5,
    },
    ["Base.AC556"] = {
        rpm             = 750,
        burstCount      = 3,
        enableSpread    = true,
        sustainedSpread = 0.10,
        maxSpread       = 2.5,
    },
})
