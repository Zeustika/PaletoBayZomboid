local SpentCasingPhysics = require("SpentCasingPhysics/Init")

if SpentCasingPhysics then
    local marzVanillaParams = {

        ["Base.AssaultRifle"] = {
            forwardOffset = 0.30,
            sideOffset    = 0.10,
            heightOffset  = 0.45,
            shellForce    = 0.90,
            sideSpread    = 60,
            heightSpread  = 30,
            ejectAngle    = 75,
        },

        ["Base.AssaultRifleAK47"] = {
            forwardOffset = 0.35,
            sideOffset    = 0.10,
            heightOffset  = 0.45,
            shellForce    = 0.90,
            sideSpread    = 60,
            heightSpread  = 75,
            ejectAngle    = 45,
        },

        ["Base.AssaultRifleA3"] = {
            forwardOffset = 0.30,
            sideOffset    = 0.10,
            heightOffset  = 0.45,
            shellForce    = 0.90,
            sideSpread    = 60,
            heightSpread  = 30,
            ejectAngle    = 75,
        },

        ["Base.AssaultRifleM4"] = {
            forwardOffset = 0.30,
            sideOffset    = 0.10,
            heightOffset  = 0.45,
            shellForce    = 0.90,
            sideSpread    = 60,
            heightSpread  = 30,
            ejectAngle    = 75,
        },

        ["Base.AssaultRifle2"] = {
            forwardOffset = 0.35,
            sideOffset    = 0.10,
            heightOffset  = 0.45,
            shellForce    = 0.55,
            sideSpread    = 90,
            heightSpread  = { 80, 90 },
            ejectAngle    = 25,
        },

        ["Base.HuntingRifle"] = {
            forwardOffset = 0.38,
            sideOffset    = 0.10,
            heightOffset  = 0.45,
            shellForce    = 0.45,
            sideSpread    = 60,
            heightSpread  = 60,
            ejectAngle    = 70,
        },

        ["Base.MSR7T_Rifle"] = {
            forwardOffset = 0.40,
            sideOffset    = 0.10,
            heightOffset  = 0.45,
            shellForce    = 0.45,
            sideSpread    = 60,
            heightSpread  = 60,
        },

        ["Base.L92_Carbine"] = {
            forwardOffset = 0.35,
            sideOffset    = 0.10,
            heightOffset  = 0.45,
            shellForce    = 0.35,
            sideSpread    = 50,
            heightSpread  = { 40, 50 },
            ejectAngle    = 10,
        },

        ["Base.L94_Rifle"] = {
            forwardOffset = 0.35,
            sideOffset    = 0.10,
            heightOffset  = 0.45,
            shellForce    = 0.35,
            sideSpread    = 50,
            heightSpread  = 30,
            ejectAngle    = 55,
        },

        ["Base.Pistol"] = {
            forwardOffset = 0.40,
            sideOffset    = 0.0,
            heightOffset  = 0.50,
            shellForce    = 0.60,
            sideSpread    = 45,
            heightSpread  = 60,
        },

        ["Base.Pistolm93r"] = {
            forwardOffset = 0.40,
            sideOffset    = 0.0,
            heightOffset  = 0.50,
            shellForce    = 0.60,
            sideSpread    = 45,
            heightSpread  = 60,
            ejectAngle    = 45,
        },

        ["Base.Pistol2"] = {
            forwardOffset = 0.40,
            sideOffset    = 0.0,
            heightOffset  = 0.50,
            shellForce    = 0.60,
            sideSpread    = 50,
            heightSpread  = 45,
        },

        ["Base.Pistol3"] = {
            forwardOffset = 0.35,
            sideOffset    = 0.0,
            heightOffset  = 0.50,
            shellForce    = 0.35,
            sideSpread    = 30,
            heightSpread  = { 100, 130 },
            ejectAngle    = 0,
        },

        ["Base.Revolver_Long"] = {
            forwardOffset = 0.10,
            sideOffset    = 0.0,
            heightOffset  = 0.30,
            shellForce    = 0.10,
            sideSpread    = 50,
            heightSpread  = { 30, 50 },
        },

        ["Base.Revolver_Short"] = {
            forwardOffset = 0.10,
            sideOffset    = 0.0,
            heightOffset  = 0.30,
            shellForce    = 0.10,
            sideSpread    = 50,
            heightSpread  = { 30, 50 },
        },

        ["Base.Revolver"] = {
            forwardOffset = 0.10,
            sideOffset    = 0.0,
            heightOffset  = 0.30,
            shellForce    = 0.10,
            sideSpread    = 50,
            heightSpread  = { 30, 50 },
        },

        ["Base.Side_By_Side"] = {
            forwardOffset = 0.27,
            sideOffset    = 0.0,
            heightOffset  = 0.45,
            shellForce    = 0.15,
            sideSpread    = 30,
            heightSpread  = { 80, 100 },
            ejectAngle    = 180,
        },

        ["Base.Side_By_Side_Sawnoff"] = {
            forwardOffset = 0.27,
            sideOffset    = 0.0,
            heightOffset  = 0.45,
            shellForce    = 0.15,
            sideSpread    = 30,
            heightSpread  = { 80, 100 },
            ejectAngle    = 180,
        },
    }

    for weapon, data in pairs(marzVanillaParams) do
        SpentCasingPhysics.RegisterWeaponParams(
            weapon,
            data.forwardOffset,
            data.sideOffset,
            data.heightOffset,
            data.shellForce,
            data.sideSpread,
            data.heightSpread,
            data.ejectAngle,
            data.verticalForce
        )
    end

    SpentCasingPhysics.RegisterCasingToAmmo({
        ["Base.762Bullets"] = "HBVCEF.762x39_Casing",
    })

    function SpentCasingPhysics.doSpawnCasing(player, weapon, params, racking, optionalItem)
        local forwardOffset = params and params.forwardOffset or 0.10
        local sideOffset    = params and params.sideOffset or 0.10
        local heightOffset  = params and params.heightOffset or 0.5
        local shellForce    = params and params.shellForce or 0.20
        local sideSpread    = params and params.sideSpread or 10
        local heightSpread  = params and params.heightSpread or 10
        local ejectAngle    = params and params.ejectAngle
        local verticalForce = params and params.verticalForce or 0
        local customSound   = params and params.customSound or nil
        local floorBounces  = params and params.floorBounces
        local ammoType      = weapon:getAmmoType():getItemKey()
        if not ammoType then return end

        local itemToEject = SpentCasingPhysics.getItemToEject(ammoType)
        if racking then
            itemToEject = ammoType
        end
        if optionalItem then
            itemToEject = optionalItem
        end
        if not itemToEject then return end

        local px, py, pz = player:getX(), player:getY(), player:getZ()

        local angleDeg = player:getDirectionAngle() or 0
        local angleRad = math.rad(angleDeg)

        local fx = math.cos(angleRad)
        local fy = math.sin(angleRad)
        local rx = math.cos(angleRad + math.pi / 2)
        local ry = math.sin(angleRad + math.pi / 2)

        local spawnWorldX = px + fx * forwardOffset + rx * sideOffset
        local spawnWorldY = py + fy * forwardOffset + ry * sideOffset
        local targetSquare = player:getCurrentSquare()
        if not targetSquare then return end

        local startX = spawnWorldX - targetSquare:getX()
        local startY = spawnWorldY - targetSquare:getY()

        local stairFrac = pz - targetSquare:getZ()
        local startZ = stairFrac + heightOffset

        local velX = (SpentCasingPhysics.RANDOM:random(sideSpread) - 5) / 200.0
        local velY = (SpentCasingPhysics.RANDOM:random(sideSpread) - 5) / 200.0

        local velZ
        if type(heightSpread) == "table" then
            local minH = tonumber(heightSpread[1]) or 0
            local maxH = tonumber(heightSpread[2]) or minH
            if maxH < minH then
                minH, maxH = maxH, minH
            end
            local rawH = SpentCasingPhysics.RANDOM:random(minH, maxH)
            velZ = rawH / 200.0
        else
            velZ = (SpentCasingPhysics.RANDOM:random(heightSpread) + 25) / 200.0
        end

        velZ = velZ + verticalForce

        if racking then
            shellForce = 0.35
        end

        if shellForce ~= 0 then
            local dirX, dirY
            if ejectAngle ~= nil then
                local totalDeg = angleDeg + ejectAngle
                local totalRad = math.rad(totalDeg)
                dirX = math.cos(totalRad)
                dirY = math.sin(totalRad)
            else
                dirX = rx
                dirY = ry
            end

            velX = velX + dirX * shellForce
            velY = velY + dirY * shellForce
        end

        SpentCasingPhysics.addCasing(
            player,
            weapon,
            targetSquare,
            itemToEject,
            startX,
            startY,
            startZ,
            velX,
            velY,
            velZ,
            customSound,
            floorBounces
        )
    end
end
