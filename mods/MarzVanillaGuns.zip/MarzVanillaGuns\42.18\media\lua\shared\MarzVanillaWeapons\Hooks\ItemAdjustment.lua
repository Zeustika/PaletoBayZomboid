require("SpentCasingPhysics/ModSupport")
local SpentCasingPhysics = require("SpentCasingPhysics/Init")
local function Adjust(Name, Property, Value)
    local item = ScriptManager.instance:getItem(Name)
    if not item then return end
    item:DoParam(Property .. " = " .. Value)
end

if SpentCasingPhysics then
    Events.OnInitWorld.Add(function()
        Adjust("Base.762Bullets", "WorldStaticModel", "HBVCEF.762x39_Round_Base")
        Adjust("Base.223Bullets", "WorldStaticModel", "HBVCEF.223_Round")
        if SandboxVars.HB.CustomIcons then
            Adjust("Base.762Bullets", "icon", "762x39_Round_Base")
            Adjust("Base.223Bullets", "icon", "223_Round")
        end
    end)
end
