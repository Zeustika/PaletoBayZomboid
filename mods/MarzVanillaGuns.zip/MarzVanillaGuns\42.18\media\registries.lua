MarzVanillaGuns_Tags = {}
MarzVanillaGuns_AmmoTypes = {}

MarzVanillaGuns_AmmoTypes.BULLET_762x39 = AmmoType.register("mvgi:bullets_762", "Base.762Bullets")
MarzVanillaGuns_AmmoTypes.BULLET_223 = AmmoType.register("mvgi:bullets_223", "Base.223Bullets")
