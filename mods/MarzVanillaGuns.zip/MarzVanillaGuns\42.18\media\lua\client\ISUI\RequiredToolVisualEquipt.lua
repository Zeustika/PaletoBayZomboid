local GW_PreventRemoval = require("WeaponSystems/Utils/PreventRemovals")
local GW_Underbarrel = require("WeaponSystems/Utils/Underbarrel")
local GW_Railing = require("WeaponSystems/Utils/Railing")
local GW_UniversalAttachment = require("WeaponSystems/Utils/UniversalAttachment")
local GW_RequiredAttachment = require("WeaponSystems/Utils/RequiredAttachment")

local function predicateNotBroken(item)
    return not item:isBroken()
end

local function getUpgradeTool(playerObj, partType)
    local tool = MarzVanillaGuns_AttachAndDetach and MarzVanillaGuns_AttachAndDetach.getPrimaryTool(playerObj, partType)
    if tool then
        return tool
    end
    return playerObj:getInventory():getFirstTagEvalRecurse(ItemTag.SCREWDRIVER, predicateNotBroken)
end

local function isRemovalBlockedByGunworks(weapon, part)
    if not weapon or not part then return false end
    local partType = part:getFullType()

    if GW_PreventRemoval and GW_PreventRemoval.IsPermanent(partType) then
        return true
    end
    if GW_Underbarrel and GW_Underbarrel.IsWeaponInUnderbarrelMode(weapon)
        and GW_Underbarrel.UnderbarrelAttachments[partType] then
        return true
    end
    if GW_Railing and GW_Railing.HasMountedAccessoryOnRailing(weapon, part) then
        return true
    end
    if GW_RequiredAttachment and GW_RequiredAttachment.IsRemovalBlocked(weapon, partType) then
        return true
    end
    if GW_UniversalAttachment and GW_UniversalAttachment.IsRegisteredOutcome(weapon, part)
        and not GW_UniversalAttachment.CanRemoveInstalledPart(weapon, part) then
        return true
    end

    return false
end

ISInventoryPaneContextMenu.onRemoveUpgradeWeapon = function(weapon, part, playerObj)
    if isRemovalBlockedByGunworks(weapon, part) then
        return
    end
    ISInventoryPaneContextMenu.transferIfNeeded(playerObj, weapon)
    local tool = getUpgradeTool(playerObj, part:getPartType())
    if tool then
        ISInventoryPaneContextMenu.equipWeapon(tool, true, false, playerObj:getPlayerNum());
    end
    ISTimedActionQueue.add(ISRemoveWeaponUpgrade:new(playerObj, weapon, part:getPartType()));
end

ISInventoryPaneContextMenu.onUpgradeWeapon = function(weapon, part, player)
    ISInventoryPaneContextMenu.transferIfNeeded(player, weapon)
    ISInventoryPaneContextMenu.transferIfNeeded(player, part)
    ISInventoryPaneContextMenu.equipWeapon(part, false, false, player:getPlayerNum());
    local tool = getUpgradeTool(player, part:getPartType())
    if tool then
        ISInventoryPaneContextMenu.equipWeapon(tool, true, false, player:getPlayerNum());
    end
    ISTimedActionQueue.add(ISUpgradeWeapon:new(player, weapon, part));
end
