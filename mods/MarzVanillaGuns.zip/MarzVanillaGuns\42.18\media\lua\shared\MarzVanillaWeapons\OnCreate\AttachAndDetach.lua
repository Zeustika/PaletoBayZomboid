MarzVanillaGuns_AttachAndDetach = MarzVanillaGuns_AttachAndDetach or {}

local function predicateNotBroken(item)
    return not item:isBroken()
end

local function hasWrench(player)
    return player:getInventory():getFirstTagEvalRecurse(ItemTag.WRENCH, predicateNotBroken)
        or player:getInventory():getFirstTagEvalRecurse(ItemTag.PIPE_WRENCH, predicateNotBroken)
end

local function hasScrewdriver(player)
    return player:getInventory():getFirstTagEvalRecurse(ItemTag.SCREWDRIVER, predicateNotBroken)
end


local weaponPartToolMapping = {
    ["Muzzle"] = { hasWrench },
    ["Canon"] = { hasScrewdriver },
    ["Scope"] = { hasScrewdriver },
    ["Sling"] = { hasScrewdriver },
    ["RecoilPad"] = { hasScrewdriver },
    ["Barrel"] = { hasWrench, hasScrewdriver },
}

function MarzVanillaGuns_AttachAndDetach.getPrimaryTool(character, partType)
    local toolChecks = weaponPartToolMapping[partType]
    if not toolChecks or not toolChecks[1] then
        return nil
    end

    return toolChecks[1](character)
end

function MarzVanillaGuns_AttachAndDetach.requiredTools(character, weapon, weaponPart)
    if not character or not weapon or not weaponPart then
        return false
    end

    local weaponPartType = weaponPart:getPartType()
    local toolChecks = weaponPartToolMapping[weaponPartType]

    if not toolChecks then
        return true
    end

    for _, toolCheck in ipairs(toolChecks) do
        if not toolCheck(character) then
            return false
        end
    end

    return true
end

function MarzVanillaGuns_AttachAndDetach.IsMagazine()
    return false
end
