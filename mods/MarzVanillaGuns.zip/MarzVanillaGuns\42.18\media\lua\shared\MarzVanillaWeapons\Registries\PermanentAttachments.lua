local PreventRemoval = require("WeaponSystems/Utils/PreventRemovals")

PreventRemoval.Register({
    -- Magazines
    "Base.44Clip",
    "Base.45Clip",
    "Base.9mmClip",
    "Base.M14Clip",
    "Base.556Clip_20",
    "Base.556Clip",
    "Base.556Clip_75",
    "Base.762Clip_30",
    "Base.762Clip_75",
    "Base.JS14_Clip",
    "Base.JS14_Clip_30",
    "Base.9mmClip_25",
    "Base.9mmClip_30",
    "Base.9mmClip_40",
    "Base.9mmClip_100",
    "Base.308Clip_10",
    "Base.308Clip_20",

    "Base.CloseBolt",
    "Base.OpenBolt",
    "Base.M9_Bayonet_Attachment",

    "Base.JS5_Stock_Folded",
    "Base.JS5_Stock_Deployed",
})
