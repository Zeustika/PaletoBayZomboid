require('TimedActions/ISReloadWeaponAction')
require("TimedActions/ISUpgradeWeapon")
require("TimedActions/ISRemoveWeaponUpgrade")

local original_ISReloadWeaponAction_canShoot = ISReloadWeaponAction.canShoot

ISReloadWeaponAction.canShoot = function(player, weapon)
    if weapon:getFullType() == "Base.Side_By_Side" then
        local barrel = weapon:getWeaponPart("Barrel")
        if not barrel then return false end
    end
    return original_ISReloadWeaponAction_canShoot(player, weapon);
end

local _ISUpgradeWeapon_complete = ISUpgradeWeapon.complete
function ISUpgradeWeapon:complete()
    local part = self.part
    local toReplace = false
    local newPart = nil
    if part:getPartType() == "Barrel" then
        local fullType = part:getFullType()
        if fullType:sub(-5) == "_Open" then
            toReplace = true
            local closedFullType = fullType:sub(1, -6) .. "_Close"
            newPart = instanceItem(closedFullType)
        end
    end

    _ISUpgradeWeapon_complete(self)

    if toReplace then
        self.weapon:attachWeaponPart(self.character, newPart)
    end
end
