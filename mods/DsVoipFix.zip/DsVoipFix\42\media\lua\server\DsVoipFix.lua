--[[
  DsVoipFix server: ask every client to re-push radio channel state when
  someone joins or reports a powered radio. Client keep-alive is local-only;
  this only nudges SyncRadioData.
]]

if not isServer() then return end

local MOD = "DsVoipFix"

local function tellClient(player)
    if player and sendServerCommand then
        sendServerCommand(player, MOD, "pushRadios", {})
    end
end

local function tellEveryone()
    local list = getOnlinePlayers and getOnlinePlayers()
    if not list then return end
    for i = 0, list:size() - 1 do
        tellClient(list:get(i))
    end
end

-- Fires on listen-server host when a local player is created.
Events.OnCreatePlayer.Add(function()
    tellEveryone()
end)

Events.OnClientCommand.Add(function(modName, cmd, _, _)
    if modName == MOD and cmd == "radioOn" then
        tellEveryone()
    end
end)
