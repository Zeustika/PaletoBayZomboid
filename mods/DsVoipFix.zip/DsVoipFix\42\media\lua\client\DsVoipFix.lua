--[[
  DsVoipFix (B42)

  Root cause: GameClient.timeoutRemotePlayers drops remotes after 5s without
  lastRemoteUpdate. Far players never get position packets, so they vanish
  locally and VOIP never plays — until you walk in range once.

  Fix: refresh lastRemoteUpdate on remotes, and periodically call
  DeviceData.transmitBatteryChange so UpdateChannelsRoaming + SyncRadioData
  keep radio freq/pos in the voice router.
]]

local MOD = "DsVoipFix"

-- Real-time intervals (ms). Keep under the 5s remote timeout.
local REMOTE_REFRESH_MS = 2500
local RADIO_PUSH_MS = 4000
local HOST_NUDGE_MS = 12000

local tRemote = 0
local tRadio = 0
local tNudge = 0

local function inventoryRadios(player, onDevice)
    if not player then return end
    local inv = player.getInventory and player:getInventory()
    local items = inv and inv.getItems and inv:getItems()
    if not items then return end
    for i = 0, items:size() - 1 do
        local it = items:get(i)
        local data = it and it.getDeviceData and it:getDeviceData()
        if data then onDevice(data) end
    end
end

local function pushRadioState(player)
    local pushed = false
    inventoryRadios(player, function(data)
        if not (data.getIsTurnedOn and data:getIsTurnedOn()) then return end
        if data.transmitBatteryChange then
            pcall(function() data:transmitBatteryChange() end)
        end
        pushed = true
    end)
    return pushed
end

local function refreshRemotePlayers()
    local list = getOnlinePlayers and getOnlinePlayers()
    if not list then return 0 end
    local stamp = getTimeInMillis()
    local self = getPlayer()
    local selfId = self and self.getOnlineID and self:getOnlineID() or -1
    local n = 0
    for i = 0, list:size() - 1 do
        local other = list:get(i)
        if other and other.getOnlineID and other:getOnlineID() ~= selfId
            and other.setLastRemoteUpdate then
            other:setLastRemoteUpdate(stamp)
            n = n + 1
        end
    end
    return n
end

Events.OnTick.Add(function()
    if not isClient() then return end
    local now = getTimeInMillis and getTimeInMillis() or 0

    if now - tRemote >= REMOTE_REFRESH_MS then
        tRemote = now
        refreshRemotePlayers()
    end

    if now - tRadio < RADIO_PUSH_MS then return end
    tRadio = now

    local player = getPlayer and getPlayer() or nil
    if not player then return end
    if player.getOnlineID and player:getOnlineID() == -1 then return end

    local radioOn = pushRadioState(player)
    if radioOn and now - tNudge >= HOST_NUDGE_MS and sendClientCommand then
        tNudge = now
        sendClientCommand(MOD, "radioOn", {})
    end
end)

Events.OnServerCommand.Add(function(modName, cmd, _)
    if modName ~= MOD or cmd ~= "pushRadios" then return end
    local player = getPlayer and getPlayer() or nil
    if player then pushRadioState(player) end
end)

-- Debug console: DsVoipFix_Status()
function DsVoipFix_Status()
    local now = getTimeInMillis and getTimeInMillis() or 0
    local lines = {}

    local list = getOnlinePlayers and getOnlinePlayers()
    local self = getPlayer and getPlayer() or nil
    local selfId = self and self.getOnlineID and self:getOnlineID() or -1
    local remotes = 0
    if list then
        for i = 0, list:size() - 1 do
            local other = list:get(i)
            if other and other.getOnlineID and other:getOnlineID() ~= selfId then
                remotes = remotes + 1
            end
        end
    end
    lines[#lines + 1] = string.format(
        "[DsVoipFix] remotes=%d lastRefresh=%dms ago",
        remotes, now - tRemote)

    local onCount = 0
    inventoryRadios(self, function(data)
        if not (data.getIsTurnedOn and data:getIsTurnedOn()) then return end
        onCount = onCount + 1
        local ch = data.getChannel and data:getChannel() or -1
        local tw = data.getIsTwoWay and data:getIsTwoWay()
        lines[#lines + 1] = string.format(
            "[DsVoipFix] device ON channel=%d twoWay=%s",
            ch, tostring(tw))
    end)
    if onCount == 0 then
        lines[#lines + 1] = "[DsVoipFix] no powered radios in top inventory"
    end
    lines[#lines + 1] = string.format(
        "[DsVoipFix] lastRadioPush=%dms ago lastHostNudge=%dms ago",
        now - tRadio, now - tNudge)

    for i = 1, #lines do print(lines[i]) end
    return table.concat(lines, "\n")
end
