local MIN_INTERVAL_MS = 50     -- sample the path often (low lag, smooth arcs)
local DEDUPE_MS       = 1500
local BURNOUT_SPEED   = 10
local SKID_SPEED      = 30

-- A floor-splat sprite renders SMALLER than a 1x1 tile, so one decal per
-- tile always reads as dashes. We instead allow several overlapping
-- decals per tile: dedupe on a quarter-tile grid and interpolate the
-- segment between drops at that same granularity, so the skid is a solid
-- continuous streak at any speed. A stationary burnout still maps to a
-- single cell, so it can't pile up (the dedupe still gates it).
local CELL_TILES    = 0.15     -- dedupe / interpolation cell size (tiles).
                               -- Tightened from 0.25 so consecutive blob
                               -- stamps overlap heavily and read as a
                               -- continuous line, not a string of dots.
local MAX_FILL_DIST = 20.0     -- skip the fill past this (teleport/chunk load)

local TYPE_V, TYPE_H, TYPE_D1, TYPE_D2 = 21, 22, 23, 24

-- ---------------------------------------------------------------------------
-- Heading -> decal-orientation mapping.
--
-- KEY FACT: PZ blits a floor decal as a SCREEN-aligned quad at the tile's
-- screen position -- it does NOT iso-project the sprite per pixel. So the
-- decal's on-screen line orientation is just its image orientation, and the
-- four sprites are authored to the four distinct ON-SCREEN line angles:
--   _h  (TYPE_H)  : screen-horizontal
--   _v  (TYPE_V)  : screen-vertical
--   _d1 (TYPE_D1) : shallow iso diagonal  ( +atan(0.5) ~= +26.565 deg )
--   _d2 (TYPE_D2) : shallow iso diagonal  ( -atan(0.5), the mirror )
--
-- A vehicle's WORLD heading therefore has to be projected into screen space
-- before we can pick the matching sprite. PZ's iso projection of a world
-- delta (dx, dy) is, up to a uniform scale:
--     sx = dx - dy
--     sy = (dx + dy) * 0.5            (2:1 tile ratio)
-- A skid line is undirected, so we fold the screen angle into [0, 180) and
-- bucket to the nearest of the four authored screen angles
-- {0 (H), 26.565 (D1), 90 (V), 153.435 (D2)} using their midpoints as bin
-- edges. Consequences (these are the cases the old world-space code got
-- wrong): driving straight along a world-cardinal road moves on screen at
-- +-26.565 deg, so it now correctly picks a shallow diagonal sprite, not
-- H/V; driving a world-diagonal moves screen-vertical/horizontal -> V/H.
--
-- HEADING_OFFSET_DEG and SWAP_D1_D2 stay as escape hatches: only the d1<->d2
-- handedness and an overall mirror are convention-ambiguous from Lua; if the
-- user reports the diagonals look mirrored, flip SWAP_D1_D2.
local HEADING_OFFSET_DEG = 0      -- added to the SCREEN angle before bucketing
local SWAP_D1_D2         = false  -- flip if the two diagonals come out mirrored

local LAST_TICK_MS = 0
local recentTiles  = {}
local lastDrop     = nil   -- {x,y,z} last placed point in the CURRENT streak

-- Probe-and-cache (project Kahlua rule: Kahlua red-logs caught Java
-- exceptions, so probe each uncertain Java method ONCE and remember the
-- result instead of call-and-hope every tick).
local probedForward = nil   -- true once getForwardVector is known usable
local lastPos       = {}    -- per-vehicle last (x,y) for delta heading

-- Returns a continuous heading in degrees (atan2 convention, from +X CCW)
-- or nil if no source is reliably available this tick. Order of
-- preference: position-delta (same coord frame as decal placement, so
-- zero axis-convention risk) -> getForwardVector (physics ground plane is
-- .x/.z) -> getDir() coarse enum (last resort, never errors).
local function vehicleHeadingDeg(v)
    -- 1. Position delta in the exact getX()/getY() frame the decal uses.
    local id = v.getId and v:getId() or tostring(v)
    local x, y = v:getX(), v:getY()
    local prev = lastPos[id]
    lastPos[id] = { x = x, y = y, ts = (getTimestampMs and getTimestampMs() or 0) }
    if prev then
        local dx, dy = x - prev.x, y - prev.y
        if (dx * dx + dy * dy) > 0.0004 then   -- ~0.02 tile of motion
            return math.deg(math.atan2(dy, dx))
        end
    end

    -- 2. getForwardVector(Vector3f): physics ground plane is .x / .z
    --    (.y is the vertical/height axis in PZ's physics Vector3f).
    if probedForward ~= false and v.getForwardVector and Vector3f then
        local ok, hx, hz = pcall(function()
            local fv = Vector3f.new(0, 0, 0)
            v:getForwardVector(fv)
            return fv:x(), fv:z()
        end)
        if ok and hx and hz and (hx * hx + hz * hz) > 1e-6 then
            probedForward = true
            -- world ground frame: X<->x, Y<->z
            return math.deg(math.atan2(hz, hx))
        elseif probedForward == nil then
            probedForward = false   -- unusable here; stop trying
        end
    end

    -- 3. Coarse 8-way enum -- never errors, just imprecise.
    if v.getDir then
        local n = tostring(v:getDir())
        -- Degrees chosen to match atan2(dy, dx) in PZ's frame
        -- (X = east, Y = south, north = -Y) so this last-resort path
        -- folds/buckets identically to the two primary paths.
        if     n == "N"  then return 90
        elseif n == "S"  then return 270
        elseif n == "E"  then return 0
        elseif n == "W"  then return 180
        elseif n == "NE" then return 315
        elseif n == "NW" then return 225
        elseif n == "SE" then return 45
        elseif n == "SW" then return 135
        end
    end
    return nil
end

local function preloadTextures()
    local files = {
        bvd_tiremark_v  = "media/textures/Item_bvd_tiremark_v.png",
        bvd_tiremark_h  = "media/textures/Item_bvd_tiremark_h.png",
        bvd_tiremark_d1 = "media/textures/Item_bvd_tiremark_d1.png",
        bvd_tiremark_d2 = "media/textures/Item_bvd_tiremark_d2.png",
    }
    for name, path in pairs(files) do
        local t = getTexture(path)
        if t and Texture and Texture.BVD_registerSharedTexture then
            Texture.BVD_registerSharedTexture(name, t)
        end
    end
    -- Re-probe the forward-vector path each world load: a stale false
    -- from one odd vehicle must not permanently disable it.
    probedForward = nil
end

Events.OnGameBoot.Add(preloadTextures)

-- Last-resort default when no heading is available: keep V (matches the
-- previous code's fallback so behaviour is unchanged on total failure).
local LAST_TYPE = TYPE_V

local function typeForVehicle(v)
    local h = vehicleHeadingDeg(v)
    if not h then return LAST_TYPE end

    -- World heading -> world unit vector -> PZ iso projection -> the
    -- ON-SCREEN line angle the skid mark actually has (see header note).
    local r  = math.rad(h)
    local wx = math.cos(r)
    local wy = math.sin(r)
    local sx = wx - wy
    local sy = (wx + wy) * 0.5
    local a  = (math.deg(math.atan2(sy, sx)) + HEADING_OFFSET_DEG) % 180.0
    if a < 0 then a = a + 180.0 end

    -- Bucket to the nearest authored screen angle. Targets are
    -- 0 (H), 26.565 (D1), 90 (V), 153.435 (D2); bin edges are the
    -- midpoints between adjacent targets (13.28 / 58.28 / 121.72 / 166.72).
    local t
    if     a < 13.283  then t = TYPE_H
    elseif a < 58.283  then t = (SWAP_D1_D2 and TYPE_D2 or TYPE_D1)
    elseif a < 121.717 then t = TYPE_V
    elseif a < 166.717 then t = (SWAP_D1_D2 and TYPE_D1 or TYPE_D2)
    else                    t = TYPE_H   -- wraps back toward 180==0
    end

    LAST_TYPE = t
    return t
end

-- Place ONE decal at a world point, resolving its own square/chunk (an
-- interpolated point may fall in a different chunk than the vehicle's),
-- with per-tile dedupe so a tile is only stamped once per DEDUPE_MS.
local function placeSplatAt(wx, wy, wz, t, now)
    -- Quarter-tile dedupe cell -> several overlapping decals per tile.
    local key = math.floor(wx / CELL_TILES) .. "," ..
                math.floor(wy / CELL_TILES) .. "," .. math.floor(wz)
    if recentTiles[key] and (now - recentTiles[key]) < DEDUPE_MS then return end
    recentTiles[key] = now
    local cell  = getCell and getCell()
    local sq    = cell and cell:getGridSquare(math.floor(wx), math.floor(wy), math.floor(wz))
    local chunk = sq and sq.getChunk and sq:getChunk()
    if chunk and chunk.addBloodSplat then
        chunk:addBloodSplat(wx, wy, wz, t)
    end
end

-- v0.1.8: per-wheel stamping. Previously a single decal at the vehicle
-- centerline approximated both tracks; the sprite had two parallel streaks
-- baked in at a fixed pixel spacing so it read correctly for sedans whose
-- wheelbase happened to match. Anything wider (pickups, vans, trucks) or
-- narrower (compacts, motorcycles) showed the marks at the wrong place
-- relative to the wheels, and on tight curves the four oriented sprites
-- turned a donut into a polygon.
--
-- v0.1.8 reads each vehicle script's wheel offsets, transforms them per-tick
-- to each wheel's world position via the vehicle's yaw, and stamps one
-- omnidirectional soft blob at every wheel. Wide pickups get wide tracks,
-- compacts get narrow tracks, circles trace as actual circles, and the
-- marks visually anchor where the rubber actually is.

-- Probe cache for the wheel-offset path. Probe once per vehicle script id
-- (cheap to lookup, never re-probes after first success).
local probedWheels = {}      -- [scriptName] = true (ok) | false (no API)

-- Per-wheel lastDrop, keyed by vehicle id + wheel index. Replaces the
-- single global lastDrop so each wheel's streak interpolates independently
-- (otherwise switching from the left wheel's last drop to the right
-- wheel's would stitch across the vehicle on every tick).
local lastDropPerWheel = {}

-- Returns a list of { x = wx, y = wy } for each wheel in world space, or
-- nil if the script API isn't usable (motorcycles missing wheels, vehicles
-- with no script). Falls back to centerline (single entry) on probe failure.
local function getWheelWorldPositions(v, vx, vy, headingDeg)
    if not v.getScript then return nil end
    local script = v:getScript()
    if not script or not script.getWheelCount then return nil end

    -- Probe-cache the wheel API per script name.
    local scriptName = (script.getName and script:getName()) or "?"
    local probed = probedWheels[scriptName]
    if probed == false then return nil end

    local ok, n = pcall(function() return script:getWheelCount() end)
    if not ok or not n or n < 1 then
        probedWheels[scriptName] = false
        return nil
    end

    local r = math.rad(headingDeg or 0)
    local cosT, sinT = math.cos(r), math.sin(r)

    -- Local frame in PZ vehicle scripts:
    --   .z() = longitudinal (positive = forward of origin)
    --   .x() = lateral (positive = vehicle's right side)
    --   .y() = vertical (height), not used here
    -- World frame: +x = east, +y = south. Heading 0 = east-facing forward.
    --   Forward unit in world: (cos h, sin h)
    --   Right unit in world (90 deg CCW in this frame): (-sin h, cos h)
    -- Wheel world = origin + oz * Forward + ox * Right.
    -- v0.1.8: rear-wheel filter. Real burnouts/oversteer skids come from
    -- the rear axle, not all four wheels. Stamping all 4 produces chaotic
    -- divergent tracks during curves (front wheels turn, rear track
    -- straight, four streaks fan out). Collect all wheels, then keep only
    -- the rearmost pair by z-coordinate. In PZ vehicle scripts the rear
    -- axle conventionally sits at the most-negative .z(); REAR_Z_PREFER
    -- = "min" reflects that. If a non-vanilla script flips conventions
    -- and you see FRONT-wheel marks, swap to "max".
    local all = {}
    for i = 0, n - 1 do
        local ok2, w = pcall(function() return script:getWheel(i) end)
        if ok2 and w and w.getOffset then
            local ok3, off = pcall(function() return w:getOffset() end)
            if ok3 and off then
                local ox = off.x and off:x() or 0
                local oz = off.z and off:z() or 0
                all[#all + 1] = { ox = ox, oz = oz, idx = i }
            end
        end
    end

    -- Pick the rear-axle pair: extreme-z wheels. For a 4-wheel car this
    -- gives left-rear + right-rear; for 2-wheel (motorcycle) we keep both.
    local rear
    if #all <= 2 then
        rear = all
    else
        table.sort(all, function(a, b) return a.oz < b.oz end)
        -- The two smallest-z entries. If vehicle has 6 wheels (some trucks),
        -- this still picks the rearmost axle pair only.
        rear = { all[1], all[2] }
    end

    -- Transform rear-pair offsets to world coords.
    local out = {}
    for _, p in ipairs(rear) do
        local wx = vx + p.oz * cosT + p.ox * (-sinT)
        local wy = vy + p.oz * sinT + p.ox * cosT
        out[#out + 1] = { x = wx, y = wy, idx = p.idx }
    end

    if #out == 0 then
        probedWheels[scriptName] = false
        return nil
    end
    probedWheels[scriptName] = true
    return out
end

local function dropMark(v, sq)
    if not sq then return end

    -- Vehicle world coords (floats). addBloodSplat treats them as the
    -- splat's render anchor inside the resolved tile.
    local vx = v:getX() or sq:getX()
    local vy = v:getY() or sq:getY()
    local vz = v:getZ() or sq:getZ()
    local t  = typeForVehicle(v)
    local now = getTimestampMs and getTimestampMs() or 0
    local vid = (v.getId and v:getId()) or tostring(v)

    if (now % 8000) < 50 then
        for k, ts in pairs(recentTiles) do
            if (now - ts) > DEDUPE_MS * 4 then recentTiles[k] = nil end
        end
        -- Drop heading state for vehicles untouched for a while so the
        -- table can't accrete stale per-id entries on long sessions.
        for k, p in pairs(lastPos) do
            if p.ts and (now - p.ts) > 60000 then lastPos[k] = nil end
        end
        -- Same GC for the per-wheel drop cache; entries naturally age out
        -- once the vehicle stops feeding new positions.
        for k, p in pairs(lastDropPerWheel) do
            if p.ts and (now - p.ts) > 60000 then lastDropPerWheel[k] = nil end
        end
    end

    -- Resolve each wheel's world position via the vehicle script + yaw.
    -- Falls back to centerline if the wheel API isn't usable for this
    -- vehicle (e.g. exotic scripts with no wheel data) so we never silently
    -- stop drawing.
    local heading = vehicleHeadingDeg(v)
    local wheels = getWheelWorldPositions(v, vx, vy, heading)
    if not wheels then
        wheels = { { x = vx, y = vy, idx = -1 } }
    end

    -- Per-wheel streak: each wheel's interpolation chain is independent so
    -- successive drops form a coherent track along that wheel's path. A
    -- level change resets the chain to a fresh single point.
    for _, p in ipairs(wheels) do
        local key  = vid .. ":" .. p.idx
        local prev = lastDropPerWheel[key]
        if prev and prev.z == vz then
            local dx, dy = p.x - prev.x, p.y - prev.y
            local dist = math.sqrt(dx * dx + dy * dy)
            if dist > 0.0 and dist <= MAX_FILL_DIST then
                local steps = math.ceil(dist / CELL_TILES)
                for i = 1, steps do
                    local f = i / steps
                    placeSplatAt(prev.x + dx * f, prev.y + dy * f, vz, t, now)
                end
            else
                placeSplatAt(p.x, p.y, vz, t, now)
            end
        else
            placeSplatAt(p.x, p.y, vz, t, now)
        end
        lastDropPerWheel[key] = { x = p.x, y = p.y, z = vz, ts = now }
    end

    -- lastDrop retained for any other consumers, kept centerline-aligned
    -- so existing behaviour (level-change reset) still hangs off it.
    lastDrop = { x = vx, y = vy, z = vz }
end

local function onPlayerUpdate(player)
    if not player or player:isDead() then lastDrop = nil return end
    local sv = SandboxVars and SandboxVars.BetterVehicleDynamics
    if sv and sv.SkidMarks == false then lastDrop = nil return end
    local v = player:getVehicle()
    if not v or v:getDriver() ~= player then lastDrop = nil return end
    local now = getTimestampMs and getTimestampMs() or 0
    if now - LAST_TICK_MS < MIN_INTERVAL_MS then return end

    local speed = v:getCurrentSpeedKmHour() or 0
    if speed < 0 then speed = -speed end
    local gas, brake = v:isGasPedalPressed(), v:isBrakePedalPressed()
    local drifting  = BetterVehicleDynamicsMod
                       and BetterVehicleDynamicsMod.driftActive == true
                       and speed > 15
    local isBurnout = speed < BURNOUT_SPEED and gas
    local isSkid    = speed > SKID_SPEED    and brake
    if not (isBurnout or isSkid or drifting) then return end

    dropMark(v, v:getCurrentSquare())
    LAST_TICK_MS = now
end

Events.OnPlayerUpdate.Add(onPlayerUpdate)
