FightZ = FightZ or {}

local BOOKS = {
    { fullType = "FightZ.FightZBook1", common = 4.0, uncommon = 2.5 },
    { fullType = "FightZ.FightZBook2", common = 3.2, uncommon = 2.0 },
    { fullType = "FightZ.FightZBook3", common = 2.3, uncommon = 1.4 },
    { fullType = "FightZ.FightZBook4", common = 1.4, uncommon = 0.9 },
    { fullType = "FightZ.FightZBook5", common = 0.8, uncommon = 0.55 },
}

local CONTAINERS = {
    { name = "BookstoreBooks", weight = "common" },
    { name = "LibraryBooks", weight = "common" },
    { name = "UniversityLibraryBooks", weight = "common" },
    { name = "PostOfficeBooks", weight = "uncommon" },
    { name = "CrateBooks", weight = "uncommon" },
    { name = "CrateBooksSchool", weight = "common" },
    { name = "CrateMagazines", weight = "uncommon" },
    { name = "GymLockers", weight = "uncommon" },
}

local function requireDistributions()
    if ProceduralDistributions and ProceduralDistributions.list then
        return true
    end

    pcall(function()
        return require("Items/ProceduralDistributions")
    end)
    return ProceduralDistributions and ProceduralDistributions.list
end

local function alreadyAdded(items, fullType)
    for index = 1, #items, 2 do
        if items[index] == fullType then
            return true
        end
    end

    return false
end

local function addToContainer(containerName, fullType, weight)
    local container = ProceduralDistributions.list[containerName]
    if not container or not container.items then
        return
    end

    if alreadyAdded(container.items, fullType) then
        return
    end

    table.insert(container.items, fullType)
    table.insert(container.items, weight)
end

function FightZ.addBookDistributions()
    if not requireDistributions() then
        return
    end

    for _, container in ipairs(CONTAINERS) do
        for _, book in ipairs(BOOKS) do
            addToContainer(container.name, book.fullType, book[container.weight])
        end
    end
end

FightZ.addBookDistributions()

if Events then
    if Events.OnInitGlobalModData then
        Events.OnInitGlobalModData.Add(FightZ.addBookDistributions)
    end
    if Events.OnPreDistributionMerge then
        Events.OnPreDistributionMerge.Add(FightZ.addBookDistributions)
    end
end
