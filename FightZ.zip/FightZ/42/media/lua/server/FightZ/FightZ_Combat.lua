FightZ = FightZ or {}

if FightZ.ENABLE_SERVER_COMBAT_EVENTS == nil then
    FightZ.ENABLE_SERVER_COMBAT_EVENTS = false
end

local function safeCall(target, methodName, ...)
    if target and target[methodName] then
        return target[methodName](target, ...)
    end
    return nil
end

local function randomFloat()
    if FightZ.randomInt then
        return FightZ.randomInt(10000) / 10000
    end
    if ZombRand then
        return ZombRand(10000) / 10000
    end
    return math.random()
end

local function randomRange(minValue, maxValue)
    minValue = tonumber(minValue) or 0
    maxValue = tonumber(maxValue) or minValue
    if maxValue <= minValue then
        return minValue
    end
    return minValue + ((maxValue - minValue) * randomFloat())
end

local function addPlayerXp(player, perk, amount)
    amount = tonumber(amount) or 0
    if not player or not perk or amount <= 0 then
        return false
    end

    if FightZ.ensureFistXpMultiplierConfig then
        FightZ.ensureFistXpMultiplierConfig()
    end

    local xp = safeCall(player, "getXp")
    if not xp or not xp.AddXP then
        return false
    end

    if addXp then
        addXp(player, perk, amount)
    else
        xp:AddXP(perk, amount, false, true, false, false)
    end

    return true
end

local function addFistXp(player, amount)
    if FightZ.ENABLE_FIST_XP == false then
        return
    end

    local perk = FightZ.resolvePerk and (FightZ.resolvePerk() or FightZ.registerFistPerk())
    if not perk then
        return
    end

    FightZ.applyTraitBoost(player)
    addPlayerXp(player, perk, amount)
end

local function drainEndurance(player, amount)
    if FightZ.ENABLE_FIST_ENDURANCE == false then
        return
    end

    local stats = safeCall(player, "getStats")
    if not stats or not CharacterStat or not CharacterStat.ENDURANCE then
        return
    end

    if stats.remove then
        stats:remove(CharacterStat.ENDURANCE, amount)
    end
end

local function getSandboxMuscleStrainFactor()
    if SandboxVars and SandboxVars.MuscleStrainFactor ~= nil then
        return tonumber(SandboxVars.MuscleStrainFactor) or 1
    end

    if getSandboxOptions then
        local options = getSandboxOptions()
        if options and options.getOptionByName then
            local option = options:getOptionByName("MuscleStrainFactor")
            if option and option.getValue then
                local value = option:getValue()
                if value ~= nil then
                    return tonumber(value) or 1
                end
            end
        end
    end

    return 1
end

local function getTimeMs()
    if FightZ.getTimeMs then
        return FightZ.getTimeMs()
    end

    if getTimestampMs then
        return getTimestampMs()
    end

    if getGameTime then
        local gameTime = getGameTime()
        if gameTime and gameTime.getWorldAgeHours then
            return gameTime:getWorldAgeHours() * 3600000
        end
    end

    return os.time() * 1000
end

local function applyMuscleStrain(player, weapon, critical)
    if FightZ.ENABLE_FIST_MUSCLE_STRAIN == false then
        return
    end

    local sandboxFactor = getSandboxMuscleStrainFactor()
    if sandboxFactor <= 0 then
        return
    end

    local modData = safeCall(player, "getModData")
    local now = getTimeMs()
    local lastTime = modData and tonumber(modData.FightZLastStrainMs) or 0
    local chain = 1
    if lastTime > 0 and now - lastTime <= (FightZ.MANUAL_PUNCH_STRAIN_CHAIN_WINDOW_MS or 7500) then
        chain = (tonumber(modData.FightZStrainChain) or 0) + 1
    end
    if chain > 20 then
        chain = 20
    end

    if modData then
        modData.FightZLastStrainMs = now
        modData.FightZStrainChain = chain
    end

    local level = FightZ.getFistLevel and FightZ.getFistLevel(player) or 0
    local skillMultiplier = 1 - (level * 0.035)
    if skillMultiplier < 0.65 then
        skillMultiplier = 0.65
    end

    local chainStep = FightZ.getSandboxComboStrainStep
        and FightZ.getSandboxComboStrainStep()
        or (FightZ.MANUAL_PUNCH_STRAIN_CHAIN_STEP or 0.05)
    local chainMultiplier = (FightZ.MANUAL_PUNCH_STRAIN_CHAIN_BASE_MULTIPLIER or 0.8)
        + ((chain - 1) * chainStep)
    local maxMultiplier = FightZ.MANUAL_PUNCH_STRAIN_CHAIN_MAX_MULTIPLIER or 2.0
    if chainMultiplier > maxMultiplier then
        chainMultiplier = maxMultiplier
    end

    local fitnessMultiplier = FightZ.getFitnessPunchStrainMultiplier
        and FightZ.getFitnessPunchStrainMultiplier(player)
        or 1.0
    local amount = (FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_BASE or 0.20)
        * sandboxFactor
        * chainMultiplier
        * skillMultiplier
        * fitnessMultiplier
    if critical then
        amount = amount * 1.35
    end

    if player.addBothArmMuscleStrain then
        player:addBothArmMuscleStrain(amount * 0.5)
    elseif player.addLeftArmMuscleStrain and player.addRightArmMuscleStrain then
        player:addLeftArmMuscleStrain(amount * 0.5)
        player:addRightArmMuscleStrain(amount * 0.5)
    elseif player.addArmMuscleStrain then
        player:addArmMuscleStrain(amount)
    end
end

local function applyZombieDamage(zombie, damage)
    if FightZ.ENABLE_FIST_DAMAGE == false then
        return
    end

    local health = safeCall(zombie, "getHealth")
    if not health or not zombie.setHealth then
        return
    end

    local newHealth = health - damage
    if newHealth < 0 then
        newHealth = 0
    end

    zombie:setHealth(newHealth)
end

local function applyZombieReaction(zombie, level, boost, critical)
    if not FightZ.ENABLE_ZOMBIE_REACTIONS then
        return
    end

    local staggerChance = 18 + (level * 4) + (boost * 7)
    local knockdownChance = 3 + (level * 2) + (boost * 4)

    if critical then
        staggerChance = staggerChance + 20
        knockdownChance = knockdownChance + 8
    end

    if staggerChance > 85 then
        staggerChance = 85
    end
    if knockdownChance > 32 then
        knockdownChance = 32
    end

    if zombie.setHitReaction and FightZ.randomInt(100) < staggerChance then
        zombie:setHitReaction("staggerback")
    end

    if zombie.setStaggerBack and FightZ.randomInt(100) < staggerChance then
        zombie:setStaggerBack(true)
    end

    if zombie.setKnockedDown and FightZ.randomInt(100) < knockdownChance then
        zombie:setKnockedDown(true)
    end
end

local function onWeaponHitXp(owner, weapon, hitObject, damage, hitCount)
    if weapon and FightZ.isBareHands and not FightZ.isBareHands(weapon) then
        return
    end
    if FightZ.hasEmptyHandsForFightZ and not FightZ.hasEmptyHandsForFightZ(owner) then
        return
    end
    if not FightZ.isFightZHit or not FightZ.isFightZHit(owner, hitObject, weapon) then
        return
    end

    local hits = hitCount or 1
    if hits < 1 then
        hits = 1
    end

    local xpAmount = ((damage or 0.35) * 2.0) + (hits * 0.55)
    if xpAmount < 0.4 then
        xpAmount = 0.4
    elseif xpAmount > 8 then
        xpAmount = 8
    end

    addFistXp(owner, xpAmount)

    if FightZ.clearConfirmedPunch then
        FightZ.clearConfirmedPunch(owner)
    end
end

local function onWeaponHitCharacter(attacker, target, weapon)
    if isClient and isClient() then
        return
    end

    if weapon and FightZ.isBareHands and not FightZ.isBareHands(weapon) then
        return
    end
    if FightZ.hasEmptyHandsForFightZ and not FightZ.hasEmptyHandsForFightZ(attacker) then
        return
    end
    if not FightZ.isFightZHit or not FightZ.isFightZHit(attacker, target, weapon) then
        return
    end

    local level = FightZ.getFistLevel(attacker)
    local boost = FightZ.getPlayerFistBoost and FightZ.getPlayerFistBoost(attacker) or 0
    local critical = FightZ.getPreparedPunchCritical and FightZ.getPreparedPunchCritical(attacker)
    if critical == nil then
        critical = FightZ.rollCriticalPunch(attacker)
    end
    if level < 0 then
        level = 0
    elseif level > 10 then
        level = 10
    end
    local levelRatio = level / 10
    local levelDamage = (levelRatio ^ (FightZ.MANUAL_PUNCH_LEVEL_EXPONENT or 1.45))
        * (FightZ.MANUAL_PUNCH_LEVEL_DAMAGE or 0.225)
    local boostDamage = boost * ((FightZ.MANUAL_PUNCH_BOOST_DAMAGE or 0.006)
        + (level * (FightZ.MANUAL_PUNCH_BOOST_LEVEL_DAMAGE or 0.004)))
    local extraDamage = (FightZ.MANUAL_PUNCH_BASE_DAMAGE or 0.055) + levelDamage + boostDamage
    local weakDamageHit = extraDamage <= (FightZ.MANUAL_PUNCH_WEAK_DAMAGE_THRESHOLD or 0.08)
    if not weakDamageHit and not critical and FightZ.getWeakPunchChance then
        weakDamageHit = (randomFloat() * 100) < FightZ.getWeakPunchChance(attacker)
    end
    local maxDamage = FightZ.MANUAL_PUNCH_MAX_DAMAGE or 0.42
    if extraDamage > maxDamage then
        extraDamage = maxDamage
    end
    if critical then
        extraDamage = extraDamage * (FightZ.MANUAL_PUNCH_CRIT_MULTIPLIER or 1.45)
        local critMaxDamage = FightZ.MANUAL_PUNCH_CRIT_MAX_DAMAGE or (maxDamage * 1.45)
        if extraDamage > critMaxDamage then
            extraDamage = critMaxDamage
        end
    end
    if weakDamageHit and not critical and FightZ.getWeakPunchDamageRange then
        local weakMin, weakMax = FightZ.getWeakPunchDamageRange(attacker)
        extraDamage = randomRange(weakMin, weakMax)
    elseif FightZ.getPainDamageMultiplier then
        extraDamage = extraDamage * FightZ.getPainDamageMultiplier(attacker)
    end

    local strengthMultiplier = FightZ.getStrengthPunchDamageMultiplier
        and FightZ.getStrengthPunchDamageMultiplier(attacker)
        or 1.0
    extraDamage = extraDamage * strengthMultiplier
    local finalDamageCap = critical
        and (FightZ.MANUAL_PUNCH_CRIT_MAX_DAMAGE or (maxDamage * 1.45))
        or maxDamage
    if extraDamage > finalDamageCap then
        extraDamage = finalDamageCap
    end
    extraDamage = extraDamage * (FightZ.getSandboxFistDamageMultiplier
        and FightZ.getSandboxFistDamageMultiplier()
        or 1.0)

    applyZombieDamage(target, extraDamage)
    applyZombieReaction(target, level, boost, critical)
    drainEndurance(attacker, randomRange(FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MIN or 0.003, FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MAX or 0.005))
    applyMuscleStrain(attacker, weapon, critical)

    if FightZ.clearConfirmedPunch then
        FightZ.clearConfirmedPunch(attacker)
    end
end

local punchXpAwardTimes = setmetatable({}, { __mode = "k" })
local punchObjectHitTimes = setmetatable({}, { __mode = "k" })
local punchAnimationTimes = setmetatable({}, { __mode = "k" })
local punchAnimationSequences = setmetatable({}, { __mode = "k" })
local validPunchSpeedTiers = {
    normal = true,
    winded = true,
    strained = true,
    tired = true,
    heavyStrain = true,
    exhausted = true,
    severeStrain = true,
    extremeStrain = true,
}

local function creditVanillaZombieKill(player)
    if not player or not player.getZombieKills or not player.setZombieKills then
        return
    end

    local kills = tonumber(player:getZombieKills()) or 0
    player:setZombieKills(kills + 1)
end

local fistMaintenanceItems = {
    ["Base.Gloves_RagWrap"] = true,
    ["Base.Gloves_BurlapWrap"] = true,
    ["Base.Gloves_HuntingCamo"] = true,
    ["Base.Gloves_WhiteTINT"] = true,
    ["Base.Gloves_DenimWrap"] = true,
    ["Base.Gloves_TarpWrap"] = true,
    ["Base.Gloves_FingerlessGloves"] = true,
    ["Base.Gloves_FingerlessLeatherGloves_Black"] = true,
    ["Base.Gloves_FingerlessLeatherGloves_Brown"] = true,
    ["Base.Gloves_FingerlessLeatherGloves"] = true,
    ["Base.Gloves_LeatherWrap"] = true,
    ["Base.Gloves_LeatherGlovesBrown"] = true,
    ["Base.Gloves_LeatherGloves"] = true,
    ["Base.Gloves_LeatherGlovesBlack"] = true,
    ["Base.Gloves_BoxingRed"] = true,
    ["Base.Gloves_BoxingBlue"] = true,
    ["Base.Gloves_BoneGloves"] = true,
    ["Base.Gloves_MetalArmour"] = true,
    ["Base.Gloves_MetalScrapArmour"] = true,
    ["Base.Chainmail_SleeveFull_L"] = true,
    ["Base.Chainmail_SleeveFull_R"] = true,
}

local function addPerkXp(player, perk, amount)
    addPlayerXp(player, perk, amount)
end

local function hasFistMaintenanceEquipment(player)
    local wornItems = safeCall(player, "getWornItems")
    local size = wornItems and safeCall(wornItems, "size") or nil
    if size == nil and wornItems then
        size = safeCall(wornItems, "getItemCount")
    end
    size = tonumber(size) or 0

    for i = 0, size - 1 do
        local entry = safeCall(wornItems, "get", i)
        if not entry then
            entry = safeCall(wornItems, "getItemByIndex", i)
        end
        local item = safeCall(entry, "getItem") or safeCall(entry, "getInventoryItem") or entry
        local fullType = safeCall(item, "getFullType")
        if fullType and fistMaintenanceItems[tostring(fullType)] == true then
            return true
        end
    end

    return false
end

local function addPunchSecondaryXp(player, critical)
    if not Perks then
        return
    end

    local multiplier = critical
        and (FightZ.MANUAL_PUNCH_PHYSICAL_XP_CRIT_MULTIPLIER or 1.5)
        or 1.0
    addPerkXp(player, Perks.Strength, (FightZ.MANUAL_PUNCH_STRENGTH_XP or 1.0) * multiplier)
    addPerkXp(player, Perks.Fitness, (FightZ.MANUAL_PUNCH_FITNESS_XP or 1.0) * multiplier)

    local hasMaintenanceTrait = FightZ.hasTrait
        and ((FightZ.TRAIT_FIGHTER and FightZ.hasTrait(player, FightZ.TRAIT_FIGHTER) == true)
            or (FightZ.TRAIT_INICIATE and FightZ.hasTrait(player, FightZ.TRAIT_INICIATE) == true))
    if FightZ.ENABLE_FIST_MAINTENANCE_XP ~= false
        and hasMaintenanceTrait
        and hasFistMaintenanceEquipment(player) then
        local amount = FightZ.MANUAL_PUNCH_MAINTENANCE_XP or 0.35
        if critical then
            amount = amount * (FightZ.MANUAL_PUNCH_MAINTENANCE_XP_CRIT_MULTIPLIER or 1.5)
        end
        local maintenancePerk = Perks.Maintenance
        if not maintenancePerk and Perks.FromString then
            maintenancePerk = Perks.FromString("Maintenance")
        end
        addPerkXp(player, maintenancePerk, amount)
    end
end

local function resolvePunchObject(args)
    local x = args and tonumber(args.x) or nil
    local y = args and tonumber(args.y) or nil
    local z = args and tonumber(args.z) or nil
    local objectIndex = args and tonumber(args.objectIndex) or nil
    local cell = getCell and getCell() or nil
    if not cell or not cell.getGridSquare or not x or not y or not z or not objectIndex then
        return nil
    end

    local square = cell:getGridSquare(math.floor(x), math.floor(y), math.floor(z))
    local objects = square and safeCall(square, "getObjects") or nil
    objectIndex = math.floor(objectIndex)
    if not objects or not objects.size or not objects.get
        or objectIndex < 0 or objectIndex >= objects:size() then
        return nil
    end

    local object = objects:get(objectIndex)
    if not FightZ.isPunchableDoorObject or not FightZ.isPunchableDoorObject(object) then
        return nil
    end
    return object, square
end

local function applyPunchObjectCommand(player, args)
    local object, square = resolvePunchObject(args)
    local playerSquare = safeCall(player, "getCurrentSquare") or safeCall(player, "getSquare")
    if not object or not square or not playerSquare then
        return
    end

    local playerZ = math.floor(tonumber(safeCall(playerSquare, "getZ")) or 0)
    local objectZ = math.floor(tonumber(safeCall(square, "getZ")) or playerZ)
    if playerZ ~= objectZ then
        return
    end

    local adjacent = safeCall(object, "isAdjacentToSquare", playerSquare) == true
    local exactDoor = safeCall(playerSquare, "getDoorTo", square) == object
    if square ~= playerSquare and not adjacent and not exactDoor then
        return
    end

    local px = tonumber(safeCall(player, "getX"))
    local py = tonumber(safeCall(player, "getY"))
    local sx = tonumber(safeCall(square, "getX"))
    local sy = tonumber(safeCall(square, "getY"))
    if not px or not py or not sx or not sy then
        return
    end
    local dx = (sx + 0.5) - px
    local dy = (sy + 0.5) - py
    if (dx * dx) + (dy * dy) > 4.0 then
        return
    end

    local now = getTimeMs()
    local lastHit = punchObjectHitTimes[player] or 0
    if lastHit > 0 and now - lastHit < 150 then
        return
    end
    punchObjectHitTimes[player] = now

    local damage = math.floor(tonumber(args and args.damage) or 0)
    damage = math.max(1, math.min(FightZ.MANUAL_PUNCH_OBJECT_MAX_DAMAGE or 30, damage))
    if FightZ.applyPunchObjectDamage then
        FightZ.applyPunchObjectDamage(object, damage)
    end
end

local function broadcastPunchAnimation(player, args)
    if not player or not sendServerCommand then
        return
    end

    local now = getTimeMs()
    local lastAnimation = punchAnimationTimes[player] or 0
    if lastAnimation > 0 and now - lastAnimation < 100 then
        return
    end
    punchAnimationTimes[player] = now

    local speedTier = tostring(args and args.speedTier or "normal")
    if validPunchSpeedTiers[speedTier] ~= true then
        speedTier = "normal"
    end
    local sequence = (punchAnimationSequences[player] or 0) + 1
    punchAnimationSequences[player] = sequence
    local playerOnlineID = math.floor(tonumber(safeCall(player, "getOnlineID")) or -1)
    if playerOnlineID < 0 then
        return
    end

    sendServerCommand("FightZ", "PunchAnimation", {
        playerOnlineID = playerOnlineID,
        sequence = sequence,
        critical = args and args.critical == true,
        floorAttack = args and args.floorAttack == true,
        animIndex = math.max(1, math.min(3, math.floor(tonumber(args and args.animIndex) or 1))),
        speedTier = speedTier,
        punchSpeed = math.max(0.30, math.min(1.20, tonumber(args and args.punchSpeed) or 0.90)),
        floorSpeed = math.max(0.30, math.min(1.20, tonumber(args and args.floorSpeed) or 1.0)),
        durationMs = math.max(300, math.min(2000, tonumber(args and args.durationMs) or 1200)),
    })
end

local function onClientCommand(module, command, player, args)
    if module ~= "FightZ" then
        return
    end
    if not player or safeCall(player, "isDead") == true then
        return
    end

    -- Animation replication is cosmetic and already rate-limited. Handle it
    -- before trait/hand validation because the server-side IsoPlayer can lag
    -- one inventory or trait update behind the client that started the punch.
    if command == "PunchAnimation" then
        broadcastPunchAnimation(player, args)
        return
    end

    if not FightZ.hasFistCombatTrait or FightZ.hasFistCombatTrait(player) ~= true then
        return
    end
    if not FightZ.hasEmptyHandsForFightZ or FightZ.hasEmptyHandsForFightZ(player) ~= true then
        return
    end
    if command == "PunchObject" then
        applyPunchObjectCommand(player, args)
        return
    end
    if command ~= "PunchXp" then
        return
    end

    local now = getTimeMs()
    local lastAward = punchXpAwardTimes[player] or 0
    if lastAward > 0 and now - lastAward < 150 then
        return
    end
    punchXpAwardTimes[player] = now

    local critical = args and args.critical == true
    addFistXp(player, critical and 2.0 or 1.0)
    addPunchSecondaryXp(player, critical)
    if args and args.killedZombie == true then
        creditVanillaZombieKill(player)
    end
end

if Events and Events.OnClientCommand then
    Events.OnClientCommand.Add(onClientCommand)
end

if Events and FightZ.ENABLE_SERVER_COMBAT_EVENTS ~= false then
    if Events.OnWeaponHitXp then
        Events.OnWeaponHitXp.Add(onWeaponHitXp)
    end
    if FightZ.ENABLE_SERVER_CHARACTER_HIT_EVENT == true and Events.OnWeaponHitCharacter then
        Events.OnWeaponHitCharacter.Add(onWeaponHitCharacter)
    end
end
