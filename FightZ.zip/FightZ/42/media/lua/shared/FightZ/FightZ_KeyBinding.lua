FightZ = FightZ or {}

if keyBinding and Keyboard then
    local section = {}
    section.value = "[FightZ]"
    table.insert(keyBinding, section)

    local punch = {}
    punch.value = "FightZPunch"
    punch.key = Keyboard.KEY_Z
    table.insert(keyBinding, punch)
end
