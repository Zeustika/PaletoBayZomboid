FightZ = FightZ or {}

FightZ.PERK_ID = "Fist"
FightZ.TRAIT_INICIATE = "fightz:fistiniciate"
FightZ.TRAIT_FIGHTER = "fightz:fistfighter"
FightZ.TRAIT_AMATEUR = "fightz:fistamateur"
FightZ.BOOST_INICIATE = 1
FightZ.BOOST_FIGHTER = 3
FightZ.XP_LEVELS = { 75, 150, 300, 750, 1500, 3000, 4500, 6000, 8000, 10000 }
FightZ.SKILLBOOK_MULTIPLIERS = { 3, 5, 8, 12, 16 }

local function resolveTraitObject(traitId)
    if type(traitId) ~= "string" then
        return traitId
    end

    if FightZ.TRAIT_OBJECTS and FightZ.TRAIT_OBJECTS[traitId] then
        return FightZ.TRAIT_OBJECTS[traitId]
    end

    if CharacterTrait and CharacterTrait.get and ResourceLocation and ResourceLocation.of then
        local okLocation, resourceLocation = pcall(function()
            return ResourceLocation.of(traitId)
        end)
        if okLocation and resourceLocation then
            local okTrait, traitObject = pcall(function()
                return CharacterTrait.get(resourceLocation)
            end)
            if okTrait and traitObject then
                FightZ.TRAIT_OBJECTS = FightZ.TRAIT_OBJECTS or {}
                FightZ.TRAIT_OBJECTS[traitId] = traitObject
                return traitObject
            end
        end
    end

    if CharacterTrait and CharacterTrait.register then
        local okRegister, traitObject = pcall(function()
            return CharacterTrait.register(traitId)
        end)
        if okRegister and traitObject then
            FightZ.TRAIT_OBJECTS = FightZ.TRAIT_OBJECTS or {}
            FightZ.TRAIT_OBJECTS[traitId] = traitObject
            return traitObject
        end
    end

    return nil
end

local function normalizeTraitId(value)
    if value == nil then
        return nil
    end
    return tostring(value):lower()
end

local function traitValueMatches(value, traitId, traitObject)
    if value == nil then
        return false
    end

    if traitObject and value == traitObject then
        return true
    end

    local target = normalizeTraitId(traitId)
    if not target then
        return false
    end

    local valueText = normalizeTraitId(value)
    if valueText == target or (valueText and valueText:find(target, 1, true)) then
        return true
    end

    local methods = {
        "getId",
        "getID",
        "getName",
        "getType",
        "getTraitID",
        "getFullType",
        "getResourceLocation",
    }
    for i = 1, #methods do
        local methodName = methods[i]
        if value[methodName] then
            local ok, result = pcall(value[methodName], value)
            result = ok and normalizeTraitId(result) or nil
            if result == target or (result and result:find(target, 1, true)) then
                return true
            end
        end
    end

    return false
end

local function collectionContainsTrait(collection, traitId, traitObject)
    if not collection then
        return false
    end

    if collection.contains then
        if traitObject then
            local ok, result = pcall(function()
                return collection:contains(traitObject)
            end)
            if ok and result == true then
                return true
            end
        end
    end

    local size = nil
    if collection.size then
        local ok, result = pcall(collection.size, collection)
        size = ok and tonumber(result) or nil
    elseif collection.getItemCount then
        local ok, result = pcall(collection.getItemCount, collection)
        size = ok and tonumber(result) or nil
    end

    if size and size > 0 then
        for i = 0, size - 1 do
            local entry = nil
            if collection.get then
                local ok, result = pcall(collection.get, collection, i)
                entry = ok and result or nil
            end
            if entry == nil and collection.getItemByIndex then
                local ok, result = pcall(collection.getItemByIndex, collection, i)
                entry = ok and result or nil
            end
            if traitValueMatches(entry, traitId, traitObject) then
                return true
            end
        end
    end

    if collection.iterator then
        local okIterator, iterator = pcall(collection.iterator, collection)
        if okIterator and iterator and iterator.hasNext and iterator.next then
            while true do
                local okHasNext, hasNext = pcall(iterator.hasNext, iterator)
                if not okHasNext or hasNext ~= true then
                    break
                end
                local okNext, entry = pcall(iterator.next, iterator)
                if okNext and traitValueMatches(entry, traitId, traitObject) then
                    return true
                end
            end
        end
    end

    return false
end

local function hasTrait(player, traitId)
    if not player or not traitId then
        return false
    end

    local traitObject = resolveTraitObject(traitId)

    if player.hasTrait and traitObject then
        local ok, result = pcall(function()
            return player:hasTrait(traitObject)
        end)
        if ok and result == true then
            return true
        end
    end

    local characterTraits = nil
    if player.getCharacterTraits then
        local okTraits, resultTraits = pcall(function()
            return player:getCharacterTraits()
        end)
        if okTraits then
            characterTraits = resultTraits
        end
    end
    if collectionContainsTrait(characterTraits, traitId, traitObject) then
        return true
    end

    if player.getTraits then
        local okTraits, resultTraits = pcall(function()
            return player:getTraits()
        end)
        if okTraits and resultTraits ~= characterTraits and collectionContainsTrait(resultTraits, traitId, traitObject) then
            return true
        end
    end

    return false
end

function FightZ.hasTrait(player, traitId)
    return hasTrait(player, traitId)
end

function FightZ.resolveTraitObject(traitId)
    return resolveTraitObject(traitId)
end

function FightZ.resolvePerk()
    if not Perks then
        return nil
    end

    return Perks[FightZ.PERK_ID] or Perks.Fist
end

function FightZ.registerFistPerk()
    return FightZ.resolvePerk()
end

local function addUniqueMultiplierKey(keys, value)
    if value == nil then
        return
    end

    local key = tostring(value)
    if key == "" then
        return
    end

    for i = 1, #keys do
        if keys[i] == key then
            return
        end
    end

    keys[#keys + 1] = key
end

function FightZ.getFistXpMultiplierKeys()
    local keys = {}
    addUniqueMultiplierKey(keys, FightZ.PERK_ID)
    addUniqueMultiplierKey(keys, "Fist")

    local perk = FightZ.resolvePerk()
    if perk then
        local methodNames = { "getType", "getName", "name" }
        for i = 1, #methodNames do
            local method = perk[methodNames[i]]
            if type(method) == "function" then
                local ok, result = pcall(method, perk)
                if ok and (type(result) == "string" or type(result) == "number") then
                    addUniqueMultiplierKey(keys, result)
                end
            end
        end
    end

    return keys
end

function FightZ.ensureFistXpMultiplierConfig()
    if not SandboxVars then
        return
    end

    SandboxVars.MultiplierConfig = SandboxVars.MultiplierConfig or {}
    local config = SandboxVars.MultiplierConfig
    if config.Global == nil then
        config.Global = 1.0
    end
    if config.GlobalToggle == nil then
        config.GlobalToggle = true
    end

    local keys = FightZ.getFistXpMultiplierKeys()
    for i = 1, #keys do
        local key = keys[i]
        if config[key] == nil then
            config[key] = 1.0
        end
    end
end

function FightZ.registerSkillBook()
    if not SkillBook then
        return
    end

    local perk = FightZ.resolvePerk()
    if not perk then
        return
    end

    SkillBook[FightZ.PERK_ID] = SkillBook[FightZ.PERK_ID] or {}
    SkillBook[FightZ.PERK_ID].perk = perk
    SkillBook[FightZ.PERK_ID].maxMultiplier1 = FightZ.SKILLBOOK_MULTIPLIERS[1]
    SkillBook[FightZ.PERK_ID].maxMultiplier2 = FightZ.SKILLBOOK_MULTIPLIERS[2]
    SkillBook[FightZ.PERK_ID].maxMultiplier3 = FightZ.SKILLBOOK_MULTIPLIERS[3]
    SkillBook[FightZ.PERK_ID].maxMultiplier4 = FightZ.SKILLBOOK_MULTIPLIERS[4]
    SkillBook[FightZ.PERK_ID].maxMultiplier5 = FightZ.SKILLBOOK_MULTIPLIERS[5]
end

function FightZ.refreshFistPerkName()
end

function FightZ.getTraitFistBoost(player)
    if hasTrait(player, FightZ.TRAIT_FIGHTER) then
        return FightZ.BOOST_FIGHTER
    end

    if hasTrait(player, FightZ.TRAIT_INICIATE) then
        return FightZ.BOOST_INICIATE
    end

    return 0
end

function FightZ.hasFistCombatTrait(player)
    return hasTrait(player, FightZ.TRAIT_AMATEUR)
        or hasTrait(player, FightZ.TRAIT_INICIATE)
        or hasTrait(player, FightZ.TRAIT_FIGHTER)
end

function FightZ.getPlayerFistBoost(player)
    return FightZ.getTraitFistBoost(player)
end

function FightZ.applyTraitBoost(player)
    local perk = FightZ.resolvePerk()
    local boost = FightZ.getTraitFistBoost(player)
    local xp = player and player.getXp and player:getXp() or nil
    if not perk or boost <= 0 or not xp then
        return
    end

    if xp.getPerkBoost then
        local current = xp:getPerkBoost(perk)
        if current and current >= boost then
            return
        end
    end

    if xp.setPerkBoost then
        xp:setPerkBoost(perk, boost)
    end
end

local function bootstrapFightZSkillBook()
    FightZ.ensureFistXpMultiplierConfig()
    FightZ.registerSkillBook()
end

bootstrapFightZSkillBook()

if Events then
    if Events.OnGameBoot then
        Events.OnGameBoot.Add(bootstrapFightZSkillBook)
    end
    if Events.OnGameStart then
        Events.OnGameStart.Add(bootstrapFightZSkillBook)
    end
end
