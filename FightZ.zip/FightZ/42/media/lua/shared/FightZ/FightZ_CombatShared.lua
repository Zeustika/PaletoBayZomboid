FightZ = FightZ or {}

FightZ.ENABLE_FIST_COMBAT = true
FightZ.ENABLE_FIST_XP = true
FightZ.ENABLE_FIST_DAMAGE = true
FightZ.ENABLE_FIST_ENDURANCE = true
FightZ.ENABLE_FIST_MUSCLE_STRAIN = true
FightZ.ENABLE_REQUIRE_PUNCH_INTENT = true
FightZ.ENABLE_SERVER_COMBAT_EVENTS = false
FightZ.ENABLE_SERVER_CHARACTER_HIT_EVENT = false
FightZ.ENABLE_ZOMBIE_REACTIONS = false
FightZ.ENABLE_CUSTOM_PUNCH_ANIMATIONS = false
if FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MIN == nil
    or FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MIN == 0.01
    or FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MIN == 0.006 then
    FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MIN = 0.003
end
if FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MAX == nil
    or FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MAX == 0.015
    or FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MAX == 0.09
    or FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MAX == 0.009 then
    FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MAX = 0.005
end
FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_BASE = FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_BASE or 0.20
FightZ.MANUAL_PUNCH_STRAIN_CHAIN_WINDOW_MS = FightZ.MANUAL_PUNCH_STRAIN_CHAIN_WINDOW_MS or 7500
FightZ.MANUAL_PUNCH_STRAIN_CHAIN_BASE_MULTIPLIER = FightZ.MANUAL_PUNCH_STRAIN_CHAIN_BASE_MULTIPLIER or 0.8
if FightZ.MANUAL_PUNCH_STRAIN_CHAIN_STEP == nil
    or FightZ.MANUAL_PUNCH_STRAIN_CHAIN_STEP == 0.5
    or FightZ.MANUAL_PUNCH_STRAIN_CHAIN_STEP == 0.2
    or FightZ.MANUAL_PUNCH_STRAIN_CHAIN_STEP == 0.1 then
    FightZ.MANUAL_PUNCH_STRAIN_CHAIN_STEP = 0.05
end
if FightZ.MANUAL_PUNCH_STRAIN_CHAIN_MAX_MULTIPLIER == nil
    or FightZ.MANUAL_PUNCH_STRAIN_CHAIN_MAX_MULTIPLIER == 5.0 then
    FightZ.MANUAL_PUNCH_STRAIN_CHAIN_MAX_MULTIPLIER = 2.0
end
FightZ.MANUAL_PUNCH_CRIT_BASE_CHANCE = FightZ.MANUAL_PUNCH_CRIT_BASE_CHANCE or 3
FightZ.MANUAL_PUNCH_CRIT_LEVEL_CHANCE = FightZ.MANUAL_PUNCH_CRIT_LEVEL_CHANCE or 1.2
FightZ.MANUAL_PUNCH_CRIT_BOOST_CHANCE = FightZ.MANUAL_PUNCH_CRIT_BOOST_CHANCE or 2.0
FightZ.MANUAL_PUNCH_CRIT_MAX_CHANCE = FightZ.MANUAL_PUNCH_CRIT_MAX_CHANCE or 25
FightZ.MANUAL_PUNCH_PAIN_DAMAGE_PENALTY_PER_LEVEL = FightZ.MANUAL_PUNCH_PAIN_DAMAGE_PENALTY_PER_LEVEL or 0.05
FightZ.MANUAL_PUNCH_PAIN_DAMAGE_MAX_PENALTY = FightZ.MANUAL_PUNCH_PAIN_DAMAGE_MAX_PENALTY or 0.20
FightZ.MANUAL_PUNCH_WEAK_DAMAGE_THRESHOLD = FightZ.MANUAL_PUNCH_WEAK_DAMAGE_THRESHOLD or 0.08
FightZ.MANUAL_PUNCH_WEAK_DAMAGE_RANGES = FightZ.MANUAL_PUNCH_WEAK_DAMAGE_RANGES or {
    [0] = { min = 0.06, max = 0.07 },
    [1] = { min = 0.04, max = 0.05 },
    [2] = { min = 0.02, max = 0.03 },
    [3] = { min = 0.015, max = 0.025 },
    [4] = { min = 0.01, max = 0.02 },
}
FightZ.MANUAL_PUNCH_WEAK_HIT_CHANCE = FightZ.MANUAL_PUNCH_WEAK_HIT_CHANCE or 12
FightZ.MANUAL_PUNCH_WEAK_HIT_PAIN_CHANCE = FightZ.MANUAL_PUNCH_WEAK_HIT_PAIN_CHANCE or 5
FightZ.MANUAL_PUNCH_WEAK_HIT_MAX_CHANCE = FightZ.MANUAL_PUNCH_WEAK_HIT_MAX_CHANCE or 35
FightZ.MANUAL_FLOOR_SMASH_ENABLED = FightZ.MANUAL_FLOOR_SMASH_ENABLED ~= false
FightZ.MANUAL_FLOOR_SMASH_BASE_CHANCE = FightZ.MANUAL_FLOOR_SMASH_BASE_CHANCE or 14
FightZ.MANUAL_FLOOR_SMASH_LEVEL_CHANCE = FightZ.MANUAL_FLOOR_SMASH_LEVEL_CHANCE or 2.0
FightZ.MANUAL_FLOOR_SMASH_BOOST_CHANCE = FightZ.MANUAL_FLOOR_SMASH_BOOST_CHANCE or 3.0
FightZ.MANUAL_FLOOR_SMASH_CRIT_BONUS = FightZ.MANUAL_FLOOR_SMASH_CRIT_BONUS or 8
FightZ.MANUAL_FLOOR_SMASH_MAX_CHANCE = FightZ.MANUAL_FLOOR_SMASH_MAX_CHANCE or 45
FightZ.MANUAL_FLOOR_SMASH_MIN_CHANCE = FightZ.MANUAL_FLOOR_SMASH_MIN_CHANCE or 1
FightZ.PUNCH_INTENT_WINDOW_MS = 650
FightZ.CONFIRMED_PUNCH_WINDOW_MS = 450
FightZ.STRENGTH_PUNCH_DAMAGE_CURVE = FightZ.STRENGTH_PUNCH_DAMAGE_CURVE or {
    [0] = 1.00,
    [1] = 1.01,
    [2] = 1.02,
    [3] = 1.03,
    [4] = 1.045,
    [5] = 1.06,
    [6] = 1.08,
    [7] = 1.10,
    [8] = 1.12,
    [9] = 1.14,
    [10] = 1.16,
}
FightZ.FITNESS_PUNCH_STRAIN_CURVE = FightZ.FITNESS_PUNCH_STRAIN_CURVE or {
    [0] = 1.00,
    [1] = 0.99,
    [2] = 0.98,
    [3] = 0.97,
    [4] = 0.95,
    [5] = 0.93,
    [6] = 0.91,
    [7] = 0.89,
    [8] = 0.87,
    [9] = 0.85,
    [10] = 0.82,
}
FightZ.FIST_PUNCH_SPEED_CURVE = FightZ.FIST_PUNCH_SPEED_CURVE or {
    [0] = 1.00,
    [1] = 1.01,
    [2] = 1.02,
    [3] = 1.03,
    [4] = 1.045,
    [5] = 1.06,
    [6] = 1.08,
    [7] = 1.10,
    [8] = 1.12,
    [9] = 1.14,
    [10] = 1.16,
}

local function safeCall(target, methodName, ...)
    if target and target[methodName] then
        return target[methodName](target, ...)
    end
    return nil
end

local function getCurveLevel(player, perk)
    if not player or not perk or not player.getPerkLevel then
        return 0
    end

    local ok, value = pcall(player.getPerkLevel, player, perk)
    local level = ok and math.floor(tonumber(value) or 0) or 0
    if level < 0 then
        return 0
    end
    if level > 10 then
        return 10
    end
    return level
end

local function getCurveMultiplier(curve, level)
    level = math.max(0, math.min(10, math.floor(tonumber(level) or 0)))
    return tonumber(curve and curve[level]) or 1.0
end

local function getFightZSandboxNumber(name, fallback, minimum, maximum)
    local value = SandboxVars
        and SandboxVars.FightZ
        and SandboxVars.FightZ[name]
        or nil

    if value == nil and getSandboxOptions then
        local ok, optionValue = pcall(function()
            local options = getSandboxOptions()
            local option = options and options:getOptionByName("FightZ." .. name) or nil
            return option and option:getValue() or nil
        end)
        if ok then
            value = optionValue
        end
    end

    value = tonumber(value) or fallback
    if minimum ~= nil and value < minimum then
        value = minimum
    elseif maximum ~= nil and value > maximum then
        value = maximum
    end
    return value
end

function FightZ.getSandboxFistDamageMultiplier()
    return getFightZSandboxNumber("FistDamageMultiplier", 1.0, 0.10, 5.0)
end

function FightZ.getSandboxComboStrainStep()
    return getFightZSandboxNumber(
        "ComboMuscleStrainStep",
        FightZ.MANUAL_PUNCH_STRAIN_CHAIN_STEP or 0.05,
        0.0,
        0.5
    )
end

function FightZ.getStrengthPunchDamageMultiplier(player)
    local perk = Perks and Perks.Strength or nil
    return getCurveMultiplier(FightZ.STRENGTH_PUNCH_DAMAGE_CURVE, getCurveLevel(player, perk))
end

function FightZ.getFitnessPunchStrainMultiplier(player)
    local perk = Perks and Perks.Fitness or nil
    return getCurveMultiplier(FightZ.FITNESS_PUNCH_STRAIN_CURVE, getCurveLevel(player, perk))
end

function FightZ.getFistPunchSpeedMultiplier(player)
    local level = FightZ.getFistLevel and FightZ.getFistLevel(player) or 0
    return getCurveMultiplier(FightZ.FIST_PUNCH_SPEED_CURVE, level)
end

function FightZ.isPlayer(object)
    if not object then
        return false
    end

    if instanceof then
        return instanceof(object, "IsoPlayer")
    end

    return object.getXp ~= nil and object.getInventory ~= nil
end

function FightZ.isZombie(object)
    if not object then
        return false
    end

    if instanceof then
        return instanceof(object, "IsoZombie")
    end

    return object.setHitReaction ~= nil and object.isZombie ~= nil
end

function FightZ.isPunchableDoorObject(object)
    if not object then
        return false
    end

    if safeCall(object, "isDestroyed") == true
        or safeCall(object, "IsOpen") == true
        or safeCall(object, "isOpen") == true then
        return false
    end

    if instanceof then
        if instanceof(object, "IsoDoor") then
            return true
        end
        if not instanceof(object, "IsoThumpable") then
            return false
        end
    end

    return safeCall(object, "isDoor") == true
end

function FightZ.applyPunchObjectDamage(object, amount)
    amount = math.floor((tonumber(amount) or 0) + 0.5)
    if not FightZ.isPunchableDoorObject(object) or amount <= 0 then
        return false
    end

    if instanceof and instanceof(object, "IsoDoor") then
        local health = tonumber(safeCall(object, "getHealth"))
        if not health or not object.setHealth then
            return false
        end

        local remaining = health - amount
        object:setHealth(math.max(0, remaining))
        if remaining <= 0 and object.destroy then
            object:destroy()
        end
        return true
    end

    if object.Damage then
        local ok = pcall(object.Damage, object, amount)
        return ok == true
    end

    return false
end

function FightZ.isBareHands(weapon)
    if not weapon then
        return true
    end

    local weaponType = safeCall(weapon, "getType")
    if weaponType == "BareHands" then
        return true
    end

    local fullType = safeCall(weapon, "getFullType")
    if fullType == "Base.BareHands" or fullType == "base.BareHands" then
        return true
    end

    return false
end

FightZ.FIST_ALLOWED_SECONDARY_ITEMS = FightZ.FIST_ALLOWED_SECONDARY_ITEMS or {
    ["Base.Lighter"] = true,
    ["Base.Matches"] = true,
    ["Base.HandTorch"] = true,
    ["Base.FlashLight_AngleHead"] = true,
    ["Base.FlashLight_AngleHead_Army"] = true,
    ["Base.Torch"] = true,
    ["Base.PenLight"] = true,
    ["Base.Lantern_HurricaneLit"] = true,
    ["Base.Lantern_Hurricane"] = true,
    ["Base.Lantern_Hurricane_CopperLit"] = true,
    ["Base.Lantern_Hurricane_Copper"] = true,
    ["Base.Lantern_Hurricane_ForgedLit"] = true,
    ["Base.Lantern_Hurricane_Forged"] = true,
    ["Base.Lantern_Hurricane_GoldLit"] = true,
    ["Base.Lantern_Hurricane_Gold"] = true,
    ["Base.Lantern_Hurricane_SilverLit"] = true,
    ["Base.Lantern_Hurricane_Silver"] = true,
    ["Base.Lantern_Propane"] = true,
    ["Base.Lantern_CraftedElectric"] = true,
    ["Base.Flashlight_Crafted"] = true,
    ["Base.LEDLantern"] = true,
    ["Base.LedLantern"] = true,
    ["Base.Lantern_LED"] = true,
    ["Base.Lantern_LEDLit"] = true,
    ["LEDLantern.LEDLantern"] = true,
    ["LEDLantern.LEDLantern_Blue"] = true,
    ["LEDLantern.LEDLantern_Red"] = true,
    ["LEDLantern.LEDLantern_Green"] = true,
    ["LEDLantern.LEDLantern_Orange"] = true,
    ["LEDLantern.LEDLantern_White"] = true,
    ["LEDLantern.LEDLantern_Black"] = true,
}
FightZ.FIST_PRIMARY_ONLY_SECONDARY_ITEMS = FightZ.FIST_PRIMARY_ONLY_SECONDARY_ITEMS or {
    ["Base.Lighter"] = true,
    ["Base.Matches"] = true,
    ["Base.HandTorch"] = true,
    ["Base.FlashLight_AngleHead"] = true,
    ["Base.FlashLight_AngleHead_Army"] = true,
    ["Base.Torch"] = true,
    ["Base.PenLight"] = true,
    ["Base.Lantern_HurricaneLit"] = true,
    ["Base.Lantern_Hurricane"] = true,
    ["Base.Lantern_Hurricane_CopperLit"] = true,
    ["Base.Lantern_Hurricane_Copper"] = true,
    ["Base.Lantern_Hurricane_ForgedLit"] = true,
    ["Base.Lantern_Hurricane_Forged"] = true,
    ["Base.Lantern_Hurricane_GoldLit"] = true,
    ["Base.Lantern_Hurricane_Gold"] = true,
    ["Base.Lantern_Hurricane_SilverLit"] = true,
    ["Base.Lantern_Hurricane_Silver"] = true,
    ["Base.Lantern_Propane"] = true,
    ["Base.Lantern_CraftedElectric"] = true,
    ["Base.Flashlight_Crafted"] = true,
    ["Base.LEDLantern"] = true,
    ["Base.LedLantern"] = true,
    ["Base.Lantern_LED"] = true,
    ["Base.Lantern_LEDLit"] = true,
    ["LEDLantern.LEDLantern"] = true,
    ["LEDLantern.LEDLantern_Blue"] = true,
    ["LEDLantern.LEDLantern_Red"] = true,
    ["LEDLantern.LEDLantern_Green"] = true,
    ["LEDLantern.LEDLantern_Orange"] = true,
    ["LEDLantern.LEDLantern_White"] = true,
    ["LEDLantern.LEDLantern_Black"] = true,
}

function FightZ.isAllowedSecondaryForFists(item)
    if FightZ.isBareHands(item) then
        return true
    end

    local fullType = safeCall(item, "getFullType")
    if fullType and FightZ.FIST_ALLOWED_SECONDARY_ITEMS[fullType] == true then
        return true
    end

    local itemType = safeCall(item, "getType")
    if itemType and FightZ.FIST_ALLOWED_SECONDARY_ITEMS[itemType] == true then
        return true
    end
    if itemType and FightZ.FIST_ALLOWED_SECONDARY_ITEMS["Base." .. tostring(itemType)] == true then
        return true
    end

    return false
end

function FightZ.isPrimaryOnlySecondaryForFists(item)
    if FightZ.isBareHands(item) then
        return false
    end

    local fullType = safeCall(item, "getFullType")
    if fullType and FightZ.FIST_PRIMARY_ONLY_SECONDARY_ITEMS[fullType] == true then
        return true
    end

    local itemType = safeCall(item, "getType")
    if itemType and FightZ.FIST_PRIMARY_ONLY_SECONDARY_ITEMS[itemType] == true then
        return true
    end
    if itemType and FightZ.FIST_PRIMARY_ONLY_SECONDARY_ITEMS["Base." .. tostring(itemType)] == true then
        return true
    end

    return false
end

function FightZ.hasFightZStyle(player)
    if not player then
        return false
    end

    if FightZ.hasFistCombatTrait then
        return FightZ.hasFistCombatTrait(player)
    end

    return FightZ.getPlayerFistBoost and FightZ.getPlayerFistBoost(player) > 0
end

function FightZ.hasEmptyHandsForFightZ(player)
    if not player then
        return false
    end

    local primary = safeCall(player, "getPrimaryHandItem")
    local secondary = safeCall(player, "getSecondaryHandItem")

    return FightZ.isBareHands(primary) and FightZ.isAllowedSecondaryForFists(secondary)
end

function FightZ.shouldUsePrimaryOnlyPunch(player)
    if not player then
        return false
    end

    local primary = safeCall(player, "getPrimaryHandItem")
    local secondary = safeCall(player, "getSecondaryHandItem")

    return FightZ.isBareHands(primary) and FightZ.isPrimaryOnlySecondaryForFists(secondary)
end

function FightZ.markPunchIntent(player, durationMs)
    local modData = safeCall(player, "getModData")
    if not modData then
        return
    end

    modData.FightZPunchIntentUntilMs = FightZ.getTimeMs() + (durationMs or FightZ.PUNCH_INTENT_WINDOW_MS)
end

function FightZ.clearPunchIntent(player)
    local modData = safeCall(player, "getModData")
    if modData then
        modData.FightZPunchIntentUntilMs = nil
    end
end

function FightZ.hasPunchIntent(player)
    if FightZ.ENABLE_REQUIRE_PUNCH_INTENT == false then
        return true
    end

    local modData = safeCall(player, "getModData")
    local intentUntil = modData and tonumber(modData.FightZPunchIntentUntilMs) or 0

    return intentUntil >= FightZ.getTimeMs()
end

function FightZ.markConfirmedPunch(player, durationMs)
    local modData = safeCall(player, "getModData")
    if not modData then
        return
    end

    modData.FightZConfirmedPunchUntilMs = FightZ.getTimeMs() + (durationMs or FightZ.CONFIRMED_PUNCH_WINDOW_MS)
end

function FightZ.clearConfirmedPunch(player)
    local modData = safeCall(player, "getModData")
    if modData then
        modData.FightZConfirmedPunchUntilMs = nil
    end
end

function FightZ.hasConfirmedPunch(player)
    local modData = safeCall(player, "getModData")
    local punchUntil = modData and tonumber(modData.FightZConfirmedPunchUntilMs) or 0

    return punchUntil >= FightZ.getTimeMs()
end

function FightZ.isVanillaBareHandsContact(target, weapon)
    if not FightZ.isBareHands(weapon) then
        return false
    end

    return true
end

function FightZ.isFightZHit(attacker, target, weapon)
    if not FightZ.ENABLE_FIST_COMBAT then
        return false
    end

    if not FightZ.isPlayer(attacker) or not FightZ.isZombie(target) then
        return false
    end

    if not FightZ.hasFightZStyle(attacker) or not FightZ.hasEmptyHandsForFightZ(attacker) then
        return false
    end

    if not FightZ.hasPunchIntent(attacker) then
        return false
    end

    if not FightZ.isBareHands(weapon) then
        return false
    end

    if FightZ.isVanillaBareHandsContact(target, weapon) and not FightZ.hasConfirmedPunch(attacker) then
        return false
    end

    if safeCall(target, "isOnFloor") == true then
        return false
    end

    local dead = safeCall(target, "isDead")
    return not dead
end

function FightZ.getTimeMs()
    if getTimestampMs then
        return getTimestampMs()
    end

    if getGameTime then
        local gameTime = getGameTime()
        if gameTime and gameTime.getWorldAgeHours then
            return gameTime:getWorldAgeHours() * 3600000
        end
    end

    return os.time() * 1000
end

function FightZ.getFistLevel(player)
    local perk = FightZ.resolvePerk and (FightZ.resolvePerk() or FightZ.registerFistPerk())
    if not player or not perk or not player.getPerkLevel then
        return 0
    end

    local level = player:getPerkLevel(perk)
    if level then
        return level
    end

    return 0
end

function FightZ.randomInt(maxExclusive)
    if ZombRand then
        return ZombRand(maxExclusive)
    end

    return math.random(0, maxExclusive - 1)
end

function FightZ.getPainMoodleLevel(player)
    local moodles = safeCall(player, "getMoodles")
    if moodles and MoodleType and moodles.getMoodleLevel then
        local candidates = { "PAIN", "Pain" }
        for i = 1, #candidates do
            local moodleType = MoodleType[candidates[i]]
            if moodleType ~= nil then
                local ok, level = pcall(moodles.getMoodleLevel, moodles, moodleType)
                level = ok and tonumber(level) or nil
                if level then
                    if level < 0 then
                        return 0
                    elseif level > 4 then
                        return 4
                    end
                    return math.floor(level)
                end
            end
        end
    end

    local stats = safeCall(player, "getStats")
    local pain = tonumber(safeCall(stats, "getPain"))
    if pain == nil then
        local bodyDamage = safeCall(player, "getBodyDamage")
        pain = tonumber(safeCall(bodyDamage, "getPain"))
    end
    if pain == nil or pain <= 0 then
        return 0
    end
    if pain > 1 then
        pain = pain / 100
    end
    local level = math.ceil(pain * 4)
    if level < 1 then
        return 1
    elseif level > 4 then
        return 4
    end
    return level
end

function FightZ.getPainDamageMultiplier(player)
    local level = FightZ.getPainMoodleLevel and FightZ.getPainMoodleLevel(player) or 0
    local penalty = level * (FightZ.MANUAL_PUNCH_PAIN_DAMAGE_PENALTY_PER_LEVEL or 0.05)
    local maxPenalty = FightZ.MANUAL_PUNCH_PAIN_DAMAGE_MAX_PENALTY or 0.20
    if penalty > maxPenalty then
        penalty = maxPenalty
    elseif penalty < 0 then
        penalty = 0
    end
    return 1 - penalty
end

function FightZ.getStatRatio(player, statName, fallback)
    local stats = safeCall(player, "getStats")
    local value = stats and safeCall(stats, "get" .. tostring(statName))
    value = tonumber(value)
    if value == nil and stats and stats.get and CharacterStat then
        local stat = CharacterStat[string.upper(tostring(statName))]
        if stat ~= nil then
            local ok, result = pcall(stats.get, stats, stat)
            value = ok and tonumber(result) or nil
        end
    end
    if value == nil then
        return fallback or 0
    end
    if value > 1 then
        value = value / 100
    end
    if value < 0 then
        return 0
    elseif value > 1 then
        return 1
    end
    return value
end

function FightZ.getMoodleLevel(player, names)
    local moodles = safeCall(player, "getMoodles")
    local candidates = type(names) == "table" and names or { names }
    if not moodles or not MoodleType or not moodles.getMoodleLevel then
        return 0
    end
    for i = 1, #candidates do
        local moodleType = MoodleType[candidates[i]]
        if moodleType ~= nil then
            local ok, level = pcall(moodles.getMoodleLevel, moodles, moodleType)
            level = ok and tonumber(level) or nil
            if level then
                if level < 0 then
                    return 0
                elseif level > 4 then
                    return 4
                end
                return math.floor(level)
            end
        end
    end
    return 0
end

function FightZ.getFloorSmashChance(player, critical)
    if FightZ.MANUAL_FLOOR_SMASH_ENABLED == false then
        return 0
    end

    local level = FightZ.getFistLevel and FightZ.getFistLevel(player) or 0
    local boost = FightZ.getPlayerFistBoost and FightZ.getPlayerFistBoost(player) or 0
    if level < 0 then
        level = 0
    elseif level > 10 then
        level = 10
    end

    local chance = (FightZ.MANUAL_FLOOR_SMASH_BASE_CHANCE or 14)
        + (level * (FightZ.MANUAL_FLOOR_SMASH_LEVEL_CHANCE or 2.0))
        + (boost * (FightZ.MANUAL_FLOOR_SMASH_BOOST_CHANCE or 3.0))
    if critical then
        chance = chance + (FightZ.MANUAL_FLOOR_SMASH_CRIT_BONUS or 8)
    end

    local endurance = FightZ.getStatRatio(player, "Endurance", 1)
    local fatigue = FightZ.getStatRatio(player, "Fatigue", 0)
    local tiredLevel = FightZ.getMoodleLevel(player, { "TIRED", "Tired" })
    local painLevel = FightZ.getPainMoodleLevel and FightZ.getPainMoodleLevel(player) or 0

    local enduranceFactor = 0.20 + (endurance * 0.80)
    local fatigueFactor = 1.00 - (fatigue * 0.70)
    local tiredFactor = 1.00 - (tiredLevel * 0.16)
    local painFactor = 1.00 - (painLevel * 0.14)
    if fatigueFactor < 0.25 then
        fatigueFactor = 0.25
    end
    if tiredFactor < 0.25 then
        tiredFactor = 0.25
    end
    if painFactor < 0.30 then
        painFactor = 0.30
    end

    chance = chance * enduranceFactor * fatigueFactor * tiredFactor * painFactor
    local maxChance = FightZ.MANUAL_FLOOR_SMASH_MAX_CHANCE or 45
    if chance > maxChance then
        chance = maxChance
    elseif chance < (FightZ.MANUAL_FLOOR_SMASH_MIN_CHANCE or 1) then
        chance = FightZ.MANUAL_FLOOR_SMASH_MIN_CHANCE or 1
    end
    return chance
end

function FightZ.getWeakPunchDamageRange(player)
    local painLevel = FightZ.getPainMoodleLevel and FightZ.getPainMoodleLevel(player) or 0
    local ranges = FightZ.MANUAL_PUNCH_WEAK_DAMAGE_RANGES or {}
    local range = ranges[painLevel] or ranges[0]
    if not range then
        return 0.06, 0.07
    end
    return tonumber(range.min) or 0.06, tonumber(range.max) or 0.07
end

function FightZ.getWeakPunchChance(player)
    local painLevel = FightZ.getPainMoodleLevel and FightZ.getPainMoodleLevel(player) or 0
    local chance = (FightZ.MANUAL_PUNCH_WEAK_HIT_CHANCE or 12)
        + (painLevel * (FightZ.MANUAL_PUNCH_WEAK_HIT_PAIN_CHANCE or 5))
    local maxChance = FightZ.MANUAL_PUNCH_WEAK_HIT_MAX_CHANCE or 35
    if chance > maxChance then
        chance = maxChance
    elseif chance < 0 then
        chance = 0
    end
    return chance
end

function FightZ.rollCriticalPunch(player)
    local level = FightZ.getFistLevel(player)
    local boost = FightZ.getPlayerFistBoost and FightZ.getPlayerFistBoost(player) or 0
    local chance = (FightZ.MANUAL_PUNCH_CRIT_BASE_CHANCE or 3)
        + (level * (FightZ.MANUAL_PUNCH_CRIT_LEVEL_CHANCE or 1.2))
        + (boost * (FightZ.MANUAL_PUNCH_CRIT_BOOST_CHANCE or 2.0))

    local maxChance = FightZ.MANUAL_PUNCH_CRIT_MAX_CHANCE or 25
    if chance > maxChance then
        chance = maxChance
    elseif chance < 0 then
        chance = 0
    end

    return FightZ.randomInt(100) < chance
end

function FightZ.getPreparedPunchCritical(_player)
    return nil
end

function FightZ.prepareNextPunchAnimation(_player, _applyVariables)
    return nil
end
