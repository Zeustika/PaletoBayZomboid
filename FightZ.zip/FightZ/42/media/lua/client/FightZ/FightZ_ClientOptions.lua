local modOptionsOk = pcall(require, "PZAPI/ModOptions")

FightZ = FightZ or {}
FightZ.ClientOptions = FightZ.ClientOptions or {}

local ClientOptions = FightZ.ClientOptions
if ClientOptions._loaded == true then
    return
end
ClientOptions._loaded = true

ClientOptions.MOD_OPTIONS_ID = "FightZ_Client"
ClientOptions.DEFAULT_PUNCH_SOUND_VOLUME = 100
ClientOptions._punchSoundVolume = ClientOptions._punchSoundVolume or ClientOptions.DEFAULT_PUNCH_SOUND_VOLUME
ClientOptions._registered = ClientOptions._registered or false

local function clampVolumePercent(value)
    local number = tonumber(value) or ClientOptions.DEFAULT_PUNCH_SOUND_VOLUME
    if number < 0 then
        number = 0
    elseif number > 100 then
        number = 100
    end
    return math.floor(number + 0.5)
end

local function splitByPipe(line)
    if luautils and luautils.split then
        return luautils.split(line, "|")
    end

    local result = {}
    for part in tostring(line):gmatch("([^|]+)") do
        result[#result + 1] = part
    end
    return result
end

local function loadSavedSliderValue(defaultValue)
    if not getFileReader then
        return defaultValue
    end

    local file = getFileReader("ModOptions.ini", true)
    if not file then
        return defaultValue
    end

    local value = defaultValue
    while true do
        local line = file:readLine()
        if not line then
            break
        end

        local fields = splitByPipe(line)
        if fields[1] == "slider"
            and fields[2] == ClientOptions.MOD_OPTIONS_ID
            and fields[3] == "PunchSoundVolume" then
            local savedValue = tonumber(fields[4])
            if savedValue ~= nil then
                value = savedValue
            end
            break
        end
    end

    file:close()
    return clampVolumePercent(value)
end

local function applyPunchSoundVolume(value)
    ClientOptions._punchSoundVolume = clampVolumePercent(value)
end

function ClientOptions.getPunchSoundVolumePercent()
    return clampVolumePercent(ClientOptions._punchSoundVolume)
end

function ClientOptions.getPunchSoundVolumeMultiplier()
    return ClientOptions.getPunchSoundVolumePercent() / 100.0
end

function FightZ.GetClientPunchSoundVolumeMultiplier()
    return ClientOptions.getPunchSoundVolumeMultiplier()
end

local function bindSliderCallback(option)
    if not option then
        return
    end

    option.onChangeApply = function(selfOrValue, maybeValue)
        local value = maybeValue
        if value == nil then
            value = selfOrValue
        end
        if type(value) == "table" then
            value = value.value
        end
        applyPunchSoundVolume(value)
    end
end

local function registerModOptions()
    if ClientOptions._registered or not modOptionsOk then
        return
    end
    if not (PZAPI and PZAPI.ModOptions and PZAPI.ModOptions.create) then
        return
    end

    local initialVolume = loadSavedSliderValue(ClientOptions.DEFAULT_PUNCH_SOUND_VOLUME)
    applyPunchSoundVolume(initialVolume)

    local options = PZAPI.ModOptions:getOptions(ClientOptions.MOD_OPTIONS_ID)
    if not options then
        options = PZAPI.ModOptions:create(ClientOptions.MOD_OPTIONS_ID, "IGUI_FightZ_Options_Title")
    end
    if not options then
        return
    end

    local volumeOption = options.getOption and options:getOption("PunchSoundVolume") or nil
    if volumeOption then
        volumeOption.value = clampVolumePercent(volumeOption.value)
        applyPunchSoundVolume(volumeOption.value)
        bindSliderCallback(volumeOption)
    else
        options:addTitle("IGUI_FightZ_Options_Audio")
        options:addDescription("IGUI_FightZ_Options_AudioDesc")
        volumeOption = options:addSlider(
            "PunchSoundVolume",
            "IGUI_FightZ_Options_PunchSoundVolume",
            0,
            100,
            5,
            initialVolume,
            "IGUI_FightZ_Options_PunchSoundVolumeTooltip"
        )
        bindSliderCallback(volumeOption)
    end

    ClientOptions._registered = true
end

registerModOptions()

if Events and Events.OnGameStart then
    Events.OnGameStart.Add(registerModOptions)
end
