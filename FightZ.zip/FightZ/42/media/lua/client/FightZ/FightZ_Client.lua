FightZ = FightZ or {}

FightZ.MANUAL_PUNCH_RANGE = FightZ.MANUAL_PUNCH_RANGE or 1.00
FightZ.MANUAL_PUNCH_MIN_RANGE = FightZ.MANUAL_PUNCH_MIN_RANGE or 0.0
FightZ.MANUAL_PUNCH_IMPACT_RANGE = FightZ.MANUAL_PUNCH_IMPACT_RANGE or 1.00
if FightZ.MANUAL_PUNCH_CLOSE_HIT_RANGE == nil or FightZ.MANUAL_PUNCH_CLOSE_HIT_RANGE == 0.70 then
    FightZ.MANUAL_PUNCH_CLOSE_HIT_RANGE = 0.82
end
FightZ.MANUAL_PUNCH_CRIT_IMPACT_RANGE = FightZ.MANUAL_PUNCH_CRIT_IMPACT_RANGE or 1.20
FightZ.MANUAL_PUNCH_CRIT_CLOSE_HIT_RANGE = FightZ.MANUAL_PUNCH_CRIT_CLOSE_HIT_RANGE or 0.85
FightZ.MANUAL_PUNCH_CRIT_FRONT_DOT = FightZ.MANUAL_PUNCH_CRIT_FRONT_DOT or -0.05
FightZ.MANUAL_PUNCH_FALLBACK_RANGE = FightZ.MANUAL_PUNCH_FALLBACK_RANGE or 1.00
if FightZ.MANUAL_PUNCH_FALLBACK_CLOSE_RANGE == nil or FightZ.MANUAL_PUNCH_FALLBACK_CLOSE_RANGE == 0.70 then
    FightZ.MANUAL_PUNCH_FALLBACK_CLOSE_RANGE = 0.90
end
FightZ.MANUAL_PUNCH_FALLBACK_FRONT_DOT = FightZ.MANUAL_PUNCH_FALLBACK_FRONT_DOT or 0.10
if FightZ.MOUSE_PUNCH_TARGET_RANGE == nil
    or FightZ.MOUSE_PUNCH_TARGET_RANGE == 1.00
    or FightZ.MOUSE_PUNCH_TARGET_RANGE == 1.05
    or FightZ.MOUSE_PUNCH_TARGET_RANGE == 1.12
    or FightZ.MOUSE_PUNCH_TARGET_RANGE == 1.20 then
    FightZ.MOUSE_PUNCH_TARGET_RANGE = 1.60
end
if FightZ.MOUSE_PUNCH_CLOSE_TARGET_RANGE == nil or FightZ.MOUSE_PUNCH_CLOSE_TARGET_RANGE == 0.70 then
    FightZ.MOUSE_PUNCH_CLOSE_TARGET_RANGE = 0.90
end
FightZ.MOUSE_PUNCH_FRONT_DOT = FightZ.MOUSE_PUNCH_FRONT_DOT or -0.05
FightZ.MOUSE_FLOOR_PUNCH_TARGET_RANGE = FightZ.MOUSE_FLOOR_PUNCH_TARGET_RANGE or 1.05
FightZ.MOUSE_FLOOR_PUNCH_CLOSE_TARGET_RANGE = FightZ.MOUSE_FLOOR_PUNCH_CLOSE_TARGET_RANGE or 0.80
FightZ.MANUAL_PUNCH_FLOOR_RANGE = FightZ.MANUAL_PUNCH_FLOOR_RANGE or 0.95
FightZ.MANUAL_PUNCH_FLOOR_CLOSE_RANGE = FightZ.MANUAL_PUNCH_FLOOR_CLOSE_RANGE or 0.60
if FightZ.MANUAL_PUNCH_CHAIN_IMPACT_RANGE == nil or FightZ.MANUAL_PUNCH_CHAIN_IMPACT_RANGE == 1.00 then
    FightZ.MANUAL_PUNCH_CHAIN_IMPACT_RANGE = 1.08
end
if FightZ.MANUAL_PUNCH_CHAIN_CLOSE_RANGE == nil or FightZ.MANUAL_PUNCH_CHAIN_CLOSE_RANGE == 0.70 then
    FightZ.MANUAL_PUNCH_CHAIN_CLOSE_RANGE = 0.82
end
if FightZ.MANUAL_PUNCH_CHAIN_FRONT_DOT == nil or FightZ.MANUAL_PUNCH_CHAIN_FRONT_DOT == 0.05 then
    FightZ.MANUAL_PUNCH_CHAIN_FRONT_DOT = -0.20
end
FightZ.MANUAL_PUNCH_COOLDOWN_MS = FightZ.MANUAL_PUNCH_COOLDOWN_MS or 360
FightZ.MANUAL_PUNCH_FRONT_DOT = FightZ.MANUAL_PUNCH_FRONT_DOT or 0.45
if FightZ.MANUAL_PUNCH_IMPACT_FRONT_DOT == nil or FightZ.MANUAL_PUNCH_IMPACT_FRONT_DOT == 0.15 then
    FightZ.MANUAL_PUNCH_IMPACT_FRONT_DOT = -0.10
end
FightZ.MANUAL_PUNCH_ACTION_TIME = FightZ.MANUAL_PUNCH_ACTION_TIME or 32
FightZ.MANUAL_PUNCH_IMPACT_DELTA = FightZ.MANUAL_PUNCH_IMPACT_DELTA or 0.18
if FightZ.MANUAL_PUNCH_REACTION_GRACE_RANGE == nil
    or FightZ.MANUAL_PUNCH_REACTION_GRACE_RANGE == 1.10
    or FightZ.MANUAL_PUNCH_REACTION_GRACE_RANGE == 1.15 then
    FightZ.MANUAL_PUNCH_REACTION_GRACE_RANGE = 1.28
end
if FightZ.MANUAL_PUNCH_CRIT_REACTION_GRACE_RANGE == nil
    or FightZ.MANUAL_PUNCH_CRIT_REACTION_GRACE_RANGE == 1.25 then
    FightZ.MANUAL_PUNCH_CRIT_REACTION_GRACE_RANGE = 1.35
end
FightZ.MANUAL_FLOOR_PUNCH_ACTION_TIME = FightZ.MANUAL_FLOOR_PUNCH_ACTION_TIME or 34
FightZ.MANUAL_FLOOR_PUNCH_IMPACT_DELTA = FightZ.MANUAL_FLOOR_PUNCH_IMPACT_DELTA or 0.24
FightZ.MANUAL_PUNCH_ACTION_FAILSAFE_MS = FightZ.MANUAL_PUNCH_ACTION_FAILSAFE_MS or 1200
FightZ.MANUAL_PUNCH_ENDURANCE_WINDED_AT = FightZ.MANUAL_PUNCH_ENDURANCE_WINDED_AT or 0.66
FightZ.MANUAL_PUNCH_ENDURANCE_TIRED_AT = FightZ.MANUAL_PUNCH_ENDURANCE_TIRED_AT or 0.40
FightZ.MANUAL_PUNCH_ENDURANCE_EXHAUSTED_AT = FightZ.MANUAL_PUNCH_ENDURANCE_EXHAUSTED_AT or 0.20
FightZ.MANUAL_PUNCH_SPEED_NORMAL = FightZ.MANUAL_PUNCH_SPEED_NORMAL or 1.00
FightZ.MANUAL_PUNCH_SPEED_WINDED = FightZ.MANUAL_PUNCH_SPEED_WINDED or 0.86
FightZ.MANUAL_PUNCH_SPEED_TIRED = FightZ.MANUAL_PUNCH_SPEED_TIRED or 0.72
FightZ.MANUAL_PUNCH_SPEED_EXHAUSTED = FightZ.MANUAL_PUNCH_SPEED_EXHAUSTED or 0.58
FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_LIGHT_AT = FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_LIGHT_AT or 4.0
FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_HIGH_AT = FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_HIGH_AT or 12.0
FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_LIGHT_SPEED = FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_LIGHT_SPEED or 0.80
FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_HIGH_SPEED = FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_HIGH_SPEED or 0.60
FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_SPEED_DECAY_PER_SECOND = FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_SPEED_DECAY_PER_SECOND or 0.10
FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_SPEED_SCORE_MAX = FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_SPEED_SCORE_MAX or 40.0
if FightZ.MANUAL_PUNCH_BASE_DAMAGE == nil
    or FightZ.MANUAL_PUNCH_BASE_DAMAGE == 0.10
    or FightZ.MANUAL_PUNCH_BASE_DAMAGE == 0.096
    or FightZ.MANUAL_PUNCH_BASE_DAMAGE == 0.085 then
    FightZ.MANUAL_PUNCH_BASE_DAMAGE = 0.055
end
if FightZ.MANUAL_PUNCH_LEVEL_DAMAGE == nil
    or FightZ.MANUAL_PUNCH_LEVEL_DAMAGE == 0.265
    or FightZ.MANUAL_PUNCH_LEVEL_DAMAGE == 0.014
    or FightZ.MANUAL_PUNCH_LEVEL_DAMAGE == 0.015
    or FightZ.MANUAL_PUNCH_LEVEL_DAMAGE == 0.012 then
    FightZ.MANUAL_PUNCH_LEVEL_DAMAGE = 0.225
end
FightZ.MANUAL_PUNCH_LEVEL_EXPONENT = FightZ.MANUAL_PUNCH_LEVEL_EXPONENT or 1.45
if FightZ.MANUAL_PUNCH_BOOST_DAMAGE == nil
    or FightZ.MANUAL_PUNCH_BOOST_DAMAGE == 0.028
    or FightZ.MANUAL_PUNCH_BOOST_DAMAGE == 0.03
    or FightZ.MANUAL_PUNCH_BOOST_DAMAGE == 0.025 then
    FightZ.MANUAL_PUNCH_BOOST_DAMAGE = 0.006
end
FightZ.MANUAL_PUNCH_BOOST_LEVEL_DAMAGE = FightZ.MANUAL_PUNCH_BOOST_LEVEL_DAMAGE or 0.004
if FightZ.MANUAL_PUNCH_CRIT_MULTIPLIER == nil
    or FightZ.MANUAL_PUNCH_CRIT_MULTIPLIER == 1.25
    or FightZ.MANUAL_PUNCH_CRIT_MULTIPLIER == 1.15
    or FightZ.MANUAL_PUNCH_CRIT_MULTIPLIER == 1.20 then
    FightZ.MANUAL_PUNCH_CRIT_MULTIPLIER = 1.45
end
if FightZ.MANUAL_PUNCH_MAX_DAMAGE == nil
    or FightZ.MANUAL_PUNCH_MAX_DAMAGE == 0.45
    or FightZ.MANUAL_PUNCH_MAX_DAMAGE == 0.38 then
    FightZ.MANUAL_PUNCH_MAX_DAMAGE = 0.42
end
FightZ.MANUAL_PUNCH_EQUIPMENT_MAX_DAMAGE = FightZ.MANUAL_PUNCH_EQUIPMENT_MAX_DAMAGE or 0.55
if FightZ.MANUAL_PUNCH_CRIT_MAX_DAMAGE == nil or FightZ.MANUAL_PUNCH_CRIT_MAX_DAMAGE == 0.55 then
    FightZ.MANUAL_PUNCH_CRIT_MAX_DAMAGE = 0.62
end
if FightZ.MANUAL_PUNCH_CRIT_EQUIPMENT_MAX_DAMAGE == nil or FightZ.MANUAL_PUNCH_CRIT_EQUIPMENT_MAX_DAMAGE == 0.65 then
    FightZ.MANUAL_PUNCH_CRIT_EQUIPMENT_MAX_DAMAGE = 0.75
end
FightZ.MANUAL_PUNCH_OBJECT_BASE_DAMAGE = FightZ.MANUAL_PUNCH_OBJECT_BASE_DAMAGE or 4
FightZ.MANUAL_PUNCH_OBJECT_LEVEL_DAMAGE = FightZ.MANUAL_PUNCH_OBJECT_LEVEL_DAMAGE or 1.0
FightZ.MANUAL_PUNCH_OBJECT_STRENGTH_DAMAGE = FightZ.MANUAL_PUNCH_OBJECT_STRENGTH_DAMAGE or 0.5
FightZ.MANUAL_PUNCH_OBJECT_BOOST_DAMAGE = FightZ.MANUAL_PUNCH_OBJECT_BOOST_DAMAGE or 1.5
FightZ.MANUAL_PUNCH_OBJECT_MAX_DAMAGE = FightZ.MANUAL_PUNCH_OBJECT_MAX_DAMAGE or 30
if FightZ.MANUAL_PUNCH_STAGGER_CHANCE == nil or FightZ.MANUAL_PUNCH_STAGGER_CHANCE == 10 then
    FightZ.MANUAL_PUNCH_STAGGER_CHANCE = 35
end
if FightZ.MANUAL_PUNCH_STAGGER_CRIT_BONUS == nil or FightZ.MANUAL_PUNCH_STAGGER_CRIT_BONUS == 12 then
    FightZ.MANUAL_PUNCH_STAGGER_CRIT_BONUS = 15
end
FightZ.MANUAL_PUNCH_STAGGER_MAX_CHANCE = FightZ.MANUAL_PUNCH_STAGGER_MAX_CHANCE or 65
FightZ.MANUAL_PUNCH_STAGGER_CLEAR_MS = FightZ.MANUAL_PUNCH_STAGGER_CLEAR_MS or 260
FightZ.MANUAL_PUNCH_HIT_FORCE = FightZ.MANUAL_PUNCH_HIT_FORCE or 0.35
FightZ.ENABLE_MANUAL_PUNCH_KNOCKDOWN = FightZ.ENABLE_MANUAL_PUNCH_KNOCKDOWN == true
if FightZ.MANUAL_PUNCH_KNOCKDOWN_BASE == nil or FightZ.MANUAL_PUNCH_KNOCKDOWN_BASE == 4 then
    FightZ.MANUAL_PUNCH_KNOCKDOWN_BASE = 2
end
if FightZ.MANUAL_PUNCH_KNOCKDOWN_LEVEL == nil or FightZ.MANUAL_PUNCH_KNOCKDOWN_LEVEL == 2 then
    FightZ.MANUAL_PUNCH_KNOCKDOWN_LEVEL = 1.25
end
if FightZ.MANUAL_PUNCH_KNOCKDOWN_BOOST == nil or FightZ.MANUAL_PUNCH_KNOCKDOWN_BOOST == 4 then
    FightZ.MANUAL_PUNCH_KNOCKDOWN_BOOST = 2.5
end
if FightZ.MANUAL_PUNCH_KNOCKDOWN_CRIT_BONUS == nil or FightZ.MANUAL_PUNCH_KNOCKDOWN_CRIT_BONUS == 12 then
    FightZ.MANUAL_PUNCH_KNOCKDOWN_CRIT_BONUS = 8
end
if FightZ.MANUAL_PUNCH_KNOCKDOWN_MAX == nil or FightZ.MANUAL_PUNCH_KNOCKDOWN_MAX == 28 then
    FightZ.MANUAL_PUNCH_KNOCKDOWN_MAX = 18
end
FightZ.MANUAL_PUNCH_STRENGTH_XP = FightZ.MANUAL_PUNCH_STRENGTH_XP or 1.0
FightZ.MANUAL_PUNCH_FITNESS_XP = FightZ.MANUAL_PUNCH_FITNESS_XP or 1.0
FightZ.MANUAL_PUNCH_PHYSICAL_XP_CRIT_MULTIPLIER = FightZ.MANUAL_PUNCH_PHYSICAL_XP_CRIT_MULTIPLIER or 1.5
FightZ.ENABLE_FIST_MAINTENANCE_XP = FightZ.ENABLE_FIST_MAINTENANCE_XP ~= false
FightZ.MANUAL_PUNCH_MAINTENANCE_XP = FightZ.MANUAL_PUNCH_MAINTENANCE_XP or 0.35
FightZ.MANUAL_PUNCH_MAINTENANCE_XP_CRIT_MULTIPLIER = FightZ.MANUAL_PUNCH_MAINTENANCE_XP_CRIT_MULTIPLIER or 1.5
FightZ.MANUAL_PUNCH_STRAIN_CHAIN_WINDOW_MS = FightZ.MANUAL_PUNCH_STRAIN_CHAIN_WINDOW_MS or 7500
FightZ.MANUAL_PUNCH_STRAIN_CHAIN_BASE_MULTIPLIER = FightZ.MANUAL_PUNCH_STRAIN_CHAIN_BASE_MULTIPLIER or 0.8
if FightZ.MANUAL_PUNCH_STRAIN_CHAIN_STEP == nil
    or FightZ.MANUAL_PUNCH_STRAIN_CHAIN_STEP == 0.5
    or FightZ.MANUAL_PUNCH_STRAIN_CHAIN_STEP == 0.2
    or FightZ.MANUAL_PUNCH_STRAIN_CHAIN_STEP == 0.1 then
    FightZ.MANUAL_PUNCH_STRAIN_CHAIN_STEP = 0.05
end
if FightZ.MANUAL_PUNCH_STRAIN_CHAIN_MAX_MULTIPLIER == nil or FightZ.MANUAL_PUNCH_STRAIN_CHAIN_MAX_MULTIPLIER == 5.0 then
    FightZ.MANUAL_PUNCH_STRAIN_CHAIN_MAX_MULTIPLIER = 2.0
end
FightZ.MANUAL_PUNCH_NATIVE_MELEE_DELAY = FightZ.MANUAL_PUNCH_NATIVE_MELEE_DELAY or 100
if FightZ.MOUSE_SUPPRESS_VANILLA_MS == nil
    or FightZ.MOUSE_SUPPRESS_VANILLA_MS == 220
    or FightZ.MOUSE_SUPPRESS_VANILLA_MS == 140
    or FightZ.MOUSE_SUPPRESS_VANILLA_MS == 80 then
    FightZ.MOUSE_SUPPRESS_VANILLA_MS = 650
end
FightZ.PUNCH_HIT_SOUND = FightZ.PUNCH_HIT_SOUND or "LargeBoneClubHit"
FightZ.PUNCH_MISS_SOUND = FightZ.PUNCH_MISS_SOUND or "LargeBoneClubSwing"
FightZ.CUSTOM_PUNCH_HIT_SOUND = FightZ.CUSTOM_PUNCH_HIT_SOUND or "FightZPunchHit"
FightZ.CUSTOM_PUNCH_CRITICAL_SOUND = FightZ.CUSTOM_PUNCH_CRITICAL_SOUND or "FightZPunchCritical"
FightZ.CUSTOM_PUNCH_MISS_SOUND = FightZ.CUSTOM_PUNCH_MISS_SOUND or "FightZPunchMiss"
FightZ.ENABLE_MANUAL_PUNCH_ANIMATIONS = true
FightZ.ENABLE_MANUAL_PUNCH_REACTIONS = FightZ.ENABLE_MANUAL_PUNCH_REACTIONS ~= false
FightZ.ENABLE_MOUSE_PUNCH = FightZ.ENABLE_MOUSE_PUNCH ~= false
FightZ.ENABLE_MOUSE_TIMED_ACTION = false
FightZ.ENABLE_MOUSE_HELD_PUNCH = FightZ.ENABLE_MOUSE_HELD_PUNCH == true
FightZ.ENABLE_JOYPAD_PUNCH = FightZ.ENABLE_JOYPAD_PUNCH ~= false
FightZ.ENABLE_JOYPAD_HELD_PUNCH = FightZ.ENABLE_JOYPAD_HELD_PUNCH == true
FightZ.DEBUG_MOUSE = FightZ.DEBUG_MOUSE ~= false
FightZ.DEBUG_MOUSE_INTERVAL_MS = FightZ.DEBUG_MOUSE_INTERVAL_MS or 650
FightZ.DEBUG_INPUT = FightZ.DEBUG_INPUT ~= false
FightZ.DEBUG_INPUT_INTERVAL_MS = FightZ.DEBUG_INPUT_INTERVAL_MS or 250
FightZ.DEBUG_INPUT_AFTER_MS = FightZ.DEBUG_INPUT_AFTER_MS or 900
FightZ.FIST_EQUIPMENT_DAMAGE_MIN_LEVEL = FightZ.FIST_EQUIPMENT_DAMAGE_MIN_LEVEL or 7
FightZ.MANUAL_PUNCH_UNPROTECTED_HAND_SCRATCH_CHANCE = FightZ.MANUAL_PUNCH_UNPROTECTED_HAND_SCRATCH_CHANCE or 0.75

FightZ.FIST_EQUIPMENT_DAMAGE_CATEGORIES = FightZ.FIST_EQUIPMENT_DAMAGE_CATEGORIES or {
    cloth = {
        priority = 10,
        minBonus = 0.05,
        maxBonus = 0.05,
        items = {
            "Base.Gloves_RagWrap",
            "Base.Gloves_BurlapWrap",
            "Base.Gloves_HuntingCamo",
            "Base.Gloves_WhiteTINT",
        },
    },
    leather = {
        priority = 20,
        minBonus = 0.05,
        maxBonus = 0.10,
        items = {
            "Base.Gloves_DenimWrap",
            "Base.Gloves_TarpWrap",
            "Base.Gloves_FingerlessGloves",
            "Base.Gloves_FingerlessLeatherGloves_Black",
            "Base.Gloves_FingerlessLeatherGloves_Brown",
            "Base.Gloves_FingerlessLeatherGloves",
        },
    },
    gloves = {
        priority = 30,
        minBonus = 0.10,
        maxBonus = 0.15,
        items = {
            "Base.Gloves_LeatherWrap",
            "Base.Gloves_LeatherGlovesBrown",
            "Base.Gloves_LeatherGloves",
            "Base.Gloves_LeatherGlovesBlack",
        },
    },
    professional = {
        priority = 40,
        minBonus = 0.20,
        maxBonus = 0.20,
        items = {
            "Base.Gloves_BoxingRed",
            "Base.Gloves_BoxingBlue",
        },
    },
    crafting = {
        priority = 50,
        minBonus = 0.20,
        maxBonus = 0.30,
        items = {
            "Base.Gloves_BoneGloves",
            "Base.Gloves_MetalArmour",
            "Base.Gloves_MetalScrapArmour",
            "Base.Chainmail_SleeveFull_L",
            "Base.Chainmail_SleeveFull_R",
        },
    },
}

local PUNCH_ANIMS = {
    "Bob_AttackPunch01_Hit",
    "Bob_AttackPunch02_Hit",
    "Bob_AttackPunch03_Hit",
}

local PUNCH_ACTIONS = {
    "FightZPunchAction01",
    "FightZPunchAction02",
    "FightZPunchAction03",
}

local CRIT_ANIMS = {
    "Bob_AttackPunch01_CritHit",
    "Bob_AttackPunch02_CritHit",
    "Bob_AttackPunch03_CritHit",
}

local CRIT_ACTIONS = {
    "FightZPunchCritAction01",
    "FightZPunchCritAction02",
    "FightZPunchCritAction03",
}

local PRIMARY_ONLY_PUNCH_ANIMS = {
    "Bob_AttackPunch01_Hit",
}

local PRIMARY_ONLY_PUNCH_ACTIONS = {
    "FightZPunchAction01",
}

local PRIMARY_ONLY_CRIT_ANIMS = {
    "Bob_AttackPunch01_CritHit",
}

local PRIMARY_ONLY_CRIT_ACTIONS = {
    "FightZPunchCritAction01",
}

local FLOOR_ACTION = "FightZFloorPunchAction"
local AIM_VECTOR = Vector2 and Vector2.new and Vector2.new() or nil
local CONTROLLED_STAGGERS = setmetatable({}, { __mode = "k" })
local PENDING_MOUSE_PUNCHES = setmetatable({}, { __mode = "k" })
local REMOTE_PUNCH_ANIMATIONS = setmetatable({}, { __mode = "k" })
local COMBAT_TEXT_FIST_WEAPON = { FightZ = true }
local PUNCH_BLOOD_SPLATS_BY_LEVEL = { 0, 0, 1, 2, 5 }
local FIST_EQUIPMENT_DAMAGE_LOOKUP = nil
local PUNCH_SPEED_TIERS = {
    { tier = "normal", speed = 1.00 },
    { tier = "winded", speed = 0.86 },
    { tier = "strained", speed = 0.80 },
    { tier = "tired", speed = 0.72 },
    { tier = "heavyStrain", speed = 0.60 },
    { tier = "exhausted", speed = 0.58 },
    { tier = "severeStrain", speed = 0.45 },
    { tier = "extremeStrain", speed = 0.35 },
}
local restoreVanillaBareHandAttack
local holdVanillaAfterFightZAction
local clearVanillaAttackSuppression
local isAttackClickDown
local isAiming
local isMeleeInputDown
local isJoypadAttackInputDown
local isJoypadMeleeInputDown
local isJoypadAimInputDown

local function safeCall(target, methodName, ...)
    if target and target[methodName] then
        return target[methodName](target, ...)
    end
    return nil
end

local function toNumber(value, fallback)
    local number = tonumber(value)
    if number ~= nil then
        return number
    end
    return fallback
end

local function getNowMs()
    if FightZ.getTimeMs then
        return FightZ.getTimeMs()
    end
    if getTimestampMs then
        return getTimestampMs()
    end
    return os.time() * 1000
end

local function getVariableBoolean(object, name)
    if not object or not name then
        return false
    end
    if object.getVariableBoolean then
        local ok, value = pcall(function()
            return object:getVariableBoolean(name)
        end)
        if ok and value ~= nil then
            return value == true
        end
    end
    if object.getVariableString then
        local ok, value = pcall(function()
            return object:getVariableString(name)
        end)
        if ok and value ~= nil then
            value = tostring(value):lower()
            return value == "true" or value == "1"
        end
    end
    return false
end

local function clampRatio(value)
    value = toNumber(value, nil)
    if value == nil then
        return nil
    end
    if value > 1 then
        value = value / 100
    end
    if value < 0 then
        return 0
    end
    if value > 1 then
        return 1
    end
    return value
end

local function getPlayerEnduranceRatio(player)
    local stats = safeCall(player, "getStats")
    if not stats then
        return 1
    end

    local endurance = nil
    if stats.getEndurance then
        local ok, value = pcall(function()
            return stats:getEndurance()
        end)
        if ok then
            endurance = clampRatio(value)
        end
    end

    if endurance == nil and stats.get and CharacterStat and CharacterStat.ENDURANCE then
        local ok, value = pcall(function()
            return stats:get(CharacterStat.ENDURANCE)
        end)
        if ok then
            endurance = clampRatio(value)
        end
    end

    return endurance or 1
end

local function resolveBodyPartType(typeName)
    if not BodyPartType or not typeName then
        return nil
    end

    if BodyPartType[typeName] then
        return BodyPartType[typeName]
    end

    if BodyPartType.FromString then
        local ok, value = pcall(BodyPartType.FromString, typeName)
        if ok then
            return value
        end
    end

    return nil
end

local function getPlayerBodyPartByNames(player, names)
    local bodyDamage = safeCall(player, "getBodyDamage")
    if not bodyDamage or not bodyDamage.getBodyPart then
        return nil
    end

    for i = 1, #names do
        local bodyPartType = resolveBodyPartType(names[i])
        if bodyPartType then
            local ok, bodyPart = pcall(bodyDamage.getBodyPart, bodyDamage, bodyPartType)
            if ok and bodyPart then
                return bodyPart, bodyPartType
            end
        end
    end

    return nil
end

local function getStoredFightZMuscleStrainScore(player)
    local modData = safeCall(player, "getModData")
    if not modData then
        return 0
    end

    local now = getNowMs()
    local score = toNumber(modData.FightZMuscleStrainSpeedScore, 0)
    local lastMs = toNumber(modData.FightZMuscleStrainSpeedLastMs, now)
    local elapsedSeconds = math.max(0, now - lastMs) / 1000
    local decay = elapsedSeconds * (FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_SPEED_DECAY_PER_SECOND or 0.10)
    score = math.max(0, score - decay)
    modData.FightZMuscleStrainSpeedScore = score
    modData.FightZMuscleStrainSpeedLastMs = now
    return score
end

local function addStoredFightZMuscleStrainScore(player, amount)
    local modData = safeCall(player, "getModData")
    if not modData then
        return
    end

    local score = getStoredFightZMuscleStrainScore(player) + toNumber(amount, 0)
    local maxScore = FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_SPEED_SCORE_MAX or 40
    if score > maxScore then
        score = maxScore
    end
    modData.FightZMuscleStrainSpeedScore = score
    modData.FightZMuscleStrainSpeedLastMs = getNowMs()
end

local function readBodyPartMuscleStrain(bodyPart)
    if not bodyPart then
        return nil, nil
    end

    local methods = {
        { name = "getMuscleStrainLevel", isLevel = true },
        { name = "getMuscleStrain", isLevel = false },
        { name = "getMuscleStrainTime", isLevel = false },
    }

    for i = 1, #methods do
        local method = methods[i]
        if bodyPart[method.name] then
            local ok, value = pcall(bodyPart[method.name], bodyPart)
            value = ok and toNumber(value, nil) or nil
            if value ~= nil then
                return value, method.isLevel
            end
        end
    end

    return nil, nil
end

local function getArmMuscleStrainSpeedMultiplier(player)
    local partGroups = {
        { "Hand_L", "LeftHand" },
        { "Hand_R", "RightHand" },
        { "ForeArm_L", "LeftForeArm" },
        { "ForeArm_R", "RightForeArm" },
        { "UpperArm_L", "LeftArm" },
        { "UpperArm_R", "RightArm" },
    }

    local maxValue = getStoredFightZMuscleStrainScore(player)
    local maxLevel = 0
    for i = 1, #partGroups do
        local bodyPart = getPlayerBodyPartByNames(player, partGroups[i])
        local value, isLevel = readBodyPartMuscleStrain(bodyPart)
        if value then
            if isLevel then
                maxLevel = math.max(maxLevel, value)
            else
                maxValue = math.max(maxValue, value)
            end
        end
    end

    if maxLevel >= 3 or maxValue >= (FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_HIGH_AT or 12.0) then
        return FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_HIGH_SPEED or 0.60
    end
    if maxLevel >= 1 or maxValue >= (FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_LIGHT_AT or 4.0) then
        return FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_LIGHT_SPEED or 0.80
    end
    return 1.0
end

local function getEndurancePunchSpeed(player)
    local endurance = getPlayerEnduranceRatio(player)
    if endurance <= (FightZ.MANUAL_PUNCH_ENDURANCE_EXHAUSTED_AT or 0.20) then
        return FightZ.MANUAL_PUNCH_SPEED_EXHAUSTED or 0.58
    end
    if endurance <= (FightZ.MANUAL_PUNCH_ENDURANCE_TIRED_AT or 0.40) then
        return FightZ.MANUAL_PUNCH_SPEED_TIRED or 0.72
    end
    if endurance <= (FightZ.MANUAL_PUNCH_ENDURANCE_WINDED_AT or 0.66) then
        return FightZ.MANUAL_PUNCH_SPEED_WINDED or 0.86
    end
    return FightZ.MANUAL_PUNCH_SPEED_NORMAL or 1.00
end

local function resolvePunchSpeedTier(speed)
    speed = toNumber(speed, 1.0)
    local bestTier = PUNCH_SPEED_TIERS[1].tier
    local bestDistance = math.abs(speed - PUNCH_SPEED_TIERS[1].speed)
    for i = 2, #PUNCH_SPEED_TIERS do
        local tier = PUNCH_SPEED_TIERS[i]
        local distance = math.abs(speed - tier.speed)
        if distance < bestDistance then
            bestTier = tier.tier
            bestDistance = distance
        end
    end
    return bestTier
end

local function getPunchSpeedTier(player)
    local penaltySpeed = getEndurancePunchSpeed(player) * getArmMuscleStrainSpeedMultiplier(player)
    if penaltySpeed < 0.30 then
        penaltySpeed = 0.30
    elseif penaltySpeed > 1.0 then
        penaltySpeed = 1.0
    end

    local fistMultiplier = FightZ.getFistPunchSpeedMultiplier
        and FightZ.getFistPunchSpeedMultiplier(player)
        or 1.0
    local speed = penaltySpeed * fistMultiplier
    if speed < 0.30 then
        speed = 0.30
    elseif speed > 1.16 then
        speed = 1.16
    end
    return resolvePunchSpeedTier(penaltySpeed), speed
end

local function getScaledPunchMs(player, baseMs)
    local _, speed = getPunchSpeedTier(player)
    speed = toNumber(speed, 1)
    if speed <= 0 then
        speed = 1
    end
    return math.floor((baseMs or 0) / speed)
end

local function randomFloat()
    if FightZ.randomInt then
        return FightZ.randomInt(10000) / 10000
    end
    if ZombRand then
        return ZombRand(10000) / 10000
    end
    return math.random()
end

local function randomRange(minValue, maxValue)
    minValue = toNumber(minValue, 0)
    maxValue = toNumber(maxValue, minValue)
    if maxValue <= minValue then
        return minValue
    end
    return minValue + ((maxValue - minValue) * randomFloat())
end

local function getInventoryItemFullType(item)
    if not item then
        return nil
    end

    if item.getFullType then
        local ok, value = pcall(item.getFullType, item)
        if ok and value then
            return tostring(value)
        end
    end

    local module = nil
    if item.getModule then
        local ok, value = pcall(item.getModule, item)
        if ok then
            module = value and tostring(value) or nil
        end
    end

    local itemType = nil
    if item.getType then
        local ok, value = pcall(item.getType, item)
        if ok then
            itemType = value and tostring(value) or nil
        end
    end

    if module and itemType and module ~= "" then
        return module .. "." .. itemType
    end
    return itemType
end

local function buildFistEquipmentDamageLookup()
    if FIST_EQUIPMENT_DAMAGE_LOOKUP then
        return FIST_EQUIPMENT_DAMAGE_LOOKUP
    end

    local lookup = {}
    local categories = FightZ.FIST_EQUIPMENT_DAMAGE_CATEGORIES or {}
    for categoryId, category in pairs(categories) do
        local items = category and category.items or nil
        if items then
            for i = 1, #items do
                local fullType = items[i]
                local definition = {
                    category = categoryId,
                    priority = toNumber(category.priority, 0),
                    minBonus = toNumber(category.minBonus, 0),
                    maxBonus = toNumber(category.maxBonus, category.minBonus or 0),
                }
                lookup[fullType] = definition
                local shortType = tostring(fullType):match("%.([^%.]+)$")
                if shortType then
                    lookup[shortType] = definition
                end
            end
        end
    end

    FIST_EQUIPMENT_DAMAGE_LOOKUP = lookup
    return lookup
end

local function getWornEntryItem(entry)
    if not entry then
        return nil
    end
    if entry.getItem then
        local ok, item = pcall(entry.getItem, entry)
        if ok and item then
            return item
        end
    end
    if entry.getInventoryItem then
        local ok, item = pcall(entry.getInventoryItem, entry)
        if ok and item then
            return item
        end
    end
    return entry
end

local function getFightZBestFistEquipment(player)
    if not player or not player.getWornItems then
        return nil
    end

    local okWorn, wornItems = pcall(player.getWornItems, player)
    if not okWorn or not wornItems then
        return nil
    end

    local size = nil
    if wornItems.size then
        local ok, value = pcall(wornItems.size, wornItems)
        if ok then
            size = toNumber(value, nil)
        end
    end
    if size == nil and wornItems.getItemCount then
        local ok, value = pcall(wornItems.getItemCount, wornItems)
        if ok then
            size = toNumber(value, nil)
        end
    end
    if not size or size <= 0 then
        return nil
    end

    local lookup = buildFistEquipmentDamageLookup()
    local best = nil
    for i = 0, size - 1 do
        local entry = nil
        if wornItems.get then
            local ok, value = pcall(wornItems.get, wornItems, i)
            if ok then
                entry = value
            end
        end
        if not entry and wornItems.getItemByIndex then
            local ok, value = pcall(wornItems.getItemByIndex, wornItems, i)
            if ok then
                entry = value
            end
        end

        local item = getWornEntryItem(entry)
        local fullType = getInventoryItemFullType(item)
        local definition = fullType and lookup[fullType] or nil
        if definition and (not best
            or definition.priority > best.priority
            or (definition.priority == best.priority and definition.maxBonus > best.maxBonus)) then
            best = {
                category = definition.category,
                fullType = fullType,
                priority = definition.priority,
                minBonus = definition.minBonus,
                maxBonus = definition.maxBonus,
            }
        end
    end

    return best
end

local function canUseFistEquipmentDamage(player)
    if not player then
        return false
    end

    if FightZ.hasTrait and FightZ.TRAIT_FIGHTER and FightZ.hasTrait(player, FightZ.TRAIT_FIGHTER) then
        return true
    end

    if not FightZ.hasTrait
        or not FightZ.TRAIT_INICIATE
        or FightZ.hasTrait(player, FightZ.TRAIT_INICIATE) ~= true then
        return false
    end

    local level = FightZ.getFistLevel and FightZ.getFistLevel(player) or 0
    return level >= (FightZ.FIST_EQUIPMENT_DAMAGE_MIN_LEVEL or 7)
end

local function getFistEquipmentDamageBonus(player)
    if not canUseFistEquipmentDamage(player) then
        return 0, nil
    end

    local equipment = getFightZBestFistEquipment(player)
    if not equipment then
        return 0, nil
    end

    return randomRange(equipment.minBonus, equipment.maxBonus), equipment
end

local function hasFistMaintenanceTrait(player)
    if not player or not FightZ.hasTrait then
        return false
    end

    if FightZ.TRAIT_FIGHTER and FightZ.hasTrait(player, FightZ.TRAIT_FIGHTER) == true then
        return true
    end
    if FightZ.TRAIT_INICIATE and FightZ.hasTrait(player, FightZ.TRAIT_INICIATE) == true then
        return true
    end

    return false
end

local function rollFloatPercent(chance)
    chance = toNumber(chance, 0)
    if chance <= 0 then
        return false
    end
    if chance >= 100 then
        return true
    end
    return (randomFloat() * 100) < chance
end

local function hasFightZHandProtection(player)
    return getFightZBestFistEquipment(player) ~= nil
end

local function getRandomHandBodyPart(player)
    local left = getPlayerBodyPartByNames(player, { "Hand_L", "LeftHand" })
    local right = getPlayerBodyPartByNames(player, { "Hand_R", "RightHand" })
    if left and right then
        return randomFloat() < 0.5 and left or right
    end
    return left or right
end

local function syncBodyPartIfSupported(bodyPart)
    if syncBodyPart and bodyPart then
        pcall(syncBodyPart, bodyPart, 0xFFFFFFFFFFF)
    end
end

local function applyUnprotectedHandScratchRisk(player)
    if hasFightZHandProtection(player) then
        return
    end
    if not rollFloatPercent(FightZ.MANUAL_PUNCH_UNPROTECTED_HAND_SCRATCH_CHANCE or 0.75) then
        return
    end

    local bodyPart = getRandomHandBodyPart(player)
    if not bodyPart then
        return
    end

    local applied = false
    if bodyPart.setScratched then
        local ok = pcall(bodyPart.setScratched, bodyPart, true, false)
        applied = ok or applied
    end
    if not applied and bodyPart.setCut then
        local ok = pcall(bodyPart.setCut, bodyPart, true)
        applied = ok or applied
    end
    if bodyPart.AddDamage then
        pcall(bodyPart.AddDamage, bodyPart, 1.0)
    end
    if applied then
        syncBodyPartIfSupported(bodyPart)
    end
end

local function debugMouse(player, message)
    if FightZ.DEBUG_MOUSE ~= true then
        return
    end

    local now = getNowMs()
    local modData = player and safeCall(player, "getModData") or nil
    if modData then
        local nextDebug = toNumber(modData.FightZNextMouseDebugMs, 0)
        if nextDebug > now then
            return
        end
        modData.FightZNextMouseDebugMs = now + FightZ.DEBUG_MOUSE_INTERVAL_MS
    end

    print("[FightZ] mouse: " .. tostring(message))
end

local function boolText(value)
    return value and "true" or "false"
end

local function formatNumber(value)
    value = tonumber(value)
    if value == nil then
        return "nil"
    end
    return string.format("%.2f", value)
end

local function debugInput(player, message, throttleKey, throttleMs)
    if FightZ.DEBUG_INPUT ~= true then
        return
    end

    if throttleKey then
        local now = getNowMs()
        local modData = player and safeCall(player, "getModData") or nil
        if modData then
            local nextDebug = toNumber(modData[throttleKey], 0)
            if nextDebug > now then
                return
            end
            modData[throttleKey] = now + (throttleMs or FightZ.DEBUG_INPUT_INTERVAL_MS or 250)
        end
    end

    print("[FightZ] " .. tostring(message))
end

local function getItemDebugName(item)
    if not item then
        return "nil"
    end
    return tostring(safeCall(item, "getFullType") or safeCall(item, "getType") or item)
end

local function getActionDebugSummary(player)
    local actions = safeCall(player, "getCharacterActions")
    if not actions then
        return "actions=nil"
    end

    local empty = actions.isEmpty and actions:isEmpty() == true
    local size = actions.size and actions:size() or nil
    local first = nil
    if size and size > 0 and actions.get then
        local ok, action = pcall(function()
            return actions:get(0)
        end)
        if ok and action then
            first = action.Type or (action.getType and action:getType()) or tostring(action)
        end
    end

    return "actionsEmpty=" .. boolText(empty) .. " actionsSize=" .. tostring(size) .. " firstAction=" .. tostring(first)
end

local function getPlayerDebugSummary(player)
    if not player then
        return "player=nil"
    end

    local modData = safeCall(player, "getModData")
    local nextPunch = modData and toNumber(modData.FightZNextManualPunchMs, 0) or 0
    local cooldown = nextPunch - getNowMs()
    if cooldown < 0 then
        cooldown = 0
    end

    return "aim=" .. boolText(isAiming(player))
        .. " style=" .. boolText(FightZ.hasFightZStyle and FightZ.hasFightZStyle(player))
        .. " emptyHands=" .. boolText(FightZ.hasEmptyHandsForFightZ and FightZ.hasEmptyHandsForFightZ(player))
        .. " attacking=" .. boolText(safeCall(player, "isAttacking") == true)
        .. " doShove=" .. boolText(safeCall(player, "isDoShove") == true)
        .. " shoveAim=" .. boolText(safeCall(player, "isShoveAim") == true)
        .. " meleeDown=" .. boolText(isMeleeInputDown and isMeleeInputDown(player))
        .. " joypadAttack=" .. boolText(isJoypadAttackInputDown and isJoypadAttackInputDown(player))
        .. " joypadMelee=" .. boolText(isJoypadMeleeInputDown and isJoypadMeleeInputDown(player))
        .. " nativeDelay=" .. tostring(math.floor(toNumber(safeCall(player, "getMeleeDelay"), 0)))
        .. " cooldownMs=" .. tostring(math.floor(cooldown))
        .. " primary=" .. getItemDebugName(safeCall(player, "getPrimaryHandItem"))
        .. " secondary=" .. getItemDebugName(safeCall(player, "getSecondaryHandItem"))
        .. " " .. getActionDebugSummary(player)
end

local function getVectorXY(vector)
    if not vector then
        return nil, nil
    end

    local x = nil
    local y = nil
    if vector.getX then
        x = safeCall(vector, "getX")
    elseif vector.x ~= nil then
        x = vector.x
    end
    if vector.getY then
        y = safeCall(vector, "getY")
    elseif vector.y ~= nil then
        y = vector.y
    end

    return toNumber(x, nil), toNumber(y, nil)
end

local function getPlayerForward(player)
    if player and player.getAimVector and AIM_VECTOR then
        local ok, aimVector = pcall(function()
            return player:getAimVector(AIM_VECTOR)
        end)
        if ok then
            local aimX, aimY = getVectorXY(aimVector)
            if aimX ~= nil and aimY ~= nil then
                local aimLength = math.sqrt((aimX * aimX) + (aimY * aimY))
                if aimLength > 0 then
                    return aimX / aimLength, aimY / aimLength
                end
            end
        end
    end

    local direction = safeCall(player, "getForwardDirection")
    local x, y = getVectorXY(direction)
    if x ~= nil and y ~= nil then
        local length = math.sqrt((x * x) + (y * y))
        if length > 0 then
            return x / length, y / length
        end
    end

    return 0, -1
end

local function hasQueuedAction(player)
    local actions = safeCall(player, "getCharacterActions")
    if actions and actions.isEmpty then
        return actions:isEmpty() == false
    end
    return false
end

local function hasQueuedFightZAttack(player)
    if FightZ.ENABLE_MOUSE_TIMED_ACTION ~= true then
        return false
    end
    return ISTimedActionQueue
        and ISTimedActionQueue.hasActionType
        and ISTimedActionQueue.hasActionType(player, "FightZManualPunchAction") == true
end

local function clearQueuedFightZAttack(player)
    if FightZ.ENABLE_MOUSE_TIMED_ACTION ~= true then
        return false
    end
    if not player or not hasQueuedFightZAttack(player) or not ISTimedActionQueue then
        return false
    end
    if ISTimedActionQueue.clear then
        ISTimedActionQueue.clear(player)
    elseif ISTimedActionQueue.getTimedActionQueue then
        local queue = ISTimedActionQueue.getTimedActionQueue(player)
        if queue and queue.resetQueue then
            queue:resetQueue()
        end
    end
    if player.clearVariable then
        player:clearVariable("LAttackType")
    end
    print("[FightZ] cleared stale FightZ timed action")
    return true
end

local function getNativeMeleeDelay(player)
    return toNumber(safeCall(player, "getMeleeDelay"), 0)
end

local function getPlayerJoypadId(player)
    if not player then
        return nil
    end

    local joypadId = toNumber(safeCall(player, "getJoypadBind"), nil)
    if joypadId ~= nil and joypadId >= 0 then
        return joypadId
    end

    local playerNum = toNumber(safeCall(player, "getPlayerNum"), nil)
    local joypadData = playerNum and JoypadState and JoypadState.players and JoypadState.players[playerNum + 1] or nil
    joypadId = toNumber(joypadData and joypadData.id, nil)
    if joypadId ~= nil and joypadId >= 0 then
        return joypadId
    end

    return nil
end

local function getJoypadButtonBinding(bindingName)
    if not CharacterJoypadButtonBinding then
        return nil
    end
    if bindingName == "Attack" then
        return CharacterJoypadButtonBinding.Attack
    end
    if bindingName == "Melee" then
        return CharacterJoypadButtonBinding.Melee
    end
    if bindingName == "Aim" then
        return CharacterJoypadButtonBinding.Aim
    end
    if bindingName == "PrecisionAim" then
        return CharacterJoypadButtonBinding.PrecisionAim
    end
    if CharacterJoypadButtonBinding.fromString then
        local ok, binding = pcall(CharacterJoypadButtonBinding.fromString, bindingName)
        if ok then
            return binding
        end
    end
    return CharacterJoypadButtonBinding[bindingName]
end

local function isJoypadBindingDown(player, bindingName)
    local joypadId = getPlayerJoypadId(player)
    local binding = getJoypadButtonBinding(bindingName)
    if joypadId == nil or not binding or not binding.isDown then
        return false
    end

    local ok, down = pcall(binding.isDown, binding, joypadId)
    return ok and down == true
end

isJoypadAttackInputDown = function(player)
    return isJoypadBindingDown(player, "Attack")
end

isJoypadMeleeInputDown = function(player)
    return isJoypadBindingDown(player, "Melee")
end

isJoypadAimInputDown = function(player)
    return isJoypadBindingDown(player, "Aim")
        or isJoypadBindingDown(player, "PrecisionAim")
        or isJoypadAttackInputDown(player)
end

isAiming = function(player)
    if safeCall(player, "isAiming") == true then
        return true
    end
    if safeCall(player, "isForceAiming") == true then
        return true
    end
    if safeCall(player, "isForceAim") == true then
        return true
    end
    if isJoypadAimInputDown and isJoypadAimInputDown(player) then
        return true
    end
    return false
end

local function getManualPunchBlockReason(player, allowAttackState, allowQueuedAction, allowNativeMeleeDelay)
    if not player or (player.isDead and player:isDead()) then
        return "no-player"
    end
    if safeCall(player, "getVehicle") then
        return "in-vehicle"
    end
    if hasQueuedAction(player) then
        if hasQueuedFightZAttack(player) then
            if FightZ.ENABLE_MOUSE_TIMED_ACTION == true or not clearQueuedFightZAttack(player) then
                return "queued-fightz-action"
            end
        elseif allowQueuedAction ~= true then
            return "queued-action"
        end
    end
    if safeCall(player, "isAttacking") == true and allowAttackState ~= true then
        return "already-attacking"
    end
    if not isAiming(player) then
        return "not-aiming"
    end
    if not FightZ.hasFightZStyle or not FightZ.hasFightZStyle(player) then
        return "no-fightz-style"
    end
    if not FightZ.hasEmptyHandsForFightZ or not FightZ.hasEmptyHandsForFightZ(player) then
        return "hands-not-empty"
    end

    local modData = safeCall(player, "getModData")
    local now = getNowMs()
    local nextPunch = modData and toNumber(modData.FightZNextManualPunchMs, 0) or 0
    if nextPunch > now then
        return "cooldown"
    end
    if FightZ.ENABLE_MOUSE_TIMED_ACTION == true and getNativeMeleeDelay(player) > 0 and allowNativeMeleeDelay ~= true then
        return "native-melee-delay"
    end

    return nil
end

local function canManualPunch(player, allowAttackState, allowQueuedAction, allowNativeMeleeDelay)
    return getManualPunchBlockReason(player, allowAttackState, allowQueuedAction, allowNativeMeleeDelay) == nil
end

local function isZombieOnFloor(zombie)
    return safeCall(zombie, "isOnFloor") == true
end

local function squaresBlockPunchLine(fromSquare, toSquare)
    if not fromSquare or not toSquare then
        return true
    end
    if fromSquare == toSquare then
        return false
    end

    local checks = {
        "isBlockedTo",
        "isWallTo",
        "isWindowTo",
        "isDoorBlockedTo",
        "isHoppableTo",
    }
    for _, methodName in ipairs(checks) do
        if fromSquare[methodName] then
            local ok, blocked = pcall(fromSquare[methodName], fromSquare, toSquare)
            if ok and blocked == true then
                return true
            end
        end
    end

    return false
end

local function hasClearPunchPath(player, target)
    local fromSquare = safeCall(player, "getCurrentSquare") or safeCall(player, "getSquare")
    local targetSquare = safeCall(target, "getCurrentSquare") or safeCall(target, "getSquare")
    if not fromSquare or not targetSquare then
        return false
    end

    local fromX = toNumber(safeCall(fromSquare, "getX"), nil)
    local fromY = toNumber(safeCall(fromSquare, "getY"), nil)
    local fromZ = math.floor(toNumber(safeCall(fromSquare, "getZ"), 0))
    local targetX = toNumber(safeCall(targetSquare, "getX"), nil)
    local targetY = toNumber(safeCall(targetSquare, "getY"), nil)
    local targetZ = math.floor(toNumber(safeCall(targetSquare, "getZ"), fromZ))
    if fromX == nil or fromY == nil or targetX == nil or targetY == nil or fromZ ~= targetZ then
        return false
    end
    if fromX == targetX and fromY == targetY then
        return true
    end

    local deltaX = targetX - fromX
    local deltaY = targetY - fromY
    local steps = math.max(math.abs(deltaX), math.abs(deltaY))
    local cell = safeCall(player, "getCell") or (getCell and getCell()) or nil
    if not cell or not cell.getGridSquare or steps < 1 then
        return false
    end

    local previous = fromSquare
    for step = 1, steps do
        local x = math.floor(fromX + ((deltaX * step) / steps) + 0.5)
        local y = math.floor(fromY + ((deltaY * step) / steps) + 0.5)
        local square = step == steps and targetSquare or cell:getGridSquare(x, y, fromZ)
        if squaresBlockPunchLine(previous, square) then
            return false
        end
        previous = square
    end

    return true
end

local function isValidTarget(player, zombie, allowFloor)
    if not FightZ.isZombie or not FightZ.isZombie(zombie) then
        return false
    end
    if safeCall(zombie, "isDead") == true then
        return false
    end
    if isZombieOnFloor(zombie) and allowFloor ~= true then
        return false
    end

    local pz = math.floor(toNumber(safeCall(player, "getZ"), 0))
    local zz = math.floor(toNumber(safeCall(zombie, "getZ"), pz))
    return pz == zz and hasClearPunchPath(player, zombie)
end

local function getPunchTargetScore(player, zombie, allowFloor)
    if not isValidTarget(player, zombie, allowFloor) then
        return nil
    end

    local px = toNumber(safeCall(player, "getX"), nil)
    local py = toNumber(safeCall(player, "getY"), nil)
    if px == nil or py == nil then
        return nil
    end

    local zx = toNumber(safeCall(zombie, "getX"), nil)
    local zy = toNumber(safeCall(zombie, "getY"), nil)
    if zx == nil or zy == nil then
        return nil
    end

    local dx = zx - px
    local dy = zy - py
    local distSq = (dx * dx) + (dy * dy)
    local minRange = FightZ.MANUAL_PUNCH_MIN_RANGE or 0
    local onFloor = isZombieOnFloor(zombie)
    local maxRange = onFloor and (FightZ.MANUAL_PUNCH_FLOOR_RANGE or 0.95) or (FightZ.MANUAL_PUNCH_RANGE or 1.00)
    if distSq < (minRange * minRange) or distSq > (maxRange * maxRange) then
        return nil
    end

    if onFloor and distSq <= ((FightZ.MANUAL_PUNCH_FLOOR_CLOSE_RANGE or 0.60) * (FightZ.MANUAL_PUNCH_FLOOR_CLOSE_RANGE or 0.60)) then
        return 0.75 - (math.sqrt(distSq) * 0.2)
    end

    local distance = math.sqrt(distSq)
    if distance <= 0 then
        return onFloor and 0.75 or nil
    end

    local forwardX, forwardY = getPlayerForward(player)
    local dot = ((dx * forwardX) + (dy * forwardY)) / distance
    if not onFloor and dot < FightZ.MANUAL_PUNCH_FRONT_DOT then
        return nil
    end
    if onFloor and dot < 0 then
        return nil
    end

    return dot - (distance * 0.2)
end

local function getFallbackPunchTargetScore(player, zombie, allowFloor)
    if not isValidTarget(player, zombie, allowFloor) then
        return nil
    end

    local px = toNumber(safeCall(player, "getX"), nil)
    local py = toNumber(safeCall(player, "getY"), nil)
    local zx = toNumber(safeCall(zombie, "getX"), nil)
    local zy = toNumber(safeCall(zombie, "getY"), nil)
    if px == nil or py == nil or zx == nil or zy == nil then
        return nil
    end

    local dx = zx - px
    local dy = zy - py
    local distSq = (dx * dx) + (dy * dy)
    local onFloor = isZombieOnFloor(zombie)
    local maxRange = onFloor and (FightZ.MANUAL_PUNCH_FLOOR_RANGE or 0.95) or (FightZ.MANUAL_PUNCH_FALLBACK_RANGE or 1.00)
    if distSq > (maxRange * maxRange) then
        return nil
    end

    local distance = math.sqrt(distSq)
    local closeRange = onFloor and (FightZ.MANUAL_PUNCH_FLOOR_CLOSE_RANGE or 0.60) or (FightZ.MANUAL_PUNCH_FALLBACK_CLOSE_RANGE or 0.70)
    if distance <= closeRange then
        return 1.5 - (distance * 0.2)
    end
    if distance <= 0 then
        return nil
    end

    local forwardX, forwardY = getPlayerForward(player)
    local dot = ((dx * forwardX) + (dy * forwardY)) / distance
    if onFloor then
        if dot < -0.15 then
            return nil
        end
    elseif dot < (FightZ.MANUAL_PUNCH_FALLBACK_FRONT_DOT or 0.10) then
        return nil
    end

    return dot - (distance * 0.15)
end

local function isTargetInPunchArc(player, zombie, critical)
    local allowFloor = isZombieOnFloor(zombie)
    if not isValidTarget(player, zombie, allowFloor) then
        return false
    end

    local px = toNumber(safeCall(player, "getX"), nil)
    local py = toNumber(safeCall(player, "getY"), nil)
    local zx = toNumber(safeCall(zombie, "getX"), nil)
    local zy = toNumber(safeCall(zombie, "getY"), nil)
    if px == nil or py == nil or zx == nil or zy == nil then
        return false
    end

    local dx = zx - px
    local dy = zy - py
    local distSq = (dx * dx) + (dy * dy)
    local onFloor = isZombieOnFloor(zombie)
    local impactRange = onFloor and (FightZ.MANUAL_PUNCH_FLOOR_RANGE or 0.95)
        or (critical and (FightZ.MANUAL_PUNCH_CRIT_IMPACT_RANGE or 1.20))
        or (FightZ.MANUAL_PUNCH_IMPACT_RANGE or FightZ.MANUAL_PUNCH_RANGE or 1.00)
    if distSq > (impactRange * impactRange) then
        return false
    end

    local closeRange = onFloor and (FightZ.MANUAL_PUNCH_FLOOR_CLOSE_RANGE or 0.60)
        or (critical and (FightZ.MANUAL_PUNCH_CRIT_CLOSE_HIT_RANGE or 0.85))
        or (FightZ.MANUAL_PUNCH_CLOSE_HIT_RANGE or 0.70)
    if distSq <= (closeRange * closeRange) then
        return true
    end

    local distance = math.sqrt(distSq)
    if distance <= 0 then
        return true
    end

    local forwardX, forwardY = getPlayerForward(player)
    local dot = ((dx * forwardX) + (dy * forwardY)) / distance
    if onFloor then
        return dot >= 0
    end

    if critical then
        return dot >= (FightZ.MANUAL_PUNCH_CRIT_FRONT_DOT or -0.05)
    end
    return dot >= (FightZ.MANUAL_PUNCH_IMPACT_FRONT_DOT or FightZ.MANUAL_PUNCH_FRONT_DOT or 0)
end

local function isSelectedTargetReachable(player, zombie, floorAttack)
    if not isValidTarget(player, zombie, floorAttack == true) then
        return false
    end

    local px = toNumber(safeCall(player, "getX"), nil)
    local py = toNumber(safeCall(player, "getY"), nil)
    local zx = toNumber(safeCall(zombie, "getX"), nil)
    local zy = toNumber(safeCall(zombie, "getY"), nil)
    if px == nil or py == nil or zx == nil or zy == nil then
        return false
    end

    local dx = zx - px
    local dy = zy - py
    local distSq = (dx * dx) + (dy * dy)
    local maxRange = floorAttack and (FightZ.MOUSE_FLOOR_PUNCH_TARGET_RANGE or 1.05) or (FightZ.MANUAL_PUNCH_CHAIN_IMPACT_RANGE or 1.00)
    if distSq > (maxRange * maxRange) then
        return false
    end

    local distance = math.sqrt(distSq)
    local closeRange = floorAttack and (FightZ.MOUSE_FLOOR_PUNCH_CLOSE_TARGET_RANGE or 0.80) or (FightZ.MANUAL_PUNCH_CHAIN_CLOSE_RANGE or 0.70)
    if distance <= closeRange then
        return true
    end
    if distance <= 0 then
        return true
    end

    local forwardX, forwardY = getPlayerForward(player)
    local dot = ((dx * forwardX) + (dy * forwardY)) / distance
    if floorAttack then
        return dot >= -0.25
    end
    return dot >= (FightZ.MANUAL_PUNCH_CHAIN_FRONT_DOT or 0.05)
end

local function isQueuedTargetStillReachable(player, zombie, floorAttack, critical)
    if not isValidTarget(player, zombie, floorAttack == true) then
        return false
    end

    local px = toNumber(safeCall(player, "getX"), nil)
    local py = toNumber(safeCall(player, "getY"), nil)
    local zx = toNumber(safeCall(zombie, "getX"), nil)
    local zy = toNumber(safeCall(zombie, "getY"), nil)
    if px == nil or py == nil or zx == nil or zy == nil then
        return false
    end

    local dx = zx - px
    local dy = zy - py
    local distSq = (dx * dx) + (dy * dy)
    local maxRange = floorAttack and (FightZ.MOUSE_FLOOR_PUNCH_TARGET_RANGE or 1.05)
        or (critical and (FightZ.MANUAL_PUNCH_CRIT_REACTION_GRACE_RANGE or 1.25))
        or (FightZ.MANUAL_PUNCH_REACTION_GRACE_RANGE or 1.10)
    if distSq > (maxRange * maxRange) then
        return false
    end

    local distance = math.sqrt(distSq)
    if distance <= (critical and (FightZ.MANUAL_PUNCH_CRIT_CLOSE_HIT_RANGE or 0.85) or (FightZ.MANUAL_PUNCH_CLOSE_HIT_RANGE or 0.70)) then
        return true
    end
    if distance <= 0 then
        return true
    end

    local forwardX, forwardY = getPlayerForward(player)
    local dot = ((dx * forwardX) + (dy * forwardY)) / distance
    if floorAttack then
        return dot >= -0.25
    end
    return dot >= (critical and (FightZ.MANUAL_PUNCH_CRIT_FRONT_DOT or -0.05) or (FightZ.MANUAL_PUNCH_CHAIN_FRONT_DOT or 0.05))
end

local function canApplyPunchImpact(player, zombie, floorAttack, critical, lockedTarget)
    if floorAttack == true then
        return isTargetInPunchArc(player, zombie, critical) or isSelectedTargetReachable(player, zombie, true)
    end
    if isTargetInPunchArc(player, zombie, critical) then
        return true
    end
    if lockedTarget == true then
        return isQueuedTargetStillReachable(player, zombie, false, critical)
    end
    return false
end

local function findPunchTarget(player, allowFloorTargets)
    if allowFloorTargets == nil then
        allowFloorTargets = true
    end

    local cell = safeCall(player, "getCell") or (getCell and getCell()) or nil
    local zombies = safeCall(cell, "getZombieList")
    if not zombies or not zombies.size or not zombies.get then
        return nil
    end

    local best = nil
    local bestScore = -999
    local size = zombies:size()
    if not size then
        return nil
    end

    for index = 0, size - 1 do
        local zombie = zombies:get(index)
        local score = getPunchTargetScore(player, zombie, false)
        if score and score > bestScore then
            best = zombie
            bestScore = score
        end
    end

    if best then
        return best, false
    end

    for index = 0, size - 1 do
        local zombie = zombies:get(index)
        local score = getFallbackPunchTargetScore(player, zombie, false)
        if score and score > bestScore then
            best = zombie
            bestScore = score
        end
    end

    if best then
        return best, false
    end

    if allowFloorTargets ~= true then
        return nil
    end

    for index = 0, size - 1 do
        local zombie = zombies:get(index)
        local score = getPunchTargetScore(player, zombie, true)
        if score and score > bestScore then
            best = zombie
            bestScore = score
        end
    end

    if best then
        return best, true
    end

    for index = 0, size - 1 do
        local zombie = zombies:get(index)
        local score = getFallbackPunchTargetScore(player, zombie, true)
        if score and score > bestScore then
            best = zombie
            bestScore = score
        end
    end

    return best, best ~= nil
end

local function findMousePunchTarget(player)
    local cell = safeCall(player, "getCell") or (getCell and getCell()) or nil
    local zombies = safeCall(cell, "getZombieList")
    if not zombies or not zombies.size or not zombies.get then
        return nil
    end

    local px = toNumber(safeCall(player, "getX"), nil)
    local py = toNumber(safeCall(player, "getY"), nil)
    if px == nil or py == nil then
        return nil
    end

    local forwardX, forwardY = getPlayerForward(player)
    local best = nil
    local bestScore = -999
    local size = zombies:size()
    local maxRange = FightZ.MOUSE_PUNCH_TARGET_RANGE or 1.00
    local closeRange = FightZ.MOUSE_PUNCH_CLOSE_TARGET_RANGE or 0.70
    local frontDot = FightZ.MOUSE_PUNCH_FRONT_DOT or -0.05

    for index = 0, size - 1 do
        local zombie = zombies:get(index)
        if isValidTarget(player, zombie, false) then
            local zx = toNumber(safeCall(zombie, "getX"), nil)
            local zy = toNumber(safeCall(zombie, "getY"), nil)
            if zx ~= nil and zy ~= nil then
                local dx = zx - px
                local dy = zy - py
                local distSq = (dx * dx) + (dy * dy)
                if distSq <= (maxRange * maxRange) then
                    local distance = math.sqrt(distSq)
                    local dot = 1
                    if distance > 0 then
                        dot = ((dx * forwardX) + (dy * forwardY)) / distance
                    end
                    if distance <= closeRange or dot >= frontDot then
                        local score = (distance <= closeRange and 1.0 or 0.0) + dot - (distance * 0.15)
                        if score > bestScore then
                            best = zombie
                            bestScore = score
                        end
                    end
                end
            end
        end
    end

    return best
end

local function findMouseFloorPunchTarget(player)
    local cell = safeCall(player, "getCell") or (getCell and getCell()) or nil
    local zombies = safeCall(cell, "getZombieList")
    if not zombies or not zombies.size or not zombies.get then
        return nil
    end

    local px = toNumber(safeCall(player, "getX"), nil)
    local py = toNumber(safeCall(player, "getY"), nil)
    if px == nil or py == nil then
        return nil
    end

    local forwardX, forwardY = getPlayerForward(player)
    local best = nil
    local bestScore = -999
    local size = zombies:size()
    local maxRange = FightZ.MOUSE_FLOOR_PUNCH_TARGET_RANGE or 1.05
    local closeRange = FightZ.MOUSE_FLOOR_PUNCH_CLOSE_TARGET_RANGE or 0.80

    for index = 0, size - 1 do
        local zombie = zombies:get(index)
        if isZombieOnFloor(zombie) and isValidTarget(player, zombie, true) then
            local zx = toNumber(safeCall(zombie, "getX"), nil)
            local zy = toNumber(safeCall(zombie, "getY"), nil)
            if zx ~= nil and zy ~= nil then
                local dx = zx - px
                local dy = zy - py
                local distSq = (dx * dx) + (dy * dy)
                if distSq <= (maxRange * maxRange) then
                    local distance = math.sqrt(distSq)
                    local dot = 1
                    if distance > 0 then
                        dot = ((dx * forwardX) + (dy * forwardY)) / distance
                    end
                    if distance <= closeRange or dot >= -0.25 then
                        local score = (distance <= closeRange and 1.0 or 0.0) + dot - (distance * 0.15)
                        if score > bestScore then
                            best = zombie
                            bestScore = score
                        end
                    end
                end
            end
        end
    end

    return best
end

local function isPunchableDoorReachable(player, object)
    if not FightZ.isPunchableDoorObject or not FightZ.isPunchableDoorObject(object) then
        return false
    end

    local playerSquare = safeCall(player, "getCurrentSquare") or safeCall(player, "getSquare")
    local objectSquare = safeCall(object, "getSquare")
    if not playerSquare or not objectSquare then
        return false
    end

    local playerZ = math.floor(toNumber(safeCall(playerSquare, "getZ"), 0))
    local objectZ = math.floor(toNumber(safeCall(objectSquare, "getZ"), playerZ))
    if playerZ ~= objectZ then
        return false
    end
    if playerSquare == objectSquare then
        return true
    end

    return safeCall(object, "isAdjacentToSquare", playerSquare) == true
end

local function doorSeparatesSquares(object, playerSquare, otherSquare)
    local objectSquare = safeCall(object, "getSquare")
    if not objectSquare or not playerSquare or not otherSquare then
        return false
    end

    local objectX = toNumber(safeCall(objectSquare, "getX"), nil)
    local objectY = toNumber(safeCall(objectSquare, "getY"), nil)
    local playerX = toNumber(safeCall(playerSquare, "getX"), nil)
    local playerY = toNumber(safeCall(playerSquare, "getY"), nil)
    local otherX = toNumber(safeCall(otherSquare, "getX"), nil)
    local otherY = toNumber(safeCall(otherSquare, "getY"), nil)
    if objectX == nil or objectY == nil or playerX == nil or playerY == nil or otherX == nil or otherY == nil then
        return false
    end

    local oppositeX = objectX
    local oppositeY = objectY
    if safeCall(object, "getNorth") == true then
        oppositeY = oppositeY - 1
    else
        oppositeX = oppositeX - 1
    end

    return (playerX == objectX and playerY == objectY and otherX == oppositeX and otherY == oppositeY)
        or (otherX == objectX and otherY == objectY and playerX == oppositeX and playerY == oppositeY)
end

local function findPunchableDoorInSquare(square, playerSquare, otherSquare)
    local objects = safeCall(square, "getObjects")
    if not objects or not objects.size or not objects.get then
        return nil
    end

    for index = 0, objects:size() - 1 do
        local object = objects:get(index)
        if FightZ.isPunchableDoorObject
            and FightZ.isPunchableDoorObject(object)
            and doorSeparatesSquares(object, playerSquare, otherSquare) then
            return object
        end
    end

    return nil
end

local function findPunchableDoorTarget(player)
    local playerSquare = safeCall(player, "getCurrentSquare") or safeCall(player, "getSquare")
    local cell = safeCall(player, "getCell") or (getCell and getCell()) or nil
    if not playerSquare or not cell or not cell.getGridSquare then
        return nil
    end

    local squareX = toNumber(safeCall(playerSquare, "getX"), nil)
    local squareY = toNumber(safeCall(playerSquare, "getY"), nil)
    local squareZ = math.floor(toNumber(safeCall(playerSquare, "getZ"), 0))
    if squareX == nil or squareY == nil then
        return nil
    end

    local forwardX, forwardY = getPlayerForward(player)
    local stepX = forwardX >= 0 and 1 or -1
    local stepY = forwardY >= 0 and 1 or -1
    local directions = {}
    local function addDirection(dx, dy)
        if dx ~= 0 or dy ~= 0 then
            directions[#directions + 1] = { x = dx, y = dy }
        end
    end

    if math.abs(forwardX) >= math.abs(forwardY) then
        addDirection(stepX, 0)
        if math.abs(forwardY) > 0.15 then
            addDirection(0, stepY)
        end
    else
        addDirection(0, stepY)
        if math.abs(forwardX) > 0.15 then
            addDirection(stepX, 0)
        end
    end

    for _, direction in ipairs(directions) do
        local otherSquare = cell:getGridSquare(squareX + direction.x, squareY + direction.y, squareZ)
        if otherSquare then
            local door = safeCall(playerSquare, "getDoorTo", otherSquare)
            if isPunchableDoorReachable(player, door) then
                return door
            end

            door = findPunchableDoorInSquare(otherSquare, playerSquare, otherSquare)
                or findPunchableDoorInSquare(playerSquare, playerSquare, otherSquare)
            if isPunchableDoorReachable(player, door) then
                return door
            end
        end
    end

    return nil
end

local function getTargetDebugMetrics(player, zombie)
    if not player or not zombie then
        return nil
    end

    local px = toNumber(safeCall(player, "getX"), nil)
    local py = toNumber(safeCall(player, "getY"), nil)
    local zx = toNumber(safeCall(zombie, "getX"), nil)
    local zy = toNumber(safeCall(zombie, "getY"), nil)
    if px == nil or py == nil or zx == nil or zy == nil then
        return nil
    end

    local dx = zx - px
    local dy = zy - py
    local distSq = (dx * dx) + (dy * dy)
    local distance = math.sqrt(distSq)
    local dot = 1
    if distance > 0 then
        local forwardX, forwardY = getPlayerForward(player)
        dot = ((dx * forwardX) + (dy * forwardY)) / distance
    end

    return {
        distance = distance,
        dot = dot,
        floor = isZombieOnFloor(zombie),
        dead = safeCall(zombie, "isDead") == true,
        validStand = isValidTarget(player, zombie, false),
        validFloor = isValidTarget(player, zombie, true),
        standScore = getPunchTargetScore(player, zombie, false) or getFallbackPunchTargetScore(player, zombie, false),
        floorScore = getPunchTargetScore(player, zombie, true) or getFallbackPunchTargetScore(player, zombie, true),
        arc = isTargetInPunchArc(player, zombie, false),
        critArc = isTargetInPunchArc(player, zombie, true),
        queuedReach = isQueuedTargetStillReachable(player, zombie, false, false),
        floorReach = isSelectedTargetReachable(player, zombie, true),
    }
end

local function describeTargetForDebug(label, player, zombie)
    if not zombie then
        return label .. "=none"
    end

    local metrics = getTargetDebugMetrics(player, zombie)
    if not metrics then
        return label .. "=metrics-nil"
    end

    return label
        .. "{dist=" .. formatNumber(metrics.distance)
        .. " dot=" .. formatNumber(metrics.dot)
        .. " floor=" .. boolText(metrics.floor)
        .. " dead=" .. boolText(metrics.dead)
        .. " validStand=" .. boolText(metrics.validStand)
        .. " validFloor=" .. boolText(metrics.validFloor)
        .. " standScore=" .. formatNumber(metrics.standScore)
        .. " floorScore=" .. formatNumber(metrics.floorScore)
        .. " arc=" .. boolText(metrics.arc)
        .. " critArc=" .. boolText(metrics.critArc)
        .. " queuedReach=" .. boolText(metrics.queuedReach)
        .. " floorReach=" .. boolText(metrics.floorReach)
        .. "}"
end

local function findNearestZombieForDebug(player, wantFloor)
    local cell = safeCall(player, "getCell") or (getCell and getCell()) or nil
    local zombies = safeCall(cell, "getZombieList")
    if not zombies or not zombies.size or not zombies.get then
        return nil
    end

    local px = toNumber(safeCall(player, "getX"), nil)
    local py = toNumber(safeCall(player, "getY"), nil)
    if px == nil or py == nil then
        return nil
    end

    local best = nil
    local bestDistSq = nil
    local size = zombies:size()
    for index = 0, size - 1 do
        local zombie = zombies:get(index)
        if FightZ.isZombie and FightZ.isZombie(zombie) and safeCall(zombie, "isDead") ~= true then
            local onFloor = isZombieOnFloor(zombie)
            if onFloor == wantFloor then
                local zx = toNumber(safeCall(zombie, "getX"), nil)
                local zy = toNumber(safeCall(zombie, "getY"), nil)
                if zx ~= nil and zy ~= nil then
                    local dx = zx - px
                    local dy = zy - py
                    local distSq = (dx * dx) + (dy * dy)
                    if bestDistSq == nil or distSq < bestDistSq then
                        best = zombie
                        bestDistSq = distSq
                    end
                end
            end
        end
    end

    return best
end

local function buildTargetDebugSummary(player)
    local mouseStand = findMousePunchTarget(player)
    local mouseFloor = findMouseFloorPunchTarget(player)
    local nearestStand = findNearestZombieForDebug(player, false)
    local nearestFloor = findNearestZombieForDebug(player, true)

    return describeTargetForDebug("mouseStand", player, mouseStand)
        .. " | " .. describeTargetForDebug("mouseFloor", player, mouseFloor)
        .. " | " .. describeTargetForDebug("nearStand", player, nearestStand)
        .. " | " .. describeTargetForDebug("nearFloor", player, nearestFloor)
end

local function getSandboxMuscleStrainFactor()
    if SandboxVars and SandboxVars.MuscleStrainFactor ~= nil then
        return toNumber(SandboxVars.MuscleStrainFactor, 1)
    end

    if getSandboxOptions then
        local options = getSandboxOptions()
        if options and options.getOptionByName then
            local option = options:getOptionByName("MuscleStrainFactor")
            if option and option.getValue then
                return toNumber(option:getValue(), 1)
            end
        end
    end

    return 1
end

local function addPlayerXp(player, perk, amount)
    amount = tonumber(amount) or 0
    if not player or not perk or amount <= 0 then
        return false
    end

    if FightZ.ensureFistXpMultiplierConfig then
        FightZ.ensureFistXpMultiplierConfig()
    end

    local xp = safeCall(player, "getXp")
    if not xp or not xp.AddXP then
        return false
    end

    if addXp then
        addXp(player, perk, amount)
    else
        xp:AddXP(perk, amount, false, true, false, false)
    end

    return true
end

local function addFistXp(player, amount, killedZombie)
    if isClient and isClient() and sendClientCommand then
        sendClientCommand(player, "FightZ", "PunchXp", {
            critical = (tonumber(amount) or 0) > 1.0,
            killedZombie = killedZombie == true,
        })
        return
    end

    if FightZ.ENABLE_FIST_XP == false then
        return
    end

    local perk = FightZ.resolvePerk and FightZ.resolvePerk()
    if not perk then
        return
    end

    if FightZ.applyTraitBoost then
        FightZ.applyTraitBoost(player)
    end

    addPlayerXp(player, perk, amount)
end

local function creditVanillaZombieKill(player, previousKills)
    if not player or not player.getZombieKills or not player.setZombieKills then
        return
    end

    local currentKills = toNumber(player:getZombieKills(), 0)
    previousKills = toNumber(previousKills, currentKills)
    if currentKills <= previousKills then
        player:setZombieKills(previousKills + 1)
    end
end

local function addPunchPhysicalXp(player, critical)
    if isClient and isClient() then
        return
    end

    if not Perks then
        return
    end

    local multiplier = critical and FightZ.MANUAL_PUNCH_PHYSICAL_XP_CRIT_MULTIPLIER or 1.0
    local strengthXp = (FightZ.MANUAL_PUNCH_STRENGTH_XP or 0) * multiplier
    local fitnessXp = (FightZ.MANUAL_PUNCH_FITNESS_XP or 0) * multiplier

    if Perks.Strength and strengthXp > 0 then
        addPlayerXp(player, Perks.Strength, strengthXp)
    end
    if Perks.Fitness and fitnessXp > 0 then
        addPlayerXp(player, Perks.Fitness, fitnessXp)
    end
end

local function addPunchMaintenanceXp(player, critical)
    if isClient and isClient() then
        return
    end

    if FightZ.ENABLE_FIST_MAINTENANCE_XP == false then
        return
    end
    if not hasFistMaintenanceTrait(player) then
        return
    end
    if not getFightZBestFistEquipment(player) then
        return
    end

    if not Perks then
        return
    end

    local perk = Perks.Maintenance
    if not perk and Perks.FromString then
        perk = Perks.FromString("Maintenance")
    end
    if not perk then
        return
    end

    local amount = FightZ.MANUAL_PUNCH_MAINTENANCE_XP or 0
    if critical then
        amount = amount * (FightZ.MANUAL_PUNCH_MAINTENANCE_XP_CRIT_MULTIPLIER or 1.0)
    end
    if amount > 0 then
        addPlayerXp(player, perk, amount)
    end
end

local function drainEndurance(player, amount)
    if FightZ.ENABLE_FIST_ENDURANCE == false then
        return
    end

    local stats = safeCall(player, "getStats")
    if stats and stats.remove and CharacterStat and CharacterStat.ENDURANCE then
        stats:remove(CharacterStat.ENDURANCE, amount)
    end
end

local function addMuscleStrain(player, critical)
    if FightZ.ENABLE_FIST_MUSCLE_STRAIN == false then
        return
    end

    local sandboxFactor = getSandboxMuscleStrainFactor()
    if sandboxFactor <= 0 then
        return
    end

    local modData = safeCall(player, "getModData")
    local now = getNowMs()
    local lastTime = modData and toNumber(modData.FightZLastStrainMs, 0) or 0
    local chain = 1
    if modData and lastTime > 0 and now - lastTime <= (FightZ.MANUAL_PUNCH_STRAIN_CHAIN_WINDOW_MS or 7500) then
        chain = toNumber(modData.FightZStrainChain, 0) + 1
    end
    if chain > 20 then
        chain = 20
    end

    if modData then
        modData.FightZLastStrainMs = now
        modData.FightZStrainChain = chain
    end

    local level = FightZ.getFistLevel and FightZ.getFistLevel(player) or 0
    local skillMultiplier = 1 - (level * 0.035)
    if skillMultiplier < 0.65 then
        skillMultiplier = 0.65
    end

    local chainStep = FightZ.getSandboxComboStrainStep
        and FightZ.getSandboxComboStrainStep()
        or (FightZ.MANUAL_PUNCH_STRAIN_CHAIN_STEP or 0.05)
    local chainMultiplier = (FightZ.MANUAL_PUNCH_STRAIN_CHAIN_BASE_MULTIPLIER or 0.8)
        + ((chain - 1) * chainStep)
    local maxChainMultiplier = FightZ.MANUAL_PUNCH_STRAIN_CHAIN_MAX_MULTIPLIER or 2.0
    if chainMultiplier > maxChainMultiplier then
        chainMultiplier = maxChainMultiplier
    end
    if chainMultiplier < 0 then
        chainMultiplier = 0
    end

    local fitnessMultiplier = FightZ.getFitnessPunchStrainMultiplier
        and FightZ.getFitnessPunchStrainMultiplier(player)
        or 1.0
    local amount = (FightZ.MANUAL_PUNCH_MUSCLE_STRAIN_BASE or 0.20)
        * sandboxFactor
        * chainMultiplier
        * skillMultiplier
        * fitnessMultiplier
    if critical then
        amount = amount * 1.35
    end

    addStoredFightZMuscleStrainScore(player, amount)
    if player.addBothArmMuscleStrain then
        -- Un golpe sin arma reparte la carga entre ambos brazos.
        player:addBothArmMuscleStrain(amount * 0.5)
    elseif player.addLeftArmMuscleStrain and player.addRightArmMuscleStrain then
        player:addLeftArmMuscleStrain(amount * 0.5)
        player:addRightArmMuscleStrain(amount * 0.5)
    elseif player.addArmMuscleStrain then
        player:addArmMuscleStrain(amount)
    end
end

local function getCustomPunchSoundVolumeMultiplier()
    if FightZ.GetClientPunchSoundVolumeMultiplier then
        local ok, volume = pcall(FightZ.GetClientPunchSoundVolumeMultiplier)
        if ok then
            volume = tonumber(volume)
            if volume then
                if volume < 0 then
                    return 0
                elseif volume > 1 then
                    return 1
                end
                return volume
            end
        end
    end
    return 1.0
end

local function applyFightZSoundVolume(emitter, handle, volume)
    if not handle or handle == 0 or handle == false then
        return false
    end

    local changed = false
    if type(handle) == "table" or type(handle) == "userdata" then
        pcall(function()
            if handle.setVolume then
                handle:setVolume(volume)
                changed = true
            elseif handle.setVolumeAll then
                handle:setVolumeAll(volume)
                changed = true
            end
        end)
    end
    if emitter and emitter.setVolume then
        local ok = pcall(emitter.setVolume, emitter, handle, volume)
        changed = changed or ok
    end
    return changed
end

local function stopFightZSound(emitter, handle)
    if type(handle) == "table" or type(handle) == "userdata" then
        pcall(function()
            if handle.stop then
                handle:stop()
            end
        end)
    end
    if emitter and emitter.stopSound then
        pcall(emitter.stopSound, emitter, handle)
    end
end

local function playFightZSound(player, sound, volume)
    volume = tonumber(volume) or 1.0
    if volume <= 0 then
        return
    end
    if volume > 1 then
        volume = 1
    end

    local emitter = safeCall(player, "getEmitter")
    if emitter and emitter.playSound then
        local ok, handle = pcall(function()
            return emitter:playSound(sound)
        end)
        if ok and handle and handle ~= 0 then
            if not applyFightZSoundVolume(emitter, handle, volume) and volume < 0.999 then
                stopFightZSound(emitter, handle)
            end
            return
        end
    end
    if volume < 0.999 then
        local soundManager = getSoundManager and getSoundManager() or nil
        if soundManager and soundManager.PlaySound then
            pcall(soundManager.PlaySound, soundManager, sound, false, volume)
        end
        return
    end
    if player and player.playSound then
        pcall(function()
            player:playSound(sound)
        end)
    end
end

local function useCustomPunchSounds()
    return SandboxVars
        and SandboxVars.FightZ
        and SandboxVars.FightZ.CustomPunchSounds == true
end

local function playPunchHitSound(player, critical)
    if useCustomPunchSounds() then
        local sound = critical
            and FightZ.CUSTOM_PUNCH_CRITICAL_SOUND
            or FightZ.CUSTOM_PUNCH_HIT_SOUND
        playFightZSound(player, sound, getCustomPunchSoundVolumeMultiplier())
        return
    end

    playFightZSound(player, FightZ.PUNCH_HIT_SOUND or "BareHandsHit")
end

local function playPunchMissSound(player)
    if useCustomPunchSounds() then
        playFightZSound(player, FightZ.CUSTOM_PUNCH_MISS_SOUND, getCustomPunchSoundVolumeMultiplier())
        return
    end

    playFightZSound(player, FightZ.PUNCH_MISS_SOUND or "LargeBoneClubSwing")
end

local function killZombieNow(player, zombie)
    if not zombie then
        return false
    end

    if zombie.isDead and zombie:isDead() then
        return true
    end

    if player and zombie.setAttackedBy then
        pcall(function()
            zombie:setAttackedBy(player)
        end)
    end

    if zombie.setHitReaction then
        pcall(function()
            zombie:setHitReaction("")
        end)
    end
    if zombie.setBumpFall then
        pcall(function()
            zombie:setBumpFall(false)
        end)
    end
    if zombie.setBumpStaggered then
        pcall(function()
            zombie:setBumpStaggered(false)
        end)
    end
    if zombie.clearVariable then
        pcall(function()
            zombie:clearVariable("BumpFall")
        end)
        pcall(function()
            zombie:clearVariable("BumpFallType")
        end)
        pcall(function()
            zombie:clearVariable("BumpFallAnimFinished")
        end)
        pcall(function()
            zombie:clearVariable("BumpAnimFinished")
        end)
    end

    if zombie.Kill then
        pcall(function()
            zombie:Kill(player)
        end)
    end
    if zombie.isDead and zombie:isDead() then
        return true
    end

    if zombie.DoDeath then
        pcall(function()
            zombie:DoDeath(nil, player, true)
        end)
    end
    if zombie.isDead and zombie:isDead() then
        return true
    end

    if zombie.setHealth then
        pcall(function()
            zombie:setHealth(0)
        end)
    end

    local bodyDamage = zombie.getBodyDamage and zombie:getBodyDamage() or nil
    if bodyDamage and bodyDamage.setOverallBodyHealth then
        pcall(function()
            bodyDamage:setOverallBodyHealth(0)
        end)
    end

    if zombie.die and (not zombie.isDead or not zombie:isDead()) then
        pcall(function()
            zombie:die()
        end)
    end

    return zombie.isDead and zombie:isDead() == true
end

local function applyPunchDamage(player, zombie, critical, floorAttack)
    if FightZ.ENABLE_FIST_DAMAGE == false then
        return false
    end

    local health = toNumber(safeCall(zombie, "getHealth"), nil)
    if health == nil or not zombie.setHealth then
        return false
    end

    if floorAttack == true
        and FightZ.getFloorSmashChance
        and isZombieOnFloor(zombie) then
        local smashChance = FightZ.getFloorSmashChance(player, critical)
        if (randomFloat() * 100) < smashChance and killZombieNow(player, zombie) then
            return true
        end
    end

    local level = FightZ.getFistLevel and FightZ.getFistLevel(player) or 0
    local boost = FightZ.getPlayerFistBoost and FightZ.getPlayerFistBoost(player) or 0
    if level < 0 then
        level = 0
    elseif level > 10 then
        level = 10
    end

    local levelRatio = level / 10
    local levelDamage = (levelRatio ^ (FightZ.MANUAL_PUNCH_LEVEL_EXPONENT or 1.45))
        * (FightZ.MANUAL_PUNCH_LEVEL_DAMAGE or 0.225)
    local boostDamage = boost * ((FightZ.MANUAL_PUNCH_BOOST_DAMAGE or 0.006)
        + (level * (FightZ.MANUAL_PUNCH_BOOST_LEVEL_DAMAGE or 0.004)))
    local damage = FightZ.MANUAL_PUNCH_BASE_DAMAGE
        + levelDamage
        + boostDamage
    local weakDamageHit = damage <= (FightZ.MANUAL_PUNCH_WEAK_DAMAGE_THRESHOLD or 0.08)
    if not weakDamageHit and not critical and FightZ.getWeakPunchChance then
        weakDamageHit = (randomFloat() * 100) < FightZ.getWeakPunchChance(player)
    end
    if damage > FightZ.MANUAL_PUNCH_MAX_DAMAGE then
        damage = FightZ.MANUAL_PUNCH_MAX_DAMAGE
    end
    if critical then
        damage = damage * (FightZ.MANUAL_PUNCH_CRIT_MULTIPLIER or 1.45)
        local critMaxDamage = FightZ.MANUAL_PUNCH_CRIT_MAX_DAMAGE or (FightZ.MANUAL_PUNCH_MAX_DAMAGE * 1.45)
        if damage > critMaxDamage then
            damage = critMaxDamage
        end
    end
    local equipmentBonus = getFistEquipmentDamageBonus(player)
    if equipmentBonus > 0 then
        damage = damage * (1 + equipmentBonus)
        local equipmentMaxDamage = critical
            and (FightZ.MANUAL_PUNCH_CRIT_EQUIPMENT_MAX_DAMAGE or FightZ.MANUAL_PUNCH_EQUIPMENT_MAX_DAMAGE)
            or (FightZ.MANUAL_PUNCH_EQUIPMENT_MAX_DAMAGE or FightZ.MANUAL_PUNCH_MAX_DAMAGE)
        if damage > equipmentMaxDamage then
            damage = equipmentMaxDamage
        end
    end
    if weakDamageHit and not critical and FightZ.getWeakPunchDamageRange then
        local weakMin, weakMax = FightZ.getWeakPunchDamageRange(player)
        damage = randomRange(weakMin, weakMax)
        if equipmentBonus > 0 then
            damage = damage * (1 + equipmentBonus)
        end
    elseif FightZ.getPainDamageMultiplier then
        damage = damage * FightZ.getPainDamageMultiplier(player)
    end

    local strengthMultiplier = FightZ.getStrengthPunchDamageMultiplier
        and FightZ.getStrengthPunchDamageMultiplier(player)
        or 1.0
    damage = damage * strengthMultiplier
    local finalDamageCap = critical
        and (equipmentBonus > 0
            and (FightZ.MANUAL_PUNCH_CRIT_EQUIPMENT_MAX_DAMAGE or FightZ.MANUAL_PUNCH_CRIT_MAX_DAMAGE)
            or (FightZ.MANUAL_PUNCH_CRIT_MAX_DAMAGE or (FightZ.MANUAL_PUNCH_MAX_DAMAGE * 1.45)))
        or (equipmentBonus > 0
            and (FightZ.MANUAL_PUNCH_EQUIPMENT_MAX_DAMAGE or FightZ.MANUAL_PUNCH_MAX_DAMAGE)
            or FightZ.MANUAL_PUNCH_MAX_DAMAGE)
    if damage > finalDamageCap then
        damage = finalDamageCap
    end
    damage = damage * (FightZ.getSandboxFistDamageMultiplier
        and FightZ.getSandboxFistDamageMultiplier()
        or 1.0)

    local newHealth = health - damage
    if newHealth > 0 then
        zombie:setHealth(newHealth)
        return false
    end

    killZombieNow(player, zombie)
    return true
end

local function rollPercent(chance)
    chance = toNumber(chance, 0)
    if chance <= 0 then
        return false
    end

    if FightZ.randomInt then
        return FightZ.randomInt(100) < chance
    end
    if ZombRand then
        return ZombRand(100) < chance
    end
    return math.random(0, 99) < chance
end

local function getNextPunchReaction(zombie, critical, floorAttack)
    if floorAttack then
        return "Floor"
    end
    if critical then
        return "Uppercut"
    end

    local reactions = { "HeadLeft", "HeadRight", "HeadTop" }
    local index = 1
    local modData = safeCall(zombie, "getModData")
    if modData then
        index = toNumber(modData.FightZLastHitReactionIndex, 0) + 1
        if index > #reactions then
            index = 1
        end
        modData.FightZLastHitReactionIndex = index
    end
    return reactions[index]
end

local function applyPunchReaction(player, zombie, critical, floorAttack)
    if FightZ.ENABLE_MANUAL_PUNCH_REACTIONS == false or not zombie then
        return
    end

    if player and zombie.setAttackedBy then
        pcall(function()
            zombie:setAttackedBy(player)
        end)
    end
    if player and zombie.setTarget then
        pcall(function()
            zombie:setTarget(player)
        end)
    end
    if player and zombie.setHitFromBehind then
        local forwardX, forwardY = getPlayerForward(player)
        local zForwardX, zForwardY = getPlayerForward(zombie)
        local facingDot = (forwardX * zForwardX) + (forwardY * zForwardY)
        pcall(function()
            zombie:setHitFromBehind(facingDot > 0)
        end)
    end
    if zombie.setHitForce then
        pcall(function()
            zombie:setHitForce(FightZ.MANUAL_PUNCH_HIT_FORCE or 0.35)
        end)
    end

    if zombie.setHitReaction then
        local reaction = getNextPunchReaction(zombie, critical, floorAttack)
        pcall(function()
            zombie:setHitReaction(reaction)
        end)
    end

    if zombie.setStaggerBack and floorAttack ~= true then
        local chance = FightZ.MANUAL_PUNCH_STAGGER_CHANCE or 0
        if critical then
            chance = chance + (FightZ.MANUAL_PUNCH_STAGGER_CRIT_BONUS or 0)
        end
        if chance > (FightZ.MANUAL_PUNCH_STAGGER_MAX_CHANCE or chance) then
            chance = FightZ.MANUAL_PUNCH_STAGGER_MAX_CHANCE
        end
        if rollPercent(chance) then
            pcall(function()
                zombie:setStaggerBack(true)
            end)
            CONTROLLED_STAGGERS[zombie] = getNowMs() + (FightZ.MANUAL_PUNCH_STAGGER_CLEAR_MS or 260)
        end
    end
end

local function applyPunchKnockdown(player, zombie, critical, floorAttack)
    if FightZ.ENABLE_MANUAL_PUNCH_KNOCKDOWN ~= true then
        return false
    end
    if floorAttack == true or not zombie or isZombieOnFloor(zombie) or safeCall(zombie, "isDead") == true then
        return false
    end
    if not zombie.knockDown then
        return false
    end

    local level = FightZ.getFistLevel and FightZ.getFistLevel(player) or 0
    local boost = FightZ.getPlayerFistBoost and FightZ.getPlayerFistBoost(player) or 0
    local chance = (FightZ.MANUAL_PUNCH_KNOCKDOWN_BASE or 0)
        + (level * (FightZ.MANUAL_PUNCH_KNOCKDOWN_LEVEL or 0))
        + (boost * (FightZ.MANUAL_PUNCH_KNOCKDOWN_BOOST or 0))

    if critical then
        chance = chance + (FightZ.MANUAL_PUNCH_KNOCKDOWN_CRIT_BONUS or 0)
    end
    if chance > (FightZ.MANUAL_PUNCH_KNOCKDOWN_MAX or chance) then
        chance = FightZ.MANUAL_PUNCH_KNOCKDOWN_MAX
    end
    if not rollPercent(chance) then
        return false
    end

    local ok = pcall(function()
        zombie:knockDown(false)
    end)
    return ok == true
end

local function getSandboxBloodLevel()
    local bloodLevel = SandboxVars and toNumber(SandboxVars.BloodLevel, nil) or nil
    if bloodLevel == nil and getSandboxOptions then
        local ok, value = pcall(function()
            local option = getSandboxOptions():getOptionByName("BloodLevel")
            return option and option:getValue() or nil
        end)
        if ok then
            bloodLevel = toNumber(value, nil)
        end
    end

    bloodLevel = math.floor(toNumber(bloodLevel, 3) + 0.5)
    return math.max(1, math.min(5, bloodLevel))
end

local function applyPunchBloodEffects(zombie)
    if not zombie then
        return
    end

    local bloodLevel = getSandboxBloodLevel()
    if bloodLevel <= 1 then
        return
    end
    if zombie.addBlood then
        pcall(function()
            zombie:addBlood(nil, false, true, false)
        end)
    end

    -- Vanilla scales a weapon with SplatNumber=1 to 0/1/2/5 decals.
    local splatCount = PUNCH_BLOOD_SPLATS_BY_LEVEL[bloodLevel] or 0
    if zombie.splatBlood then
        pcall(function()
            for _ = 1, splatCount do
                zombie:splatBlood(3, 0.3)
            end
        end)
    end

    if zombie.splatBloodFloorBig then
        pcall(function()
            zombie:splatBloodFloorBig()
        end)
    end
end

local function getCombatTextTimestamp()
    local ok, value = pcall(function()
        return getGameTime():getCalender():getTimeInMillis()
    end)
    if ok then
        return value
    end
    return getNowMs()
end

local function notifyCombatTextBeforePunch(zombie, critical)
    if not zombie
        or type(CombatText) ~= "table"
        or type(CombatText.Fn) ~= "table"
        or type(CombatTextCache) ~= "table"
        or type(CombatTextCache.TrackingList) ~= "table" then
        return
    end

    local uid = nil
    if type(CombatText.Fn.getEntityId) == "function" then
        local ok, value = pcall(CombatText.Fn.getEntityId, zombie)
        if ok then
            uid = value
        end
    end
    if uid == nil and zombie.getUID then
        local ok, value = pcall(zombie.getUID, zombie)
        if ok then
            uid = value
        end
    end
    if uid == nil then
        return
    end

    local health = toNumber(safeCall(zombie, "getHealth"), 0) * 100
    local timestamp = getCombatTextTimestamp()
    local trackingItem = CombatTextCache.TrackingList[uid]
    if trackingItem == nil then
        trackingItem = {
            fullHp = health,
            hp = health,
            isDead = safeCall(zombie, "isDead") == true,
            entity = zombie,
            isOnFire = false,
            isBleeding = false,
            weapon = COMBAT_TEXT_FIST_WEAPON,
            isCrit = critical == true,
            tick = timestamp,
        }
        CombatTextCache.TrackingList[uid] = trackingItem
        CombatTextCache.TrackingListCount = toNumber(CombatTextCache.TrackingListCount, 0) + 1
    else
        trackingItem.entity = zombie
        trackingItem.weapon = COMBAT_TEXT_FIST_WEAPON
        trackingItem.isCrit = critical == true
        trackingItem.tick = timestamp
    end

    if type(CombatTextCache.HealthBarManagers) == "table" then
        for _, manager in pairs(CombatTextCache.HealthBarManagers) do
            if manager and manager.onHit then
                pcall(manager.onHit, manager, uid, COMBAT_TEXT_FIST_WEAPON, critical == true, trackingItem)
            end
        end
    end
end

local function applyConfirmedPunchImpact(player, zombie, critical, floorAttack)
    local killsBefore = player and player.getZombieKills
        and toNumber(player:getZombieKills(), 0)
        or 0
    local healthBefore = toNumber(safeCall(zombie, "getHealth"), nil)
    playPunchHitSound(player, critical)
    if FightZ.ENABLE_FIST_DAMAGE ~= false and healthBefore ~= nil then
        notifyCombatTextBeforePunch(zombie, critical)
    end
    local killed = applyPunchDamage(player, zombie, critical, floorAttack)
    local healthAfter = toNumber(safeCall(zombie, "getHealth"), healthBefore)
    if healthBefore ~= nil and ((healthAfter ~= nil and healthAfter < healthBefore) or killed == true) then
        applyPunchBloodEffects(zombie)
    end
    if killed ~= true then
        local knockedDown = applyPunchKnockdown(player, zombie, critical, floorAttack)
        if knockedDown ~= true then
            applyPunchReaction(player, zombie, critical, floorAttack)
        end
    end
    if killed == true and not (isClient and isClient()) then
        creditVanillaZombieKill(player, killsBefore)
    end
    addFistXp(player, critical and 2.0 or 1.0, killed)
    addPunchPhysicalXp(player, critical)
    addPunchMaintenanceXp(player, critical)
    drainEndurance(player, randomRange(FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MIN or 0.003, FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MAX or 0.005))
    addMuscleStrain(player, critical)
    applyUnprotectedHandScratchRisk(player)
end

local function getPunchObjectDamage(player, critical)
    local level = FightZ.getFistLevel and FightZ.getFistLevel(player) or 0
    local boost = FightZ.getPlayerFistBoost and FightZ.getPlayerFistBoost(player) or 0
    local strength = 0
    if Perks and Perks.Strength and player and player.getPerkLevel then
        strength = toNumber(safeCall(player, "getPerkLevel", Perks.Strength), 0)
    end

    local damage = (FightZ.MANUAL_PUNCH_OBJECT_BASE_DAMAGE or 4)
        + (math.max(0, math.min(10, level)) * (FightZ.MANUAL_PUNCH_OBJECT_LEVEL_DAMAGE or 1.0))
        + (math.max(0, math.min(10, strength)) * (FightZ.MANUAL_PUNCH_OBJECT_STRENGTH_DAMAGE or 0.5))
        + (math.max(0, boost) * (FightZ.MANUAL_PUNCH_OBJECT_BOOST_DAMAGE or 1.5))

    local equipmentBonus = getFistEquipmentDamageBonus(player)
    if equipmentBonus > 0 then
        damage = damage * (1 + equipmentBonus)
    end
    if FightZ.getPainDamageMultiplier then
        damage = damage * FightZ.getPainDamageMultiplier(player)
    end
    if critical then
        damage = damage * (FightZ.MANUAL_PUNCH_CRIT_MULTIPLIER or 1.45)
    end

    return math.max(1, math.min(FightZ.MANUAL_PUNCH_OBJECT_MAX_DAMAGE or 30, math.floor(damage + 0.5)))
end

local function applyConfirmedDoorImpact(player, object, critical)
    if not isPunchableDoorReachable(player, object) then
        return false
    end

    local square = safeCall(object, "getSquare")
    local damage = getPunchObjectDamage(player, critical)
    local applied = false
    if isClient and isClient() and sendClientCommand and square then
        sendClientCommand(player, "FightZ", "PunchObject", {
            x = safeCall(square, "getX"),
            y = safeCall(square, "getY"),
            z = safeCall(square, "getZ"),
            objectIndex = safeCall(object, "getObjectIndex"),
            damage = damage,
        })
        applied = true
    elseif FightZ.applyPunchObjectDamage then
        applied = FightZ.applyPunchObjectDamage(object, damage) == true
    end

    if not applied then
        return false
    end

    playPunchHitSound(player, critical)
    drainEndurance(player, randomRange(FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MIN or 0.003, FightZ.MANUAL_PUNCH_ENDURANCE_DRAIN_MAX or 0.005))
    addMuscleStrain(player, critical)
    applyUnprotectedHandScratchRisk(player)
    return true
end

local function canApplyFightZImpact(player, target, floorAttack, critical, lockedTarget)
    if FightZ.isZombie and FightZ.isZombie(target) then
        return canApplyPunchImpact(player, target, floorAttack, critical, lockedTarget)
    end
    return floorAttack ~= true and isPunchableDoorReachable(player, target)
end

local function applyConfirmedFightZImpact(player, target, critical, floorAttack)
    if FightZ.isZombie and FightZ.isZombie(target) then
        applyConfirmedPunchImpact(player, target, critical, floorAttack)
        return true
    end
    return applyConfirmedDoorImpact(player, target, critical)
end

local function facePunchTarget(player, target)
    if not player or not target then
        return
    end
    if player.faceThisObject then
        local ok = pcall(function()
            player:faceThisObject(target)
        end)
        if ok then
            return
        end
    end

    local x = toNumber(safeCall(target, "getX"), nil)
    local y = toNumber(safeCall(target, "getY"), nil)
    if x ~= nil and y ~= nil and player.faceLocationF then
        pcall(function()
            player:faceLocationF(x, y)
        end)
    end
end

local function facePunchLocation(player, x, y)
    x = toNumber(x, nil)
    y = toNumber(y, nil)
    if not player or x == nil or y == nil then
        return
    end
    if player.faceLocationF then
        pcall(function()
            player:faceLocationF(x, y)
        end)
    end
end

local function getNextPunchSelection(player, critical)
    local modData = safeCall(player, "getModData")
    local list = critical and CRIT_ANIMS or PUNCH_ANIMS
    local actions = critical and CRIT_ACTIONS or PUNCH_ACTIONS
    if FightZ.shouldUsePrimaryOnlyPunch and FightZ.shouldUsePrimaryOnlyPunch(player) then
        list = critical and PRIMARY_ONLY_CRIT_ANIMS or PRIMARY_ONLY_PUNCH_ANIMS
        actions = critical and PRIMARY_ONLY_CRIT_ACTIONS or PRIMARY_ONLY_PUNCH_ACTIONS
    end
    local nextIndex = 1
    if modData then
        local lastIndex = toNumber(modData.FightZPunchAnimIndex, 0)
        if #list > 1 then
            nextIndex = ((FightZ.randomInt and FightZ.randomInt(#list)) or math.random(0, #list - 1)) + 1
            if nextIndex == lastIndex then
                nextIndex = (nextIndex % #list) + 1
            end
        end
        modData.FightZPunchAnimIndex = nextIndex
    end

    return list[nextIndex], actions[nextIndex], nextIndex
end

if FightZ.ENABLE_MOUSE_TIMED_ACTION == true and ISBaseTimedAction then
FightZManualPunchAction = FightZManualPunchAction or ISBaseTimedAction:derive("FightZManualPunchAction")

function FightZManualPunchAction:isValid()
    return self.character
        and (not self.character.isDead or not self.character:isDead())
        and (not FightZ.hasEmptyHandsForFightZ or FightZ.hasEmptyHandsForFightZ(self.character))
end

function FightZManualPunchAction:start()
    self.startedAtMs = getNowMs()
    facePunchLocation(self.character, self.targetX, self.targetY)
    if self.character and self.actionName then
        if self.character.SetVariable then
            self.character:SetVariable("LAttackType", self.actionName)
        elseif self.character.setVariable then
            self.character:setVariable("LAttackType", self.actionName)
        end
    end
    if self.setActionAnim then
        self:setActionAnim("LAttack")
    end
    if self.action and self.action.setUseProgressBar then
        self.action:setUseProgressBar(false)
    end
    if self.hasInitialTarget ~= true then
        self.missSoundPlayed = true
        playPunchMissSound(self.character)
    end
end

function FightZManualPunchAction:applyImpact()
    if self.applied then
        return
    end

    self.applied = true
    local target = self.target
    local floorAttack = self.floorAttack == true
    if target and FightZ.isPunchableDoorObject and FightZ.isPunchableDoorObject(target) then
        -- Keep the selected door; unlike zombies, world objects do not need reacquisition.
    elseif floorAttack then
        target = findMouseFloorPunchTarget(self.character)
    else
        target = findMousePunchTarget(self.character)
        if not target then
            target = findPunchTarget(self.character, false)
        end
    end

    if target then
        facePunchTarget(self.character, target)
    else
        facePunchLocation(self.character, self.targetX, self.targetY)
    end

    if target and canApplyFightZImpact(self.character, target, floorAttack, self.critical, self.hasInitialTarget == true) then
        applyConfirmedFightZImpact(self.character, target, self.critical, floorAttack)
    elseif not self.missSoundPlayed then
        self.missSoundPlayed = true
        playPunchMissSound(self.character)
    end
end

function FightZManualPunchAction:update()
    if self.startedAtMs and (getNowMs() - self.startedAtMs) > getScaledPunchMs(self.character, FightZ.MANUAL_PUNCH_ACTION_FAILSAFE_MS or 1200) then
        if not self.applied then
            self:applyImpact()
        end
        if self.forceComplete then
            self:forceComplete()
        end
    end
end

function FightZManualPunchAction:animEvent(event, parameter)
    if event == "AttackCollisionCheck" then
        self:applyImpact()
    elseif event == "EndAttack" then
        if not self.applied then
            self:applyImpact()
        end
        if self.forceComplete then
            self:forceComplete()
        end
    end
end

function FightZManualPunchAction:clearAttackVariables()
    if self.character and self.character.clearVariable then
        self.character:clearVariable("LAttackType")
    end
end

function FightZManualPunchAction:stop()
    self:clearAttackVariables()
    restoreVanillaBareHandAttack(self.character)
    ISBaseTimedAction.stop(self)
end

function FightZManualPunchAction:forceCancel()
    self:clearAttackVariables()
    restoreVanillaBareHandAttack(self.character)
    ISBaseTimedAction.forceCancel(self)
end

function FightZManualPunchAction:perform()
    if not self.applied then
        self:applyImpact()
    end
    self:clearAttackVariables()
    holdVanillaAfterFightZAction(self.character)
    if self.character and self.character.setMeleeDelay then
        pcall(function()
            self.character:setMeleeDelay(FightZ.MANUAL_PUNCH_NATIVE_MELEE_DELAY or 100)
        end)
    end
    ISBaseTimedAction.perform(self)
end

function FightZManualPunchAction:new(character, target, critical, actionName, floorAttack)
    local o = ISBaseTimedAction.new(self, character)
    o.Type = "FightZManualPunchAction"
    o.character = character
    o.target = target
    o.hasInitialTarget = target ~= nil
    o.targetX = target and safeCall(target, "getX") or nil
    o.targetY = target and safeCall(target, "getY") or nil
    o.critical = critical
    o.actionName = actionName
    o.floorAttack = floorAttack == true
    o.maxTime = -1
    o.stopOnWalk = false
    o.stopOnRun = false
    o.stopOnAim = false
    o.ignoreHandsWounds = true
    o.applied = false
    o.missSoundPlayed = false
    return o
end
end

local function playPunchFallback(player, anim)
    if FightZ.ENABLE_MANUAL_PUNCH_ANIMATIONS ~= true then
        return
    end
    if player.PlayAnimUnlooped then
        player:PlayAnimUnlooped(anim)
    elseif player.PlayAnim then
        player:PlayAnim(anim)
    end
end

local function setCooldown(player)
    local modData = safeCall(player, "getModData")
    if modData then
        modData.FightZNextManualPunchMs = getNowMs() + getScaledPunchMs(player, FightZ.MANUAL_PUNCH_COOLDOWN_MS or 360)
    end
end

isMeleeInputDown = function(player)
    if isJoypadMeleeInputDown and isJoypadMeleeInputDown(player) then
        return true
    end

    if isKeyDown then
        local ok, pressed = pcall(function()
            return isKeyDown("Melee")
        end)
        if ok and pressed == true then
            return true
        end
    end

    if GameKeyboard and GameKeyboard.isKeyDown then
        local ok, pressed = pcall(function()
            return GameKeyboard.isKeyDown("Melee")
        end)
        if ok and pressed == true then
            return true
        end
    end

    if Keyboard and Keyboard.KEY_SPACE then
        if Keyboard.isKeyDown then
            local ok, pressed = pcall(function()
                return Keyboard.isKeyDown(Keyboard.KEY_SPACE)
            end)
            if ok and pressed == true then
                return true
            end
        end
        if isKeyDown then
            local ok, pressed = pcall(function()
                return isKeyDown(Keyboard.KEY_SPACE)
            end)
            if ok and pressed == true then
                return true
            end
        end
    end

    return false
end

local function isMouseOverUi()
    if not UIManager or not UIManager.getUI then
        return false
    end

    local ok, uis = pcall(function()
        return UIManager.getUI()
    end)
    if not ok or not uis or not uis.size or not uis.get then
        return false
    end

    for i = 1, uis:size() do
        local ui = uis:get(i - 1)
        if ui and ui.isMouseOver then
            local overOk, over = pcall(function()
                return ui:isMouseOver()
            end)
            if overOk and over == true then
                return true
            end
        end
    end

    return false
end

function restoreVanillaBareHandAttack(player)
    local modData = safeCall(player, "getModData")

    if modData then
        modData.FightZSavedMeleeAuthorization = nil
        modData.FightZPrevAuthorizeMeleeAction = nil
        modData.FightZPrevAuthorizedHandToHandAction = nil
        modData.FightZPrevAuthorizedHandToHand = nil
        modData.FightZShoveGuardActive = nil
    end
end

function holdVanillaAfterFightZAction(player)
    restoreVanillaBareHandAttack(player)
end

clearVanillaAttackSuppression = function(player)
    local modData = safeCall(player, "getModData")
    if modData then
        modData.FightZSuppressVanillaAttackUntilMs = nil
    end
    if modData and (modData.FightZShoveGuardActive or modData.FightZSavedMeleeAuthorization == true) then
        restoreVanillaBareHandAttack(player)
    end
end

local function updateControlledStaggers()
    local now = getNowMs()
    for zombie, untilMs in pairs(CONTROLLED_STAGGERS) do
        if not zombie or untilMs <= now or safeCall(zombie, "isDead") == true then
            if zombie and zombie.setStaggerBack then
                pcall(function()
                    zombie:setStaggerBack(false)
                end)
            end
            CONTROLLED_STAGGERS[zombie] = nil
        end
    end
end

local function canTryMousePunch(player)
    if not player then
        return false
    end
    if not isAiming(player) then
        return false
    end
    if not FightZ.hasFightZStyle or not FightZ.hasFightZStyle(player) then
        return false
    end
    if not FightZ.hasEmptyHandsForFightZ or not FightZ.hasEmptyHandsForFightZ(player) then
        return false
    end
    return true
end

local function getMousePunchBlockReason(player, hasTarget)
    if FightZ.ENABLE_MOUSE_PUNCH == false then
        return "disabled"
    end
    return getManualPunchBlockReason(player, true, false, false)
end

local function setFightZMousePunchVariables(player, punchEnabled, floorEnabled, animIndex, critical)
    if not player or not player.setVariable then
        return
    end

    player:setVariable("FightZMousePunch", punchEnabled == true)
    player:setVariable("FightZMouseFloorPunch", floorEnabled == true)
    player:setVariable("FightZMousePunchCritical", punchEnabled == true and critical == true and floorEnabled ~= true)
    player:setVariable("FightZMousePunchImpact", false)
    if punchEnabled == true and animIndex then
        player:setVariable("FightZMousePunchAnim", tostring(animIndex))
    elseif player.clearVariable then
        player:clearVariable("FightZMousePunchAnim")
    end
    if punchEnabled == true then
        local tier, speed = getPunchSpeedTier(player)
        player:setVariable("FightZPunchSpeedTier", tier)
        player:setVariable("FightZPunchAnimSpeed", tostring(speed * 0.90))
        player:setVariable("FightZFloorPunchAnimSpeed", tostring(speed))
    end
    if punchEnabled ~= true and player.clearVariable then
        player:clearVariable("FightZMousePunchAnim")
        player:clearVariable("FightZMousePunchImpact")
        player:clearVariable("FightZMousePunchCritical")
        player:clearVariable("FightZPunchSpeedTier")
        player:clearVariable("FightZPunchAnimSpeed")
        player:clearVariable("FightZFloorPunchAnimSpeed")
    end
end

local function sendPunchAnimationToServer(player, critical, floorAttack, animIndex)
    if not player
        or not (isClient and isClient())
        or not sendClientCommand then
        return
    end

    local tier, speed = getPunchSpeedTier(player)
    local durationMs = getScaledPunchMs(player, FightZ.MANUAL_PUNCH_ACTION_FAILSAFE_MS or 1200)
    pcall(function()
        sendClientCommand(player, "FightZ", "PunchAnimation", {
            critical = critical == true,
            floorAttack = floorAttack == true,
            animIndex = math.max(1, math.min(3, math.floor(toNumber(animIndex, 1)))),
            speedTier = tostring(tier or "normal"),
            punchSpeed = math.max(0.30, math.min(1.20, toNumber(speed, 1.0) * 0.90)),
            floorSpeed = math.max(0.30, math.min(1.20, toNumber(speed, 1.0))),
            durationMs = math.max(300, math.min(2000, durationMs)),
        })
    end)
end

local function clearRemotePunchVariables(player)
    if not player or not player.setVariable then
        return
    end

    player:setVariable("FightZMousePunch", false)
    player:setVariable("FightZMouseFloorPunch", false)
    player:setVariable("FightZMousePunchCritical", false)
    player:setVariable("FightZMousePunchImpact", false)
    if player.clearVariable then
        player:clearVariable("FightZMousePunchAnim")
        player:clearVariable("FightZPunchSpeedTier")
        player:clearVariable("FightZPunchAnimSpeed")
        player:clearVariable("FightZFloorPunchAnimSpeed")
    end
end

local function isLocalPlayerObject(player)
    if not player then
        return false
    end
    if player.isLocalPlayer then
        local ok, value = pcall(player.isLocalPlayer, player)
        if ok then
            return value == true
        end
    end
    if getNumActivePlayers and getSpecificPlayer then
        for playerIndex = 0, getNumActivePlayers() - 1 do
            if getSpecificPlayer(playerIndex) == player then
                return true
            end
        end
    end
    return false
end

local function applyRemotePunchVariables(player, state)
    if not player or not state or not player.setVariable then
        return false
    end

    local floorAttack = state.floorAttack == true
    player:setVariable("FightZMousePunch", true)
    player:setVariable("FightZMouseFloorPunch", floorAttack)
    player:setVariable("FightZMousePunchCritical", state.critical == true and not floorAttack)
    player:setVariable("FightZMousePunchImpact", false)
    if floorAttack then
        if player.clearVariable then
            player:clearVariable("FightZMousePunchAnim")
        end
    else
        player:setVariable("FightZMousePunchAnim", tostring(state.animIndex))
    end
    player:setVariable("FightZPunchSpeedTier", state.speedTier)
    player:setVariable("FightZPunchAnimSpeed", tostring(state.punchSpeed))
    player:setVariable("FightZFloorPunchAnimSpeed", tostring(state.floorSpeed))
    return true
end

local function queueRemotePunchAnimation(args)
    if type(args) ~= "table" or type(getPlayerByOnlineID) ~= "function" then
        return
    end

    local onlineID = math.floor(toNumber(args.playerOnlineID, -1))
    if onlineID < 0 then
        return
    end
    local ok, player = pcall(getPlayerByOnlineID, onlineID)
    if not ok or not player or isLocalPlayerObject(player) then
        return
    end

    local sequence = math.floor(toNumber(args.sequence, 0))
    local previous = REMOTE_PUNCH_ANIMATIONS[player]
    if previous and sequence > 0 and sequence <= toNumber(previous.sequence, 0) then
        return
    end

    clearRemotePunchVariables(player)
    REMOTE_PUNCH_ANIMATIONS[player] = {
        sequence = sequence,
        critical = args.critical == true,
        floorAttack = args.floorAttack == true,
        animIndex = math.max(1, math.min(3, math.floor(toNumber(args.animIndex, 1)))),
        speedTier = tostring(args.speedTier or "normal"),
        punchSpeed = math.max(0.30, math.min(1.20, toNumber(args.punchSpeed, 0.90))),
        floorSpeed = math.max(0.30, math.min(1.20, toNumber(args.floorSpeed, 1.0))),
        durationMs = math.max(300, math.min(2000, toNumber(args.durationMs, 1200))),
        startsAtMs = getNowMs() + 30,
        started = false,
    }
end

local function updateRemotePunchAnimations()
    local now = getNowMs()
    for player, state in pairs(REMOTE_PUNCH_ANIMATIONS) do
        if not player or safeCall(player, "isDead") == true then
            if player then
                clearRemotePunchVariables(player)
            end
            REMOTE_PUNCH_ANIMATIONS[player] = nil
        elseif state.started ~= true and now >= state.startsAtMs then
            state.started = applyRemotePunchVariables(player, state)
            state.expiresAtMs = now + state.durationMs
        elseif state.started == true then
            if now >= toNumber(state.expiresAtMs, now) then
                clearRemotePunchVariables(player)
                REMOTE_PUNCH_ANIMATIONS[player] = nil
            else
                -- Remote-player network updates may restore vanilla shove
                -- variables. Reassert FightZ's animation selector until this
                -- punch has finished without restarting the animation node.
                applyRemotePunchVariables(player, state)
            end
        end
    end
end

local function onFightZServerCommand(module, command, args)
    if module == "FightZ" and command == "PunchAnimation" then
        queueRemotePunchAnimation(args)
    end
end

local function clearMousePunchState(player)
    local modData = safeCall(player, "getModData")
    if modData then
        modData.FightZMousePunchUntilMs = nil
        modData.FightZMouseAnimUntilMs = nil
        modData.FightZMouseFloorPunch = nil
        modData.FightZMousePunchCritical = nil
    end
    setFightZMousePunchVariables(player, false, false)
    PENDING_MOUSE_PUNCHES[player] = nil
end

local function setPendingMousePunch(player, target, critical, floorAttack, animIndex)
    if not player then
        return false
    end

    setFightZMousePunchVariables(player, true, floorAttack == true, animIndex, critical == true)
    sendPunchAnimationToServer(player, critical, floorAttack, animIndex)
    local now = getNowMs()
    local failsafeMs = getScaledPunchMs(player, FightZ.MANUAL_PUNCH_ACTION_FAILSAFE_MS or 1200)
    local modData = safeCall(player, "getModData")
    if modData then
        modData.FightZMouseAnimUntilMs = now + failsafeMs
    end
    PENDING_MOUSE_PUNCHES[player] = {
        target = target,
        critical = critical == true,
        floorAttack = floorAttack == true,
        expiresAtMs = now + failsafeMs,
    }
    return true
end

local function updatePendingMousePunch(player)
    local pending = player and PENDING_MOUSE_PUNCHES[player] or nil
    if not pending then
        return
    end

    local now = getNowMs()
    if now > pending.expiresAtMs
        or (pending.target and pending.target.isDead and pending.target:isDead()) then
        debugMouse(player, "mouse impact expired: animation-not-fired")
        clearMousePunchState(player)
        return
    end

    if not getVariableBoolean(player, "FightZMousePunchImpact") then
        return
    end

    if player.clearVariable then
        player:clearVariable("FightZMousePunchImpact")
    end
    local hitApplied = false
    if pending.target
        and canApplyFightZImpact(player, pending.target, pending.floorAttack, pending.critical, true) then
        applyConfirmedFightZImpact(player, pending.target, pending.critical, pending.floorAttack)
        hitApplied = true
    else
        playPunchMissSound(player)
        debugMouse(player, pending.target and "mouse impact missed: target-out-of-range" or "mouse impact missed")
    end
    PENDING_MOUSE_PUNCHES[player] = nil
    if hitApplied then
        debugMouse(player, "mouse impact applied")
    end
end

local function updateMousePunchAnimationState(player)
    if PENDING_MOUSE_PUNCHES[player] then
        return
    end

    local modData = safeCall(player, "getModData")
    local untilMs = modData and toNumber(modData.FightZMouseAnimUntilMs, 0) or 0
    if untilMs <= 0 then
        return
    end
    if untilMs > getNowMs() then
        return
    end

    clearMousePunchState(player)
end

local function doManualPunch(player, allowAttackState, allowQueuedAction, allowFloorTargets, allowMissAttack, targetOverride, floorAttackOverride, allowNativeMeleeDelay, waitForAnimImpact)
    if not canManualPunch(player, allowAttackState, allowQueuedAction, allowNativeMeleeDelay) then
        return false
    end

    local target = targetOverride
    local floorAttack = floorAttackOverride == true
    if not target then
        target, floorAttack = findPunchTarget(player, allowFloorTargets)
    end
    if not target and floorAttack ~= true then
        target = findPunchableDoorTarget(player)
    end
    if not target and allowMissAttack ~= true then
        return false
    end

    local critical = target and FightZ.rollCriticalPunch and FightZ.rollCriticalPunch(player) or false
    local anim, actionName, animIndex = getNextPunchSelection(player, critical)
    if floorAttack then
        anim = "Bob_AttackFloor1Hand"
        actionName = FLOOR_ACTION
        animIndex = nil
    end
    setCooldown(player)

    if waitForAnimImpact == true then
        return setPendingMousePunch(player, target, critical, floorAttack, animIndex)
    end

    if FightZ.ENABLE_MOUSE_TIMED_ACTION == true
        and FightZ.ENABLE_MANUAL_PUNCH_ANIMATIONS == true
        and ISTimedActionQueue
        and FightZManualPunchAction then
        local action = FightZManualPunchAction:new(player, target, critical, actionName, floorAttack)
        local ok, err = pcall(function()
            return ISTimedActionQueue.add(action)
        end)
        if ok then
            return true
        end
        print("[FightZ] timed action failed, using direct punch fallback: " .. tostring(err))
        clearQueuedFightZAttack(player)
    end

    playPunchFallback(player, anim)
    if not target then
        playPunchMissSound(player)
        return true
    end
    applyConfirmedFightZImpact(player, target, critical, floorAttack)
    return true
end

isAttackClickDown = function()
    if Mouse and Mouse.isButtonDown then
        local ok, pressed = pcall(function()
            return Mouse.isButtonDown(0)
        end)
        if ok and pressed ~= nil then
            return pressed == true
        end
    end

    if isMouseButtonDown then
        local ok, pressed = pcall(function()
            return isMouseButtonDown(0)
        end)
        if ok and pressed ~= nil then
            return pressed == true
        end
    end

    return false
end

local function tryMousePunch(player, source)
    if isMeleeInputDown and isMeleeInputDown(player) then
        debugInput(player, tostring(source or "mouse") .. " blockReason=melee-key-down | " .. getPlayerDebugSummary(player))
        debugMouse(player, tostring(source or "mouse") .. " blocked: melee-key")
        return false
    end

    local reason = getMousePunchBlockReason(player, false)
    if reason then
        debugInput(player, tostring(source or "mouse") .. " blockReason=" .. tostring(reason) .. " | " .. getPlayerDebugSummary(player))
        debugMouse(player, tostring(source or "mouse") .. " blocked: " .. reason)
        return false
    end

    local target = findMousePunchTarget(player)
    local floorAttack = false
    if not target then
        target = findMouseFloorPunchTarget(player)
        floorAttack = target ~= nil
    end
    if not target then
        target, floorAttack = findPunchTarget(player, true)
    end
    if not target then
        target = findPunchableDoorTarget(player)
        floorAttack = false
    end
    debugInput(player, tostring(source or "mouse") .. " selected: "
        .. describeTargetForDebug(floorAttack and "selectedFloor" or "selectedStand", player, target))

    if not target then
        if doManualPunch(player, true, false, false, true, nil, false, false, true) then
            debugInput(player, tostring(source or "mouse") .. " result=miss queued | " .. getPlayerDebugSummary(player))
            debugMouse(player, tostring(source or "mouse") .. " queued miss-punch")
            return true
        end

        debugInput(player, tostring(source or "mouse") .. " result=no-target | " .. getPlayerDebugSummary(player))
        debugMouse(player, tostring(source or "mouse") .. " no target")
        return false
    end

    if doManualPunch(player, true, false, floorAttack, false, target, floorAttack, false, true) then
        debugInput(player, tostring(source or "mouse") .. " result=" .. (floorAttack and "floor-punch" or "punch") .. " queued | " .. getPlayerDebugSummary(player))
        debugMouse(player, tostring(source or "mouse") .. (floorAttack and " queued floor-punch" or " queued punch"))
        return true
    end

    debugInput(player, tostring(source or "mouse") .. " result=manual-punch-failed | " .. getPlayerDebugSummary(player))
    debugMouse(player, tostring(source or "mouse") .. " blocked: manual-punch-failed")
    return false
end

local function updateHeldMousePunch(player)
    if FightZ.ENABLE_MOUSE_HELD_PUNCH ~= true then
        return
    end
    if isAttackClickDown() ~= true then
        return
    end
    if isMeleeInputDown and isMeleeInputDown(player) then
        return
    end
    if not canTryMousePunch(player) then
        return
    end

    local target = findMousePunchTarget(player)
    if not target then
        target = findMouseFloorPunchTarget(player)
    end
    if not target then
        return
    end

    tryMousePunch(player, "mouse-held")
end

local function updateJoypadPunch(player)
    if FightZ.ENABLE_JOYPAD_PUNCH == false or not player then
        return
    end

    local joypadId = getPlayerJoypadId(player)
    if joypadId == nil then
        return
    end

    local modData = safeCall(player, "getModData")
    local attackDown = isJoypadAttackInputDown and isJoypadAttackInputDown(player) == true
    local wasAttackDown = modData and modData.FightZJoypadAttackDown == true
    if modData then
        modData.FightZJoypadAttackDown = attackDown == true or nil
    end

    if attackDown ~= true then
        return
    end
    if wasAttackDown and FightZ.ENABLE_JOYPAD_HELD_PUNCH ~= true then
        return
    end
    if isMeleeInputDown and isMeleeInputDown(player) then
        debugInput(player, "joypad-attack blockReason=melee-key-down | " .. getPlayerDebugSummary(player), "FightZNextJoypadDebugMs", FightZ.DEBUG_INPUT_INTERVAL_MS)
        debugMouse(player, "joypad-attack blocked: melee-key")
        return
    end
    if not canTryMousePunch(player) then
        return
    end

    debugInput(player, "joypad-attack input: joypad=" .. tostring(joypadId) .. " " .. getPlayerDebugSummary(player) .. " | " .. buildTargetDebugSummary(player))
    local handled = tryMousePunch(player, wasAttackDown and "joypad-held" or "joypad-attack")
    debugInput(player, "joypad-attack handled=" .. boolText(handled) .. " | " .. getPlayerDebugSummary(player))
end

local function isMeleeKey(key)
    if getCore and getCore() and getCore().isKey then
        local ok, pressed = pcall(function()
            return getCore():isKey("Melee", key)
        end)
        if ok and pressed == true then
            return true
        end
    end
    return Keyboard and Keyboard.KEY_SPACE and key == Keyboard.KEY_SPACE
end

local function getVanillaMeleeDebug(player)
    return "vanillaActionDetected=" .. boolText(
        safeCall(player, "isAttacking") == true
        or safeCall(player, "isDoShove") == true
        or hasQueuedAction(player) == true
    )
end

local function markSpaceDebugCheck(player, source)
    local modData = safeCall(player, "getModData")
    if modData then
        local now = getNowMs()
        modData.FightZDebugSpaceAfterUntilMs = now + (FightZ.DEBUG_INPUT_AFTER_MS or 900)
        modData.FightZDebugNextSpaceAfterMs = now
    end
    debugInput(player, tostring(source or "space") .. ": " .. getVanillaMeleeDebug(player) .. " | " .. getPlayerDebugSummary(player) .. " | " .. buildTargetDebugSummary(player))
end

local function onKeyPressed(key)
    if FightZ.DEBUG_INPUT ~= true or not getSpecificPlayer or not isMeleeKey(key) then
        return
    end

    markSpaceDebugCheck(getSpecificPlayer(0), "space-pressed")
end

local function onKeyKeepPressed(key)
    if FightZ.DEBUG_INPUT ~= true or not getSpecificPlayer or not isMeleeKey(key) then
        return
    end

    local player = getSpecificPlayer(0)
    local modData = safeCall(player, "getModData")
    if modData then
        modData.FightZDebugSpaceAfterUntilMs = getNowMs() + (FightZ.DEBUG_INPUT_AFTER_MS or 900)
    end
    debugInput(player, "space-held tick: " .. getVanillaMeleeDebug(player) .. " | " .. getPlayerDebugSummary(player) .. " | " .. buildTargetDebugSummary(player), "FightZNextSpaceHeldDebugMs", FightZ.DEBUG_INPUT_INTERVAL_MS)
end

local function onTickDebug()
    if FightZ.DEBUG_INPUT ~= true or not getSpecificPlayer then
        return
    end

    local player = getSpecificPlayer(0)
    local modData = safeCall(player, "getModData")
    if not modData then
        return
    end

    local now = getNowMs()
    local untilMs = toNumber(modData.FightZDebugSpaceAfterUntilMs, 0)
    if untilMs < now then
        modData.FightZDebugSpaceAfterUntilMs = nil
        modData.FightZDebugNextSpaceAfterMs = nil
        return
    end

    local nextMs = toNumber(modData.FightZDebugNextSpaceAfterMs, 0)
    if nextMs > now then
        return
    end

    modData.FightZDebugNextSpaceAfterMs = now + (FightZ.DEBUG_INPUT_INTERVAL_MS or 250)
    debugInput(player, "space-after: " .. getVanillaMeleeDebug(player) .. " | " .. getPlayerDebugSummary(player) .. " | " .. buildTargetDebugSummary(player))
end

local function onMouseDown(_x, _y)
    if FightZ.ENABLE_MOUSE_PUNCH == false or not getSpecificPlayer then
        return
    end

    if isAttackClickDown() ~= true then
        return
    end

    local player = getSpecificPlayer(0)
    if isMouseOverUi() then
        return
    end
    if isMeleeInputDown and isMeleeInputDown(player) then
        return
    end
    if getMousePunchBlockReason(player, false) then
        return
    end

    debugInput(player, "mouse-down input: " .. getPlayerDebugSummary(player) .. " | " .. buildTargetDebugSummary(player))
    local handled = tryMousePunch(player, "mouse-down")
    debugInput(player, "mouse-down handled=" .. boolText(handled) .. " | " .. getPlayerDebugSummary(player))
end

local function onPlayerUpdate(player)
    if player then
        updateControlledStaggers()
        updatePendingMousePunch(player)
        updateMousePunchAnimationState(player)
        updateHeldMousePunch(player)
        updateJoypadPunch(player)
    end
end

if Events and Events.OnMouseDown then
    Events.OnMouseDown.Add(onMouseDown)
end

if Events and Events.OnPlayerUpdate then
    Events.OnPlayerUpdate.Add(onPlayerUpdate)
end

if Events and Events.OnServerCommand then
    Events.OnServerCommand.Add(onFightZServerCommand)
end

if Events and Events.OnKeyPressed then
    Events.OnKeyPressed.Add(onKeyPressed)
end

if Events and Events.OnKeyKeepPressed then
    Events.OnKeyKeepPressed.Add(onKeyKeepPressed)
end

if Events and Events.OnTick then
    Events.OnTick.Add(updateRemotePunchAnimations)
    Events.OnTick.Add(onTickDebug)
end

-- FightZ intentionally does not install a global attack hook. The mouse path
-- stays outside vanilla timed actions while this direct-combat layer is active.
