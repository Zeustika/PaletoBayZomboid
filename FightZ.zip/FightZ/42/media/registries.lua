if CharacterTrait and CharacterTrait.register then
    FightZ = FightZ or {}
    FightZ.TRAIT_OBJECTS = FightZ.TRAIT_OBJECTS or {}

    FightZ.TRAIT_OBJECTS["fightz:fistiniciate"] = CharacterTrait.register("fightz:fistiniciate")
    FightZ.TRAIT_OBJECTS["fightz:fistfighter"] = CharacterTrait.register("fightz:fistfighter")
    FightZ.TRAIT_OBJECTS["fightz:fistamateur"] = CharacterTrait.register("fightz:fistamateur")
end
